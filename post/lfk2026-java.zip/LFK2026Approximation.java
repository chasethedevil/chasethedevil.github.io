public final class LFK2026Approximation implements BachelierApproximation {
    public static final LFK2026Approximation INSTANCE = new LFK2026Approximation();

    private static final double ALPHA = 0.15;
    private static final double OTM_FIRST_SPLIT = 0.011;
    private static final double OTM_SECOND_SPLIT = 0.105;
    private static final double BETA_S = -Math.log(ALPHA);
    private static final double INV_BETA_RANGE = 1.0 / (BachelierMath.BETA_E - BETA_S);

    @Override
    public String name() {
        return "LFK2026";
    }

    @Override
    public double impliedVol(double forward, double strike, double callPrice, double timeToExpiry) {
        return impliedVolatility(forward, strike, callPrice, timeToExpiry);
    }

    public static double impliedVolatility(double forward, double strike,
                                           double callPrice, double timeToExpiry) {
        double x = forward - strike;
        double sqrtT = Math.sqrt(timeToExpiry);
        double cotm;
        double mx;
        if (x > 0.0) {
            cotm = callPrice - x;
            mx = x;
        } else if (x < 0.0) {
            cotm = callPrice;
            mx = -x;
        } else {
            return callPrice / sqrtT * BachelierMath.SQRT_2PI;
        }
        double negG = cotm / mx;
        if (negG > ALPHA) {
            double citm = cotm + mx;
            double u = mx / cotm;
            return citm / sqrtT * evalItm(u);
        }
        if (negG < 1e-300) return 0.0;
        double etaTilde = -(Math.log(negG) + BETA_S) * INV_BETA_RANGE;
        double invAbsD;
        if (etaTilde < OTM_FIRST_SPLIT) {
            invAbsD = evalOtm1(etaTilde);
        } else if (etaTilde < OTM_SECOND_SPLIT) {
            invAbsD = evalOtm2(etaTilde);
        } else {
            invAbsD = evalOtm3(etaTilde);
        }
        return mx * invAbsD / sqrtT;
    }

    private static double evalItm(double u) {
        double p = -3.39451638335349906e-10;
        p = p * u + 8.06959950534549627e-07;
        p = p * u + 1.17427118047196583e-04;
        p = p * u + 4.67776338554095131e-03;
        p = p * u + 7.81257091685455263e-02;
        p = p * u + 6.51812439800918964e-01;
        p = p * u + 2.96457253391146036e+00;
        p = p * u + 7.62695942399991100e+00;
        p = p * u + 1.10083895644891214e+01;
        p = p * u + 8.26914966237441540e+00;
        p = p * u + 2.50662827463100069e+00;
        double q = 1.76070970713414280e-06;
        q = q * u + 1.90358881940080979e-04;
        q = q * u + 6.05262799121958784e-03;
        q = q * u + 8.27294623127229206e-02;
        q = q * u + 5.72905243689549204e-01;
        q = q * u + 2.18581925252758946e+00;
        q = q * u + 4.76157470081986212e+00;
        q = q * u + 5.87074621959482457e+00;
        q = q * u + 3.79891342328838499e+00;
        q = q * u + 1.00000000000000000e+00;
        return p / q;
    }

    private static double evalOtm1(double eta) {
        double p = -1.15188057059215700e+16;
        p = p * eta + 2.23602102096865640e+16;
        p = p * eta + 1.35683441709766740e+16;
        p = p * eta + 1.32385751716178975e+15;
        p = p * eta + 4.61473754119971406e+13;
        p = p * eta + 8.14953597568851318e+11;
        p = p * eta + 8.81948242946073532e+09;
        p = p * eta + 6.20616261157058701e+07;
        p = p * eta + 2.89118707775471907e+05;
        p = p * eta + 8.30013684602045146e+02;
        p = p * eta + 1.24910559446641112e+00;
        double q = 9.01018167981477888e+17;
        q = q * eta + 1.78457095251951296e+17;
        q = q * eta + 9.31612904921204000e+15;
        q = q * eta + 2.08194332615256938e+14;
        q = q * eta + 2.66113331187980811e+12;
        q = q * eta + 2.18139815883858109e+10;
        q = q * eta + 1.19319078802154481e+08;
        q = q * eta + 4.30671117130989209e+05;
        q = q * eta + 9.50178311644246946e+02;
        q = q * eta + 1.00000000000000000e+00;
        return p / q;
    }

    private static double evalOtm2(double eta) {
        double p = 4.53512764886659485e+11;
        p = p * eta - 3.54669640321780615e+12;
        p = p * eta - 1.07736581582367109e+13;
        p = p * eta - 5.46607883881420703e+12;
        p = p * eta - 8.98414557472468994e+11;
        p = p * eta - 5.70761754440745773e+10;
        p = p * eta - 1.43888265763526964e+09;
        p = p * eta - 1.28046460022976995e+07;
        p = p * eta - 1.74963499510044603e+04;
        p = p * eta + 2.09344504116440078e+02;
        p = p * eta + 1.25087969033276813e+00;
        double q = -3.16204789033010312e+14;
        q = q * eta - 3.32157260465782750e+14;
        q = q * eta - 9.10822517732905625e+13;
        q = q * eta - 8.93831987833861328e+12;
        q = q * eta - 3.39232384615881042e+11;
        q = q * eta - 4.63359666129231930e+09;
        q = q * eta - 1.48653150107890852e+07;
        q = q * eta + 4.19868074702521844e+04;
        q = q * eta + 4.55619235679538008e+02;
        q = q * eta + 1.00000000000000000e+00;
        return p / q;
    }

    private static double evalOtm3(double eta) {
        double p = 4.62144628906322019e+00;
        p = p * eta - 1.25257952774401772e+02;
        p = p * eta + 5.74901275345015438e+03;
        p = p * eta + 9.82243936325080576e+04;
        p = p * eta + 3.38490556724923430e+05;
        p = p * eta + 4.14000232322855853e+05;
        p = p * eta + 2.11536138072810922e+05;
        p = p * eta + 4.73452995425928821e+04;
        p = p * eta + 4.52092618390189637e+03;
        p = p * eta + 1.63839367097254751e+02;
        p = p * eta + 1.61713874667576762e+00;
        double q = 5.54442814599942540e+03;
        q = q * eta + 1.16810498733679834e+06;
        q = q * eta + 7.83292053799574263e+06;
        q = q * eta + 1.55296990844987314e+07;
        q = q * eta + 1.20766363495907933e+07;
        q = q * eta + 4.03973802769196732e+06;
        q = q * eta + 5.83977840443553636e+05;
        q = q * eta + 3.37041720211591382e+04;
        q = q * eta + 6.08432004257079598e+02;
        q = q * eta + 1.00000000000000000e+00;
        return p / q;
    }
}