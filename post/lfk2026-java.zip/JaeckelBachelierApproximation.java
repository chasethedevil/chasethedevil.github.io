// Adapted for local comparison from Peter Jaeckel's ImpliedNormalVolatility.cpp.
// Original source notice: Copyright (C) 2022 Peter Jaeckel. Permission to use,
// copy, modify, and distribute that software is freely granted, provided that
// the notice is preserved. The software is provided "as is" without warranty.

public final class JaeckelBachelierApproximation implements BachelierApproximation {
	public static final JaeckelBachelierApproximation INSTANCE = new JaeckelBachelierApproximation();

	private static final double PHI0 = BachelierMath.INV_SQRT_2PI;

	@Override
	public String name() {
		return "Jaeckel2017";
	}

	@Override
	public double impliedVol(double forward, double strike, double callPrice, double timeToExpiry) {
		return impliedVolatility(forward, strike, callPrice, timeToExpiry);
	}

	public static double impliedVolatility(double forward, double strike,
			double callPrice, double timeToExpiry) {
		double x = forward - strike;
		double sqrtT = Math.sqrt(timeToExpiry);
		if (closeMoneyness(strike, forward)) {
			return callPrice / (sqrtT * PHI0);
		}

		double timeValue = callPrice - Math.max(x, 0.0);
		if (timeValue == 0.0)
			return 0.0;
		if (!(timeValue > 0.0))
			return Double.NaN;

		double phiTildeStar = -Math.abs(timeValue / (strike - forward));
		double xstar = inversePhiTilde(phiTildeStar);
		return Math.abs((strike - forward) / (xstar * sqrtT));
	}

	private static double inversePhiTilde(double phiTildeStar) {
		if (phiTildeStar > 1.0) {
			return -inversePhiTilde(1.0 - phiTildeStar);
		}
		if (phiTildeStar >= 0.0) {
			return Double.NaN;
		}

		double xbar;
		if (phiTildeStar < -0.00188203927) {
			double g = 1.0 / (phiTildeStar - 0.5);
			double g2 = g * g;
			double xibar = (0.032114372355
					- g2 * (0.016969777977
							- g2 * (0.002620733246 - 0.000096066952861 * g2)))
					/ (1.0
							- g2 * (0.6635646938
									- g2 * (0.14528712196 - 0.010472855461 * g2)));
			xbar = g * (BachelierMath.INV_SQRT_2PI + xibar * g2);
		} else {
			double h = Math.sqrt(-Math.log(-phiTildeStar));
			xbar = (9.4883409779
					- h * (9.6320903635
							- h * (0.58556997323 + 2.1464093351 * h)))
					/ (1.0
							- h * (0.65174820867
									+ h * (1.5120247828 + 0.000066437847132 * h)));
		}

		double q = (phiTilde(xbar) - phiTildeStar) / phi(xbar);
		double xbar2 = xbar * xbar;
		return xbar + 3.0 * q * xbar2 * (2.0 - q * xbar * (2.0 + xbar2))
				/ (6.0 + q * xbar * (-12.0 + xbar * (6.0 * q
						+ xbar * (-6.0 + q * xbar * (3.0 + xbar2)))));
	}

	private static double phiTilde(double x) {
		return phiTildeTimesX(x) / x;
	}

	static double phiTildeTimesX(double x) {
		double absX = Math.abs(x);
		if (absX <= 0.61200318096248076056) {
			double h = (x * x - 1.8727394675409748661e-1) * 5.3397710537550806412;
			double numerator = 1.9641549843774702457e-1
					+ h * (2.9444812226268915305e-3 + 3.095828855856470717e-5 * h);
			double denominator = 1.0
					+ h * (3.0261016846592326803e-2
							+ h * (3.3735461911896198861e-4
									+ h * (1.290112376540573289e-6 - 1.6711975835244204502e-9 * h)));
			double g = numerator / denominator;
			return BachelierMath.INV_SQRT_2PI + x * (0.5 + x * g);
		}

		if (x > 0.0) {
			return phiTildeTimesX(-x) + x;
		}

		if (x >= -3.5) {
			double numerator = 3.9894228040096173296e-1
					+ x * (-2.8827250122716400843e-1
							+ x * (1.1748934770055073669e-1
									+ x * (-2.9208930498324232842e-2
											+ x * (4.6704817087348921557e-3
													+ x * (-4.4448405482476358857e-4
															+ x * (1.9865267442385935787e-5
																	+ x * (7.6387393474143610035e-10
																			+ 1.3291525220137582449e-11 * x)))))));
			double denominator = 1.0
					+ x * (-1.9759061396728604494
							+ x * (1.7709332198933623888
									+ x * (-9.4350250026446231963e-1
											+ x * (3.2816118145388593816e-1
													+ x * (-7.6697408088214742324e-2
															+ x * (1.1843224303096222834e-2
																	+ x * (-1.1151416365524860908e-3
																			+ 4.9741005333758689307e-5 * x)))))));
			return Math.exp(-0.5 * x * x) * numerator / denominator;
		}

		double w = 1.0 / (x * x);
		double numerator = 2.999999999999991221
				+ w * (2.3654556627823149931e2
						+ w * (6.8126773449358787324e3
								+ w * (8.9697941598360784061e4
										+ w * (5.5163920591268613879e5
												+ w * (1.4345061123335662019e6
														+ w * (1.1504988246344881836e6
																+ 1.1867600400997691371e4 * w))))));
		double denominator = 1.0
				+ w * (8.3848522092737134602e1
						+ w * (2.6551350587809577877e3
								+ w * (4.0555290884673789153e4
										+ w * (3.166737476299376429e5
												+ w * (1.2329795958024320559e6
														+ w * (2.1409810540619049948e6
																+ 1.2145667804093160403e6 * w))))));
		double g = numerator / denominator;
		return BachelierMath.INV_SQRT_2PI * Math.exp(-0.5 * x * x) * w * (1.0 - g * w);
	}

	private static double phi(double x) {
		return Math.exp(-0.5 * x * x) * BachelierMath.INV_SQRT_2PI;
	}

	private static boolean closeMoneyness(double x, double y) {
		if (x == y)
			return true;
		return Math.abs(x - y) <= Double.MIN_NORMAL;
	}
}
