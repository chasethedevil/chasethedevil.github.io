public final class LFK2026DApproximation implements BachelierApproximation {
    public static final LFK2026DApproximation INSTANCE = new LFK2026DApproximation();

    private static final double ALPHA = 0.15;
    private static final double OTM_FIRST_SPLIT = 1.45000000000000007e-02;
    private static final double OTM_SECOND_SPLIT = 1.17800000000000002e-01;
    private static final double BETA_S = -Math.log(ALPHA);
    private static final double INV_BETA_RANGE = 1.0 / (BachelierMath.BETA_E - BETA_S);

    @Override
    public String name() {
        return "LFK2026D";
    }

    @Override
    public double impliedVol(double forward, double strike, double callPrice, double timeToExpiry) {
        return impliedVolatility(forward, strike, callPrice, timeToExpiry);
    }

    public static double impliedVolatility(double forward, double strike,
            double callPrice, double timeToExpiry) {
        double x = forward - strike;
        double sqrtT = Math.sqrt(timeToExpiry);
        double cotm;
        double mx;
        if (x > 0.0) {
            cotm = callPrice - x;
            mx = x;
        } else if (x < 0.0) {
            cotm = callPrice;
            mx = -x;
        } else {
            return callPrice / sqrtT * BachelierMath.SQRT_2PI;
        }
        double negG = cotm / mx;
        if (negG > ALPHA) {
            double citm = cotm + mx;
            double u = mx / cotm;
            return citm / sqrtT * evalItm(u);
        }
        if (negG < 1e-300)
            return 0.0;
        double etaTilde = -(Math.log(negG) + BETA_S) * INV_BETA_RANGE;
        double invAbsD;
        if (etaTilde < OTM_FIRST_SPLIT) {
            invAbsD = evalOtm1(etaTilde);
        } else if (etaTilde < OTM_SECOND_SPLIT) {
            invAbsD = evalOtm2(etaTilde);
        } else {
            invAbsD = evalOtm3(etaTilde);
        }
        return mx * invAbsD / sqrtT;
    }

    private static double evalItm(double u) {
        double p = -3.39451638335349906e-10;
        p = p * u + 8.06959950534549627e-07;
        p = p * u + 1.17427118047196583e-04;
        p = p * u + 4.67776338554095131e-03;
        p = p * u + 7.81257091685455263e-02;
        p = p * u + 6.51812439800918964e-01;
        p = p * u + 2.96457253391146036e+00;
        p = p * u + 7.62695942399991100e+00;
        p = p * u + 1.10083895644891214e+01;
        p = p * u + 8.26914966237441540e+00;
        p = p * u + 2.50662827463100069e+00;
        double q = 1.76070970713414280e-06;
        q = q * u + 1.90358881940080979e-04;
        q = q * u + 6.05262799121958784e-03;
        q = q * u + 8.27294623127229206e-02;
        q = q * u + 5.72905243689549204e-01;
        q = q * u + 2.18581925252758946e+00;
        q = q * u + 4.76157470081986212e+00;
        q = q * u + 5.87074621959482457e+00;
        q = q * u + 3.79891342328838499e+00;
        q = q * u + 1.00000000000000000e+00;
        return p / q;
    }

    private static double evalOtm1(double eta) {
        double p = -2.96291760969892680e+16;
        p = p * eta + 3.63093569588198400e+16;
        p = p * eta + 1.78880731995660620e+16;
        p = p * eta + 1.57119179781390850e+15;
        p = p * eta + 5.19998272533330938e+13;
        p = p * eta + 8.92378101657744629e+11;
        p = p * eta + 9.45245193184535408e+09;
        p = p * eta + 6.53920879898315892e+07;
        p = p * eta + 2.99702508527653001e+05;
        p = p * eta + 8.47619772864081597e+02;
        p = p * eta + 1.24910559446641112e+00;
        double q = 1.29402991182225946e+18;
        q = q * eta + 2.20357803266821088e+17;
        q = q * eta + 1.06746011913009540e+16;
        q = q * eta + 2.30100251568817812e+14;
        q = q * eta + 2.87260538833032178e+12;
        q = q * eta + 2.31235285898333626e+10;
        q = q * eta + 1.24538153134200945e+08;
        q = q * eta + 4.43171035283801029e+05;
        q = q * eta + 9.64273267539114840e+02;
        q = q * eta + 1.00000000000000000e+00;
        return p / q;
    }

    private static double evalOtm2(double eta) {
        double p = 2.83876889443327570e+09;
        p = p * eta - 1.47094092991961823e+10;
        p = p * eta + 6.97512731591760159e+09;
        p = p * eta + 5.89013711536382675e+10;
        p = p * eta + 2.88783135940116310e+10;
        p = p * eta + 4.55199642305969429e+09;
        p = p * eta + 2.88765027905221641e+08;
        p = p * eta + 7.86397585558160208e+06;
        p = p * eta + 9.27513975150481565e+04;
        p = p * eta + 4.91931764982681784e+02;
        p = p * eta + 1.25070935316808463e+00;
        double q = -6.97033196207605225e+11;
        q = q * eta + 1.60734143390380566e+12;
        q = q * eta + 1.79968388446012061e+12;
        q = q * eta + 4.69178670074972595e+11;
        q = q * eta + 4.49113820497479324e+10;
        q = q * eta + 1.76543913139240003e+09;
        q = q * eta + 2.88054137623462491e+07;
        q = q * eta + 1.95271993660958280e+05;
        q = q * eta + 6.81403825183943468e+02;
        q = q * eta + 1.00000000000000000e+00;
        return p / q;
    }

    private static double evalOtm3(double eta) {
        double p = -9.78571143231221896e+00;
        p = p * eta + 9.69726676635529088e+02;
        p = p * eta + 3.82246440507954903e+04;
        p = p * eta + 2.60718058985714306e+05;
        p = p * eta + 6.06698667324509122e+05;
        p = p * eta + 5.91063965520491474e+05;
        p = p * eta + 2.61260745170476090e+05;
        p = p * eta + 5.31817138355287098e+04;
        p = p * eta + 4.77794828200244592e+03;
        p = p * eta + 1.66989132560739989e+02;
        p = p * eta + 1.61982027094435455e+00;
        double q = 3.10428817652220372e+05;
        q = q * eta + 4.32860404065594450e+06;
        q = q * eta + 1.65611815097258985e+07;
        q = q * eta + 2.44793192915989943e+07;
        q = q * eta + 1.58891631710913163e+07;
        q = q * eta + 4.72538757008512411e+06;
        q = q * eta + 6.32535742841342231e+05;
        q = q * eta + 3.47884126130892910e+04;
        q = q * eta + 6.11508302127448815e+02;
        q = q * eta + 1.00000000000000000e+00;
        return p / q;
    }
}