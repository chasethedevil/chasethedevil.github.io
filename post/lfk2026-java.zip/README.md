# Bachelier Normal Implied Volatility - Java LFK2026

This directory contains a flat Java implementation of the LFK2026 Bachelier
normal implied-volatility approximation, plus accuracy and timing harnesses used
for the accompanying paper.

The main entry point is:

```java
double sigma = LFK2026Approximation.impliedVolatility(
        forward, strike, undiscountedCallPrice, timeToExpiry);
```

Inputs are the forward, strike, undiscounted Bachelier call price, and expiry in
years. The return value is the normal/Bachelier volatility in the same absolute
units as the forward per square-root year. For rates quoted as decimals, multiply
by `10000` to express the result as bp vol.

## Files

- `LFK2026Approximation.java`: accuracy-oriented LFK2026 implementation.
- `LFK2026CApproximation.java`: faster variant with the same OTM approximation
  and a split ITM branch.
- `LFK4Approximation.java`: LFK-4 reference implementation.
- `JaeckelBachelierApproximation.java`: local comparison implementation of
  Peter Jaeckel's normal implied-volatility formula.
- `BachelierMath.java`: shared constants and stable Bachelier pricing helpers
  used by the tests and benchmarks.
- `BachelierAdversarialTest.java`: main Java pass/fail accuracy test.
- `JaeckelLFK2026Comparison.java`: paper-style Java accuracy and comparison
  report.
- `BachelierTimingStability.java`: rotated timing benchmark with dedicated hot
  loops.

All Java sources are in the default package, so commands should be run from this
directory.

## Requirements

- JDK 17 or newer. The current runs used OpenJDK 21.
- Apache Commons Numbers 1.3:
  - `org.apache.commons:commons-numbers-gamma:1.3`
  - `org.apache.commons:commons-numbers-core:1.3`

`BachelierMath` uses `org.apache.commons.numbers.gamma.Erfcx` for stable
reference pricing in the test harnesses. The LFK2026 inverse approximation itself
uses only ordinary scalar arithmetic, `Math.sqrt`, and `Math.log`.

If the jars are not already in your local Maven cache, fetch them with:

```sh
mvn -q dependency:get -Dartifact=org.apache.commons:commons-numbers-gamma:1.3
mvn -q dependency:get -Dartifact=org.apache.commons:commons-numbers-core:1.3
```

## Compile

From this directory:

```sh
export COMMONS_NUMBERS_VERSION=1.3
export CP=".:$HOME/.m2/repository/org/apache/commons/commons-numbers-gamma/$COMMONS_NUMBERS_VERSION/commons-numbers-gamma-$COMMONS_NUMBERS_VERSION.jar:$HOME/.m2/repository/org/apache/commons/commons-numbers-core/$COMMONS_NUMBERS_VERSION/commons-numbers-core-$COMMONS_NUMBERS_VERSION.jar"

javac -cp "$CP" *.java
```

To clean compiled classes:

```sh
rm -f *.class
```

## Run The Main Accuracy Test

```sh
java -cp "$CP" BachelierAdversarialTest
```

This exercises normalized OTM and reflected ITM cases, branch boundaries,
tail-cutoff behavior, ATM cases, and scaled input cases across the implemented
approximations. It exits with a non-zero status by throwing `AssertionError` if
any implementation exceeds the configured tolerance. A successful run prints the
max relative errors by algorithm and category.

For the current LFK2026 implementation, recent adversarial runs showed an overall
max relative error around `3.4e-14` in double-precision Java tests. These cases
are dominated by input-price conditioning near intrinsic value, not by the direct
OTM rational approximation alone.

## Paper-Style Java Comparison

```sh
java -cp "$CP" JaeckelLFK2026Comparison | tee jaeckel_lfk2026_java_results.txt
```

This prints the Java accuracy rows used for the paper-style comparisons. It
includes LFK-4, LFK2026, LFK2026C, LFK2026B, and the local Jaeckel comparison
where relevant. It also includes a small rotated timing section, but for timing
use the dedicated benchmark below.

## Timing Benchmark

```sh
java -Xbatch -cp "$CP" BachelierTimingStability | tee java_timing_stability_warm_results.txt
```

The benchmark rotates the method order across rounds and reports median, min,
max, and samples in ns/call for `LFK-4`, `LFK2026`, `LFK2026C`, and
`Jaeckel2017`.

Absolute timings are sensitive to CPU governor, load, and core placement. For a
more stable Linux run, pin to a single performance core if appropriate for the
machine:

```sh
taskset -c 3 java -Xbatch -cp "$CP" BachelierTimingStability | tee java_timing_stability_pinned.txt
```

Recent runs on this machine reported roughly `15 ns/call` for LFK2026,
`14 ns/call` for LFK2026C, and `48 ns/call` for the local Jaeckel comparison in
the dedicated timing harness, but treat those numbers as machine-local.

## Minimal LFK2026 Smoke Example

After compiling, this one-file JShell-style snippet can be pasted into a small
class or used as a guide for integration:

```java
double forward = 0.01;
double strike = 0.012;
double timeToExpiry = 2.0;
double normalVol = 0.0050;

double callPrice = BachelierMath.bachelierCall(
        forward, strike, normalVol, timeToExpiry);

double implied = LFK2026Approximation.impliedVolatility(
        forward, strike, callPrice, timeToExpiry);

System.out.printf("implied normal vol = %.17g%n", implied);
System.out.printf("implied bp vol     = %.17g%n", 10000.0 * implied);
```

## Notes For Porting

- `LFK2026Approximation` is the core accuracy-oriented formula.
- `LFK2026CApproximation` is the faster variant currently used in the paper as
  the compact scalar implementation.
- The approximation expects an undiscounted call price. Apply or remove discount
  factors outside the function.
- For production use in another language, inline the constants from
  `BachelierMath` and port the Horner polynomial evaluations directly. The test
  harness dependency on Apache `Erfcx` is only for stable reference pricing.