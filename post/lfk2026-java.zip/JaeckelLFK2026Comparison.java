import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public final class JaeckelLFK2026Comparison {
	private static final BachelierApproximation[] APPROXIMATIONS = {
			LFK2026Approximation.INSTANCE,
			LFK2026CApproximation.INSTANCE,
			LFK2026DApproximation.INSTANCE,
			JaeckelBachelierApproximation.INSTANCE
	};

	private static final BachelierApproximation[] PAPER_APPROXIMATIONS = {
			LFK4Approximation.INSTANCE,
			LFK2026Approximation.INSTANCE,
			LFK2026CApproximation.INSTANCE,
			LFK2026DApproximation.INSTANCE,
			JaeckelBachelierApproximation.INSTANCE
	};

	private static final String[] TIMING_NAMES = { "LFK-4", "LFK2026", "LFK2026C", "LFK2026D", "Jaeckel2017" };
	private static final int ITERATIONS = 500_000;
	private static final int ROUNDS = 9;

	private static double guard;

	public static void main(String[] args) {
		printPaperAccuracyRows();
		printAccuracy("direct OTM |d| <= 8 step 0.025", denseGrid(8.0), false);
		printAccuracy("direct OTM |d| <= 30 step 0.025", denseGrid(30.0), false);
		printAccuracy("fixed tail/ATM points", fixedPoints(), false);
		printAccuracy("signed algorithm grid", new double[] { -8, -5, -3, -2, -1, -0.5, -0.1, 0,
				0.1, 0.5, 1, 2, 3, 5, 8 }, true);
		printTiming();
	}

	private static void printPaperAccuracyRows() {
		double forward = 1.0;
		double sigma = 1.0;
		double timeToExpiry = 1.0;
		double[] strikes = { 1.001, 1.01, 1.1, 1.5, 2.0, 3.0, 5.0, 7.0, 8.0,
				0.999, 0.99, 0.9, 0.5, 0.0, -0.5, -1.0 };
		Stats[] standardStats = paperStats();
		for (double strike : strikes) {
			double price = BachelierMath.bachelierCall(forward, strike, sigma, timeToExpiry);
			addPaperCase(standardStats, strike, price, timeToExpiry, sigma, strike);
		}
		printPaperStats("double precision strike grid", standardStats);

		int ulpN = 256;
		String ulpEnv = System.getenv("ULP_SAMPLES");
		if (ulpEnv != null) {
			try {
				ulpN = Integer.parseInt(ulpEnv);
			} catch (NumberFormatException e) {
			}
		}
		ulpStatsForStrikes("Double precision strike grid", strikes, forward, sigma, timeToExpiry, ulpN);

		Stats[] deepStats = paperStats();
		double[] deepStrikes = { -1, -2, -3, -5, -7, -8, -9, -10, -15, -20, -25, -30 };
		for (double strike : deepStrikes) {
			double cotm = BachelierMath.bachelierOtmPrice(forward, strike, sigma, timeToExpiry);
			if (cotm <= 0.0)
				continue;
			double reflectedStrike = 2.0 * forward - strike;
			addPaperCase(deepStats, reflectedStrike, cotm, timeToExpiry, sigma, strike);
		}
		printPaperStats("deep ITM reflection", deepStats);

		{
			List<Double> centers = new ArrayList<>();
			List<Double> cotms = new ArrayList<>();
			for (double strike : deepStrikes) {
				double cotm = BachelierMath.bachelierOtmPrice(forward, strike, sigma, timeToExpiry);
				if (cotm <= 0.0)
					continue;
				double reflectedStrike = 2.0 * forward - strike;
				centers.add(reflectedStrike);
				cotms.add(cotm);
			}
			double[] centersArr = new double[centers.size()];
			Double[] cotmArr = new Double[cotms.size()];
			for (int i = 0; i < centers.size(); i++) {
				centersArr[i] = centers.get(i);
				cotmArr[i] = cotms.get(i);
			}
			ulpStatsForPairs("Deep ITM reflection", centersArr, cotmArr, forward, sigma, timeToExpiry, ulpN);
		}

		Stats[] algorithmStats = paperStats();
		double[] dValues = { -8, -5, -3, -2, -1, -0.5, -0.1, 0.0,
				0.1, 0.5, 1.0, 2.0, 3.0, 5.0, 8.0 };
		for (double dValue : dValues) {
			CaseData data = directSignedOtmCase(forward, sigma, timeToExpiry, dValue);
			if (data.callPrice <= 0.0)
				continue;
			addPaperCase(algorithmStats, data.strike, data.callPrice, timeToExpiry, sigma, dValue);
		}
		printPaperStats("direct OTM algorithm grid", algorithmStats);

		{
			List<Double> ksList = new ArrayList<>();
			for (double dValue : dValues) {
				CaseData data = directSignedOtmCase(forward, sigma, timeToExpiry, dValue);
				if (data.callPrice <= 0.0)
					continue;
				ksList.add(data.strike);
			}
			double[] ksArr = new double[ksList.size()];
			for (int i = 0; i < ksList.size(); i++)
				ksArr[i] = ksList.get(i);
			ulpStatsForStrikes("Direct OTM algorithm grid", ksArr, forward, sigma, timeToExpiry, ulpN);
		}

		Stats[] ckkStats = paperStats();
		double[] ckkValues = { 1.00001, 1.006660, 2.0, 4.0, 8.8, 9.0, 30.0 };
		for (double strike : ckkValues) {
			double price = BachelierMath.bachelierCall(forward, strike, sigma, timeToExpiry);
			addPaperCase(ckkStats, strike, price, timeToExpiry, sigma, strike);
		}
		printPaperStats("b.p. vol strike grid", ckkStats);

		ulpStatsForStrikes("Direct b.p. vol grid", ckkValues, forward, sigma, timeToExpiry, ulpN);
	}

	private static Stats[] paperStats() {
		Stats[] stats = new Stats[PAPER_APPROXIMATIONS.length];
		for (int index = 0; index < stats.length; index++)
			stats[index] = new Stats();
		return stats;
	}

	private static void addPaperCase(Stats[] stats, double strike, double callPrice,
			double timeToExpiry, double expectedSigma, double labelValue) {
		for (int index = 0; index < PAPER_APPROXIMATIONS.length; index++) {
			BachelierApproximation approximation = PAPER_APPROXIMATIONS[index];
			double implied = approximation.impliedVol(1.0, strike, callPrice, timeToExpiry);
			if (!Double.isFinite(implied) || implied == 0.0)
				continue;
			stats[index].add(labelValue, Math.abs(implied - expectedSigma) / expectedSigma);
		}
	}

	private static void printPaperStats(String label, Stats[] stats) {
		System.out.println("JAECKEL_PAPER " + label);
		for (int index = 0; index < PAPER_APPROXIMATIONS.length; index++) {
			System.out.printf("  %-11s cases=%5d max=%.12e worst=%+.6f%n",
					PAPER_APPROXIMATIONS[index].name(), stats[index].cases,
					stats[index].maxError, stats[index].worstD);
		}
	}

	// ULP sampling helpers and percentile reporting (matches the Julia harness)
	private static double[] ulpSamples(double center, int n) {
		if (n <= 1)
			return new double[] { center };
		int half = n / 2;
		double s = center;
		for (int i = 0; i < half; i++)
			s = Math.nextDown(s);
		double[] out = new double[n];
		out[0] = s;
		for (int i = 1; i < n; i++)
			out[i] = Math.nextUp(out[i - 1]);
		return out;
	}

	private static double quantile(double[] v, double p) {
		int n = v.length;
		if (n == 0)
			return 0.0;
		double[] copy = v.clone();
		Arrays.sort(copy);
		int idx = (int) Math.ceil(p * n) - 1;
		if (idx < 0)
			idx = 0;
		if (idx >= n)
			idx = n - 1;
		return copy[idx];
	}

	private static void ulpStatsForPairs(String name, double[] centers, Double[] priceOverrides,
			double forward, double sigma, double timeToExpiry, int nUlps) {
		System.out.println("JAECKEL_ULP " + name);
		List<Double>[] errs = new ArrayList[PAPER_APPROXIMATIONS.length];
		for (int i = 0; i < errs.length; i++)
			errs[i] = new ArrayList<>();
		int totalSamples = 0;
		for (int ci = 0; ci < centers.length; ci++) {
			double Kc = centers[ci];
			double[] samples = ulpSamples(Kc, nUlps);
			for (double K : samples) {
				double price = (priceOverrides != null && priceOverrides[ci] != null)
						? priceOverrides[ci]
						: BachelierMath.bachelierCall(forward, K, sigma, timeToExpiry);
				if (price < 1e-300)
					continue;
				for (int idx = 0; idx < PAPER_APPROXIMATIONS.length; idx++) {
					double implied = PAPER_APPROXIMATIONS[idx].impliedVol(forward, K, price, timeToExpiry);
					if (!Double.isFinite(implied) || implied == 0.0)
						continue;
					double err = Math.abs(implied - sigma) / sigma;
					errs[idx].add(err);
				}
				totalSamples++;
			}
		}
		if (totalSamples == 0) {
			System.out.println("  No valid samples");
			return;
		}
		for (int idx = 0; idx < PAPER_APPROXIMATIONS.length; idx++) {
			List<Double> list = errs[idx];
			if (list.isEmpty()) {
				System.out.printf("  Samples=%8d  %-11s: no valid samples%n", totalSamples,
						PAPER_APPROXIMATIONS[idx].name());
				continue;
			}
			double[] arr = new double[list.size()];
			for (int i = 0; i < list.size(); i++)
				arr[i] = list.get(i);
			double max = 0.0;
			for (double v : arr)
				if (v > max)
					max = v;
			double p95 = quantile(arr, 0.95);
			double p99 = quantile(arr, 0.99);
			System.out.printf("  Samples=%8d  %-11s max=%.3e  p95=%.3e  p99=%.3e%n",
					totalSamples, PAPER_APPROXIMATIONS[idx].name(), max, p95, p99);
		}
	}

	private static void ulpStatsForStrikes(String name, double[] strikes,
			double forward, double sigma, double timeToExpiry, int nUlps) {
		ulpStatsForPairs(name, strikes, null, forward, sigma, timeToExpiry, nUlps);
	}

	private static double[] denseGrid(double maxAbsD) {
		int count = (int) Math.round(2.0 * maxAbsD / 0.025) + 1;
		double[] values = new double[count];
		double start = -maxAbsD;
		for (int index = 0; index < count; index++) {
			values[index] = start + index * 0.025;
		}
		return values;
	}

	private static double[] fixedPoints() {
		return new double[] { -35, -30, -25, -20, -15, -12, -10, -8, -5, -3, -2, -1,
				-0.5, -0.1, 0, 0.1, 0.5, 1, 2, 3, 5, 8, 10, 12, 15, 20, 25, 30, 35 };
	}

	private static void printAccuracy(String label, double[] dValues, boolean signedCalls) {
		Stats[] stats = new Stats[APPROXIMATIONS.length];
		for (int index = 0; index < stats.length; index++)
			stats[index] = new Stats();

		for (double dValue : dValues) {
			CaseData data = signedCalls ? signedCase(dValue) : directOtmCase(Math.abs(dValue));
			if (!(data.callPrice > 0.0))
				continue;
			for (int index = 0; index < APPROXIMATIONS.length; index++) {
				double implied = APPROXIMATIONS[index].impliedVol(data.forward, data.strike, data.callPrice, 1.0);
				if (!Double.isFinite(implied) || implied == 0.0)
					continue;
				stats[index].add(dValue, Math.abs(implied - 1.0));
			}
		}

		System.out.println("JAECKEL_JAVA " + label);
		for (int index = 0; index < APPROXIMATIONS.length; index++) {
			System.out.printf("  %-11s cases=%5d max=%.12e worst_d=%+.6f%n",
					APPROXIMATIONS[index].name(), stats[index].cases, stats[index].maxError, stats[index].worstD);
		}
	}

	private static CaseData directOtmCase(double absD) {
		double forward = 0.0;
		double strike = absD;
		double callPrice = absD == 0.0
				? BachelierMath.INV_SQRT_2PI
				: BachelierMath.bachelierOtmPrice(forward, strike, 1.0, 1.0);
		return new CaseData(forward, strike, callPrice);
	}

	private static CaseData signedCase(double dValue) {
		double forward = 1.0;
		double strike = forward - dValue;
		double callPrice = BachelierMath.bachelierCall(forward, strike, 1.0, 1.0);
		return new CaseData(forward, strike, callPrice);
	}

	private static CaseData directSignedOtmCase(double forward, double sigma,
			double timeToExpiry, double dValue) {
		double volScale = sigma * Math.sqrt(timeToExpiry);
		double sourceStrike = forward - dValue * volScale;
		double cotm = BachelierMath.bachelierOtmPrice(forward, sourceStrike, sigma, timeToExpiry);
		if (dValue > 0.0) {
			return new CaseData(forward, 2.0 * forward - sourceStrike, cotm);
		}
		return new CaseData(forward, sourceStrike, cotm);
	}

	private static void printTiming() {
		double forward = 1.0;
		double[] strikes = { 1.001, 1.01, 1.1, 1.5, 2.0, 3.0, 5.0, 7.0, 8.0,
				0.999, 0.99, 0.9, 0.5, 0.0, -0.5, -1.0 };
		double[] prices = new double[strikes.length];
		for (int index = 0; index < strikes.length; index++) {
			prices[index] = BachelierMath.bachelierCall(forward, strikes[index], 1.0, 1.0);
		}

		for (int method = 0; method < TIMING_NAMES.length; method++) {
			run(method, 100_000, forward, strikes, prices);
		}

		double[][] timings = new double[TIMING_NAMES.length][ROUNDS];
		for (int round = 0; round < ROUNDS; round++) {
			for (int offset = 0; offset < TIMING_NAMES.length; offset++) {
				int method = (round + offset) % TIMING_NAMES.length;
				timings[method][round] = run(method, ITERATIONS, forward, strikes, prices);
			}
		}

		System.out.printf("JAECKEL_JAVA rotated timing (%d rounds, %d x %d calls)%n",
				ROUNDS, ITERATIONS, strikes.length);
		for (int method = 0; method < TIMING_NAMES.length; method++) {
			double[] sorted = timings[method].clone();
			Arrays.sort(sorted);
			System.out.printf("  %-11s median=%8.2f ns/call min=%8.2f max=%8.2f samples=%s%n",
					TIMING_NAMES[method], sorted[ROUNDS / 2], sorted[0], sorted[ROUNDS - 1],
					Arrays.toString(timings[method]));
		}
		if (guard == 0.0)
			System.out.print("");
	}

	private static double run(int method, int iterations, double forward, double[] strikes, double[] prices) {
		double local = guard;
		long start = System.nanoTime();
		for (int repeat = 0; repeat < iterations; repeat++) {
			for (int index = 0; index < strikes.length; index++) {
				switch (method) {
					case 0:
						local += LFK4Approximation.impliedVolatility(forward, strikes[index], prices[index], 1.0);
						break;
					case 1:
						local += LFK2026Approximation.impliedVolatility(forward, strikes[index], prices[index], 1.0);
						break;
					case 2:
						local += LFK2026CApproximation.impliedVolatility(forward, strikes[index], prices[index], 1.0);
						break;
					case 3:
						local += LFK2026DApproximation.impliedVolatility(forward, strikes[index], prices[index], 1.0);
						break;
					case 4:
						local += JaeckelBachelierApproximation.impliedVolatility(forward, strikes[index], prices[index],
								1.0);
						break;
					default:
						throw new IllegalArgumentException();
				}
			}
		}
		long end = System.nanoTime();
		guard = local;
		return (end - start) / ((double) iterations * strikes.length);
	}

	private static final class CaseData {
		final double forward;
		final double strike;
		final double callPrice;

		CaseData(double forward, double strike, double callPrice) {
			this.forward = forward;
			this.strike = strike;
			this.callPrice = callPrice;
		}
	}

	private static final class Stats {
		int cases;
		double maxError;
		double worstD;

		void add(double dValue, double error) {
			cases++;
			if (error > maxError) {
				maxError = error;
				worstD = dValue;
			}
		}
	}
}
