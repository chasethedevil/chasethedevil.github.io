import org.apache.commons.numbers.gamma.Erfcx;
import org.apache.commons.numbers.gamma.Erfc;

public final class BachelierMath {
    public static final double SQRT_2PI = Math.sqrt(2.0 * Math.PI);
    public static final double INV_SQRT_2PI = 1.0 / SQRT_2PI;
    public static final double SQRT_2 = Math.sqrt(2.0);
    public static final double BETA_E = 300.0 * Math.log(10.0);
    private static final BachelierFormula DEFAULT_BACHELIER_FORMULA = new ErfcxBachelierFormula();

    private BachelierMath() {
    }

    public static double etaItm(double z) {
        if (z < 0.01) {
            double z2 = z * z;
            double z3 = z2 * z;
            double z4 = z2 * z2;
            double z5 = z4 * z;
            double z6 = z4 * z2;
            double z7 = z4 * z3;
            double z8 = z4 * z4;
            return 1.0 - z * 0.5 - z2 / 12.0 - z3 / 24.0 - 19.0 * z4 / 720.0
                    - 3.0 * z5 / 160.0 - 863.0 * z6 / 60480.0
                    - 275.0 * z7 / 24192.0 - 33953.0 * z8 / 3628800.0;
        }
        return -z / Math.log1p(-z);
    }

    public static double bachelierCall(double forward, double strike, double sigma, double timeToExpiry) {
        return DEFAULT_BACHELIER_FORMULA.bachelierCall(forward, strike, sigma, timeToExpiry);
    }

    public static double bachelierOtmPrice(double forward, double strike, double sigma, double timeToExpiry) {
        return DEFAULT_BACHELIER_FORMULA.bachelierOtmPrice(forward, strike, sigma, timeToExpiry);
    }

    public static interface BachelierFormula {
        default double bachelierCall(double forward, double strike, double sigma, double timeToExpiry) {
            if (sigma <= 0.0 || timeToExpiry <= 0.0)
                return Math.max(forward - strike, 0.0);
            double x = forward - strike;
            double cotm = bachelierOtmPrice(forward, strike, sigma, timeToExpiry);
            return x >= 0.0 ? x + cotm : cotm;
        }

        double bachelierOtmPrice(double forward, double strike, double sigma, double timeToExpiry);
    }

    static class CDFBachelierFormula implements BachelierFormula {
        public double bachelierOtmPrice(double forward, double strike, double sigma, double timeToExpiry) {
            double x = forward - strike;
            double v = sigma * Math.sqrt(timeToExpiry);

            double d = x / v;
            double absd = Math.abs(d);
            double absx = Math.abs(x);
            double phi = Math.exp(-0.5 * absd * absd) * INV_SQRT_2PI;
            double phic = 0.5 * Erfc.value(absd / SQRT_2);
            return v * phi - absx * phic;
        }
    }

    static class ErfcxBachelierFormula implements BachelierFormula {
        @Override
        public double bachelierOtmPrice(double forward, double strike, double sigma, double timeToExpiry) {
            double x = forward - strike;
            double v = sigma * Math.sqrt(timeToExpiry);
            double absD = Math.abs(x / v);
            double absX = Math.abs(x);
            double emhd2 = Math.exp(-0.5 * absD * absD);
            return emhd2 * (v * INV_SQRT_2PI - 0.5 * absX * Erfcx.value(absD / SQRT_2));
        }

    }

    static class CodyBachelierFormula implements BachelierFormula {
        @Override
        public double bachelierOtmPrice(double forward, double strike, double sigma, double timeToExpiry) {
            double x = forward - strike;
            double v = sigma * Math.sqrt(timeToExpiry);
            double absD = Math.abs(x / v);
            return JaeckelBachelierApproximation.phiTildeTimesX(-absD) * v;

        }

    }

}