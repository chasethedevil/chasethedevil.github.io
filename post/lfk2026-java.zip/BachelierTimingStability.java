import java.util.Arrays;

public final class BachelierTimingStability {
    private static final String[] NAMES = { "LFK-4", "LFK2026", "LFK2026C", "Jaeckel2017" };
    private static final String[] PRICE_NAMES = { "Erfcx", "Cody", "CDF" };
    private static final int WARMUP_ITERATIONS = 2_000_000;
    private static final int ITERATIONS = 750_000;
    private static final int ROUNDS = 9;

    private static double guard;

    public static void main(String[] args) {
        int rounds = ROUNDS;
        if (args.length > 0) {
            try {
                rounds = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                System.err.println("Invalid number of rounds: " + args[0]);
                System.exit(1);
            }
        }
        double forward = 1.0;
        double sigma = 1.0;
        double timeToExpiry = 1.0;
        double[] strikes = { 1.001, 1.01, 1.1, 1.5, 2.0, 3.0, 5.0, 7.0, 8.0,
                0.999, 0.99, 0.9, 0.5, 0.0, -0.5, -1.0 };
        double[] prices = computeReferencePrices(forward, sigma, timeToExpiry, strikes);

        double[][] timingsPrices = new double[PRICE_NAMES.length][rounds];
        for (int method = 0; method < PRICE_NAMES.length; method++) {
            runPrices(method, WARMUP_ITERATIONS, forward, sigma, timeToExpiry, strikes);
        }
        for (int round = 0; round < rounds; round++) {
            for (int offset = 0; offset < PRICE_NAMES.length; offset++) {
                int method = (round + offset) % PRICE_NAMES.length;
                timingsPrices[method][round] = runPrices(method, ITERATIONS, forward, sigma, timeToExpiry, strikes);
            }
        }
        System.out.printf("Rotated timing benchmark (%d rounds, %d x %d calls per method per round)%n",
                rounds, ITERATIONS, strikes.length);
        for (int method = 0; method < PRICE_NAMES.length; method++) {
            double[] sorted = timingsPrices[method].clone();
            Arrays.sort(sorted);
            System.out.printf("  %-9s median=%5.2f ns/call  min=%5.2f  max=%5.2f  samples=%s%n",
                    PRICE_NAMES[method], sorted[rounds / 2], sorted[0], sorted[rounds - 1],
                    Arrays.toString(timingsPrices[method]));
        }
        System.out.printf("Rotated timing benchmark (%d rounds, %d x %d calls per method per round)%n",
                rounds, ITERATIONS, strikes.length);

        for (int method = 0; method < NAMES.length; method++) {
            run(method, WARMUP_ITERATIONS, forward, strikes, prices, timeToExpiry);
        }

        double[][] timings = new double[NAMES.length][rounds];
        for (int round = 0; round < rounds; round++) {
            for (int offset = 0; offset < NAMES.length; offset++) {
                int method = (round + offset) % NAMES.length;
                timings[method][round] = run(method, ITERATIONS, forward, strikes, prices, timeToExpiry);
            }
        }

        System.out.printf("Rotated timing benchmark (%d rounds, %d x %d calls per method per round)%n",
                rounds, ITERATIONS, strikes.length);
        for (int method = 0; method < NAMES.length; method++) {
            double[] sorted = timings[method].clone();
            Arrays.sort(sorted);
            System.out.printf("  %-9s median=%5.2f ns/call  min=%5.2f  max=%5.2f  samples=%s%n",
                    NAMES[method], sorted[rounds / 2], sorted[0], sorted[rounds - 1], Arrays.toString(timings[method]));
        }
        if (guard == 0.0)
            System.out.print("");
    }

    private static double[] computeReferencePrices(double forward, double sigma, double timeToExpiry,
            double[] strikes) {
        double[] prices = new double[strikes.length];
        for (int index = 0; index < strikes.length; index++) {
            prices[index] = BachelierMath.bachelierCall(forward, strikes[index], sigma, timeToExpiry);
        }
        return prices;
    }

    private static double runPrices(int method, int iterations, double forward, double sigma, double timeToExpiry,
            double[] strikes) {
        BachelierMath.BachelierFormula formula;
        switch (method) {
            case 0:
                formula = new BachelierMath.ErfcxBachelierFormula();
                break;
            case 1:
                formula = new BachelierMath.CodyBachelierFormula();
                break;
            case 2:
                formula = new BachelierMath.CDFBachelierFormula();
                break;
            default:
                throw new IllegalArgumentException();
        }
        double local = guard;
        long start = System.nanoTime();
        for (int repeat = 0; repeat < iterations; repeat++) {
            for (int index = 0; index < strikes.length; index++) {
                local += formula.bachelierCall(forward, strikes[index], sigma, timeToExpiry);
            }
        }
        long end = System.nanoTime();
        guard = local;
        return (end - start) / ((double) iterations * strikes.length);
    }

    private static double run(int method, int iterations, double forward, double[] strikes,
            double[] prices, double timeToExpiry) {
        switch (method) {
            case 0:
                return timeLfk4(iterations, forward, strikes, prices, timeToExpiry);
            case 1:
                return timeLfk2026(iterations, forward, strikes, prices, timeToExpiry);
            case 2:
                return timeLfk2026C(iterations, forward, strikes, prices, timeToExpiry);
            case 3:
                return timeJaeckel(iterations, forward, strikes, prices, timeToExpiry);
            default:
                throw new IllegalArgumentException();
        }
    }

    private static double timeLfk4(int iterations, double forward, double[] strikes,
            double[] prices, double timeToExpiry) {
        double local = guard;
        long start = System.nanoTime();
        for (int repeat = 0; repeat < iterations; repeat++) {
            for (int index = 0; index < strikes.length; index++) {
                local += LFK4Approximation.impliedVolatility(forward, strikes[index], prices[index], timeToExpiry);
            }
        }
        long end = System.nanoTime();
        guard = local;
        return (end - start) / ((double) iterations * strikes.length);
    }

    private static double timeLfk2026(int iterations, double forward, double[] strikes,
            double[] prices, double timeToExpiry) {
        double local = guard;
        long start = System.nanoTime();
        for (int repeat = 0; repeat < iterations; repeat++) {
            for (int index = 0; index < strikes.length; index++) {
                local += LFK2026Approximation.impliedVolatility(forward, strikes[index], prices[index], timeToExpiry);
            }
        }
        long end = System.nanoTime();
        guard = local;
        return (end - start) / ((double) iterations * strikes.length);
    }

    private static double timeLfk2026C(int iterations, double forward, double[] strikes,
            double[] prices, double timeToExpiry) {
        double local = guard;
        long start = System.nanoTime();
        for (int repeat = 0; repeat < iterations; repeat++) {
            for (int index = 0; index < strikes.length; index++) {
                local += LFK2026CApproximation.impliedVolatility(forward, strikes[index], prices[index], timeToExpiry);
            }
        }
        long end = System.nanoTime();
        guard = local;
        return (end - start) / ((double) iterations * strikes.length);
    }

    private static double timeJaeckel(int iterations, double forward, double[] strikes,
            double[] prices, double timeToExpiry) {
        double local = guard;
        long start = System.nanoTime();
        for (int repeat = 0; repeat < iterations; repeat++) {
            for (int index = 0; index < strikes.length; index++) {
                local += JaeckelBachelierApproximation.impliedVolatility(forward, strikes[index], prices[index],
                        timeToExpiry);
            }
        }
        long end = System.nanoTime();
        guard = local;
        return (end - start) / ((double) iterations * strikes.length);
    }
}