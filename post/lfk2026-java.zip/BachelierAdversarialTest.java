import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class BachelierAdversarialTest {
    private static final double MAX_RELATIVE_ERROR = 5e-12;
    private static final int CONSECUTIVE_DOUBLES_PER_POINT = 256;

    private static final ApproximationCase[] APPROXIMATIONS = {
            new ApproximationCase("LFK-4", LFK4Approximation::impliedVolatility),
            new ApproximationCase("LFK2026B", LFK2026BApproximation::impliedVolatility),
            new ApproximationCase("LFK2026", LFK2026Approximation::impliedVolatility),
            new ApproximationCase("LFK2026C", LFK2026CApproximation::impliedVolatility),
            new ApproximationCase("Jaeckel2017", JaeckelBachelierApproximation::impliedVolatility),
    };

    public static void main(String[] args) {
        EtaBranchReport etaBranchReport = testEtaItmBranch();
        int tailCutoffChecks = testTailCutoffBranch();

        List<AbsDCase> absDValues = new ArrayList<>();
        addCoreDValues(absDValues);
        addBoundaryDValues(absDValues);

        ErrorReport report = new ErrorReport();

        int cases = 0;
        for (AbsDCase absDCase : absDValues) {
            cases += testNormalizedOtmCase(absDCase, report);
            cases += testNormalizedItmCase(absDCase, report);
        }
        cases += testScaledCases(report);

        report.print(cases, etaBranchReport, tailCutoffChecks);
        report.assertWithinTolerance();
    }

    private static EtaBranchReport testEtaItmBranch() {
        EtaBranchReport report = new EtaBranchReport();
        double[] tinyZ = { 0.0, Double.MIN_VALUE, 1e-300, 1e-200, 1e-100, 1e-20, 1e-16, 1e-12 };
        for (double z : tinyZ) {
            checkEtaItm(z, report);
        }

        for (int index = 0; index <= 400; index++) {
            checkEtaItm(index * 0.02 / 400.0, report);
        }
        checkEtaItm(Math.nextDown(0.01), report);
        checkEtaItm(0.01, report);
        checkEtaItm(Math.nextUp(0.01), report);

        double left = BachelierMath.etaItm(Math.nextDown(0.01));
        double right = BachelierMath.etaItm(0.01);
        report.boundaryJump = Math.abs(left - right);
        if (report.boundaryJump > 2e-15) {
            throw new AssertionError("etaItm discontinuity around z=1e-2: " + left + " vs " + right);
        }

        if (report.maxAbsError > 2e-15) {
            throw new AssertionError("etaItm small-z accuracy failed at z=" + report.worstZ
                    + ": abs error=" + report.maxAbsError);
        }

        double[] nearOneZ = { 0.9, 0.99, 0.999999, Math.nextDown(1.0) };
        for (double z : nearOneZ) {
            assertFinitePositive("etaItm near one z=" + z, BachelierMath.etaItm(z));
        }
        return report;
    }

    private static void checkEtaItm(double z, EtaBranchReport report) {
        double eta = BachelierMath.etaItm(z);
        assertFinitePositive("etaItm z=" + z, eta);
        double reference = etaItmSeriesReference(z);
        double absError = Math.abs(eta - reference);
        report.add(z, absError);
        if (z <= 1e-12 && Math.abs(eta - 1.0) > 1e-10) {
            throw new AssertionError("etaItm tiny-z limit failed at z=" + z + ": " + eta);
        }
    }

    private static double etaItmSeriesReference(double z) {
        if (z == 0.0)
            return 1.0;
        double sum = 0.0;
        double power = 1.0;
        for (int index = 0; index < 1000; index++) {
            double term = power / (index + 1.0);
            sum += term;
            if (Math.abs(term) < 0.25 * Math.ulp(sum))
                break;
            power *= z;
        }
        return 1.0 / sum;
    }

    private static int testTailCutoffBranch() {
        double[] callPrices = { 0.0, Double.MIN_VALUE, 1e-320, 1e-310, Math.nextDown(1e-300) };
        int checks = 0;
        for (double callPrice : callPrices) {
            for (ApproximationCase approximation : APPROXIMATIONS) {
                double implied = approximation.function.impliedVol(0.0, 1.0, callPrice, 1.0);
                if (!Double.isFinite(implied) || implied < 0.0) {
                    throw new AssertionError(approximation.name + " tail cutoff produced " + implied
                            + " for callPrice=" + callPrice);
                }
                checks++;
            }
        }
        return checks;
    }

    private static void addCoreDValues(List<AbsDCase> absDValues) {
        double[] values = {
                0.0, Double.MIN_VALUE, 1e-300, 1e-200, 1e-100, 1e-16, 1e-12,
                1e-9, 1e-6, 1e-3, 0.01, 0.05, 0.1, 0.25, 0.5, 0.75,
                1.0, 1.5, 2.0, 3.0, 5.0, 8.0, 10.0, 12.0, 16.0,
                20.0, 25.0, 30.0, 35.0, 37.0
        };
        for (double value : values) {
            addMeasuredPoint(absDValues, value, "core grid", "core absD=" + value);
        }
    }

    private static void addBoundaryDValues(List<AbsDCase> absDValues) {
        addAroundRatio(absDValues, 99.0, "eta branch", "z=1e-2 eta switch");
        addAroundRatio(absDValues, 0.50, "route boundary", "alpha=0.50 route");
        addAroundRatio(absDValues, 0.15, "route boundary", "alpha=0.15 route");
        addAroundRatio(absDValues, 0.12, "route boundary", "alpha=0.12 route");

        addAroundOtmEta(absDValues, 0.50, 0.008);
        addAroundOtmEta(absDValues, 0.50, 0.06);
        addAroundOtmEta(absDValues, 0.15, 0.01);
        addAroundOtmEta(absDValues, 0.15, 0.011);
        addAroundOtmEta(absDValues, 0.15, 0.03);
        addAroundOtmEta(absDValues, 0.15, 0.09);
        addAroundOtmEta(absDValues, 0.15, 0.105);
        addAroundOtmEta(absDValues, 0.12, 0.01);
        addAroundOtmEta(absDValues, 0.12, 0.09);
    }

    private static void addAroundRatio(List<AbsDCase> absDValues, double targetRatio,
            String category, String detail) {
        double absD = findAbsDForRatio(targetRatio);
        addAround(absDValues, absD, category, detail);
    }

    private static void addAroundOtmEta(List<AbsDCase> absDValues, double alpha, double etaTilde) {
        double betaS = -Math.log(alpha);
        double targetRatio = Math.exp(-(betaS + etaTilde * (BachelierMath.BETA_E - betaS)));
        addAroundRatio(absDValues, targetRatio, "zone split",
                "alpha=" + alpha + " etaTilde=" + etaTilde);
    }

    private static void addConsecutiveValues(List<AbsDCase> absDValues, double start,
            String category, String detail) {
        double value = start;
        for (int index = 0; index < CONSECUTIVE_DOUBLES_PER_POINT; index++) {
            absDValues.add(new AbsDCase(
                    value,
                    category,
                    detail + " [offset=" + index + ", value=" + value + "]"));
            value = Math.nextUp(value);
        }
    }

    private static void addMeasuredPoint(List<AbsDCase> absDValues, double value,
            String category, String detail) {
        addConsecutiveValues(absDValues, value, category, detail);
    }

    private static void addAround(List<AbsDCase> absDValues, double absD, String category, String detail) {
        // addMeasuredPoint(absDValues, Math.nextDown(absD), category, detail + "
        // below");
        addMeasuredPoint(absDValues, absD, category, detail + " exact");
        // addMeasuredPoint(absDValues, Math.nextUp(absD), category, detail + " above");
    }

    private static double findAbsDForRatio(double targetRatio) {
        double low = 0.0;
        double high = 1.0;
        while (ratioAtAbsD(high) > targetRatio && high < 40.0) {
            high *= 2.0;
        }
        for (int iteration = 0; iteration < 240; iteration++) {
            double mid = 0.5 * (low + high);
            if (ratioAtAbsD(mid) > targetRatio) {
                low = mid;
            } else {
                high = mid;
            }
        }
        return 0.5 * (low + high);
    }

    private static double ratioAtAbsD(double absD) {
        return normalizedOtmPrice(absD) / absD;
    }

    private static double normalizedOtmPrice(double absD) {
        return BachelierMath.bachelierOtmPrice(0.0, absD, 1.0, 1.0);
    }

    private static int testNormalizedOtmCase(AbsDCase absDCase, ErrorReport report) {
        double absD = absDCase.absD;
        double price = absD == 0.0 ? BachelierMath.INV_SQRT_2PI : normalizedOtmPrice(absD);
        if (!(price > 0.0))
            return 0;
        if (absD > 0.0 && price / absD < Math.exp(-BachelierMath.BETA_E))
            return 0;
        return testCase("OTM " + absDCase.detail + " absD=" + absD,
                "OTM " + absDCase.category, 0.0, absD, price, 1.0, 1.0, report);
    }

    private static int testNormalizedItmCase(AbsDCase absDCase, ErrorReport report) {
        double absD = absDCase.absD;
        if (absD == 0.0)
            return 0;
        double timeValue = normalizedOtmPrice(absD);
        double price = absD + timeValue;
        if (price == absD)
            return 0;
        return testCase("ITM " + absDCase.detail + " absD=" + absD,
                "ITM " + absDCase.category, absD, 0.0, price, 1.0, 1.0, report);
    }

    private static int testScaledCases(ErrorReport report) {
        int cases = 0;
        double[] forwards = { -10.0, -0.1, 0.0, 1.0, 100.0 };
        double[] sigmas = { 1e-6, 0.003, 1.0, 40.0, 1e6 };
        double[] expiries = { 1e-8, 0.01, 1.0, 100.0, 1e8 };
        double[] dValues = { -5.0, -2.0, -0.1, -1e-8, 0.0, 1e-8, 0.1, 2.0, 5.0 };
        for (double forward : forwards) {
            for (double sigma : sigmas) {
                for (double timeToExpiry : expiries) {
                    double volScale = sigma * Math.sqrt(timeToExpiry);
                    for (double dValue : dValues) {
                        double strike = forward - dValue * volScale;
                        double price = BachelierMath.bachelierCall(forward, strike, sigma, timeToExpiry);
                        if (!(price > 0.0))
                            continue;
                        String category = scaledCategory(dValue);
                        cases += testCase("scaled d=" + dValue + " sigma=" + sigma + " T=" + timeToExpiry,
                                category, forward, strike, price, timeToExpiry, sigma, report);
                    }
                }
            }
        }
        return cases;
    }

    private static String scaledCategory(double dValue) {
        if (dValue < 0.0)
            return "scaled OTM";
        if (dValue > 0.0)
            return "scaled ITM";
        return "scaled ATM";
    }

    private static int testCase(String description, String category, double forward, double strike, double callPrice,
            double timeToExpiry, double expectedSigma, ErrorReport report) {
        double intrinsic = Math.max(forward - strike, 0.0);
        if (intrinsic > 0.0) {
            double encodedTimeValue = callPrice - intrinsic;
            if (!(encodedTimeValue > 1e-6 * Math.max(1.0, Math.abs(intrinsic))))
                return 0;
        }
        report.recordCase(category);
        for (int index = 0; index < APPROXIMATIONS.length; index++) {
            ApproximationCase approximation = APPROXIMATIONS[index];
            double implied = approximation.function.impliedVol(forward, strike, callPrice, timeToExpiry);
            assertFinitePositive(approximation.name + " " + description, implied);
            double relativeError = Math.abs(implied / expectedSigma - 1.0);
            report.add(category, index, relativeError, description);
        }
        return APPROXIMATIONS.length;
    }

    private static void assertFinitePositive(String description, double value) {
        if (!Double.isFinite(value) || !(value > 0.0)) {
            throw new AssertionError(description + " produced " + value);
        }
    }

    @FunctionalInterface
    private interface ImpliedVolFunction {
        double impliedVol(double forward, double strike, double callPrice, double timeToExpiry);
    }

    private static final class ApproximationCase {
        final String name;
        final ImpliedVolFunction function;

        ApproximationCase(String name, ImpliedVolFunction function) {
            this.name = name;
            this.function = function;
        }
    }

    private static final class AbsDCase {
        final double absD;
        final String category;
        final String detail;

        AbsDCase(double absD, String category, String detail) {
            this.absD = absD;
            this.category = category;
            this.detail = detail;
        }
    }

    private static final class ErrorReport {
        private final Map<String, CategoryStats> categories = new LinkedHashMap<>();
        private final MaxError[] overall = new MaxError[APPROXIMATIONS.length];
        private int inputCases;

        ErrorReport() {
            for (int index = 0; index < overall.length; index++) {
                overall[index] = new MaxError(APPROXIMATIONS[index].name);
            }
        }

        void recordCase(String category) {
            inputCases++;
            categoryStats(category).inputCases++;
        }

        void add(String category, int approximationIndex, double relativeError, String description) {
            categoryStats(category).maxErrors[approximationIndex].add(relativeError, description);
            overall[approximationIndex].add(relativeError, category + ": " + description);
        }

        void print(int approximationEvaluations, EtaBranchReport etaBranchReport, int tailCutoffChecks) {
            System.out.println("Direct branch checks:");
            System.out.printf("  etaItm small-z samples: %d  maxAbsErr=%.3e at z=%.17g  jump@1e-2=%.3e%n",
                    etaBranchReport.samples, etaBranchReport.maxAbsError,
                    etaBranchReport.worstZ, etaBranchReport.boundaryJump);
            System.out.printf("  tail cutoff finite-output checks: %d%n", tailCutoffChecks);
            System.out.println();
            System.out.printf("Adversarial input cases: %d%n", inputCases);
            System.out.printf("Adversarial approximation evaluations: %d%n", approximationEvaluations);
            System.out.println();
            System.out.println("Overall max relative errors:");
            for (MaxError maxError : overall) {
                System.out.printf("  %-8s max=%.3e  worst=%s%n",
                        maxError.name, maxError.value, maxError.description);
            }

            System.out.println();
            System.out.println("Category max relative errors:");
            System.out.printf("  %-18s %6s", "category", "cases");
            for (ApproximationCase approximation : APPROXIMATIONS) {
                System.out.printf(" %10s", shortName(approximation.name));
            }
            System.out.println();
            for (Map.Entry<String, CategoryStats> entry : categories.entrySet()) {
                CategoryStats stats = entry.getValue();
                System.out.printf("  %-18s %6d", entry.getKey(), stats.inputCases);
                for (MaxError maxError : stats.maxErrors) {
                    System.out.printf(" %10.3e", maxError.value);
                }
                System.out.println();
            }
        }

        void assertWithinTolerance() {
            for (MaxError maxError : overall) {
                if (maxError.value > MAX_RELATIVE_ERROR) {
                    throw new AssertionError(maxError.name + " exceeded tolerance: " + maxError.value
                            + " at " + maxError.description);
                }
            }
        }

        private CategoryStats categoryStats(String category) {
            CategoryStats stats = categories.get(category);
            if (stats == null) {
                stats = new CategoryStats();
                categories.put(category, stats);
            }
            return stats;
        }

        private static String shortName(String name) {
            return name.replace("Config ", "C").replace("LFK-4", "LFK4");
        }
    }

    private static final class CategoryStats {
        final MaxError[] maxErrors = new MaxError[APPROXIMATIONS.length];
        int inputCases;

        CategoryStats() {
            for (int index = 0; index < maxErrors.length; index++) {
                maxErrors[index] = new MaxError(APPROXIMATIONS[index].name);
            }
        }
    }

    private static final class EtaBranchReport {
        int samples;
        double maxAbsError;
        double worstZ;
        double boundaryJump;

        void add(double z, double absError) {
            samples++;
            if (absError > maxAbsError) {
                maxAbsError = absError;
                worstZ = z;
            }
        }
    }

    private static final class MaxError {
        final String name;
        double value;
        String description = "";

        MaxError(String name) {
            this.name = name;
        }

        void add(double relativeError, String errorDescription) {
            if (relativeError > value) {
                value = relativeError;
                description = errorDescription;
            }
        }
    }
}
