use flash_iv_rs::{black, FlashIV, IvError, IvResult, JaeckelSolver, StrontiumIV, ThiopheneIV};

const DEFAULT_ALLOWED_REL: f64 = 1e-8;
const STRICT_REPORT_REL: f64 = 1e-10;
const STRONTIUM_UPPER_ALLOWED_REL: f64 = 2e-7;
const BACHELIER_BOUNDARY_ALLOWED_REL: f64 = 2e-2;
const STRICT_NEAR_ONE_REL: f64 = 1e-12;
const MIN_RESOLVABLE_GAP: f64 = 1e-12;

type SolveFn = fn(f64, f64, f64, f64, f64) -> f64;
type SolvePolishFn = fn(f64, f64, f64, f64, f64, bool) -> f64;
type PriceFn = fn(bool, f64, f64, f64, f64, f64) -> IvResult<f64>;
type PricePolishFn = fn(bool, f64, f64, f64, f64, f64, bool) -> IvResult<f64>;

#[derive(Clone, Debug)]
struct Case {
    category: String,
    x: f64,
    ex: f64,
    c: f64,
    log_c: f64,
    tte: f64,
    sigma: f64,
}

#[derive(Clone, Copy)]
struct Solver {
    name: &'static str,
    solve: SolveFn,
    solve_polish: SolvePolishFn,
    normalised: fn(f64, f64, f64) -> IvResult<f64>,
    normalised_polish: fn(f64, f64, f64, bool) -> IvResult<f64>,
    price: PriceFn,
    price_polish: PricePolishFn,
}

fn solvers() -> [Solver; 3] {
    [
        Solver {
            name: "FlashIV",
            solve: FlashIV::solve,
            solve_polish: FlashIV::solve_with_jaeckel,
            normalised: FlashIV::implied_volatility_from_normalised_price,
            normalised_polish: FlashIV::implied_volatility_from_normalised_price_with_jaeckel,
            price: FlashIV::implied_volatility,
            price_polish: FlashIV::implied_volatility_with_jaeckel,
        },
        Solver {
            name: "StrontiumIV",
            solve: StrontiumIV::solve,
            solve_polish: StrontiumIV::solve_with_jaeckel,
            normalised: StrontiumIV::implied_volatility_from_normalised_price,
            normalised_polish: StrontiumIV::implied_volatility_from_normalised_price_with_jaeckel,
            price: StrontiumIV::implied_volatility,
            price_polish: StrontiumIV::implied_volatility_with_jaeckel,
        },
        Solver {
            name: "ThiopheneIV",
            solve: ThiopheneIV::solve,
            solve_polish: ThiopheneIV::solve_with_jaeckel,
            normalised: ThiopheneIV::implied_volatility_from_normalised_price,
            normalised_polish: ThiopheneIV::implied_volatility_from_normalised_price_with_jaeckel,
            price: ThiopheneIV::implied_volatility,
            price_polish: ThiopheneIV::implied_volatility_with_jaeckel,
        },
    ]
}

#[test]
fn standalone_branch_and_adversarial_coverage() {
    let cases = build_cases();
    assert!(!cases.is_empty());

    for solver in solvers() {
        let mut worst_rel = 0.0;
        let mut worst: Option<(&Case, f64)> = None;
        let mut bad_allowed = 0;
        let mut bad_strict = 0;
        let mut non_finite = 0;

        for case in &cases {
            let actual = (solver.solve)(case.x, case.ex, case.c, case.log_c, case.tte);
            let rel = if actual.is_finite() {
                (actual - case.sigma).abs() / case.sigma.abs().max(1e-300)
            } else {
                f64::INFINITY
            };
            if !actual.is_finite() {
                non_finite += 1;
            }
            if rel > allowed_relative_error(solver.name, &case.category) {
                bad_allowed += 1;
            }
            if rel > STRICT_REPORT_REL {
                bad_strict += 1;
            }
            if rel > worst_rel {
                worst_rel = rel;
                worst = Some((case, actual));
            }
        }

        if non_finite != 0 || bad_allowed != 0 {
            let (case, actual) = worst.expect("worst case");
            panic!(
                "{} branch coverage failed: non_finite={} bad_allowed={} bad_strict={} max_rel={:.3e} worst_category={} x={:.17e} c={:.17e} log_c={:.17e} tte={:.17e} expected={:.17e} actual={:.17e}",
                solver.name,
                non_finite,
                bad_allowed,
                bad_strict,
                worst_rel,
                case.category,
                case.x,
                case.c,
                case.log_c,
                case.tte,
                case.sigma,
                actual
            );
        }
    }
}

#[test]
fn jaeckel_beta_space_and_forward_adapters_round_trip() {
    let cases = build_cases();
    assert!(!cases.is_empty());

    for case in &cases {
        let beta = case.c * case.ex.sqrt();
        let beta_space =
            JaeckelSolver::implied_volatility_from_normalised_price(beta, case.x, case.tte)
                .unwrap();
        assert_close(
            "JaeckelSolver",
            &format!("beta-space {}", case.category),
            beta_space,
            case.sigma,
            DEFAULT_ALLOWED_REL,
        );

        let forward_adapter = JaeckelSolver::solve(case.x, case.ex, case.c, case.log_c, case.tte);
        assert_close(
            "JaeckelSolver",
            &format!("forward-adapter {}", case.category),
            forward_adapter,
            case.sigma,
            DEFAULT_ALLOWED_REL,
        );
    }
}

#[test]
fn normalised_api_guards_match_java_reference() {
    for solver in solvers() {
        for ex in [1.0_f64, 0.5, 1e-8] {
            assert_eq!(
                (solver.normalised)(1.0, ex, 1.0),
                Err(IvError::PriceOutOfRange)
            );
        }
        assert_eq!((solver.normalised)(0.0, 1.0, 1.0), Ok(f64::EPSILON));
        assert_eq!(
            (solver.normalised)(0.1, 1.0, 0.0),
            Err(IvError::NonPositiveExpiry)
        );
    }
}

#[test]
fn full_price_api_round_trips_reference_cases() {
    struct PriceCase {
        name: &'static str,
        is_call: bool,
        strike: f64,
        sigma: f64,
        tte: f64,
    }

    let cases = [
        PriceCase {
            name: "OTM call",
            is_call: true,
            strike: 130.0,
            sigma: 0.35,
            tte: 1.0,
        },
        PriceCase {
            name: "ITM call",
            is_call: true,
            strike: 70.0,
            sigma: 0.25,
            tte: 2.0,
        },
        PriceCase {
            name: "OTM put",
            is_call: false,
            strike: 70.0,
            sigma: 0.45,
            tte: 0.5,
        },
        PriceCase {
            name: "ITM put",
            is_call: false,
            strike: 130.0,
            sigma: 0.30,
            tte: 3.0,
        },
        PriceCase {
            name: "near ATM call",
            is_call: true,
            strike: 100.01,
            sigma: 0.05,
            tte: 0.01,
        },
        PriceCase {
            name: "near ATM put",
            is_call: false,
            strike: 99.99,
            sigma: 0.05,
            tte: 0.01,
        },
    ];

    let forward = 100.0;
    let spot = 100.0;
    let drift_df = 1.0;
    let df = 1.0;

    for solver in solvers() {
        for case in &cases {
            let total_variance = case.sigma * case.sigma * case.tte;
            let price = black::price_accurate(
                case.is_call,
                case.strike,
                spot,
                total_variance,
                drift_df,
                df,
            );
            let actual =
                (solver.price)(case.is_call, price, forward, case.strike, case.tte, df).unwrap();
            let rel = (actual - case.sigma).abs() / case.sigma;
            assert!(
                rel <= DEFAULT_ALLOWED_REL,
                "{} price API failed on {}: actual={:.17e} expected={:.17e} rel={:.3e}",
                solver.name,
                case.name,
                actual,
                case.sigma,
                rel
            );
        }
    }

    for case in &cases {
        let total_variance = case.sigma * case.sigma * case.tte;
        let price = black::price_accurate(
            case.is_call,
            case.strike,
            spot,
            total_variance,
            drift_df,
            df,
        );
        let actual = JaeckelSolver::implied_volatility(
            case.is_call,
            price,
            forward,
            case.strike,
            case.tte,
            df,
        )
        .unwrap();
        let rel = (actual - case.sigma).abs() / case.sigma;
        assert!(
            rel <= DEFAULT_ALLOWED_REL,
            "JaeckelSolver price API failed on {}: actual={:.17e} expected={:.17e} rel={:.3e}",
            case.name,
            actual,
            case.sigma,
            rel
        );
    }
}

#[test]
fn polish_api_overloads_match_reference_behavior() {
    let x = -0.7_f64;
    let ex = x.exp();
    let tte: f64 = 2.0;
    let sigma = 0.42;
    let total_vol = sigma * tte.sqrt();
    let c = black::forward_normalised_black_call(x, total_vol);
    let log_c = c.ln();

    for solver in solvers() {
        let base = (solver.solve)(x, ex, c, log_c, tte);
        let explicit_unpolished = (solver.solve_polish)(x, ex, c, log_c, tte, false);
        assert_eq!(
            base.to_bits(),
            explicit_unpolished.to_bits(),
            "{} false polish overload differs",
            solver.name
        );

        let polished = (solver.solve_polish)(x, ex, c, log_c, tte, true);
        assert_close(
            solver.name,
            "direct polish",
            polished,
            sigma,
            DEFAULT_ALLOWED_REL,
        );

        let normalised_polished = (solver.normalised_polish)(c, ex, tte, true).unwrap();
        assert_close(
            solver.name,
            "normalised polish",
            normalised_polished,
            sigma,
            DEFAULT_ALLOWED_REL,
        );

        let forward = 100.0;
        let strike = forward / ex;
        let total_variance = sigma * sigma * tte;
        let price = black::price_accurate(true, strike, forward, total_variance, 1.0, 1.0);
        let price_polished =
            (solver.price_polish)(true, price, forward, strike, tte, 1.0, true).unwrap();
        assert_close(
            solver.name,
            "price polish",
            price_polished,
            sigma,
            DEFAULT_ALLOWED_REL,
        );
    }
}

#[test]
fn upper_direct_polish_guards_match_java_reference() {
    let x = -1.207_415_148_516_909_f64;
    let ex = x.exp();
    let c = 0.991_606_352_361_731_6_f64;
    let log_c = c.ln();
    let tte = 1.0;
    let reference_total_vol = 5.656_854_249_492_381;

    for solver in [solvers()[0], solvers()[1]] {
        let base = (solver.solve_polish)(x, ex, c, log_c, tte, false);
        let plus = (solver.solve_polish)(x, ex, c, log_c, tte, true);
        assert_eq!(
            base.to_bits(),
            plus.to_bits(),
            "{}+ upper direct polish guard changed",
            solver.name
        );
        let ulps = (base - reference_total_vol).abs() / ulp(reference_total_vol);
        assert!(
            ulps <= 10.0,
            "{} upper log-gap guard lost accuracy: ulps={ulps}",
            solver.name
        );
    }

    let x = -1e-6_f64;
    let ex = x.exp();
    let c = 0.9999_f64;
    let log_c = c.ln();
    let base = ThiopheneIV::solve_with_jaeckel(x, ex, c, log_c, 1.0, false);
    let plus = ThiopheneIV::solve_with_jaeckel(x, ex, c, log_c, 1.0, true);
    assert_eq!(
        base.to_bits(),
        plus.to_bits(),
        "ThiopheneIV+ upper-half direct polish guard changed"
    );
}

#[test]
fn tiny_near_atm_bachelier_boundary_coverage() {
    let mut cases = Vec::new();

    for x in [-1e-9_f64, -5e-9, -1e-8, -1e-10, -1e-12, -1e-14] {
        for c_target in [1e-7_f64, 5e-7, 1e-6, 1e-8, 1e-10, 1e-20, 1e-40, 1e-80] {
            add_bachelier_reference_case(&mut cases, x, c_target);
        }
    }
    for x in [-5e-9_f64, -1e-9] {
        for c_target in [1.01e-6_f64, 1.1e-6, 2e-6, 5e-6, 1e-5] {
            add_bachelier_reference_case(&mut cases, x, c_target);
        }
    }
    for x in [-1.01e-8_f64, -1.1e-8, -2e-8, -5e-8, -1e-7, -1e-6] {
        for c_target in [5e-7_f64, 1e-7] {
            add_bachelier_reference_case(&mut cases, x, c_target);
        }
    }

    assert!(!cases.is_empty());
    for solver in solvers() {
        for case in &cases {
            let actual = (solver.solve)(case.x, case.ex, case.c, case.log_c, case.tte);
            assert_close(
                solver.name,
                &case.category,
                actual,
                case.sigma,
                allowed_relative_error(solver.name, &case.category),
            );
        }
    }
}

#[test]
fn flash_near_one_complementary_gap_accuracy() {
    let cases = near_one_cases();
    assert!(!cases.is_empty());

    for polish in [false, true] {
        let mut worst_rel = 0.0;
        let mut worst: Option<(&Case, f64)> = None;
        for case in &cases {
            let actual =
                FlashIV::solve_with_jaeckel(case.x, case.ex, case.c, case.log_c, 1.0, polish);
            let rel = (actual - case.sigma).abs() / case.sigma.abs().max(1e-300);
            if rel > worst_rel {
                worst_rel = rel;
                worst = Some((case, actual));
            }
            assert!(
                actual.is_finite(),
                "FlashIV near-one returned non-finite value"
            );
            assert!(
                rel <= STRICT_NEAR_ONE_REL,
                "FlashIV near-one polish={polish} failed: x={:.17e} c={:.17e} expected={:.17e} actual={:.17e} rel={:.3e}",
                case.x,
                case.c,
                case.sigma,
                actual,
                rel
            );
        }
        if let Some((case, actual)) = worst {
            assert!(
                worst_rel <= STRICT_NEAR_ONE_REL,
                "worst near-one polish={polish}: x={} c={} expected={} actual={} rel={}",
                case.x,
                case.c,
                case.sigma,
                actual,
                worst_rel
            );
        }
    }
}

fn build_cases() -> Vec<Case> {
    let mut cases = Vec::new();

    for x in [
        0.0_f64, -1e-12, -1e-8, -1e-5, -1e-3, -0.01, -0.05, -0.2, -0.5, -1.0, -2.0, -4.0,
    ] {
        for v in [1e-4_f64, 1e-3, 0.01, 0.05, 0.2, 1.0, 2.5, 5.0] {
            add_from_total_vol(&mut cases, category_for_grid_case(x, v), x, v, 1.0);
        }
    }

    for x in [-3.0_f64, -4.0, -8.0, -12.0, -20.0, -50.0] {
        for v in [0.05_f64, 0.1, 0.5, 1.0, 3.0, 8.0] {
            add_from_total_vol(&mut cases, "deep-otm", x, v, 1.0);
        }
    }

    for x in [
        -2.999999_f64,
        -3.0,
        -3.000001,
        -0.010000001,
        -0.01,
        -0.009999999,
    ] {
        for c in [0.000499_f64, 0.0005, 0.000501, 0.998999, 0.9990, 0.9995] {
            add_from_price(&mut cases, "dispatch-boundary", x, c, 1.0);
        }
    }

    for x in [0.0_f64, -1e-12, -1e-10, -1e-8] {
        for c in [1e-8_f64, 1e-7, 1e-6] {
            add_from_price(&mut cases, "tiny-near-atm-central", x, c, 1.0);
        }
    }

    add_high_precision_corner_cases(&mut cases);

    for x in [0.0_f64, -1e-14, -1e-12, -1e-10, -1e-8, -1e-6, -1e-4, -0.01] {
        for c in [0.9990_f64, 0.9999, 0.999999, 0.999999999] {
            add_from_price(&mut cases, "upper-price", x, c, 1.0);
        }
    }

    for tte in [1e-4_f64, 0.01, 2.0, 30.0] {
        add_from_total_vol(&mut cases, "maturity-scaling", -0.2, 0.35 * tte.sqrt(), tte);
        add_from_total_vol(&mut cases, "maturity-scaling", -2.0, 1.2 * tte.sqrt(), tte);
        add_from_price(&mut cases, "maturity-scaling", -1e-10, 0.9999, tte);
    }

    cases
}

fn category_for_grid_case(x: f64, v: f64) -> &'static str {
    if x.abs() <= 1e-8 && v <= 1e-5 {
        "tiny-near-atm-central"
    } else if v >= 5.0 && x.abs() <= 0.01 {
        "upper-price"
    } else {
        "regular-grid"
    }
}

fn add_from_total_vol(cases: &mut Vec<Case>, category: &str, x: f64, total_vol: f64, tte: f64) {
    let log_c = black::log_normalised_black_call(x, total_vol);
    add_case(cases, category, x, log_c, tte, total_vol / tte.sqrt());
}

fn add_from_price(cases: &mut Vec<Case>, category: &str, x: f64, c: f64, tte: f64) {
    if !(c > 0.0) || !(c < 1.0) || !c.is_finite() {
        return;
    }
    let total_vol = if c >= 0.9990 {
        total_vol_for_upper_price(x, c)
    } else {
        total_vol_for_log_price(x, c.ln())
    };
    add_case(cases, category, x, c.ln(), tte, total_vol);
}

fn add_high_precision_corner_cases(cases: &mut Vec<Case>) {
    for (index, line) in include_str!("../reference-test/high-precision-corners.csv")
        .lines()
        .enumerate()
    {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let fields: Vec<_> = line.splitn(7, ',').collect();
        assert!(
            fields.len() >= 6,
            "malformed high-precision row {}",
            index + 1
        );
        let category = fields[0];
        let x: f64 = fields[1].parse().unwrap();
        let c: f64 = fields[2].parse().unwrap();
        let log_c: f64 = fields[3].parse().unwrap();
        let sigma: f64 = fields[4].parse().unwrap();
        let tte: f64 = fields[5].parse().unwrap();
        let ex = x.exp();
        if c > 0.0 && c < 1.0 && ex > 0.0 {
            cases.push(Case {
                category: category.to_string(),
                x,
                ex,
                c,
                log_c,
                tte,
                sigma,
            });
        }
    }
}

fn add_case(cases: &mut Vec<Case>, category: &str, x: f64, log_c: f64, tte: f64, sigma: f64) {
    if !(x <= 0.0) || !x.is_finite() || !log_c.is_finite() || !(log_c < 0.0) {
        return;
    }
    let c = log_c.exp();
    let ex = x.exp();
    if !(c > 0.0) || !(c < 1.0) || !(ex > 0.0) || !sigma.is_finite() || !(sigma > 0.0) {
        return;
    }
    if category != "upper-price" && category != "dispatch-boundary" && c >= 0.9990 {
        return;
    }
    cases.push(Case {
        category: category.to_string(),
        x,
        ex,
        c,
        log_c,
        tte,
        sigma,
    });
}

fn total_vol_for_log_price(x: f64, log_c: f64) -> f64 {
    let mut low = 0.0;
    let mut high = (2.0 * x.abs()).sqrt().max(1e-6) + 1e-6;
    for _ in 0..160 {
        let high_log = black::log_normalised_black_call(x, high);
        if high_log.is_finite() && high_log >= log_c {
            break;
        }
        high *= 2.0;
        if !high.is_finite() || high > 4096.0 {
            return f64::NAN;
        }
    }
    if !(black::log_normalised_black_call(x, high) >= log_c) {
        return f64::NAN;
    }
    for _ in 0..180 {
        let mid = 0.5 * (low + high);
        let mid_log = black::log_normalised_black_call(x, mid);
        if mid_log.is_finite() && mid_log >= log_c {
            high = mid;
        } else {
            low = mid;
        }
    }
    high
}

fn total_vol_for_upper_price(x: f64, c: f64) -> f64 {
    let target_gap = 1.0 - c;
    if !(target_gap > 0.0) || !target_gap.is_finite() {
        return f64::NAN;
    }
    let mut low = 0.0;
    let mut high = 1.0;
    for _ in 0..160 {
        let high_gap = black::upper_price_gap(x, high);
        if high_gap.is_finite() && high_gap <= target_gap {
            break;
        }
        high *= 2.0;
        if !high.is_finite() || high > 4096.0 {
            return f64::NAN;
        }
    }
    if !(black::upper_price_gap(x, high) <= target_gap) {
        return f64::NAN;
    }
    for _ in 0..180 {
        let mid = 0.5 * (low + high);
        let gap = black::upper_price_gap(x, mid);
        if gap.is_finite() && gap <= target_gap {
            high = mid;
        } else {
            low = mid;
        }
    }
    high
}

fn add_bachelier_reference_case(cases: &mut Vec<Case>, x: f64, c_target: f64) {
    if !(c_target > 0.0) || !(c_target < 1.0) {
        return;
    }
    let log_target = c_target.ln();
    let v_ref = bisection_solve_log_c(x, log_target);
    if !v_ref.is_finite() || !(v_ref > 0.0) {
        return;
    }
    let log_c = black::log_normalised_black_call(x, v_ref);
    let c = log_c.exp();
    if !(c > 0.0) || ((c - c_target).abs() / c_target) > 0.01 {
        return;
    }
    cases.push(Case {
        category: "tiny-near-atm-boundary".to_string(),
        x,
        ex: x.exp(),
        c,
        log_c,
        tte: 1.0,
        sigma: v_ref,
    });
}

fn bisection_solve_log_c(x: f64, log_target: f64) -> f64 {
    let mut low = 1e-320;
    let mut high = 10.0;
    for _ in 0..100 {
        let high_log = black::log_normalised_black_call(x, high);
        if high_log.is_finite() && high_log >= log_target {
            break;
        }
        high *= 2.0;
        if high > 1e6 {
            return f64::NAN;
        }
    }
    for _ in 0..100 {
        let low_log = black::log_normalised_black_call(x, low);
        if !low_log.is_finite() || low_log <= log_target {
            break;
        }
        low *= 0.5;
        if low < 1e-320 {
            break;
        }
    }
    for _ in 0..200 {
        let mid = 0.5 * (low + high);
        if mid == low || mid == high {
            break;
        }
        let mid_log = black::log_normalised_black_call(x, mid);
        if mid_log.is_finite() && mid_log >= log_target {
            high = mid;
        } else {
            low = mid;
        }
    }
    high
}

fn near_one_cases() -> Vec<Case> {
    let mut cases = Vec::new();
    let xs = [
        0.0_f64, -1e-14, -1e-12, -1e-10, -1e-8, -1e-6, -1e-4, -1e-3, -1e-2,
    ];
    let total_vols = [
        2.0_f64, 3.0, 4.0, 6.0, 8.0, 10.0, 12.0, 16.0, 24.0, 32.0, 48.0,
    ];
    for x in xs {
        for total_vol in total_vols {
            let gap = black::upper_price_gap(x, total_vol);
            if gap > 0.0 && gap < 1.0 && gap.is_finite() {
                let c = 1.0 - gap;
                add_near_one_case(&mut cases, x, c, reference_vol_for_rounded_price(x, c));
            }
        }
    }

    for x in xs {
        for c in [0.9990_f64, 0.9999, 0.999999, 0.999999999, 0.999999999999] {
            add_near_one_case(&mut cases, x, c, reference_vol_for_rounded_price(x, c));
        }
    }
    cases
}

fn add_near_one_case(cases: &mut Vec<Case>, x: f64, c: f64, true_vol: f64) {
    let gap = 1.0 - c;
    if c >= 0.9990
        && c < 1.0
        && gap >= MIN_RESOLVABLE_GAP
        && true_vol > 0.0
        && c.is_finite()
        && true_vol.is_finite()
    {
        cases.push(Case {
            category: "upper-price".to_string(),
            x,
            ex: x.exp(),
            c,
            log_c: c.ln(),
            tte: 1.0,
            sigma: true_vol,
        });
    }
}

fn reference_vol_for_rounded_price(x: f64, c: f64) -> f64 {
    let target_gap = 1.0 - c;
    let mut low = 0.0;
    let mut high = 1.0;
    for _ in 0..80 {
        let gap = black::upper_price_gap(x, high);
        if gap.is_finite() && gap <= target_gap {
            break;
        }
        high *= 2.0;
        if !high.is_finite() || high > 2048.0 {
            return f64::NAN;
        }
    }
    for _ in 0..200 {
        let mid = 0.5 * (low + high);
        let gap = black::upper_price_gap(x, mid);
        if gap.is_finite() && gap <= target_gap {
            high = mid;
        } else {
            low = mid;
        }
    }
    high
}

fn allowed_relative_error(solver: &str, category: &str) -> f64 {
    if category == "tiny-near-atm-boundary" {
        BACHELIER_BOUNDARY_ALLOWED_REL
    } else if solver == "StrontiumIV" && category == "upper-price" {
        STRONTIUM_UPPER_ALLOWED_REL
    } else {
        DEFAULT_ALLOWED_REL
    }
}

fn assert_close(solver: &str, context: &str, actual: f64, expected: f64, rel_tol: f64) {
    let rel = (actual - expected).abs() / expected.abs().max(1e-300);
    assert!(
        actual.is_finite() && rel <= rel_tol,
        "{solver} {context} failed: actual={actual:.17e} expected={expected:.17e} rel={rel:.3e} tol={rel_tol:.3e}"
    );
}

fn ulp(x: f64) -> f64 {
    if !x.is_finite() {
        return f64::NAN;
    }
    if x == 0.0 {
        return f64::from_bits(1);
    }
    let bits = x.to_bits();
    let next = if x > 0.0 {
        f64::from_bits(bits + 1)
    } else {
        f64::from_bits(bits - 1)
    };
    (next - x).abs()
}
