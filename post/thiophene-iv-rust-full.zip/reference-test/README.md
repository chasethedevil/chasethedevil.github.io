# Rust Reference Tests

This directory mirrors the standalone Java regression coverage in
`java-benchmark/reference-test` for the Rust crate.

The Cargo integration tests live in `../tests/reference_tests.rs` and cover:

- branch and adversarial grids for `FlashIV`, `StrontiumIV`, and `ThiopheneIV`
- beta-space and forward-adapter coverage for `JaeckelSolver`
- normalized API guards and full option-price APIs
- optional Jaeckel/Newton polish API behavior
- tiny near-ATM Bachelier boundary cases
- FlashIV saturated upper-price complementary-gap accuracy
- high-precision corner rows from `high-precision-corners.csv`

Run from `rust-iv/`:

```bash
cargo test --test reference_tests
cargo test --release --test reference_tests
```

Run the full crate suite:

```bash
cargo test
cargo test --release
```

The large Java `paper-multiprecision-prices.csv` fixture is not duplicated here;
the Rust reference tests generate their branch grids directly and keep only the
small high-precision corner CSV. The release-mode paper comparison binary reads
the Java fixture from the sibling `java-benchmark` folder by default:

```bash
cargo run --release --bin paper_compare -- --runs=100
```

Use `--accuracy-only`, `--timing-only`, or `--details` to narrow the paper
comparison output.

See `jaeckel-crate-and-erfcx-backends.md` for the public `jaeckel` crate API
verification and paper-grid comparison.
See `erfcx-cody-commons-johnson.md` for the focused Cody, Commons-style, and
Johnson/Faddeeva erfcx comparison that motivated making the Commons-style port
the production backend.
See `black-formula-erfcx-erfc-backends.md` for the corresponding normalized
Black formula comparison across erfcx backends, direct erfc, and production
Jaeckel Region I/II routing.

