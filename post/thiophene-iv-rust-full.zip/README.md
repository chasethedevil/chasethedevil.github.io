# Flash IV Rust Ports

This crate contains Rust ports of the standalone Java reference solvers in
`java-benchmark/reference`:

- `FlashIV`
- `StrontiumIV`
- `ThiopheneIV`
- `JaeckelSolver`

The `FlashIV`, `StrontiumIV`, and `ThiopheneIV` public APIs work on the same
normalized OTM-call convention used by the Java references: `ex = F*/K* <= 1`,
`x = ln(ex) <= 0`, and `c = OTM call price / F*`.

The shared Black helpers also keep the Java distinction between beta-space and
solver-space prices:

- `black::normalised_black_call(x, s)` returns the `sqrt(F*K)`-normalized beta.
- `black::log_normalised_black_call(x, s)` and
  `black::forward_normalised_black_call(x, s)` return the forward-normalized
  solver price.

The implementation ports the Java fast H3 path, tiny near-ATM Bachelier guard,
saturated upper-price log-gap polish, and stable Cody/Jaeckel beta-space price
dispatch used by the optional Newton polish and full price APIs. The production
special-function path uses the local Apache Commons Numbers-style `erfcx` port,
which best matched the Java reference behavior in the paper-grid and corner-case
comparisons.

`JaeckelSolver` ports the full Java Lets-Be-Rational baseline. Its Java-compatible
`implied_volatility_from_normalised_price` method takes the beta-space price
`beta = c * sqrt(ex)`, matching `JaeckelSolver.java`. The Rust-only `solve`
adapter accepts the forward-normalized `c` convention so it can be benchmarked
beside the other solvers.

## Build

```bash
cargo test
cargo test --release
cargo test --test reference_tests
cargo test --release --test reference_tests
cargo fmt -- --check
```

The Rust reference-test notes and the high-precision corner fixture are under
`reference-test/`. The Cargo integration tests that mirror the lightweight Java
standalone suites are in `tests/reference_tests.rs`.

The paper comparison harness reads the Java multiprecision CSV by default when
the repository layout is unchanged:

```bash
cargo run --release --bin paper_compare -- --runs=100
```

Use `--accuracy-only`, `--timing-only`, `--details`, or
`--csv=/path/to/paper-multiprecision-prices.csv` to narrow the run. Historical
backend and public-crate comparison notes are under `reference-test/`.

## Example

```rust
use flash_iv_rs::{black, FlashIV};

let x = -0.10;
let ex = x.exp();
let total_vol = 0.20;
let c = black::forward_normalised_black_call(x, total_vol);
let sigma = FlashIV::implied_volatility_from_normalised_price(c, ex, 1.0)?;
# Ok::<(), flash_iv_rs::IvError>(())
```

