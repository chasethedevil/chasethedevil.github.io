use crate::math::{erfc_value, erfcx_value, erfinv_value, norm_inv};
use crate::{IvError, IvResult};

pub struct JaeckelSolver;

const DEFAULT_ITERATIONS: usize = 2;
const SQRT_PI_OVER_TWO: f64 = 1.253_314_137_315_500_3;
const SQRT_THREE: f64 = 1.732_050_807_568_877_2;
const SQRT_ONE_OVER_THREE: f64 = 0.577_350_269_189_625_8;
const TWO_PI_OVER_SQRT_27: f64 = 1.209_199_576_156_145_2;
const SQRT_THREE_OVER_CBRT_TWO_PI: f64 = 0.938_643_487_427_383_6;
const PI_OVER_SIX: f64 = std::f64::consts::PI / 6.0;
const LN_TWO_PI: f64 = 1.837_877_066_409_345_3;
const ONE_OVER_SQRT_TWO: f64 = std::f64::consts::FRAC_1_SQRT_2;
const SQRT_TWO: f64 = std::f64::consts::SQRT_2;
const SQRT_TWO_PI: f64 = 2.506_628_274_631_000_2;
const ONE_OVER_SQRT_TWO_PI: f64 = 0.398_942_280_401_432_7;
const SQRT_DBL_MIN: f64 = 1.491_668_146_240_041_3e-154;
const SQRT_DBL_MAX: f64 = 1.340_780_792_994_259_6e154;
const MAX_RATIONAL_CUBIC_PARAM: f64 = 2.0 / (f64::EPSILON * f64::EPSILON);
const MIN_RATIONAL_CUBIC_PARAM: f64 = -(1.0 - 1.490_116_119_384_765_6e-8);
const ETA: f64 = -13.0;
const TAU: f64 = 0.210_224_103_813_428_65;

impl JaeckelSolver {
    pub fn implied_volatility(
        is_call: bool,
        price: f64,
        forward: f64,
        strike: f64,
        tte: f64,
        discount_factor: f64,
    ) -> IvResult<f64> {
        if !(tte > 0.0) {
            return Err(IvError::NonPositiveExpiry);
        }
        if price >= if is_call { forward } else { strike } * discount_factor {
            return Ok(f64::MAX);
        }
        let undiscounted_price = price / discount_factor;
        let mu = if is_call {
            forward - strike
        } else {
            strike - forward
        };
        let beta = if mu > 0.0 {
            undiscounted_price - mu
        } else {
            undiscounted_price
        } / (forward.sqrt() * strike.sqrt());
        let x = -(forward / strike).ln().abs();
        Ok(lets_be_rational(beta, x, DEFAULT_ITERATIONS) / tte.sqrt())
    }

    pub fn implied_volatility_from_normalised_price(beta: f64, x: f64, tte: f64) -> IvResult<f64> {
        Self::implied_volatility_from_normalised_price_with_iterations(
            beta,
            x,
            tte,
            DEFAULT_ITERATIONS,
        )
    }

    pub fn implied_volatility_from_normalized_price(beta: f64, x: f64, tte: f64) -> IvResult<f64> {
        Self::implied_volatility_from_normalised_price(beta, x, tte)
    }

    pub fn implied_volatility_from_normalised_price_with_iterations(
        beta: f64,
        x: f64,
        tte: f64,
        iterations: usize,
    ) -> IvResult<f64> {
        if !(tte > 0.0) {
            return Err(IvError::NonPositiveExpiry);
        }
        Ok(lets_be_rational(beta, -x.abs(), iterations) / tte.sqrt())
    }

    pub fn implied_volatility_from_forward_normalised_price(
        c: f64,
        ex: f64,
        tte: f64,
    ) -> IvResult<f64> {
        if !(tte > 0.0) {
            return Err(IvError::NonPositiveExpiry);
        }
        if c <= 0.0 {
            return Ok(0.0);
        }
        if c >= 1.0 {
            return Err(IvError::PriceOutOfRange);
        }
        let x = ex.ln();
        let beta = c * ex.sqrt();
        Self::implied_volatility_from_normalised_price(beta, x, tte)
    }

    pub fn solve(x: f64, ex: f64, c: f64, _log_c: f64, tte: f64) -> f64 {
        let beta = c * ex.sqrt();
        lets_be_rational(beta, -x.abs(), DEFAULT_ITERATIONS) / tte.sqrt()
    }
}

fn lets_be_rational(beta: f64, theta_x: f64, iterations: usize) -> f64 {
    if beta <= 0.0 {
        return 0.0;
    }
    let b_max = (0.5 * theta_x).exp();
    if beta >= b_max {
        return f64::MAX;
    }
    if theta_x == 0.0 {
        return implied_vol_atm(beta);
    }

    let sqrt_ax = (-theta_x).sqrt();
    let s_c = SQRT_TWO * sqrt_ax;
    let ome = one_minus_erfcx(sqrt_ax);
    let b_c = 0.5 * b_max * ome;

    let mut s_left = f64::MIN_POSITIVE;
    let mut s_right = f64::MAX;
    let s;

    if beta < b_c {
        let s_l = s_c - SQRT_PI_OVER_TWO * ome;
        let b_l = bl_over_bmax(s_c) * b_max;
        if beta < b_l {
            let (f_lower_l, df_l, d2f_l) = compute_f_lower_map_derivs(theta_x, s_l);
            let r_ll = convex_cubic_param_right(0.0, b_l, 0.0, f_lower_l, 1.0, df_l, d2f_l, true);
            let mut f = rational_cubic_interp(beta, 0.0, b_l, 0.0, f_lower_l, 1.0, df_l, r_ll);
            if !(f > 0.0) {
                let t = beta / b_l;
                f = (f_lower_l * t + b_l * (1.0 - t)) * t;
            }
            s = inverse_f_lower_map(theta_x, f);
            s_right = s_l;
            return iterate_lowest_branch(beta, theta_x, s, s_left, s_right, iterations);
        }

        let inv_v_c = SQRT_TWO_PI / b_max;
        let inv_v_l = inv_normalised_vega(theta_x, s_l);
        let r_lm = convex_cubic_param_right(b_l, b_c, s_l, s_c, inv_v_l, inv_v_c, 0.0, false);
        s = rational_cubic_interp(beta, b_l, b_c, s_l, s_c, inv_v_l, inv_v_c, r_lm);
        s_left = s_l;
        s_right = s_c;
    } else {
        let s_u = s_c + SQRT_PI_OVER_TWO * (2.0 - ome);
        let b_u = bu_over_bmax(s_c) * b_max;
        if beta <= b_u {
            let inv_v_c = SQRT_TWO_PI / b_max;
            let inv_v_u = inv_normalised_vega(theta_x, s_u);
            let r_um = convex_cubic_param_left(b_c, b_u, s_c, s_u, inv_v_c, inv_v_u, 0.0, false);
            s = rational_cubic_interp(beta, b_c, b_u, s_c, s_u, inv_v_c, inv_v_u, r_um);
            s_left = s_c;
            s_right = s_u;
        } else {
            let (f_upper_h, df_u, d2f_u) = compute_f_upper_map_derivs(theta_x, s_u);
            let mut f = f64::NEG_INFINITY;
            if d2f_u > -SQRT_DBL_MAX && d2f_u < SQRT_DBL_MAX {
                let r_uu =
                    convex_cubic_param_left(b_u, b_max, f_upper_h, 0.0, df_u, -0.5, d2f_u, true);
                f = rational_cubic_interp(beta, b_u, b_max, f_upper_h, 0.0, df_u, -0.5, r_uu);
            }
            if f <= 0.0 {
                let hh = b_max - b_u;
                let t = (beta - b_u) / hh;
                f = (f_upper_h * (1.0 - t) + 0.5 * hh * t) * (1.0 - t);
            }
            s = inverse_f_upper_map(f);
            s_left = s_u;
            if beta > 0.5 * b_max {
                return iterate_highest_branch_complementary(
                    beta, theta_x, b_max, s, s_left, s_right, iterations,
                );
            }
        }
    }

    iterate_middle_branches(beta, theta_x, s, s_left, s_right, iterations)
}

fn iterate_lowest_branch(
    beta: f64,
    theta_x: f64,
    mut s: f64,
    mut s_left: f64,
    mut s_right: f64,
    iterations: usize,
) -> f64 {
    let mut ds: f64 = 0.0;
    let mut ds_prev: f64 = 0.0;
    let mut dir_rev_count = 0;
    let ln_beta = beta.ln();
    for iter in 0..iterations {
        if ds * ds_prev < 0.0 {
            dir_rev_count += 1;
        }
        if iterations > 3 && iter > 0 && (dir_rev_count == 3 || !(s > s_left && s < s_right)) {
            s = 0.5 * (s_left + s_right);
            if s_right - s_left <= f64::EPSILON * s {
                break;
            }
            dir_rev_count = 0;
            ds = 0.0;
        }
        ds_prev = ds;

        let (bx, ln_vega) = scaled_normalised_black_and_ln_vega(theta_x, s);
        let ln_b = bx.ln() + ln_vega;
        let bpob = 1.0 / bx;
        let b_val = ln_b.exp();
        if b_val > beta && s < s_right {
            s_right = s;
        } else if b_val < beta && s > s_left {
            s_left = s;
        }
        if !(b_val > 0.0 && bpob > 0.0) {
            ds = 0.5 * (s_left + s_right) - s;
        } else {
            let h = theta_x / s;
            let x2s3 = h * h / s;
            let b_h2 = x2s3 - s / 4.0;
            let nu = (ln_beta - ln_b) * ln_b / ln_beta / bpob;
            let lambda = 1.0 / ln_b;
            let otl = 1.0 + 2.0 * lambda;
            let h2 = b_h2 - bpob * otl;
            let c = 3.0 * (x2s3 / s);
            let b_h3 = b_h2 * b_h2 - c - 0.25;
            let sq_bpob = bpob * bpob;
            let bppob = b_h2 * bpob;
            let mu = 6.0 * lambda * (1.0 + lambda);
            let h3 = b_h3 + sq_bpob * (2.0 + mu) - bppob * 3.0 * otl;
            ds = if theta_x < -190.0 {
                let h4 = (b_h2 * (b_h3 - 0.5) - (b_h2 - 2.0 / s) * 2.0 * c)
                    - bpob
                        * (sq_bpob * (6.0 + lambda * (22.0 + lambda * (36.0 + lambda * 24.0)))
                            - bppob * (12.0 + 6.0 * mu))
                    - bppob * b_h2 * 3.0 * otl
                    - b_h3 * bpob * 4.0 * otl;
                nu * householder4_factor(nu, h2, h3, h4)
            } else {
                nu * householder3_factor(nu, h2, h3)
            };
        }
        s += ds;
        if ds.abs() <= f64::EPSILON * s {
            break;
        }
    }
    s
}

fn iterate_highest_branch_complementary(
    beta: f64,
    theta_x: f64,
    b_max: f64,
    mut s: f64,
    mut s_left: f64,
    mut s_right: f64,
    iterations: usize,
) -> f64 {
    let beta_bar = b_max - beta;
    let mut ds: f64 = 0.0;
    let mut ds_prev: f64 = 0.0;
    let mut dir_rev_count = 0;
    for iter in 0..iterations {
        if ds * ds_prev < 0.0 {
            dir_rev_count += 1;
        }
        if iterations > 3 && iter > 0 && (dir_rev_count == 3 || !(s > s_left && s < s_right)) {
            s = 0.5 * (s_left + s_right);
            if s_right - s_left <= f64::EPSILON * s {
                break;
            }
            dir_rev_count = 0;
            ds = 0.0;
        }
        ds_prev = ds;

        let h = theta_x / s;
        let t = 0.5 * s;
        let gp = (2.0 / SQRT_TWO_PI)
            / (erfcx_value((t + h) * ONE_OVER_SQRT_TWO) + erfcx_value((t - h) * ONE_OVER_SQRT_TWO));
        let b_bar = normalised_vega(theta_x, s) / gp;
        if b_bar < beta_bar && s < s_right {
            s_right = s;
        } else if b_bar > beta_bar && s > s_left {
            s_left = s;
        }
        if !(b_bar > f64::MIN_POSITIVE) {
            ds = 0.5 * (s_left + s_right) - s;
        } else {
            let g_val = (beta_bar / b_bar).ln();
            let x2s3 = h * h / s;
            let b_h2 = x2s3 - s / 4.0;
            let c = 3.0 * (x2s3 / s);
            let b_h3 = b_h2 * b_h2 - c - 0.25;
            let nu = -g_val / gp;
            let h2 = b_h2 + gp;
            let h3 = b_h3 + gp * (2.0 * gp + 3.0 * b_h2);
            ds = if theta_x < -580.0 {
                let h4 = (b_h2 * (b_h3 - 0.5) - (b_h2 - 2.0 / s) * 2.0 * c)
                    + gp * (6.0 * gp * (gp + 2.0 * b_h2) + 3.0 * b_h2 * b_h2 + 4.0 * b_h3);
                nu * householder4_factor(nu, h2, h3, h4)
            } else {
                nu * householder3_factor(nu, h2, h3)
            };
        }
        s += ds;
        if ds.abs() <= f64::EPSILON * s {
            break;
        }
    }
    s
}

fn iterate_middle_branches(
    beta: f64,
    theta_x: f64,
    mut s: f64,
    mut s_left: f64,
    mut s_right: f64,
    iterations: usize,
) -> f64 {
    let mut ds: f64 = 0.0;
    let mut ds_prev: f64 = 0.0;
    let mut dir_rev_count = 0;
    for iter in 0..iterations {
        if ds * ds_prev < 0.0 {
            dir_rev_count += 1;
        }
        if iterations > 3 && iter > 0 && (dir_rev_count == 3 || !(s > s_left && s < s_right)) {
            s = 0.5 * (s_left + s_right);
            if s_right - s_left <= f64::EPSILON * s {
                break;
            }
            dir_rev_count = 0;
            ds = 0.0;
        }
        ds_prev = ds;

        let b_val = normalised_black(theta_x, s);
        let inv_bp = inv_normalised_vega(theta_x, s);
        let nu = (beta - b_val) * inv_bp;
        let h = theta_x / s;
        let x2s3 = h * h / s;
        let h2 = x2s3 - s * 0.25;
        let h3 = h2 * h2 - 3.0 * (x2s3 / s) - 0.25;
        if b_val > beta && s < s_right {
            s_right = s;
        } else if b_val < beta && s > s_left {
            s_left = s;
        }
        ds = nu * householder3_factor(nu, h2, h3);
        s += ds;
        if ds.abs() <= f64::EPSILON * s {
            break;
        }
    }
    s
}

fn implied_vol_atm(beta: f64) -> f64 {
    2.0 * SQRT_TWO * erfinv_value(beta)
}

fn householder3_factor(nu: f64, h2: f64, h3: f64) -> f64 {
    (1.0 + 0.5 * h2 * nu) / (1.0 + nu * (h2 + h3 * nu / 6.0))
}

fn householder4_factor(nu: f64, h2: f64, h3: f64, h4: f64) -> f64 {
    (1.0 + nu * (h2 + nu * h3 / 6.0))
        / (1.0 + nu * (1.5 * h2 + nu * (h2 * h2 * 0.25 + h3 / 3.0 + nu * h4 / 24.0)))
}

fn is_region_i(theta_x: f64, s: f64) -> bool {
    theta_x < s * ETA && s * (0.5 * s - (TAU + 0.5 + ETA)) + theta_x < 0.0
}

fn is_region_ii(theta_x: f64, s: f64) -> bool {
    s * (s - 2.0 * TAU) - theta_x / ETA < 0.0
}

fn normalised_black(theta_x: f64, s: f64) -> f64 {
    if theta_x == 0.0 {
        return crate::math::erf_value(0.5 * ONE_OVER_SQRT_TWO * s);
    }
    if s <= 0.0 {
        return 0.0;
    }
    if is_region_i(theta_x, s) {
        return asymptotic_expansion_of_scaled_normalised_black(theta_x / s, 0.5 * s)
            * normalised_vega(theta_x, s);
    }
    if is_region_ii(theta_x, s) {
        return small_t_expansion_of_scaled_normalised_black(theta_x / s, 0.5 * s)
            * normalised_vega(theta_x, s);
    }
    normalised_black_codys(theta_x, s)
}

fn scaled_normalised_black_and_ln_vega(theta_x: f64, s: f64) -> (f64, f64) {
    if is_region_i(theta_x, s) {
        return (
            asymptotic_expansion_of_scaled_normalised_black(theta_x / s, 0.5 * s),
            ln_normalised_vega(theta_x, s),
        );
    }
    if is_region_ii(theta_x, s) {
        return (
            small_t_expansion_of_scaled_normalised_black(theta_x / s, 0.5 * s),
            ln_normalised_vega(theta_x, s),
        );
    }
    let ln_vega = ln_normalised_vega(theta_x, s);
    (
        normalised_black_codys(theta_x, s) * (-ln_vega).exp(),
        ln_vega,
    )
}

fn poly(x: f64, coeffs: &[f64]) -> f64 {
    let mut value = 0.0;
    for &coeff in coeffs {
        value = value * x + coeff;
    }
    value
}

fn asymptotic_expansion_of_scaled_normalised_black(h: f64, t: f64) -> f64 {
    let e = (t / h) * (t / h);
    let r = (h + t) * (h - t);
    let q = (h / r) * (h / r);
    let a0 = 2.0;
    let a1 = poly(e, &[-2.0, -6.0]);
    let a2 = poly(e, &[6.0, 60.0, 30.0]);
    let a3 = poly(e, &[-30.0, -630.0, -1050.0, -210.0]);
    let a4 = poly(e, &[210.0, 7560.0, 26460.0, 17640.0, 1890.0]);
    let coeffs = [
        poly(
            e,
            &[
                -1890.0, -103950.0, -623700.0, -873180.0, -311850.0, -20790.0,
            ],
        ),
        poly(
            e,
            &[
                20790.0, 1621620.0, 14864850.0, 35675640.0, 26756730.0, 5945940.0, 270270.0,
            ],
        ),
        poly(
            e,
            &[
                -270270.0,
                -28378350.0,
                -368918550.0,
                -1352701350.0,
                -1739187450.0,
                -811620810.0,
                -122972850.0,
                -4054050.0,
            ],
        ),
        poly(
            e,
            &[
                4054050.0,
                551350800.0,
                9648639000.0,
                50172922800.0,
                98553955500.0,
                78843164400.0,
                25086461400.0,
                2756754000.0,
                68918850.0,
            ],
        ),
        poly(
            e,
            &[
                -68918850.0,
                -11785123350.0,
                -267129462600.0,
                -1869906238200.0,
                -5209024520700.0,
                -6366585525300.0,
                -3472683013800.0,
                -801388387800.0,
                -66782365650.0,
                -1309458150.0,
            ],
        ),
        poly(
            e,
            &[
                1309458150.0,
                274986211500.0,
                7837107027750.0,
                71056437051600.0,
                266461638943500.0,
                461866840835400.0,
                384889034029500.0,
                152263793682000.0,
                26646163894350.0,
                1741579339500.0,
                27498621150.0,
            ],
        ),
        poly(
            e,
            &[
                -27498621150.0,
                -6957151150950.0,
                -243500290283250.0,
                -2775903309229050.0,
                -13482958930541100.0,
                -31460237504595900.0,
                -37180280687249700.0,
                -22471598217568500.0,
                -6741479465270550.0,
                -925301103076350.0,
                -48700058056650.0,
                -632468286450.0,
            ],
        ),
        poly(
            e,
            &[
                6.3246828645e11,
                1.89740485935e14,
                8.0007238235925e15,
                1.12010133530295e17,
                6.8406188691715875e17,
                2.067387036016302e18,
                3.289024830025935e18,
                2.81916414002223e18,
                1.29211689751018875e18,
                304027505296515000.0,
                33603040059088500.0,
                1454677058835000.0,
                15811707161250.0,
            ],
        ),
        poly(
            e,
            &[
                -1.581170716125e13,
                -5.54990921359875e15,
                -2.774954606799375e17,
                -4.6804234368016125e18,
                -3.51031757760120938e19,
                -1.33392067948845956e20,
                -2.74868503652167425e20,
                -3.17155965752500875e20,
                -2.06151377739125569e20,
                -7.41067044160255312e19,
                -1.40412703104048375e19,
                -1.2764791191277125e18,
                -4.624924344665625e16,
                -4.2691609335375e14,
            ],
        ),
        poly(
            e,
            &[
                4.2691609335375e14,
                1.733279339016225e17,
                1.01396841332449162e19,
                2.02793682664898325e20,
                1.83238577550783129e21,
                8.55113361903654604e21,
                2.2155209831140142e22,
                3.31110828245610914e22,
                2.89721974714909549e22,
                1.47701398874267613e22,
                4.27556680951827302e21,
                6.66322100184665925e20,
                5.06984206662245812e19,
                1.5599514051146025e18,
                1.238056670725875e16,
            ],
        ),
        poly(
            e,
            &[
                -1.238056670725875e16,
                -5.75696351887531875e18,
                -3.89554531443896569e20,
                -9.11557603578717971e21,
                -9.76668860977197826e22,
                -5.49104937393846778e23,
                -1.74715207352587611e24,
                -3.28310994036181115e24,
                -3.72085793241005264e24,
                -2.55352995361474201e24,
                -1.04829124411552567e24,
                -2.49593153360839444e23,
                -3.25556286992399275e22,
                -2.10359446979704147e21,
                -5.56506473491280812e19,
                -3.8379756792502125e17,
            ],
        ),
        poly(
            e,
            &[
                3.8379756792502125e17,
                2.0264511586441122e20,
                1.57049964794918696e22,
                4.25081904711579936e23,
                5.32870530549159134e24,
                3.55247020366106089e25,
                1.36178024473674001e26,
                3.1425697955463231e26,
                4.47816195865351041e26,
                3.98058840769200926e26,
                2.19979885688242617e26,
                7.42789224401858187e25,
                1.48019591819210871e25,
                1.63960163245895118e24,
                9.10889795810528434e22,
                2.09399953059891594e21,
                1.26653197415257012e19,
            ],
        ),
    ];
    let thresholds = [
        12.347, 12.958, 13.729, 14.718, 16.016, 17.769, 20.221, 23.816, 29.419, 38.93, 57.171,
        99.347,
    ];
    let val = -h - t + TAU + 0.5;
    let mut upper_bound = 0;
    while upper_bound < thresholds.len() && thresholds[upper_bound] <= val {
        upper_bound += 1;
    }
    let n_extra = coeffs.len() - upper_bound;
    let mut omega = 0.0;
    for k in (0..n_extra).rev() {
        omega = q * (coeffs[k] + omega);
    }
    omega = a0 + q * (a1 + q * (a2 + q * (a3 + q * (a4 + omega))));
    (t / r) * omega
}

fn y_prime_tail_rational(w: f64) -> f64 {
    w * (-2.9999999999994663866
        + w * (-1.7556263323542206288e2
            + w * (-3.4735035445495633334e3
                + w * (-2.7805745693864308643e4
                    + w * (-8.3836021460741980839e4 - 6.6818249032616849037e4 * w)))))
        / (1.0
            + w * (6.3520877744831739102e1
                + w * (1.4404389037604337538e3
                    + w * (1.4562545638507033944e4
                        + w * (6.6886794165651675684e4
                            + w * (1.2569970380923908488e5 + 6.9286518679803751694e4 * w))))))
}

fn y_prime(h: f64) -> f64 {
    if h < -4.0 {
        let w = 1.0 / (h * h);
        return w * (1.0 + y_prime_tail_rational(w));
    }
    if h <= -0.46875 {
        return (1.0000000000594317229
            - h * (6.1911449879694112749e-1
                - h * (2.2180844736576013957e-1
                    - h * (4.5650900351352987865e-2
                        - h * (5.545521007735379052e-3
                            - h * (3.0717392274913902347e-4
                                - h * (4.2766597835908713583e-8
                                    + 8.4592436406580605619e-10 * h)))))))
            / (1.0
                - h * (1.8724286369589162071
                    - h * (1.5685497236077651429
                        - h * (7.6576489836589035112e-1
                            - h * (2.3677701403094640361e-1
                                - h * (4.6762548903194957675e-2
                                    - h * (5.5290453576936595892e-3
                                        - 3.0822020417927147113e-4 * h)))))));
    }
    1.0 + h * SQRT_PI_OVER_TWO * erfcx_value(-ONE_OVER_SQRT_TWO * h)
}

fn small_t_expansion_of_scaled_normalised_black(h: f64, t: f64) -> f64 {
    let a = y_prime(h);
    let h2 = h * h;
    let t2 = t * t;
    let b0 = 2.0 * a;
    let b1 = (-1.0 + a * (3.0 + h2)) / 3.0;
    let b2 = (-7.0 - h2 + a * (15.0 + h2 * (10.0 + h2))) / 60.0;
    let b3 = (-57.0 + (-18.0 - h2) * h2 + a * (105.0 + h2 * (105.0 + h2 * (21.0 + h2)))) / 2520.0;
    let b4 = (-561.0
        + h2 * (-285.0 + (-33.0 - h2) * h2)
        + a * (945.0 + h2 * (1260.0 + h2 * (378.0 + h2 * (36.0 + h2)))))
        / 181440.0;
    let b5 = (-6555.0
        + h2 * (-4680.0 + h2 * (-840.0 + (-52.0 - h2) * h2))
        + a * (10395.0 + h2 * (17325.0 + h2 * (6930.0 + h2 * (990.0 + h2 * (55.0 + h2))))))
        / 19958400.0;
    let b6 = (-89055.0
        + h2 * (-82845.0 + h2 * (-20370.0 + h2 * (-1926.0 + (-75.0 - h2) * h2)))
        + a * (135135.0
            + h2 * (270270.0
                + h2 * (135135.0 + h2 * (25740.0 + h2 * (2145.0 + h2 * (78.0 + h2)))))))
        / 3113510400.0;
    t * (b0 + t2 * (b1 + t2 * (b2 + t2 * (b3 + t2 * (b4 + t2 * (b5 + b6 * t2))))))
}

fn normalised_black_codys(theta_x: f64, s: f64) -> f64 {
    let h = theta_x / s;
    let t = 0.5 * s;
    let q1 = -ONE_OVER_SQRT_TWO * (h + t);
    let q2 = -ONE_OVER_SQRT_TWO * (h - t);
    let codys_threshold = 0.46875;
    let two_b = if q1 < codys_threshold {
        if q2 < codys_threshold {
            (0.5 * theta_x).exp() * erfc_value(q1) - (-0.5 * theta_x).exp() * erfc_value(q2)
        } else {
            (0.5 * theta_x).exp() * erfc_value(q1)
                - (-0.5 * (h * h + t * t)).exp() * erfcx_value(q2)
        }
    } else if q2 < codys_threshold {
        (-0.5 * (h * h + t * t)).exp() * erfcx_value(q1) - (-0.5 * theta_x).exp() * erfc_value(q2)
    } else {
        (-0.5 * (h * h + t * t)).exp() * (erfcx_value(q1) - erfcx_value(q2))
    };
    (0.5 * two_b).max(0.0)
}

fn normalised_vega(x: f64, s: f64) -> f64 {
    let ax = x.abs();
    if ax <= 0.0 {
        return ONE_OVER_SQRT_TWO_PI * (-0.125 * s * s).exp();
    }
    if s <= 0.0 || s <= ax * SQRT_DBL_MIN {
        return 0.0;
    }
    let h = x / s;
    let t = 0.5 * s;
    ONE_OVER_SQRT_TWO_PI * (-0.5 * (h * h + t * t)).exp()
}

fn inv_normalised_vega(x: f64, s: f64) -> f64 {
    let ax = x.abs();
    if ax <= 0.0 {
        return SQRT_TWO_PI * (0.125 * s * s).exp();
    }
    if s <= 0.0 || s <= ax * SQRT_DBL_MIN {
        return f64::MAX;
    }
    let h = x / s;
    let t = 0.5 * s;
    SQRT_TWO_PI * (0.5 * (h * h + t * t)).exp()
}

fn ln_normalised_vega(x: f64, s: f64) -> f64 {
    if x.abs() <= 0.0 {
        return -0.5 * LN_TWO_PI - 0.125 * s * s;
    }
    if s <= 0.0 {
        return -f64::MAX;
    }
    let h = x / s;
    let t = 0.5 * s;
    -0.5 * LN_TWO_PI - 0.5 * (h * h + t * t)
}

fn one_minus_erfcx(x: f64) -> f64 {
    if x < -0.2 || x > 1.0 / 3.0 {
        return 1.0 - erfcx_value(x);
    }
    x * (1.128379167095512574
        - x * (1.0000000000000002
            + x * (1.1514967181784756
                + x * (0.57689001208873741
                    + x * (0.14069188744609651 + 0.014069285713634565 * x))))
            / (1.0
                + x * (1.9037494962421563
                    + x * (1.5089908593742723
                        + x * (0.62486081658640257
                            + x * (0.1358008134514386 + 0.012463320728346347 * x))))))
}

fn bl_over_bmax(s_c: f64) -> f64 {
    if s_c < 2.6267851073127395 {
        if s_c < 0.7099295739719539 {
            let g = (8.0741072372882856924e-2
                + s_c
                    * (9.8078911786358897272e-2
                        + s_c
                            * (3.9760631445677058375e-2
                                + s_c
                                    * (5.9716928459589189876e-3
                                        + s_c
                                            * (-6.4036399341479799981e-6
                                                + 4.5425102093616062245e-7 * s_c)))))
                / (1.0
                    + s_c
                        * (1.8594977672287664353
                            + s_c
                                * (1.3658801475711790419
                                    + s_c
                                        * (4.6132707108655653215e-1
                                            + 6.1254597049831720643e-2 * s_c))));
            return s_c
                * s_c
                * (0.07560996640296361767172 + s_c * (s_c * g - 0.09672719281339436290858));
        }
        return (1.9795737927598581235e-9
            + s_c
                * (-2.7081288564685588037e-8
                    + s_c
                        * (7.5610142272549044609e-2
                            + s_c
                                * (6.917130174466834016e-2
                                    + s_c
                                        * (2.9537058950963019803e-2
                                            + s_c
                                                * (6.5849252702302307774e-3
                                                    + 6.9711400639834715731e-4 * s_c))))))
            / (1.0
                + s_c
                    * (2.1941448525586579756
                        + s_c
                            * (2.1297103549995181357
                                + s_c
                                    * (1.1571483187179784072
                                        + s_c
                                            * (3.7831622253060456794e-1
                                                + s_c
                                                    * (7.1714862448829349869e-2
                                                        + 6.6361975827861200167e-3 * s_c))))));
    }
    if s_c < 7.348469228349534 {
        return (-9.3325115354837883291e-5
            + s_c
                * (5.3118033972794648837e-4
                    + s_c
                        * (7.4114855448345002595e-2
                            + s_c
                                * (7.4039658186822817454e-2
                                    + s_c
                                        * (3.9225177407687604785e-2
                                            + s_c
                                                * (1.0022913378254090083e-2
                                                    + 1.7012579407246055469e-3 * s_c))))))
            / (1.0
                + s_c
                    * (2.2217238132228132256
                        + s_c
                            * (2.3441816707087403282
                                + s_c
                                    * (1.3912323646271141826
                                        + s_c
                                            * (5.3231258443501838354e-1
                                                + s_c
                                                    * (1.1744005919716101572e-1
                                                        + 1.6195405895930935811e-2 * s_c))))));
    }
    (1.4500072297240603183e-3
        + s_c
            * (-1.5116692485011195757e-3
                + s_c
                    * (7.1682178310936334831e-2
                        + s_c
                            * (3.921610857820463493e-2
                                + s_c
                                    * (2.9342405658628443931e-2
                                        + s_c
                                            * (5.1832526171631521426e-3
                                                + 1.6930208078421474854e-3 * s_c))))))
        / (1.0
            + s_c
                * (1.6176313502305414664
                    + s_c
                        * (1.6823159175281531664
                            + s_c
                                * (8.4878307567372222113e-1
                                    + s_c
                                        * (3.7543742137375791321e-1
                                            + s_c
                                                * (7.126137099644302999e-2
                                                    + 1.6116992546788676159e-2 * s_c))))))
}

fn bu_over_bmax(s_c: f64) -> f64 {
    if s_c < 1.7888543819998317 {
        if s_c < 0.7745966692414833 {
            let g = (-6.063099881233561706e-2
                + s_c
                    * (-8.1011946637120604985e-2
                        + s_c
                            * (-4.2505564862438753828e-2
                                + s_c
                                    * (-8.9880000946868691788e-3
                                        + s_c
                                            * (-7.5603072110443268356e-6
                                                + 4.3879556621540147458e-7 * s_c)))))
                / (1.0
                    + s_c
                        * (1.8400371530721828756
                            + s_c
                                * (1.5709283443886143691
                                    + s_c
                                        * (6.8913245453611400484e-1
                                            + 1.4703173061720980923e-1 * s_c))));
            return 0.7899085945560627246288 + s_c * s_c * (0.0614616805805147403487 + s_c * g);
        }
        return (7.8990944435755287611e-1
            + s_c
                * (-1.2655410534988972886
                    + s_c
                        * (-2.8803040699221003256
                            + s_c
                                * (-2.6936198689113258727
                                    + s_c
                                        * (-1.1213067281643205754
                                            + s_c
                                                * (-2.1277793801691629892e-1
                                                    + 5.1486445905299802703e-6 * s_c))))))
            / (1.0
                + s_c
                    * (-1.6021222722060444448
                        + s_c
                            * (-3.7242680976480704555
                                + s_c
                                    * (-3.2083117718907365085
                                        + s_c
                                            * (-1.2922333835930958583
                                                - 2.3762328334050001161e-1 * s_c)))));
    }
    if s_c < 6.164414002968976 {
        return (7.8990640048967596475e-1
            + s_c
                * (1.5993699253596663678
                    + s_c
                        * (1.6481729039140370242
                            + s_c
                                * (9.8227188109869200166e-1
                                    + s_c
                                        * (3.6313557966186936883e-1
                                            + s_c
                                                * (7.8277036261179606301e-2
                                                    + 9.3404307364538726214e-3 * s_c))))))
            / (1.0
                + s_c
                    * (2.0247407005640401446
                        + s_c
                            * (2.0087454279103740489
                                + s_c
                                    * (1.1627561803056961973
                                        + s_c
                                            * (4.2004672123723823581e-1
                                                + s_c
                                                    * (8.9130862793887234546e-2
                                                        + 1.0436767768858021717e-2 * s_c))))));
    }
    (7.91133825948419359e-1
        + s_c
            * (1.24653733210880042
                + s_c
                    * (1.32747426980537386
                        + s_c
                            * (6.95009705717846778e-1
                                + s_c
                                    * (3.05965944268228457e-1
                                        + s_c
                                            * (6.02200363391352887e-2
                                                + 1.29050244454344842e-2 * s_c))))))
        / (1.0
            + s_c
                * (1.58117486714634672
                    + s_c
                        * (1.60144713247629644
                            + s_c
                                * (8.30040185836882436e-1
                                    + s_c
                                        * (3.53071863813401531e-1
                                            + s_c
                                                * (6.95901684131758475e-2
                                                    + 1.44197580643890011e-2 * s_c))))))
}

fn compute_f_lower_map_derivs(x: f64, s: f64) -> (f64, f64, f64) {
    let ax = x.abs();
    let z = SQRT_ONE_OVER_THREE * ax / s;
    let y = z * z;
    let s2 = s * s;
    let phi_cdf = 0.5 * erfc_value(ONE_OVER_SQRT_TWO * z);
    let phi_pdf = ONE_OVER_SQRT_TWO_PI * (-0.5 * z * z).exp();
    let fpp = PI_OVER_SIX * y / (s2 * s)
        * phi_cdf
        * (8.0 * SQRT_THREE * s * ax + (3.0 * s2 * (s2 - 8.0) - 8.0 * x * x) * phi_cdf / phi_pdf)
        * (2.0 * y + 0.25 * s2).exp();
    let phi2 = phi_cdf * phi_cdf;
    let fp = 2.0 * std::f64::consts::PI * y * phi2 * (y + 0.125 * s * s).exp();
    let f = TWO_PI_OVER_SQRT_27 * ax * (phi2 * phi_cdf);
    (f, fp, fpp)
}

fn compute_f_upper_map_derivs(x: f64, s: f64) -> (f64, f64, f64) {
    let f = 0.5 * erfc_value(0.5 * ONE_OVER_SQRT_TWO * s);
    let w = (x / s) * (x / s);
    let fp = -0.5 * (0.5 * w).exp();
    let fpp = SQRT_PI_OVER_TWO * (w + 0.125 * s * s).exp() * w / s;
    (f, fp, fpp)
}

fn inverse_f_lower_map(x: f64, f: f64) -> f64 {
    let ax = x.abs();
    ax / (SQRT_THREE * norm_inv(SQRT_THREE_OVER_CBRT_TWO_PI * f.cbrt() / ax.cbrt()).abs())
}

fn inverse_f_upper_map(f: f64) -> f64 {
    -2.0 * norm_inv(f)
}

fn rational_cubic_interp(
    x: f64,
    x_l: f64,
    x_r: f64,
    y_l: f64,
    y_r: f64,
    d_l: f64,
    d_r: f64,
    r: f64,
) -> f64 {
    let h = x_r - x_l;
    if h.abs() <= 0.0 {
        return 0.5 * (y_l + y_r);
    }
    let t = (x - x_l) / h;
    if !(r < MAX_RATIONAL_CUBIC_PARAM) {
        return y_r * t + y_l * (1.0 - t);
    }
    let omt = 1.0 - t;
    let t2 = t * t;
    let omt2 = omt * omt;
    (y_r * t2 * t
        + (r * y_r - h * d_r) * t2 * omt
        + (r * y_l + h * d_l) * t * omt2
        + y_l * omt2 * omt)
        / (1.0 + (r - 3.0) * t * omt)
}

fn convex_cubic_param_right(
    x_l: f64,
    x_r: f64,
    y_l: f64,
    y_r: f64,
    d_l: f64,
    d_r: f64,
    d2_r: f64,
    prefer_shape: bool,
) -> f64 {
    let h = x_r - x_l;
    let slope = (y_r - y_l) / h;
    let num = 0.5 * h * d2_r + (d_r - d_l);
    let den = slope - d_l;
    let r = if den.abs() < f64::MIN_POSITIVE {
        if num > 0.0 {
            MAX_RATIONAL_CUBIC_PARAM
        } else {
            MIN_RATIONAL_CUBIC_PARAM
        }
    } else {
        num / den
    };
    r.max(min_rational_cubic_param(d_l, d_r, slope, prefer_shape))
}

fn convex_cubic_param_left(
    x_l: f64,
    x_r: f64,
    y_l: f64,
    y_r: f64,
    d_l: f64,
    d_r: f64,
    d2_l: f64,
    prefer_shape: bool,
) -> f64 {
    let h = x_r - x_l;
    let slope = (y_r - y_l) / h;
    let num = 0.5 * h * d2_l + (d_r - d_l);
    let den = d_r - slope;
    let r = if den.abs() < f64::MIN_POSITIVE {
        if num > 0.0 {
            MAX_RATIONAL_CUBIC_PARAM
        } else {
            MIN_RATIONAL_CUBIC_PARAM
        }
    } else {
        num / den
    };
    r.max(min_rational_cubic_param(d_l, d_r, slope, prefer_shape))
}

fn min_rational_cubic_param(d_l: f64, d_r: f64, slope: f64, prefer_shape: bool) -> f64 {
    let monotonic = d_l * slope >= 0.0 && d_r * slope >= 0.0;
    let convex = d_l <= slope && slope <= d_r;
    let concave = d_l >= slope && slope >= d_r;
    if !monotonic && !convex && !concave {
        return MIN_RATIONAL_CUBIC_PARAM;
    }
    let mut r1 = f64::NEG_INFINITY;
    if monotonic {
        if slope.abs() > f64::MIN_POSITIVE {
            r1 = (d_r + d_l) / slope;
        } else if prefer_shape {
            r1 = MAX_RATIONAL_CUBIC_PARAM;
        }
    }
    let drms = d_r - slope;
    let smdl = slope - d_l;
    let drmdl = d_r - d_l;
    let mut r2 = f64::NEG_INFINITY;
    if convex || concave {
        if smdl.abs() > f64::MIN_POSITIVE && drms.abs() > f64::MIN_POSITIVE {
            r2 = (drmdl / drms).abs().max((drmdl / smdl).abs());
        } else if prefer_shape {
            r2 = MAX_RATIONAL_CUBIC_PARAM;
        }
    } else if monotonic && prefer_shape {
        r2 = MAX_RATIONAL_CUBIC_PARAM;
    }
    MIN_RATIONAL_CUBIC_PARAM.max(r1.max(r2))
}
