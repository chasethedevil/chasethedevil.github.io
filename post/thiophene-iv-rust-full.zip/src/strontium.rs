use crate::black;
use crate::{next_down, IvError, IvResult};

pub struct StrontiumIV;

const MIN_TOTAL_VOL: f64 = 1e-10;
const UPPER_POLISH_GUARD_CUTOFF: f64 = 0.99;
const POLYA_FACTOR: f64 = 2.0 / std::f64::consts::PI;
const SQRT_EPSILON: f64 = 1.490_116_119_384_765_6e-8;

impl StrontiumIV {
    pub fn implied_volatility_from_normalised_price(c: f64, ex: f64, tte: f64) -> IvResult<f64> {
        Self::implied_volatility_from_normalised_price_with_jaeckel(c, ex, tte, false)
    }

    pub fn implied_volatility_from_normalized_price(c: f64, ex: f64, tte: f64) -> IvResult<f64> {
        Self::implied_volatility_from_normalised_price(c, ex, tte)
    }

    pub fn implied_volatility_from_normalised_price_with_jaeckel(
        c: f64,
        ex: f64,
        tte: f64,
        jaeckel_newton_polish: bool,
    ) -> IvResult<f64> {
        if !(tte > 0.0) {
            return Err(IvError::NonPositiveExpiry);
        }
        if c <= 0.0 {
            return Ok(f64::EPSILON);
        }
        if c >= 1.0 {
            return Err(IvError::PriceOutOfRange);
        }
        let x = ex.ln();
        Ok(Self::solve_with_jaeckel(
            x,
            ex,
            c,
            c.ln(),
            tte,
            jaeckel_newton_polish,
        ))
    }

    pub fn implied_volatility_from_normalized_price_with_jaeckel(
        c: f64,
        ex: f64,
        tte: f64,
        jaeckel_newton_polish: bool,
    ) -> IvResult<f64> {
        Self::implied_volatility_from_normalised_price_with_jaeckel(
            c,
            ex,
            tte,
            jaeckel_newton_polish,
        )
    }

    pub fn implied_volatility(
        is_call: bool,
        price: f64,
        forward: f64,
        strike: f64,
        tte: f64,
        discount_factor: f64,
    ) -> IvResult<f64> {
        Self::implied_volatility_with_jaeckel(
            is_call,
            price,
            forward,
            strike,
            tte,
            discount_factor,
            false,
        )
    }

    pub fn implied_volatility_with_jaeckel(
        is_call: bool,
        price: f64,
        forward: f64,
        strike: f64,
        tte: f64,
        discount_factor: f64,
        jaeckel_newton_polish: bool,
    ) -> IvResult<f64> {
        let n = black::normalize_price(is_call, price, forward, strike, discount_factor);
        Self::implied_volatility_from_normalised_price_with_jaeckel(
            n.c,
            n.ex,
            tte,
            jaeckel_newton_polish,
        )
    }

    pub fn solve(x: f64, ex: f64, c: f64, log_c: f64, tte: f64) -> f64 {
        Self::solve_with_jaeckel(x, ex, c, log_c, tte, false)
    }

    pub fn solve_with_jaeckel(
        x: f64,
        ex: f64,
        c: f64,
        log_c: f64,
        tte: f64,
        jaeckel_newton_polish: bool,
    ) -> f64 {
        let implied_vol = solve_unpolished(x, ex, c, log_c, tte);
        if jaeckel_newton_polish && !is_upper_polish_guard(c) {
            black::polish_with_jaeckel_newton(x, ex, c, tte, implied_vol)
        } else {
            implied_vol
        }
    }
}

fn solve_unpolished(x: f64, ex: f64, c: f64, log_c: f64, tte: f64) -> f64 {
    let tiny = black::tiny_near_atm_bachelier_volatility(x, c, log_c, tte);
    if tiny.is_finite() {
        return tiny;
    }

    let mut v = if c <= 0.0005 && x.abs() < 0.01 {
        let atm_vol = black::SQRT_TWO_PI * c;
        (x * x + atm_vol * atm_vol).sqrt()
    } else {
        sr_guess(c, ex, x)
    };
    if !(v > MIN_TOTAL_VOL) || !v.is_finite() {
        v = MIN_TOTAL_VOL;
    }

    if is_upper_polish_guard(c) {
        v = v.max(upper_price_guess(x, c));
        return black::polish_upper_log_gap_halley(x, c, log_c, v) / tte.sqrt();
    }

    v = black::fast_h3_step(x, v, log_c);
    for iter in 0..3 {
        let (next, residual) = black::exact_h3_step(x, v, log_c);
        v = next;
        if iter >= 1 && residual.abs() < 1e-4 {
            break;
        }
    }
    v / tte.sqrt()
}

fn upper_price_guess(x: f64, c: f64) -> f64 {
    let r = -2.0 * (-c).ln_1p() - black::LOG_2PI;
    let mut d = r.sqrt();
    d -= 0.5 * r.ln() * d / (r + 1.0);
    d + (d * d - 2.0 * x).max(0.0).sqrt()
}

fn sr_guess(price: f64, ey: f64, y: f64) -> f64 {
    let alpha = price * ey;
    let r = 2.0 * alpha - ey + 1.0;
    let exp_minus_py = (-POLYA_FACTOR * y).exp();
    let ey_exp_minus_py = ey * exp_minus_py;
    let inv_ey_exp_minus_py = 1.0 / ey_exp_minus_py;
    let a = (ey_exp_minus_py - inv_ey_exp_minus_py) * (ey_exp_minus_py - inv_ey_exp_minus_py);
    let r2 = r * r;
    let ey2 = ey * ey;
    let b = 4.0 * (exp_minus_py + 1.0 / exp_minus_py)
        - 2.0 / ey * (ey_exp_minus_py + inv_ey_exp_minus_py) * (ey2 + 1.0 - r2);

    let mut beta = if alpha.abs() < SQRT_EPSILON {
        let c =
            -16.0 * (1.0 - 1.0 / ey) * alpha - 16.0 * (1.0 - 3.0 / ey + 1.0 / ey2) * alpha * alpha;
        c / b
    } else if (ey - alpha).abs() < SQRT_EPSILON {
        let delta = alpha - ey;
        let c =
            -16.0 * (1.0 + 1.0 / ey) * delta - 16.0 * (1.0 + 3.0 / ey + 1.0 / ey2) * delta * delta;
        if c == 0.0 {
            b / a
        } else {
            c / b
        }
    } else if y.abs() < SQRT_EPSILON {
        let a2 = alpha * alpha;
        let a4 = a2 * a2;
        let c = 16.0 * ((a2 - a4) + (2.0 * a4 + 2.0 * alpha * a2 - a2 - alpha) * y);
        let bx = 16.0 * (a2 - y * (alpha + a2));
        c / bx
    } else {
        let eym1 = ey - 1.0;
        let eyp1 = ey + 1.0;
        let c = (r2 - eym1 * eym1) * (eyp1 * eyp1 - r2) / ey2;
        2.0 * c / (b + (b * b + 4.0 * a * c).sqrt())
    };

    if !(beta > 0.0) || !beta.is_finite() {
        beta = SQRT_EPSILON;
    } else if beta > 1.0 {
        beta = 1.0;
    }
    let gamma = -beta.ln() / POLYA_FACTOR;

    if y >= 0.0 {
        let polya_at_switch = 0.5 * (1.0 + (1.0 - exp_minus_py * exp_minus_py).sqrt());
        let c0 = polya_at_switch - 0.5 / ey;
        let gamma_plus_y = (gamma + y).max(0.0);
        let gamma_minus_y = (gamma - y).max(0.0);
        if price <= c0 {
            gamma_plus_y.sqrt() - gamma_minus_y.sqrt()
        } else {
            gamma_plus_y.sqrt() + gamma_minus_y.sqrt()
        }
    } else {
        let polya_at_switch = 0.5 * (1.0 - (1.0 - 1.0 / (exp_minus_py * exp_minus_py)).sqrt());
        let c0 = 0.5 - polya_at_switch / ey;
        let gamma_plus_y = (gamma + y).max(0.0);
        if price <= c0 {
            -gamma_plus_y.sqrt() + (gamma - y).sqrt()
        } else {
            gamma_plus_y.sqrt() + (gamma - y).sqrt()
        }
    }
}

fn is_upper_polish_guard(c: f64) -> bool {
    c >= next_down(UPPER_POLISH_GUARD_CUTOFF)
}
