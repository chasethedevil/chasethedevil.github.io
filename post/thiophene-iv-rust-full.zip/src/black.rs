use crate::math::{erf_value, erfc_value, erfcx_value};

pub(crate) const SQRT_TWO: f64 = std::f64::consts::SQRT_2;
pub(crate) const SQRT_TWO_PI: f64 = 2.506_628_274_631_000_2;
pub(crate) const SQRT_PI_OVER_TWO: f64 = 1.253_314_137_315_500_1;
pub(crate) const ONE_OVER_SQRT_PI: f64 = 0.564_189_583_547_756_3;
pub(crate) const ONE_OVER_SQRT_TWO_PI: f64 = 0.398_942_280_401_432_7;
pub(crate) const LOG2: f64 = std::f64::consts::LN_2;
pub(crate) const LOG_2PI: f64 = 1.837_877_066_409_345_3;

const TINY_NEAR_ATM_PRICE_CUTOFF: f64 = 1e-6;
const TINY_NEAR_ATM_X_CUTOFF: f64 = 1e-8;
const TINY_NEAR_ATM_PRICE_CUTOFF_TOLERANCE: f64 = 1.0 + 1e-12;
const TINY_BACHELIER_TAIL_LOG_GAP: f64 = 20.0;
const TINY_BACHELIER_TAIL_RATIO_CUTOFF: f64 = 4.0;

const JAECKEL_ETA: f64 = -13.0;
const JAECKEL_TAU: f64 = 0.210_224_103_813_428_65;
const SQRT_DBL_MIN: f64 = 1.491_668_146_240_041_3e-154;

const LFK2026_ALPHA: f64 = 0.15;
const LFK2026_BETA_S: f64 = 1.897_119_984_885_881_3;
const LFK2026_BETA_E: f64 = 690.775_527_898_213_7;
const LFK2026_INV_BETA_RANGE: f64 = 1.0 / (LFK2026_BETA_E - LFK2026_BETA_S);

const P: f64 = 0.3275911;
const A1: f64 = 0.254829592;
const A2: f64 = -0.284496736;
const A3: f64 = 1.421413741;
const A4: f64 = -1.453152027;
const A5: f64 = 1.061405429;

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct NormalizedPrice {
    pub c: f64,
    pub ex: f64,
}

pub fn normalised_black_call(x: f64, s: f64) -> f64 {
    if s <= 0.0 {
        return ((0.5 * x).exp() - (-0.5 * x).exp()).max(0.0);
    }
    if x <= 0.0 {
        return stable_normalised_black(x, s);
    }
    stable_normalised_black(-x, s) + (0.5 * x).exp() - (-0.5 * x).exp()
}

pub fn forward_normalised_black_call(x: f64, s: f64) -> f64 {
    let log_c = log_normalised_black_call(x, s);
    if log_c.is_finite() {
        log_c.exp()
    } else {
        0.0
    }
}

pub fn upper_price_gap(x: f64, s: f64) -> f64 {
    let d1 = x / s + 0.5 * s;
    let b1 = d1 / SQRT_TWO;
    let d2 = d1 - s;
    let b2 = -d2 / SQRT_TWO;
    0.5 * (-b1 * b1).exp() * erfcx_value(b1) + 0.5 * (-x - b2 * b2).exp() * erfcx_value(b2)
}

pub fn log_normalised_black_call(x: f64, s: f64) -> f64 {
    if s <= 0.0 {
        return if x <= 0.0 {
            f64::NEG_INFINITY
        } else {
            ((0.5 * x).exp() - (-0.5 * x).exp()).ln()
        };
    }
    if x == 0.0 {
        return erf_value(s / (2.0 * SQRT_TWO)).ln();
    }
    let h = x / s;
    let t = 0.5 * s;
    let diff = erfcx_value(-(h + t) / SQRT_TWO) - erfcx_value(-(h - t) / SQRT_TWO);
    if diff <= 0.0 || !diff.is_finite() {
        f64::NEG_INFINITY
    } else {
        -0.5 * (h * h + t * t) - LOG2 - 0.5 * x + diff.ln()
    }
}

pub fn price_accurate(
    is_call: bool,
    strike: f64,
    spot: f64,
    total_variance: f64,
    drift_discount_factor: f64,
    discount_factor: f64,
) -> f64 {
    let sign = if is_call { 1.0 } else { -1.0 };
    let forward = spot / drift_discount_factor;
    if total_variance < f64::EPSILON {
        return discount_factor * (sign * (forward - strike)).max(0.0);
    }
    let sqrt_var = total_variance.sqrt();
    let x = (forward / strike).ln();
    let sqrt_fk = (forward * strike).sqrt();
    if is_call {
        if x <= 0.0 {
            return discount_factor * sqrt_fk * normalised_black_call(x, sqrt_var);
        }
        return discount_factor * sqrt_fk * normalised_black_call(-x, sqrt_var)
            + discount_factor * (forward - strike);
    }
    if x >= 0.0 {
        return discount_factor * sqrt_fk * normalised_black_call(-x, sqrt_var);
    }
    discount_factor * sqrt_fk * normalised_black_call(x, sqrt_var)
        + discount_factor * (strike - forward)
}

pub fn log_price(
    is_call: bool,
    strike: f64,
    spot: f64,
    total_variance: f64,
    drift_discount_factor: f64,
    discount_factor: f64,
) -> f64 {
    let forward = spot / drift_discount_factor;
    let sqrt_var = total_variance.sqrt();
    let x = (forward / strike).ln();
    if is_call {
        if x > 0.0 {
            let price = price_accurate(
                is_call,
                strike,
                spot,
                total_variance,
                drift_discount_factor,
                discount_factor,
            );
            return if price > 0.0 {
                price.ln()
            } else {
                f64::NEG_INFINITY
            };
        }
        return (discount_factor * forward).ln() + log_normalised_black_call(x, sqrt_var);
    }
    if x < 0.0 {
        let price = price_accurate(
            is_call,
            strike,
            spot,
            total_variance,
            drift_discount_factor,
            discount_factor,
        );
        return if price > 0.0 {
            price.ln()
        } else {
            f64::NEG_INFINITY
        };
    }
    (discount_factor * strike).ln() + log_normalised_black_call(-x, sqrt_var)
}

pub fn normalize_price(
    is_call: bool,
    price: f64,
    forward: f64,
    strike: f64,
    discount_factor: f64,
) -> NormalizedPrice {
    let mut c = price / forward / discount_factor;
    let mut ex = forward / strike;

    if !is_call {
        if ex <= 1.0 {
            c = c + 1.0 - 1.0 / ex;
        } else {
            c *= ex;
            ex = 1.0 / ex;
        }
    } else if ex > 1.0 {
        c = (forward * (c - 1.0) + strike) / strike;
        ex = 1.0 / ex;
    }
    NormalizedPrice { c, ex }
}

fn is_jaeckel_region_i(theta_x: f64, s: f64) -> bool {
    theta_x < s * JAECKEL_ETA && s * (0.5 * s - (JAECKEL_TAU + 0.5 + JAECKEL_ETA)) + theta_x < 0.0
}

fn is_jaeckel_region_ii(theta_x: f64, s: f64) -> bool {
    s * (s - 2.0 * JAECKEL_TAU) - theta_x / JAECKEL_ETA < 0.0
}

fn stable_normalised_black(theta_x: f64, s: f64) -> f64 {
    if theta_x == 0.0 {
        return erf_value(0.5 * s / SQRT_TWO);
    }
    if s <= 0.0 {
        return 0.0;
    }
    if is_jaeckel_region_i(theta_x, s) {
        return asymptotic_expansion_of_scaled_normalised_black(theta_x / s, 0.5 * s)
            * normalised_vega(theta_x, s);
    }
    if is_jaeckel_region_ii(theta_x, s) {
        return small_t_expansion_of_scaled_normalised_black(theta_x / s, 0.5 * s)
            * normalised_vega(theta_x, s);
    }
    stable_normalised_black_codys(theta_x, s)
}

fn poly(x: f64, coeffs: &[f64]) -> f64 {
    let mut value = 0.0;
    for &coeff in coeffs {
        value = value * x + coeff;
    }
    value
}

fn asymptotic_expansion_of_scaled_normalised_black(h: f64, t: f64) -> f64 {
    let e = (t / h) * (t / h);
    let r = (h + t) * (h - t);
    let q = (h / r) * (h / r);
    let a0 = 2.0;
    let a1 = poly(e, &[-2.0, -6.0]);
    let a2 = poly(e, &[6.0, 60.0, 30.0]);
    let a3 = poly(e, &[-30.0, -630.0, -1050.0, -210.0]);
    let a4 = poly(e, &[210.0, 7560.0, 26460.0, 17640.0, 1890.0]);
    let coeffs = [
        poly(
            e,
            &[
                -1890.0, -103950.0, -623700.0, -873180.0, -311850.0, -20790.0,
            ],
        ),
        poly(
            e,
            &[
                20790.0, 1621620.0, 14864850.0, 35675640.0, 26756730.0, 5945940.0, 270270.0,
            ],
        ),
        poly(
            e,
            &[
                -270270.0,
                -28378350.0,
                -368918550.0,
                -1352701350.0,
                -1739187450.0,
                -811620810.0,
                -122972850.0,
                -4054050.0,
            ],
        ),
        poly(
            e,
            &[
                4054050.0,
                551350800.0,
                9648639000.0,
                50172922800.0,
                98553955500.0,
                78843164400.0,
                25086461400.0,
                2756754000.0,
                68918850.0,
            ],
        ),
        poly(
            e,
            &[
                -68918850.0,
                -11785123350.0,
                -267129462600.0,
                -1869906238200.0,
                -5209024520700.0,
                -6366585525300.0,
                -3472683013800.0,
                -801388387800.0,
                -66782365650.0,
                -1309458150.0,
            ],
        ),
        poly(
            e,
            &[
                1309458150.0,
                274986211500.0,
                7837107027750.0,
                71056437051600.0,
                266461638943500.0,
                461866840835400.0,
                384889034029500.0,
                152263793682000.0,
                26646163894350.0,
                1741579339500.0,
                27498621150.0,
            ],
        ),
        poly(
            e,
            &[
                -27498621150.0,
                -6957151150950.0,
                -243500290283250.0,
                -2775903309229050.0,
                -13482958930541100.0,
                -31460237504595900.0,
                -37180280687249700.0,
                -22471598217568500.0,
                -6741479465270550.0,
                -925301103076350.0,
                -48700058056650.0,
                -632468286450.0,
            ],
        ),
        poly(
            e,
            &[
                6.3246828645e11,
                1.89740485935e14,
                8.0007238235925e15,
                1.12010133530295e17,
                6.8406188691715875e17,
                2.067387036016302e18,
                3.289024830025935e18,
                2.81916414002223e18,
                1.29211689751018875e18,
                304027505296515000.0,
                33603040059088500.0,
                1454677058835000.0,
                15811707161250.0,
            ],
        ),
        poly(
            e,
            &[
                -1.581170716125e13,
                -5.54990921359875e15,
                -2.774954606799375e17,
                -4.6804234368016125e18,
                -3.51031757760120938e19,
                -1.33392067948845956e20,
                -2.74868503652167425e20,
                -3.17155965752500875e20,
                -2.06151377739125569e20,
                -7.41067044160255312e19,
                -1.40412703104048375e19,
                -1.2764791191277125e18,
                -4.624924344665625e16,
                -4.2691609335375e14,
            ],
        ),
        poly(
            e,
            &[
                4.2691609335375e14,
                1.733279339016225e17,
                1.01396841332449162e19,
                2.02793682664898325e20,
                1.83238577550783129e21,
                8.55113361903654604e21,
                2.2155209831140142e22,
                3.31110828245610914e22,
                2.89721974714909549e22,
                1.47701398874267613e22,
                4.27556680951827302e21,
                6.66322100184665925e20,
                5.06984206662245812e19,
                1.5599514051146025e18,
                1.238056670725875e16,
            ],
        ),
        poly(
            e,
            &[
                -1.238056670725875e16,
                -5.75696351887531875e18,
                -3.89554531443896569e20,
                -9.11557603578717971e21,
                -9.76668860977197826e22,
                -5.49104937393846778e23,
                -1.74715207352587611e24,
                -3.28310994036181115e24,
                -3.72085793241005264e24,
                -2.55352995361474201e24,
                -1.04829124411552567e24,
                -2.49593153360839444e23,
                -3.25556286992399275e22,
                -2.10359446979704147e21,
                -5.56506473491280812e19,
                -3.8379756792502125e17,
            ],
        ),
        poly(
            e,
            &[
                3.8379756792502125e17,
                2.0264511586441122e20,
                1.57049964794918696e22,
                4.25081904711579936e23,
                5.32870530549159134e24,
                3.55247020366106089e25,
                1.36178024473674001e26,
                3.1425697955463231e26,
                4.47816195865351041e26,
                3.98058840769200926e26,
                2.19979885688242617e26,
                7.42789224401858187e25,
                1.48019591819210871e25,
                1.63960163245895118e24,
                9.10889795810528434e22,
                2.09399953059891594e21,
                1.26653197415257012e19,
            ],
        ),
    ];

    let thresholds = [
        12.347, 12.958, 13.729, 14.718, 16.016, 17.769, 20.221, 23.816, 29.419, 38.93, 57.171,
        99.347,
    ];
    let val = -h - t + JAECKEL_TAU + 0.5;
    let mut upper_bound = 0;
    while upper_bound < thresholds.len() && thresholds[upper_bound] <= val {
        upper_bound += 1;
    }
    let n_extra = coeffs.len() - upper_bound;
    let mut omega = 0.0;
    for k in (0..n_extra).rev() {
        omega = q * (coeffs[k] + omega);
    }
    omega = a0 + q * (a1 + q * (a2 + q * (a3 + q * (a4 + omega))));
    (t / r) * omega
}

fn y_prime_tail_rational(w: f64) -> f64 {
    w * (-2.9999999999994663866
        + w * (-1.7556263323542206288e2
            + w * (-3.4735035445495633334e3
                + w * (-2.7805745693864308643e4
                    + w * (-8.3836021460741980839e4 - 6.6818249032616849037e4 * w)))))
        / (1.0
            + w * (6.3520877744831739102e1
                + w * (1.4404389037604337538e3
                    + w * (1.4562545638507033944e4
                        + w * (6.6886794165651675684e4
                            + w * (1.2569970380923908488e5 + 6.9286518679803751694e4 * w))))))
}

fn y_prime(h: f64) -> f64 {
    if h < -4.0 {
        let w = 1.0 / (h * h);
        return w * (1.0 + y_prime_tail_rational(w));
    }
    if h <= -0.46875 {
        return (1.0000000000594317229
            - h * (6.1911449879694112749e-1
                - h * (2.2180844736576013957e-1
                    - h * (4.5650900351352987865e-2
                        - h * (5.545521007735379052e-3
                            - h * (3.0717392274913902347e-4
                                - h * (4.2766597835908713583e-8
                                    + 8.4592436406580605619e-10 * h)))))))
            / (1.0
                - h * (1.8724286369589162071
                    - h * (1.5685497236077651429
                        - h * (7.6576489836589035112e-1
                            - h * (2.3677701403094640361e-1
                                - h * (4.6762548903194957675e-2
                                    - h * (5.5290453576936595892e-3
                                        - 3.0822020417927147113e-4 * h)))))));
    }
    1.0 + h * SQRT_PI_OVER_TWO * erfcx_value(-h / SQRT_TWO)
}

fn small_t_expansion_of_scaled_normalised_black(h: f64, t: f64) -> f64 {
    let a = y_prime(h);
    let h2 = h * h;
    let t2 = t * t;
    let b0 = 2.0 * a;
    let b1 = (-1.0 + a * (3.0 + h2)) / 3.0;
    let b2 = (-7.0 - h2 + a * (15.0 + h2 * (10.0 + h2))) / 60.0;
    let b3 = (-57.0 + (-18.0 - h2) * h2 + a * (105.0 + h2 * (105.0 + h2 * (21.0 + h2)))) / 2520.0;
    let b4 = (-561.0
        + h2 * (-285.0 + (-33.0 - h2) * h2)
        + a * (945.0 + h2 * (1260.0 + h2 * (378.0 + h2 * (36.0 + h2)))))
        / 181440.0;
    let b5 = (-6555.0
        + h2 * (-4680.0 + h2 * (-840.0 + (-52.0 - h2) * h2))
        + a * (10395.0 + h2 * (17325.0 + h2 * (6930.0 + h2 * (990.0 + h2 * (55.0 + h2))))))
        / 19958400.0;
    let b6 = (-89055.0
        + h2 * (-82845.0 + h2 * (-20370.0 + h2 * (-1926.0 + (-75.0 - h2) * h2)))
        + a * (135135.0
            + h2 * (270270.0
                + h2 * (135135.0 + h2 * (25740.0 + h2 * (2145.0 + h2 * (78.0 + h2)))))))
        / 3113510400.0;
    t * (b0 + t2 * (b1 + t2 * (b2 + t2 * (b3 + t2 * (b4 + t2 * (b5 + b6 * t2))))))
}

fn stable_normalised_black_codys(theta_x: f64, s: f64) -> f64 {
    let h = theta_x / s;
    let t = 0.5 * s;
    let q1 = -(h + t) / SQRT_TWO;
    let q2 = -(h - t) / SQRT_TWO;
    let codys_threshold = 0.46875;
    let two_b = if q1 < codys_threshold {
        if q2 < codys_threshold {
            (0.5 * theta_x).exp() * erfc_value(q1) - (-0.5 * theta_x).exp() * erfc_value(q2)
        } else {
            (0.5 * theta_x).exp() * erfc_value(q1)
                - (-0.5 * (h * h + t * t)).exp() * erfcx_value(q2)
        }
    } else if q2 < codys_threshold {
        (-0.5 * (h * h + t * t)).exp() * erfcx_value(q1) - (-0.5 * theta_x).exp() * erfc_value(q2)
    } else {
        (-0.5 * (h * h + t * t)).exp() * (erfcx_value(q1) - erfcx_value(q2))
    };
    (0.5 * two_b).max(0.0)
}

pub(crate) fn fast_erfcx(z: f64) -> f64 {
    if z >= 2.5 {
        let iz2 = 1.0 / (2.0 * z * z);
        return ONE_OVER_SQRT_PI / z * (1.0 - iz2 * (1.0 - 3.0 * iz2 * (1.0 - 5.0 * iz2)));
    }
    if z >= 0.0 {
        let t = 1.0 / (1.0 + P * z);
        return ((((A5 * t + A4) * t + A3) * t + A2) * t + A1) * t;
    }
    if !z.is_nan() {
        return 2.0 * (z * z).exp() - fast_erfcx(-z);
    }
    f64::NAN
}

pub(crate) fn fast_h3_step(x: f64, v: f64, log_c: f64) -> f64 {
    let h = x / v;
    let t = 0.5 * v;
    let h2 = h * h;
    let t2 = t * t;
    let diff = fast_erfcx(-(h + t) / SQRT_TWO) - fast_erfcx(-(h - t) / SQRT_TWO);
    if diff <= 0.0 {
        return v;
    }
    let log_c_est = -0.5 * (h2 + t2) - LOG2 - 0.5 * x + diff.ln();
    let log_vega = (2.0 / SQRT_TWO_PI) / diff;
    let vov = (h + t) * (h - t) / v;
    let d2 = vov - log_vega;
    let h2mt2 = h2 - t2;
    let d3 = (-3.0 * h2 - t2 + h2mt2 * h2mt2) / (v * v) - 3.0 * log_vega * vov
        + 2.0 * log_vega * log_vega;
    let hn = -(log_c_est - log_c) / log_vega;
    let num = 1.0 + 0.5 * d2 * hn;
    let denom = 1.0 + d2 * hn + d3 * hn * hn / 6.0;
    let v1 = v + hn * num / denom;
    if v1 > 0.0 && v1.is_finite() {
        v1
    } else {
        v
    }
}

pub(crate) fn exact_h3_step(x: f64, v: f64, log_c: f64) -> (f64, f64) {
    let h = x / v;
    let t = 0.5 * v;
    let h2 = h * h;
    let t2 = t * t;
    let diff = erfcx_value(-(h + t) / SQRT_TWO) - erfcx_value(-(h - t) / SQRT_TWO);
    if diff <= 0.0 || !diff.is_finite() {
        return (v, f64::INFINITY);
    }
    let log_c_est = if x == 0.0 {
        erf_value(t / SQRT_TWO).ln()
    } else {
        -0.5 * (h2 + t2) - LOG2 - 0.5 * x + diff.ln()
    };
    let log_vega = (2.0 / SQRT_TWO_PI) / diff;
    let vov = (h + t) * (h - t) / v;
    let d2 = vov - log_vega;
    let h2mt2 = h2 - t2;
    let d3 = (-3.0 * h2 - t2 + h2mt2 * h2mt2) / (v * v) - 3.0 * log_vega * vov
        + 2.0 * log_vega * log_vega;
    let residual = log_c_est - log_c;
    let hn = -residual / log_vega;
    let num = 1.0 + 0.5 * d2 * hn;
    let denom = 1.0 + d2 * hn + d3 * hn * hn / 6.0;
    let next = if denom != 0.0 {
        v + hn * num / denom
    } else {
        v
    };
    (
        if next > 0.0 && next.is_finite() {
            next
        } else {
            v
        },
        residual,
    )
}

pub(crate) fn tiny_near_atm_bachelier_volatility(x: f64, c: f64, log_c: f64, tte: f64) -> f64 {
    if !(c > 0.0)
        || x > 0.0
        || c > TINY_NEAR_ATM_PRICE_CUTOFF * TINY_NEAR_ATM_PRICE_CUTOFF_TOLERANCE
        || x.abs() > TINY_NEAR_ATM_X_CUTOFF
    {
        return f64::NAN;
    }
    let m = -x;
    let beta = c * (0.5 * x).exp();
    let log_beta = log_c + 0.5 * x;
    let mut v = tiny_bachelier_deep_tail_volatility(m, log_beta);
    if v.is_finite() {
        return v / tte.sqrt();
    }
    v = lfk2026_bachelier_volatility(m, beta);
    if v.is_finite() && v > 0.0 {
        v = tiny_black_expansion_polish(m, beta, v);
        return v / tte.sqrt();
    }
    0.0
}

fn tiny_black_expansion_polish(m: f64, beta: f64, mut v: f64) -> f64 {
    if !(beta > 0.0) || !(v > 0.0) || !v.is_finite() {
        return v;
    }
    if m > 0.0 && m / v > TINY_BACHELIER_TAIL_RATIO_CUTOFF {
        return v;
    }
    for _ in 0..2 {
        let a = if m == 0.0 { 0.0 } else { m / v };
        let phi = (-0.5 * a * a).exp() / SQRT_TWO_PI;
        let derivative = phi * (-0.125 * v * v).exp();
        if !(derivative > 0.0) || !derivative.is_finite() {
            break;
        }
        let price = tiny_black_sqrt_normalised_expansion(m, v);
        let step = (price - beta) / derivative;
        let v1 = v - step;
        if !(v1 > 0.0) || !v1.is_finite() {
            break;
        }
        v = v1;
        if step.abs() <= 2.0 * ulp(v) {
            break;
        }
    }
    v
}

fn tiny_black_sqrt_normalised_expansion(m: f64, v: f64) -> f64 {
    let a = if m == 0.0 { 0.0 } else { m / v };
    let phi = (-0.5 * a * a).exp() / SQRT_TWO_PI;
    let q = if m == 0.0 {
        0.5
    } else {
        0.5 * erfc_value(a / SQRT_TWO)
    };
    let i0 = v * phi - m * q;
    let v2 = v * v;
    let m2 = m * m;
    let i2 = (v2 * v * phi - m2 * i0) / 3.0;
    let i4 = (v2 * v2 * v * phi - m2 * i2) / 5.0;
    i0 - 0.125 * i2 + i4 / 128.0
}

fn tiny_bachelier_deep_tail_volatility(k: f64, log_c: f64) -> f64 {
    if !(k > 0.0) || !log_c.is_finite() {
        return f64::NAN;
    }
    let log_gap = k.ln() - log_c;
    if log_gap <= TINY_BACHELIER_TAIL_LOG_GAP {
        return f64::NAN;
    }
    let target_log_ratio = log_c - k.ln();
    let mut tail_ratio = (1.0_f64.max(-2.0 * (target_log_ratio + 0.5 * LOG_2PI))).sqrt();
    for _ in 0..4 {
        let mills_ratio = SQRT_PI_OVER_TWO * erfcx_value(tail_ratio / SQRT_TWO);
        let scaled_gap = 1.0 / tail_ratio - mills_ratio;
        if !(scaled_gap > 0.0) || !scaled_gap.is_finite() {
            return f64::NAN;
        }
        let residual =
            -0.5 * tail_ratio * tail_ratio - 0.5 * LOG_2PI + scaled_gap.ln() - target_log_ratio;
        let slope = -tail_ratio
            + (1.0 - 1.0 / (tail_ratio * tail_ratio) - tail_ratio * mills_ratio) / scaled_gap;
        let step = residual / slope;
        let next = tail_ratio - step;
        if !(next > 0.0) || !next.is_finite() {
            return f64::NAN;
        }
        tail_ratio = next;
        if step.abs() <= 1e-14 * 1.0_f64.max(tail_ratio) {
            break;
        }
    }
    let v = k / tail_ratio;
    if k / v > TINY_BACHELIER_TAIL_RATIO_CUTOFF {
        v
    } else {
        f64::NAN
    }
}

pub(crate) fn lfk2026_bachelier_volatility(k: f64, c: f64) -> f64 {
    if !(c > 0.0) || !(k > 0.0) {
        if k == 0.0 && c > 0.0 {
            return SQRT_TWO_PI * c;
        }
        return f64::NAN;
    }
    let z_pos = c / k;
    if z_pos > LFK2026_ALPHA {
        let u = k / c;
        return (c + k) * lfk2026_eval_itm(u);
    }
    if z_pos < 1e-300 {
        return 0.0;
    }
    let eta_tilde = -((z_pos.ln()) + LFK2026_BETA_S) * LFK2026_INV_BETA_RANGE;
    let inv_abs_d = if eta_tilde < 0.01 {
        lfk2026_eval_otm1(eta_tilde)
    } else if eta_tilde < 0.09 {
        lfk2026_eval_otm2(eta_tilde)
    } else {
        lfk2026_eval_otm3(eta_tilde)
    };
    k * inv_abs_d
}

fn lfk2026_eval_itm(u: f64) -> f64 {
    let mut p = -2.70797042551215202e-09;
    p = p * u + 5.03803837400379678e-06;
    p = p * u + 5.87928493313025560e-04;
    p = p * u + 1.83954491376296485e-02;
    p = p * u + 2.36012991833862845e-01;
    p = p * u + 1.47171929792136824e+00;
    p = p * u + 4.81532474104199881e+00;
    p = p * u + 8.38783649295939249e+00;
    p = p * u + 7.32071451154750097e+00;
    p = p * u + 2.50662827463100024e+00;
    let mut q = 1.06715338537575127e-05;
    q = q * u + 9.08750187647611803e-04;
    q = q * u + 2.23188636991579585e-02;
    q = q * u + 2.30574991341749191e-01;
    q = q * u + 1.17534367470784673e+00;
    q = q * u + 3.18165296194859026e+00;
    q = q * u + 4.63611136038634353e+00;
    q = q * u + 3.42054254140456848e+00;
    q = q * u + 1.0;
    p / q
}

fn lfk2026_eval_otm1(eta: f64) -> f64 {
    let mut p = -3.48308852288966554e+18;
    p = p * eta + 1.10299370004290995e+18;
    p = p * eta - 4.02413716168378048e+17;
    p = p * eta - 7.43714349945829120e+16;
    p = p * eta - 2.49477863322856750e+15;
    p = p * eta - 2.85331260987706523e+13;
    p = p * eta - 5.10817469063371429e+10;
    p = p * eta + 2.40533073130836535e+09;
    p = p * eta + 3.07861092585915886e+07;
    p = p * eta + 1.95717866058198881e+05;
    p = p * eta + 6.82178299087715914e+02;
    p = p * eta + 1.24910559446641112e+00;
    let mut q = -8.65868218927210598e+18;
    q = q * eta - 5.43691399201888000e+17;
    q = q * eta - 9.16374230029381000e+15;
    q = q * eta - 4.73283686242051484e+13;
    q = q * eta + 4.46201521087863831e+11;
    q = q * eta + 9.14684611768276405e+09;
    q = q * eta + 7.18091511301956624e+07;
    q = q * eta + 3.22084448691854079e+05;
    q = q * eta + 8.31825318775392361e+02;
    q = q * eta + 1.0;
    p / q
}

fn lfk2026_eval_otm2(eta: f64) -> f64 {
    let mut p = 2.99147136389716260e+12;
    p = p * eta - 8.76625536254249121e+12;
    p = p * eta + 3.09426714906955234e+13;
    p = p * eta + 5.73825498368429922e+13;
    p = p * eta + 2.03806992766065625e+13;
    p = p * eta + 2.58076177636243115e+12;
    p = p * eta + 1.39249460078530365e+11;
    p = p * eta + 3.45074450506824827e+09;
    p = p * eta + 4.12660599897888750e+07;
    p = p * eta + 2.57450335132154607e+05;
    p = p * eta + 8.82143141269435318e+02;
    p = p * eta + 1.24860495497317925e+00;
    let mut q = 2.10719786854519525e+15;
    q = q * eta + 1.45588799532258475e+15;
    q = q * eta + 2.92823593402229500e+14;
    q = q * eta + 2.31200993253629883e+13;
    q = q * eta + 7.95484765720863647e+11;
    q = q * eta + 1.24794454367125645e+10;
    q = q * eta + 9.56102882581782639e+07;
    q = q * eta + 4.17679926778023364e+05;
    q = q * eta + 9.91194200989211254e+02;
    q = q * eta + 1.0;
    p / q
}

fn lfk2026_eval_otm3(eta: f64) -> f64 {
    let mut p = -1.01865471163877160e+02;
    p = p * eta + 2.99524578014802091e+03;
    p = p * eta - 1.04999322668089051e+05;
    p = p * eta - 1.90438009836981818e+06;
    p = p * eta - 6.49374308713343088e+06;
    p = p * eta - 7.65563194503842667e+06;
    p = p * eta - 3.62091305895698769e+06;
    p = p * eta - 6.78815730118479463e+05;
    p = p * eta - 3.63727433825341577e+04;
    p = p * eta + 1.53669112770474931e+03;
    p = p * eta + 1.34977888075358550e+02;
    p = p * eta + 1.61947615412173973e+00;
    let mut q = -2.24196883894425444e+07;
    q = q * eta - 1.51588857602825403e+08;
    q = q * eta - 2.93510878971269727e+08;
    q = q * eta - 2.16291778562989831e+08;
    q = q * eta - 6.44309250732882321e+07;
    q = q * eta - 6.85415582536362950e+06;
    q = q * eta - 3.44836595974720476e+04;
    q = q * eta + 2.27524257249606417e+04;
    q = q * eta + 5.91576136257250369e+02;
    q = q * eta + 1.0;
    p / q
}

pub(crate) fn upper_target_log_gap(c: f64, log_c: f64) -> f64 {
    let gap_from_log_price = -log_c.exp_m1();
    if gap_from_log_price > 0.0 && gap_from_log_price.is_finite() {
        gap_from_log_price.ln()
    } else {
        (-c).ln_1p()
    }
}

pub(crate) fn polish_upper_log_gap_halley(x: f64, c: f64, log_c: f64, mut v: f64) -> f64 {
    let target = upper_target_log_gap(c, log_c);
    for _ in 0..3 {
        v = halley_log_gap_step(x, v, target);
    }
    v
}

pub(crate) fn polish_upper_log_gap_householder(x: f64, c: f64, log_c: f64, mut v: f64) -> f64 {
    let target = upper_target_log_gap(c, log_c);
    for _ in 0..2 {
        v = householder_log_gap_step(x, v, target);
    }
    v
}

pub(crate) fn halley_log_gap_step(x: f64, v: f64, target_log_gap: f64) -> f64 {
    let v = v.abs();
    if !(v > 0.0) || !v.is_finite() {
        return v;
    }
    let d1 = x / v + 0.5 * v;
    let b1 = d1 / SQRT_TWO;
    let d2 = d1 - v;
    let b2 = -d2 / SQRT_TWO;
    let erfcx_sum = erfcx_value(b1) + erfcx_value(b2);
    if !(erfcx_sum > 0.0) || !erfcx_sum.is_finite() {
        return v;
    }
    let log_gap = -b1 * b1 - LOG2 + erfcx_sum.ln();
    if !log_gap.is_finite() {
        return v;
    }
    let f_val = log_gap - target_log_gap;
    let mut step = 0.5 * SQRT_TWO_PI * erfcx_sum * f_val;
    let d1p = 0.5 - x / (v * v);
    let q = f_val * (d1 * d1p * 0.5 * SQRT_TWO_PI * erfcx_sum - 1.0);
    let denom = 1.0 - 0.5 * q;
    if denom > 0.1 {
        step /= denom;
    }
    if !step.is_finite() {
        return v;
    }
    let next = v + step;
    if next > 0.0 && next.is_finite() {
        next
    } else {
        v
    }
}

fn householder_log_gap_step(x: f64, v: f64, target_log_gap: f64) -> f64 {
    let v = v.abs();
    if !(v > 0.0) || !v.is_finite() {
        return v;
    }
    let h = x / v;
    let t = 0.5 * v;
    let h2 = h * h;
    let t2 = t * t;
    let d1 = h + t;
    let b1 = d1 / SQRT_TWO;
    let d2 = d1 - v;
    let b2 = -d2 / SQRT_TWO;
    let erfcx_sum = erfcx_value(b1) + erfcx_value(b2);
    if !(erfcx_sum > 0.0) || !erfcx_sum.is_finite() {
        return v;
    }
    let log_gap = -b1 * b1 - LOG2 + erfcx_sum.ln();
    if !log_gap.is_finite() {
        return v;
    }
    let residual = log_gap - target_log_gap;
    let eta = 0.5 * SQRT_TWO_PI * erfcx_sum * residual;
    let first_term = (-3.0 * h2 - t2 + (h2 - t2) * (h2 - t2)) / (v * v);
    let y = 2.0 / (SQRT_TWO_PI * erfcx_sum);
    let a = (h + t) * (h - t) / v;
    let q = a + y;
    let d3 = first_term + 3.0 * y * a + 2.0 * y * y;
    let numerator = 1.0 + 0.5 * q * eta;
    let denominator = 1.0 + q * eta + d3 * eta * eta / 6.0;
    let next = if denominator != 0.0 {
        v + eta * numerator / denominator
    } else {
        v
    };
    if next > 0.0 && next.is_finite() {
        next
    } else {
        v
    }
}

pub(crate) fn polish_with_jaeckel_newton(
    x: f64,
    ex: f64,
    c: f64,
    tte: f64,
    implied_vol: f64,
) -> f64 {
    if !(implied_vol > 0.0)
        || !(tte > 0.0)
        || !(ex > 0.0)
        || !(c > 0.0)
        || !implied_vol.is_finite()
        || !tte.is_finite()
    {
        return implied_vol;
    }
    let sqrt_ex = ex.sqrt();
    let target_beta = c * sqrt_ex;
    if !(target_beta > 0.0) || !(target_beta < sqrt_ex) || !target_beta.is_finite() {
        return implied_vol;
    }
    let sqrt_tte = tte.sqrt();
    let total_vol = implied_vol * sqrt_tte;
    let next_total_vol = newton_polish_total_vol(x, target_beta, total_vol);
    if next_total_vol > 0.0 && next_total_vol.is_finite() {
        next_total_vol / sqrt_tte
    } else {
        implied_vol
    }
}

fn newton_polish_total_vol(x: f64, target_beta: f64, s: f64) -> f64 {
    if !(target_beta > 0.0) || !(s > 0.0) || !target_beta.is_finite() || !s.is_finite() {
        return s;
    }
    let vega = normalised_vega(x, s);
    if !(vega > 0.0) || !vega.is_finite() {
        return s;
    }
    let stable_beta = if x == 0.0 {
        erf_value(0.5 * s / SQRT_TWO)
    } else if is_jaeckel_region_i(x, s) {
        asymptotic_expansion_of_scaled_normalised_black(x / s, 0.5 * s) * vega
    } else if is_jaeckel_region_ii(x, s) {
        small_t_expansion_of_scaled_normalised_black(x / s, 0.5 * s) * vega
    } else {
        stable_normalised_black_codys(x, s)
    };
    if !(stable_beta > 0.0) || !stable_beta.is_finite() {
        return s;
    }
    let next = s - (stable_beta - target_beta) / vega;
    if next > 0.0 && next.is_finite() {
        next
    } else {
        s
    }
}

fn normalised_vega(x: f64, s: f64) -> f64 {
    let ax = x.abs();
    if ax == 0.0 {
        return ONE_OVER_SQRT_TWO_PI * (-0.125 * s * s).exp();
    }
    if s <= 0.0 || s <= ax * SQRT_DBL_MIN {
        return 0.0;
    }
    let h = x / s;
    let t = 0.5 * s;
    ONE_OVER_SQRT_TWO_PI * (-0.5 * (h * h + t * t)).exp()
}

fn ulp(x: f64) -> f64 {
    if !x.is_finite() {
        return f64::NAN;
    }
    if x == 0.0 {
        return f64::from_bits(1);
    }
    let bits = x.to_bits();
    let next = if x > 0.0 {
        f64::from_bits(bits + 1)
    } else {
        f64::from_bits(bits - 1)
    };
    (next - x).abs()
}
