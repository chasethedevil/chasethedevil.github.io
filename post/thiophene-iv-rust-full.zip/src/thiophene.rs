use crate::black;
use crate::{next_down, IvError, IvResult};

pub struct ThiopheneIV;

const MIN_TOTAL_VOL: f64 = 1e-10;
const DIRECT_POLISH_PRICE_CUTOFF: f64 = 0.5;
const NORM_INV_LOW: f64 = 0.02425;
const NORM_INV_HIGH: f64 = 1.0 - NORM_INV_LOW;
const MIN_SUBNORMAL: f64 = 5e-324;

impl ThiopheneIV {
    pub fn implied_volatility_from_normalised_price(c: f64, ex: f64, tte: f64) -> IvResult<f64> {
        Self::implied_volatility_from_normalised_price_with_jaeckel(c, ex, tte, false)
    }

    pub fn implied_volatility_from_normalized_price(c: f64, ex: f64, tte: f64) -> IvResult<f64> {
        Self::implied_volatility_from_normalised_price(c, ex, tte)
    }

    pub fn implied_volatility_from_normalised_price_with_jaeckel(
        c: f64,
        ex: f64,
        tte: f64,
        jaeckel_newton_polish: bool,
    ) -> IvResult<f64> {
        if !(tte > 0.0) {
            return Err(IvError::NonPositiveExpiry);
        }
        if c <= 0.0 {
            return Ok(f64::EPSILON);
        }
        if c >= 1.0 {
            return Err(IvError::PriceOutOfRange);
        }
        let x = ex.ln();
        Ok(Self::solve_with_jaeckel(
            x,
            ex,
            c,
            c.ln(),
            tte,
            jaeckel_newton_polish,
        ))
    }

    pub fn implied_volatility_from_normalized_price_with_jaeckel(
        c: f64,
        ex: f64,
        tte: f64,
        jaeckel_newton_polish: bool,
    ) -> IvResult<f64> {
        Self::implied_volatility_from_normalised_price_with_jaeckel(
            c,
            ex,
            tte,
            jaeckel_newton_polish,
        )
    }

    pub fn implied_volatility(
        is_call: bool,
        price: f64,
        forward: f64,
        strike: f64,
        tte: f64,
        discount_factor: f64,
    ) -> IvResult<f64> {
        Self::implied_volatility_with_jaeckel(
            is_call,
            price,
            forward,
            strike,
            tte,
            discount_factor,
            false,
        )
    }

    pub fn implied_volatility_with_jaeckel(
        is_call: bool,
        price: f64,
        forward: f64,
        strike: f64,
        tte: f64,
        discount_factor: f64,
        jaeckel_newton_polish: bool,
    ) -> IvResult<f64> {
        let n = black::normalize_price(is_call, price, forward, strike, discount_factor);
        Self::implied_volatility_from_normalised_price_with_jaeckel(
            n.c,
            n.ex,
            tte,
            jaeckel_newton_polish,
        )
    }

    pub fn solve(x: f64, ex: f64, c: f64, log_c: f64, tte: f64) -> f64 {
        Self::solve_with_jaeckel(x, ex, c, log_c, tte, false)
    }

    pub fn solve_with_jaeckel(
        x: f64,
        ex: f64,
        c: f64,
        log_c: f64,
        tte: f64,
        jaeckel_newton_polish: bool,
    ) -> f64 {
        let implied_vol = solve_unpolished(x, ex, c, log_c, tte);
        if jaeckel_newton_polish && is_direct_polish_region(c) {
            black::polish_with_jaeckel_newton(x, ex, c, tte, implied_vol)
        } else {
            implied_vol
        }
    }
}

fn is_direct_polish_region(c: f64) -> bool {
    c <= DIRECT_POLISH_PRICE_CUTOFF
}

fn solve_unpolished(x: f64, ex: f64, c: f64, log_c: f64, tte: f64) -> f64 {
    let tiny = black::tiny_near_atm_bachelier_volatility(x, c, log_c, tte);
    if tiny.is_finite() {
        return tiny;
    }

    let mut v = choi_l3_guess(x, ex, c);
    if !(v > MIN_TOTAL_VOL) || !v.is_finite() {
        v = fallback_guess(x, c, log_c);
    }
    if !(v > MIN_TOTAL_VOL) || !v.is_finite() {
        v = MIN_TOTAL_VOL;
    }

    if c > 0.5 {
        let target_log_gap = black::upper_target_log_gap(c, log_c);
        for _ in 0..3 {
            v = black::halley_log_gap_step(x, v, target_log_gap);
        }
    } else {
        for _ in 0..3 {
            v = chebyshev_log_price_step(x, v, log_c);
        }
    }
    v / tte.sqrt()
}

fn chebyshev_log_price_step(x: f64, v: f64, log_c: f64) -> f64 {
    let h = x / v;
    let t = 0.5 * v;
    let diff = if ((h+t < 0) && (h-t < 0)) {
        crate::math::erfcx_value(-(h + t) / black::SQRT_TWO) - crate::math::erfcx_value(-(h - t) / black::SQRT_TWO)
    } else {
        crate::math::erfc_value(-(h + t) / black::SQRT_TWO) - crate::math::erfc_value(-(h - t) / black::SQRT_TWO)
    };
    if !(diff > 0.0) || !diff.is_finite() {
        return v;
    }
    let log_c_est = if x == 0.0 {
        crate::math::erf_value(t / black::SQRT_TWO).ln()
    } else {
        if ((h+t < 0) && (h-t < 0)) {
            -0.5 * (h * h + t * t) - black::LOG2 - 0.5 * x + diff.ln()
        } else {
            - black::LOG2 - 0.5 * x + diff.ln()
        }
    };
    if !log_c_est.is_finite() {
        return v;
    }
    let log_vega = (2.0 / black::SQRT_TWO_PI) / diff;
    let d2 = (h + t) * (h - t) / v - log_vega;
    let step = -(log_c_est - log_c) / log_vega;
    let next = v + step * (1.0 - 0.5 * d2 * step);
    if next > 0.0 && next.is_finite() {
        next
    } else {
        v
    }
}

fn choi_l3_guess(x: f64, ex: f64, c: f64) -> f64 {
    let k = (-x).max(0.0);
    if k == 0.0 {
        return atm_total_vol(c);
    }
    let mut ek = 1.0 / ex;
    if !(ek > 0.0) || !ek.is_finite() {
        ek = k.exp();
    }
    let denominator = 2.0 * c + ek - 1.0;
    if !(denominator > 0.0) || !denominator.is_finite() {
        return f64::NAN;
    }
    let probability = clamp_probability(c * (c + ek) / denominator);
    inverse_d1(norm_inv(probability), k)
}

fn inverse_d1(z: f64, k: f64) -> f64 {
    if k == 0.0 {
        return (2.0 * z).max(0.0);
    }
    let root = (z * z + 2.0 * k).sqrt();
    if z >= 0.0 {
        z + root
    } else {
        2.0 * k / (root - z)
    }
}

fn atm_total_vol(c: f64) -> f64 {
    if c < 1e-4 {
        return black::SQRT_TWO_PI * c * (1.0 + std::f64::consts::PI * c * c / 12.0);
    }
    2.0 * norm_inv(0.5 * (1.0 + c))
}

fn norm_inv(probability: f64) -> f64 {
    let p = clamp_probability(probability);
    if p < NORM_INV_LOW {
        let q = (-2.0 * p.ln()).sqrt();
        return tail_norm_inv(q);
    }
    if p > NORM_INV_HIGH {
        let q = (-2.0 * (-p).ln_1p()).sqrt();
        return -tail_norm_inv(q);
    }

    let q = p - 0.5;
    let r = q * q;
    let num = (((((-39.69683028665376 * r + 220.9460984245205) * r - 275.9285104469687) * r
        + 138.3577518672690)
        * r
        - 30.66479806614716)
        * r
        + 2.506628277459239)
        * q;
    let den = ((((-54.47609879822406 * r + 161.5858368580409) * r - 155.6989798598866) * r
        + 66.80131188771972)
        * r
        - 13.28068155288572)
        * r
        + 1.0;
    num / den
}

fn tail_norm_inv(q: f64) -> f64 {
    (((((-0.007784894002430293 * q - 0.3223964580411365) * q - 2.400758277161838) * q
        - 2.549732539343734)
        * q
        + 4.374664141464968)
        * q
        + 2.938163982698783)
        / ((((0.007784695709041462 * q + 0.3224671290700398) * q + 2.445134137142996) * q
            + 3.754408661907416)
            * q
            + 1.0)
}

fn clamp_probability(probability: f64) -> f64 {
    probability.max(MIN_SUBNORMAL).min(next_down(1.0))
}

fn fallback_guess(x: f64, c: f64, log_c: f64) -> f64 {
    if c < 1e-4 && x.abs() < 0.01 {
        let atm_vol = black::SQRT_TWO_PI * c;
        return (x * x + atm_vol * atm_vol).sqrt();
    }
    let d = (-2.0 * log_c - black::LOG_2PI).max(0.0).sqrt();
    let disc = d * d - 2.0 * x;
    if disc > 0.0 && d > 0.0 {
        return -2.0 * x / (d + disc.sqrt());
    }
    (2.0 * x.abs()).sqrt()
}
