use crate::black;
use crate::math::{erf_value, erfcx_value};
use crate::{next_down, IvError, IvResult};

pub struct FlashIV;

const MIN_TOTAL_VOL: f64 = 1e-10;
const SMALL_PRICE_LI_CUTOFF: f64 = 0.0005;
const UPPER_PRICE_CUTOFF: f64 = 0.9990;
const UPPER_POLISH_GUARD_CUTOFF: f64 = 0.99;
const NEAR_ATM_X_CUTOFF: f64 = 0.01;

const M00: f64 = -0.00006103098165;
const M01: f64 = 5.33967643357688;
const M10: f64 = -0.40661990365427;
const M02: f64 = 3.25023425332360;
const M11: f64 = -36.19405221599028;
const M20: f64 = 0.08975394404851;
const M03: f64 = 83.84593224417796;
const M12: f64 = 41.21772632732834;
const M21: f64 = 3.83815885394565;
const M30: f64 = -0.21619763215668;

const N00: f64 = 1.0;
const N01: f64 = 22.96302109010794;
const N10: f64 = -0.48466536361620;
const N02: f64 = -0.77268824532468;
const N11: f64 = -1.34102279982050;
const N20: f64 = 0.43027619553168;
const N03: f64 = -5.70531500645109;
const N12: f64 = 2.45782574294244;
const N21: f64 = -0.04763802358853;
const N30: f64 = -0.03326944290044;

impl FlashIV {
    pub fn implied_volatility_from_normalised_price(c: f64, ex: f64, tte: f64) -> IvResult<f64> {
        Self::implied_volatility_from_normalised_price_with_jaeckel(c, ex, tte, false)
    }

    pub fn implied_volatility_from_normalized_price(c: f64, ex: f64, tte: f64) -> IvResult<f64> {
        Self::implied_volatility_from_normalised_price(c, ex, tte)
    }

    pub fn implied_volatility_from_normalised_price_with_jaeckel(
        c: f64,
        ex: f64,
        tte: f64,
        jaeckel_newton_polish: bool,
    ) -> IvResult<f64> {
        if !(tte > 0.0) {
            return Err(IvError::NonPositiveExpiry);
        }
        if c <= 0.0 {
            return Ok(f64::EPSILON);
        }
        if c >= 1.0 {
            return Err(IvError::PriceOutOfRange);
        }
        let x = ex.ln();
        Ok(Self::solve_with_jaeckel(
            x,
            ex,
            c,
            c.ln(),
            tte,
            jaeckel_newton_polish,
        ))
    }

    pub fn implied_volatility_from_normalized_price_with_jaeckel(
        c: f64,
        ex: f64,
        tte: f64,
        jaeckel_newton_polish: bool,
    ) -> IvResult<f64> {
        Self::implied_volatility_from_normalised_price_with_jaeckel(
            c,
            ex,
            tte,
            jaeckel_newton_polish,
        )
    }

    pub fn implied_volatility(
        is_call: bool,
        price: f64,
        forward: f64,
        strike: f64,
        tte: f64,
        discount_factor: f64,
    ) -> IvResult<f64> {
        Self::implied_volatility_with_jaeckel(
            is_call,
            price,
            forward,
            strike,
            tte,
            discount_factor,
            false,
        )
    }

    pub fn implied_volatility_with_jaeckel(
        is_call: bool,
        price: f64,
        forward: f64,
        strike: f64,
        tte: f64,
        discount_factor: f64,
        jaeckel_newton_polish: bool,
    ) -> IvResult<f64> {
        let normalised = black::normalize_price(is_call, price, forward, strike, discount_factor);
        Self::implied_volatility_from_normalised_price_with_jaeckel(
            normalised.c,
            normalised.ex,
            tte,
            jaeckel_newton_polish,
        )
    }

    pub fn solve(x: f64, ex: f64, c: f64, log_c: f64, tte: f64) -> f64 {
        Self::solve_with_jaeckel(x, ex, c, log_c, tte, false)
    }

    pub fn solve_with_jaeckel(
        x: f64,
        ex: f64,
        c: f64,
        log_c: f64,
        tte: f64,
        jaeckel_newton_polish: bool,
    ) -> f64 {
        let implied_vol = solve_unpolished(x, ex, c, log_c, tte);
        if jaeckel_newton_polish && !is_upper_polish_guard(c) {
            black::polish_with_jaeckel_newton(x, ex, c, tte, implied_vol)
        } else {
            implied_vol
        }
    }
}

fn solve_unpolished(x: f64, ex: f64, c: f64, log_c: f64, tte: f64) -> f64 {
    let tiny = black::tiny_near_atm_bachelier_volatility(x, c, log_c, tte);
    if tiny.is_finite() {
        return tiny;
    }

    let mut v = li_or_asym_guess(x, c, log_c, ex);
    if !(v > MIN_TOTAL_VOL) || !v.is_finite() {
        v = MIN_TOTAL_VOL;
    }

    if is_upper_polish_guard(c) {
        v = v.max(upper_price_guess(x, c));
        return black::polish_upper_log_gap_householder(x, c, log_c, v) / tte.sqrt();
    }

    v = black::fast_h3_step(x, v, log_c);
    for iter in 0..3 {
        let (next, residual) = black::exact_h3_step(x, v, log_c);
        v = next;
        if iter >= 1 && residual.abs() < 1e-4 {
            break;
        }
    }
    v / tte.sqrt()
}

fn li_or_asym_guess(x: f64, c: f64, log_c: f64, ex: f64) -> f64 {
    let ax = x.abs();
    if is_upper_price(c) {
        return upper_price_guess(x, c);
    }
    if ax < 3.0 && c > SMALL_PRICE_LI_CUTOFF && c < next_down(UPPER_PRICE_CUTOFF) {
        return li_rational_guess(x, c);
    }
    if c <= SMALL_PRICE_LI_CUTOFF && ax < NEAR_ATM_X_CUTOFF {
        return near_atm_small_price_guess(x, c);
    }
    if c <= 0.5 && log_c < -2.0 {
        return asym_otm_guess(x, log_c);
    }
    let p = 1.0 / ex - c;
    if p > 1e-300 {
        let logp = p.ln();
        let arg = -2.0 * logp - 2.0 * x - black::LOG_2PI;
        if arg > 0.0 {
            let d = arg.sqrt();
            return d + (d * d + 2.0 * x).max(0.0).sqrt();
        }
    }
    (2.0 * x.abs()).sqrt()
}

fn is_upper_price(c: f64) -> bool {
    c >= next_down(UPPER_PRICE_CUTOFF)
}

fn is_upper_polish_guard(c: f64) -> bool {
    c >= next_down(UPPER_POLISH_GUARD_CUTOFF)
}

fn near_atm_small_price_guess(x: f64, c: f64) -> f64 {
    let atm_vol = black::SQRT_TWO_PI * c;
    (x * x + atm_vol * atm_vol).sqrt()
}

fn upper_price_guess(x: f64, c: f64) -> f64 {
    let r = -2.0 * (-c).ln_1p() - black::LOG_2PI;
    let mut d = r.sqrt();
    d -= 0.5 * r.ln() * d / (r + 1.0);
    d + (d * d - 2.0 * x).max(0.0).sqrt()
}

fn li_rational_guess(x: f64, c: f64) -> f64 {
    let x2 = x * x;
    let c2 = c * c;
    let c3 = c2 * c;
    let num = M00
        + x * (M10 + x * (M20 + x * M30))
        + c * (M01 + M11 * x + M21 * x2)
        + c2 * (M02 + M12 * x)
        + c3 * M03;
    let den = N00
        + x * (N10 + x * (N20 + x * N30))
        + c * (N01 + N11 * x + N21 * x2)
        + c2 * (N02 + N12 * x)
        + c3 * N03;
    num / den
}

fn asym_otm_guess(x: f64, log_c: f64) -> f64 {
    let d = (-2.0 * log_c - black::LOG_2PI).sqrt();
    let disc = d * d - 2.0 * x;
    if disc <= 0.0 {
        d
    } else {
        -2.0 * x / (d + disc.sqrt())
    }
}

#[allow(dead_code)]
fn exact_h3_step_inline(x: f64, v: f64, log_c: f64) -> (f64, f64) {
    let h = x / v;
    let t = 0.5 * v;
    let h2 = h * h;
    let t2 = t * t;
    let diff = erfcx_value(-(h + t) / black::SQRT_TWO) - erfcx_value(-(h - t) / black::SQRT_TWO);
    let log_c_est = if x == 0.0 {
        erf_value(t / black::SQRT_TWO).ln()
    } else {
        -0.5 * (h2 + t2) - black::LOG2 - 0.5 * x + diff.ln()
    };
    let log_vega = (2.0 / black::SQRT_TWO_PI) / diff;
    let vov = (h + t) * (h - t) / v;
    let d2 = vov - log_vega;
    let h2mt2 = h2 - t2;
    let d3 = (-3.0 * h2 - t2 + h2mt2 * h2mt2) / (v * v) - 3.0 * log_vega * vov
        + 2.0 * log_vega * log_vega;
    let residual = log_c_est - log_c;
    let hn = -residual / log_vega;
    let numerator = 1.0 + 0.5 * d2 * hn;
    let denominator = 1.0 + d2 * hn + d3 * hn * hn / 6.0;
    let next = v + hn * numerator / denominator;
    (
        if next > 0.0 && next.is_finite() {
            next
        } else {
            v
        },
        residual,
    )
}
