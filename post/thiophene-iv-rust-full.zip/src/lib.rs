pub mod black;

mod flash;
mod jaeckel;
mod math;
mod strontium;
mod thiophene;

pub use flash::FlashIV;
pub use jaeckel::JaeckelSolver;
pub use strontium::StrontiumIV;
pub use thiophene::ThiopheneIV;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IvError {
    PriceOutOfRange,
    NonPositiveExpiry,
}

pub type IvResult<T> = Result<T, IvError>;

pub(crate) fn next_down(x: f64) -> f64 {
    if x.is_nan() || x == f64::NEG_INFINITY {
        x
    } else if x == 0.0 {
        -f64::from_bits(1)
    } else if x > 0.0 {
        f64::from_bits(x.to_bits() - 1)
    } else {
        f64::from_bits(x.to_bits() + 1)
    }
}

#[cfg(test)]
mod tests {
    use super::{black, FlashIV, StrontiumIV, ThiopheneIV};

    fn assert_close(actual: f64, expected: f64, rel_tol: f64) {
        let rel = (actual - expected).abs() / expected.abs().max(1e-300);
        assert!(
            rel <= rel_tol,
            "actual={actual:.17e} expected={expected:.17e} rel={rel:.3e} tol={rel_tol:.3e}"
        );
    }

    #[test]
    fn flash_round_trips_normalised_prices() {
        for &(x, sigma) in &[
            (0.0_f64, 0.005_f64),
            (0.0, 0.2),
            (-0.005, 0.005),
            (-0.1, 0.2),
            (-1.0, 0.5),
            (-1.0, 1.0),
        ] {
            let ex = x.exp();
            let c = black::forward_normalised_black_call(x, sigma);
            assert!(c > 0.0, "underflowed c for x={x} sigma={sigma}");
            let got = FlashIV::implied_volatility_from_normalised_price(c, ex, 1.0).unwrap();
            assert_close(got, sigma, 5e-10);
        }
    }

    #[test]
    fn strontium_round_trips_normalised_prices() {
        for &(x, sigma) in &[
            (0.0_f64, 0.01_f64),
            (0.0, 0.2),
            (-0.005, 0.02),
            (-0.1, 0.2),
            (-1.0, 0.5),
            (-1.0, 1.0),
        ] {
            let ex = x.exp();
            let c = black::forward_normalised_black_call(x, sigma);
            assert!(c > 0.0, "underflowed c for x={x} sigma={sigma}");
            let got = StrontiumIV::implied_volatility_from_normalised_price(c, ex, 1.0).unwrap();
            assert_close(got, sigma, 2e-8);
        }
    }

    #[test]
    fn thiophene_round_trips_normalised_prices() {
        for &(x, sigma) in &[
            (0.0_f64, 0.01_f64),
            (0.0, 0.2),
            (-0.005, 0.02),
            (-0.1, 0.2),
            (-1.0, 0.5),
            (-1.0, 1.0),
        ] {
            let ex = x.exp();
            let c = black::forward_normalised_black_call(x, sigma);
            assert!(c > 0.0, "underflowed c for x={x} sigma={sigma}");
            let got = ThiopheneIV::implied_volatility_from_normalised_price(c, ex, 1.0).unwrap();
            assert_close(got, sigma, 2e-8);
        }
    }
}
