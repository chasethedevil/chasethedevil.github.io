#[link(name = "m")]
extern "C" {
    fn erf(x: f64) -> f64;
    fn erfc(x: f64) -> f64;
}

pub(crate) fn erf_value(x: f64) -> f64 {
    unsafe { erf(x) }
}

pub(crate) fn erfc_value(x: f64) -> f64 {
    unsafe { erfc(x) }
}

pub(crate) fn erfinv_value(x: f64) -> f64 {
    if x <= -1.0 {
        return f64::NEG_INFINITY;
    }
    if x >= 1.0 {
        return f64::INFINITY;
    }
    let mut y = std::f64::consts::FRAC_1_SQRT_2 * norm_inv(0.5 * (1.0 + x));
    for _ in 0..2 {
        let error = erf_value(y) - x;
        let derivative = 2.0 * (-y * y).exp() / std::f64::consts::PI.sqrt();
        if !(derivative > 0.0) || !derivative.is_finite() {
            break;
        }
        let next = y - error / derivative;
        if !next.is_finite() {
            break;
        }
        y = next;
    }
    y
}

pub(crate) fn norm_inv(probability: f64) -> f64 {
    const NORM_INV_LOW: f64 = 0.02425;
    const NORM_INV_HIGH: f64 = 1.0 - NORM_INV_LOW;
    let p = probability
        .max(f64::from_bits(1))
        .min(crate::next_down(1.0));
    if p < NORM_INV_LOW {
        let q = (-2.0 * p.ln()).sqrt();
        return tail_norm_inv(q);
    }
    if p > NORM_INV_HIGH {
        let q = (-2.0 * (-p).ln_1p()).sqrt();
        return -tail_norm_inv(q);
    }

    let q = p - 0.5;
    let r = q * q;
    let num = (((((-39.69683028665376 * r + 220.9460984245205) * r - 275.9285104469687) * r
        + 138.3577518672690)
        * r
        - 30.66479806614716)
        * r
        + 2.506628277459239)
        * q;
    let den = ((((-54.47609879822406 * r + 161.5858368580409) * r - 155.6989798598866) * r
        + 66.80131188771972)
        * r
        - 13.28068155288572)
        * r
        + 1.0;
    num / den
}

fn tail_norm_inv(q: f64) -> f64 {
    (((((-0.007784894002430293 * q - 0.3223964580411365) * q - 2.400758277161838) * q
        - 2.549732539343734)
        * q
        + 4.374664141464968)
        * q
        + 2.938163982698783)
        / ((((0.007784695709041462 * q + 0.3224671290700398) * q + 2.445134137142996) * q
            + 3.754408661907416)
            * q
            + 1.0)
}

pub(crate) fn erfcx_value(z: f64) -> f64 {
    commons_erfcx(z)
}

pub(crate) fn commons_erfcx(x: f64) -> f64 {
    const COMPUTE_ERF: f64 = 0.5;
    const ERFCX_APPROX: f64 = 6.71e7;
    const ERFCX_NEG_X_MAX: f64 = 26.628_735_713_751_49;
    const EXP_XX_1: f64 = 9.778_887_033_462_524e-9;
    const ONE_OVER_ROOT_PI: f64 = 0.564_189_583_547_756_3;

    if x.is_nan() {
        return f64::NAN;
    }
    let ax = x.abs();
    if ax < COMPUTE_ERF {
        let erfx = commons_erf_imp(x, false, false);
        if ax < EXP_XX_1 {
            return 1.0 - erfx;
        }
        let em1 = (x * x).exp_m1();
        return -erfx * em1 + em1 - erfx + 1.0;
    }
    if x < 0.0 {
        if x < -ERFCX_NEG_X_MAX {
            return f64::INFINITY;
        }
        let e = commons_expxx(x);
        return e - commons_erf_imp(-x, true, true) + e;
    }
    if x > ERFCX_APPROX {
        return ONE_OVER_ROOT_PI / x;
    }
    commons_erf_imp(x, true, true)
}

fn commons_erf_imp(z: f64, mut invert: bool, scaled: bool) -> f64 {
    if z.is_nan() {
        return f64::NAN;
    }
    if z < 0.0 {
        if !invert {
            return -commons_erf_imp(-z, invert, false);
        }
        if z < -0.5 {
            return 2.0 - commons_erf_imp(-z, invert, false);
        }
        return 1.0 + commons_erf_imp(-z, false, false);
    }

    let mut result;
    if z < 0.5 {
        if z < 1e-10 {
            result = if z == 0.0 {
                z
            } else {
                z * 1.125 + z * 0.003_379_167_095_512_574
            };
        } else {
            let zz = z * z;
            let mut p = -0.000_322_780_120_964_605_7;
            p = -0.007_727_583_458_021_333 + p * zz;
            p = -0.050_999_073_514_677_74 + p * zz;
            p = -0.338_165_134_459_360_94 + p * zz;
            p = 0.083_430_589_214_653_18 + p * zz;
            let mut q = 0.000_370_900_071_787_748;
            q = 0.008_585_719_250_744_062 + q * zz;
            q = 0.087_522_260_014_225_25 + q * zz;
            q = 0.455_004_033_050_794 + q * zz;
            q = 1.0 + q * zz;
            result = z * (1.044_948_577_880_859_4 + p / q);
        }
    } else if scaled
        || (if invert {
            z < 27.300_781
        } else {
            z < 5.930_664_062_5
        })
    {
        invert = !invert;
        let mut branch_needs_erfc_scaling = true;
        if z < 1.5 {
            let zm = z - 0.5;
            let mut p = 0.001_804_245_382_970_142_2;
            p = 0.019_504_900_125_121_88 + p * zm;
            p = 0.088_890_036_896_788_45 + p * zm;
            p = 0.191_003_695_796_775_44 + p * zm;
            p = 0.178_114_665_841_120_34 + p * zm;
            p = -0.098_090_592_216_281_24 + p * zm;
            let mut q = 0.000_003_375_114_724_830_941_5;
            q = 0.011_338_523_357_700_141 + q * zm;
            q = 0.123_850_974_679_008_64 + q * zm;
            q = 0.578_052_804_889_902_4 + q * zm;
            q = 1.426_280_048_455_113_2 + q * zm;
            q = 1.847_590_709_830_022_2 + q * zm;
            q = 1.0 + q * zm;
            result = 0.405_935_764_312_744_14 + p / q;
        } else if z < 2.5 {
            let zm = z - 1.5;
            let mut p = 0.000_235_839_115_596_880_72;
            p = 0.003_239_624_062_908_421_3 + p * zm;
            p = 0.017_567_943_631_180_21 + p * zm;
            p = 0.043_948_189_642_095_16 + p * zm;
            p = 0.038_654_037_503_570_72 + p * zm;
            p = -0.024_350_047_620_769_844 + p * zm;
            let mut q = 0.004_103_697_239_789_046;
            q = 0.056_392_183_742_047_82 + q * zm;
            q = 0.325_732_924_782_444_45 + q * zm;
            q = 0.982_403_709_157_920_2 + q * zm;
            q = 1.539_914_949_485_524_5 + q * zm;
            q = 1.0 + q * zm;
            result = 0.506_728_172_302_246_1 + p / q;
        } else if z < 4.0 {
            let zm = z - 3.5;
            let mut p = 0.000_011_321_240_664_884_756;
            p = 0.000_250_269_961_544_794_6 + p * zm;
            p = 0.002_128_256_209_146_186_5 + p * zm;
            p = 0.008_408_076_155_555_854 + p * zm;
            p = 0.013_738_442_589_635_534 + p * zm;
            p = 0.002_952_767_165_309_716_6 + p * zm;
            let mut q = 0.000_479_411_269_521_714_5;
            q = 0.010_598_290_648_487_654 + q * zm;
            q = 0.095_849_272_630_106_14 + q * zm;
            q = 0.442_597_659_481_563_14 + q * zm;
            q = 1.042_178_141_669_384_2 + q * zm;
            q = 1.0 + q * zm;
            result = 0.540_575_027_465_820_3 + p / q;
        } else {
            branch_needs_erfc_scaling = false;
            const ONE_OVER_ROOT_PI: f64 = 0.564_189_583_547_756_3;
            let izz = 1.0 / (z * z);
            let mut p = 0.016_315_387_137_302_098;
            p = 0.305_326_634_961_232_34 + p * izz;
            p = 0.360_344_899_949_804_44 + p * izz;
            p = 0.125_781_726_111_229_25 + p * izz;
            p = 0.016_083_785_148_742_277 + p * izz;
            p = 0.000_658_749_161_529_837_8 + p * izz;
            let mut q = 1.0;
            q = 2.568_520_192_289_822_4 + q * izz;
            q = 1.872_952_849_923_460_5 + q * izz;
            q = 0.527_905_102_951_428_4 + q * izz;
            q = 0.060_518_341_312_441_32 + q * izz;
            q = 0.002_335_204_976_268_692 + q * izz;
            result = izz * p / q;
            result = (ONE_OVER_ROOT_PI - result) / z;

            if !scaled {
                result *= commons_expmxx(z);
            }
        }

        if branch_needs_erfc_scaling {
            if scaled {
                result /= z;
            } else {
                result *= commons_expmxx(z) / z;
            }
        }
    } else {
        result = 0.0;
        invert = !invert;
    }

    if invert {
        1.0 - result
    } else {
        result
    }
}

fn commons_expxx(x: f64) -> f64 {
    let hi = x * x;
    let lo = x.mul_add(x, -hi);
    commons_exp_split(hi, lo)
}

fn commons_expmxx(x: f64) -> f64 {
    let hi = x * x;
    let lo = x.mul_add(x, -hi);
    commons_exp_split(-hi, -lo)
}

fn commons_exp_split(a: f64, b: f64) -> f64 {
    let ea = a.exp();
    ea * b + ea
}
