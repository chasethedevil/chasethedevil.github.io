use crate::BachelierApproximation;
use crate::bachelier::{SQRT_2PI, BETA_E, horner_fma, compensated_horner};

// Coefficients for LFK-2026D
const ITM_P: &[f64] = &[
    -4.65265558992178091e-10,
    1.05235933163643455e-06,
    1.47202178774997984e-04,
    5.64558312979549122e-03,
    9.09966326047395163e-02,
    7.34750872354295814e-01,
    3.24402310014664552e+00,
    8.12648140447389089e+00,
    1.14543066346484252e+01,
    8.42485636816455674e+00,
    2.50662827463100069e+00,
];

const ITM_Q: &[f64] = &[
    2.28341984221306373e-06,
    2.36760046313931670e-04,
    7.23828855606915064e-03,
    9.54315750923705464e-02,
    6.39770808881645281e-01,
    2.37191992482267100e+00,
    5.03921642061634589e+00,
    6.07970038657490086e+00,
    3.86103141157010077e+00,
    1.00000000000000000e+00,
];

const OTM1_P: &[f64] = &[
    -2.96395042663182040e+16,
    3.62838879018953520e+16,
    1.78658618333973120e+16,
    1.56904027926578950e+15,
    5.19368756010638359e+13,
    8.91531697161449219e+11,
    9.44581589550058174e+09,
    6.53611675151704401e+07,
    2.99618635665829992e+05,
    8.47530810840063168e+02,
    1.24910559446641112e+00,
];

const OTM1_Q: &[f64] = &[
    1.29269560324044749e+18,
    2.20058295205793216e+17,
    1.06606300118269980e+16,
    2.29858834171351469e+14,
    2.87034661638471143e+12,
    2.31107083200922852e+10,
    1.24493548388175711e+08,
    4.43083541806348017e+05,
    9.64202046959835457e+02,
    1.00000000000000000e+00,
];

const OTM2_P: &[f64] = &[
    -6.61239075869791746e+08,
    1.62378491403351936e+10,
    1.13198337411263535e+11,
    1.19878819579142670e+11,
    4.02855862390664368e+10,
    5.39175086339226437e+09,
    3.14620934571658313e+08,
    8.19927380012440588e+06,
    9.46468717214613571e+04,
    4.96981535010803043e+02,
    1.25074356253990016e+00,
];

const OTM2_Q: &[f64] = &[
    2.23596574526603223e+12,
    5.09238069969748535e+12,
    2.88491100450677539e+12,
    5.91602168132293091e+11,
    5.04459176208850708e+10,
    1.86655405927325511e+09,
    2.95456139630521014e+07,
    1.97937782726469188e+05,
    6.85476271400451537e+02,
    1.00000000000000000e+00,
];

const OTM3_P: &[f64] = &[
    -1.11902532698727715e+01,
    1.07597730298822444e+03,
    4.13667315131132564e+04,
    2.76424097229397390e+05,
    6.32649190526084858e+05,
    6.08248667700386490e+05,
    2.66111592338471615e+05,
    5.37552040498790011e+04,
    4.80344511662094283e+03,
    1.67305954124578307e+02,
    1.62011148722240828e+00,
];

const OTM3_Q: &[f64] = &[
    3.39963113047561375e+05,
    4.63416168998120166e+06,
    1.74050389017384872e+07,
    2.53463649364431314e+07,
    1.62600619921462983e+07,
    4.79251112948869262e+06,
    6.37330539760460495e+05,
    3.48967850482948270e+04,
    6.11826576941137773e+02,
    1.00000000000000000e+00,
];

#[inline]
fn horner_basic(x: f64, c: &[f64]) -> f64 {
    if c.is_empty() {
        return 0.0;
    }
    let mut y = c[0];
    for &coeff in &c[1..] {
        y = y * x + coeff;
    }
    y
}

fn implied_volatility_generic<FITM, FOTM1, FOTM2, FOTM3>(
    forward: f64,
    strike: f64,
    call_price: f64,
    time_to_expiry: f64,
    eval_itm: FITM,
    eval_otm1: FOTM1,
    eval_otm2: FOTM2,
    eval_otm3: FOTM3,
) -> f64
where
    FITM: Fn(f64) -> f64,
    FOTM1: Fn(f64) -> f64,
    FOTM2: Fn(f64) -> f64,
    FOTM3: Fn(f64) -> f64,
{
    let x = forward - strike;
    let sqrt_t = time_to_expiry.sqrt();
    let cotm;
    let mx;
    if x > 0.0 {
        cotm = call_price - x;
        mx = x;
    } else if x < 0.0 {
        cotm = call_price;
        mx = -x;
    } else {
        return call_price / sqrt_t * SQRT_2PI;
    }

    let neg_g = cotm / mx;
    let alpha = 0.15;
    if neg_g > alpha {
        let citm = cotm + mx;
        let u = mx / cotm;
        return citm / sqrt_t * eval_itm(u);
    }
    if neg_g < 1e-300 {
        return 0.0;
    }

    let beta_s = -alpha.ln();
    let inv_beta_range = 1.0 / (BETA_E - beta_s);
    let eta_tilde = -(neg_g.ln() + beta_s) * inv_beta_range;

    let otm_first_split = 1.45000000000000007e-02;
    let otm_second_split = 1.17800000000000002e-01;

    let inv_abs_d = if eta_tilde < otm_first_split {
        eval_otm1(eta_tilde)
    } else if eta_tilde < otm_second_split {
        eval_otm2(eta_tilde)
    } else {
        eval_otm3(eta_tilde)
    };

    mx * inv_abs_d / sqrt_t
}

pub struct Lfk2026D;
pub struct Lfk2026DFma;
pub struct Lfk2026DFmaPlusPlus;

impl BachelierApproximation for Lfk2026D {
    fn name(&self) -> &'static str {
        "LFK-2026D"
    }

    fn implied_vol(&self, forward: f64, strike: f64, call_price: f64, time_to_expiry: f64) -> f64 {
        implied_volatility_generic(
            forward,
            strike,
            call_price,
            time_to_expiry,
            |x| horner_basic(x, ITM_P) / horner_basic(x, ITM_Q),
            |x| horner_basic(x, OTM1_P) / horner_basic(x, OTM1_Q),
            |x| horner_basic(x, OTM2_P) / horner_basic(x, OTM2_Q),
            |x| horner_basic(x, OTM3_P) / horner_basic(x, OTM3_Q),
        )
    }
}

impl BachelierApproximation for Lfk2026DFma {
    fn name(&self) -> &'static str {
        "LFK-2026D+"
    }

    fn implied_vol(&self, forward: f64, strike: f64, call_price: f64, time_to_expiry: f64) -> f64 {
        implied_volatility_generic(
            forward,
            strike,
            call_price,
            time_to_expiry,
            |x| horner_fma(x, ITM_P) / horner_fma(x, ITM_Q),
            |x| horner_fma(x, OTM1_P) / horner_fma(x, OTM1_Q),
            |x| horner_fma(x, OTM2_P) / horner_fma(x, OTM2_Q),
            |x| horner_fma(x, OTM3_P) / horner_fma(x, OTM3_Q),
        )
    }
}

impl BachelierApproximation for Lfk2026DFmaPlusPlus {
    fn name(&self) -> &'static str {
        "LFK-2026D++"
    }

    fn implied_vol(&self, forward: f64, strike: f64, call_price: f64, time_to_expiry: f64) -> f64 {
        implied_volatility_generic(
            forward,
            strike,
            call_price,
            time_to_expiry,
            |x| compensated_horner(x, ITM_P) / compensated_horner(x, ITM_Q),
            |x| compensated_horner(x, OTM1_P) / compensated_horner(x, OTM1_Q),
            |x| compensated_horner(x, OTM2_P) / compensated_horner(x, OTM2_Q),
            |x| compensated_horner(x, OTM3_P) / compensated_horner(x, OTM3_Q),
        )
    }
}
