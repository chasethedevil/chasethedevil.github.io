use crate::BachelierApproximation;
use crate::bachelier::{SQRT_2PI, BETA_E, eta_itm};

pub struct Lfk4;

impl BachelierApproximation for Lfk4 {
    fn name(&self) -> &'static str {
        "LFK-4"
    }

    fn implied_vol(&self, forward: f64, strike: f64, call_price: f64, time_to_expiry: f64) -> f64 {
        implied_volatility(forward, strike, call_price, time_to_expiry)
    }
}

pub fn implied_volatility(forward: f64, strike: f64, call_price: f64, time_to_expiry: f64) -> f64 {
    let x = forward - strike;
    let sqrt_t = time_to_expiry.sqrt();
    let cotm;
    let mx;
    if x > 0.0 {
        cotm = call_price - x;
        mx = x;
    } else if x < 0.0 {
        cotm = call_price;
        mx = -x;
    } else {
        return call_price / sqrt_t * SQRT_2PI;
    }

    let neg_g = cotm / mx;
    let alpha = 0.15;
    if neg_g > alpha {
        let citm = cotm + mx;
        let z = mx / citm;
        if z < 1e-12 {
            return citm / sqrt_t * SQRT_2PI;
        }
        let eta = eta_itm(z);
        return citm / sqrt_t * eval_itm(eta);
    }
    if neg_g < 1e-300 {
        return 0.0;
    }

    let beta_s = -alpha.ln();
    let inv_beta_range = 1.0 / (BETA_E - beta_s);
    let eta_tilde = -(neg_g.ln() + beta_s) * inv_beta_range;
    let h_tilde = if eta_tilde < 0.01 {
        eval_otm1(eta_tilde)
    } else if eta_tilde < 0.09 {
        eval_otm2(eta_tilde)
    } else {
        eval_otm3(eta_tilde)
    };
    mx / (sqrt_t * h_tilde.sqrt())
}

fn eval_itm(eta: f64) -> f64 {
    let mut p = 1.51572668682518700e-01;
    p = p * eta + 1.09330638190985000e+02;
    p = p * eta + 7.90707966760372100e+02;
    p = p * eta + 1.08286456420599900e+03;
    p = p * eta + 3.01082790712661200e+02;
    p = p * eta + 1.08380689149178900e+01;
    p = p * eta + 2.72371165872840300e+00;
    p = p * eta + 6.15537142506315700e-02;

    let mut q = 4.09018764595470300e+01;
    q = q * eta + 3.13477112714715600e+02;
    q = q * eta + 4.41191422131873800e+02;
    q = q * eta + 1.18667485966319300e+02;
    q = q * eta + 1.43606275651932600e+00;
    q = q * eta + 1.00000000000000000e+00;

    p / q
}

fn eval_otm1(eta: f64) -> f64 {
    let mut p = 1.50597534113032100e+16;
    p = p * eta + 2.86426785121224200e+17;
    p = p * eta + 1.79953960350881700e+16;
    p = p * eta + 3.77808909050483900e+14;
    p = p * eta + 4.29625615004082500e+12;
    p = p * eta + 3.05937036117592300e+10;
    p = p * eta + 1.42810081253082500e+08;
    p = p * eta + 4.31496767266483600e+05;
    p = p * eta + 7.76762255354144900e+02;
    p = p * eta + 6.40916855197435600e-01;

    let mut q = 2.11469320780659900e+14;
    q = q * eta + 1.52537970783469100e+13;
    q = q * eta + 3.79858284395221800e+11;
    q = q * eta + 5.00780489626591100e+09;
    q = q * eta + 4.04118077443947400e+07;
    q = q * eta + 2.06873161602072200e+05;
    q = q * eta + 6.40570978803313000e+02;
    q = q * eta + 1.00000000000000000e+00;

    p / q
}

fn eval_otm2(eta: f64) -> f64 {
    let mut p = 5.49285975459723700e+10;
    p = p * eta + 9.27389180065033500e+13;
    p = p * eta + 5.36012253949798100e+13;
    p = p * eta + 8.12797087823512700e+12;
    p = p * eta + 4.29163238246605600e+11;
    p = p * eta + 8.43447050851671200e+09;
    p = p * eta + 6.43096183452158800e+07;
    p = p * eta + 2.78070450475325300e+05;
    p = p * eta + 6.39079933804697600e+02;
    p = p * eta + 6.42169839689494600e-01;

    let mut q = 6.74349669690636500e+10;
    q = q * eta + 3.99260159678884800e+10;
    q = q * eta + 6.35929914962633100e+09;
    q = q * eta + 3.68872214152576800e+08;
    q = q * eta + 8.63513439338472900e+06;
    q = q * eta + 8.68068900260648900e+04;
    q = q * eta + 4.28486009383811600e+02;
    q = q * eta + 1.00000000000000000e+00;

    p / q
}

fn eval_otm3(eta: f64) -> f64 {
    let mut p = 6.72856898188759000e+02;
    p = p * eta + 1.09068992023043900e+08;
    p = p * eta + 6.19268950184923200e+08;
    p = p * eta + 9.30641173003945500e+08;
    p = p * eta + 4.97528976607789800e+08;
    p = p * eta + 1.02052455123794500e+08;
    p = p * eta + 7.68029811694819100e+06;
    p = p * eta + 1.69280158400530700e+05;
    p = p * eta + 3.19590431302283200e+02;
    p = p * eta + 9.41976680476019500e-01;

    let mut q = 7.91790615223977900e+04;
    q = q * eta + 4.51067045062578200e+05;
    q = q * eta + 6.82908543365963500e+05;
    q = q * eta + 3.70696113130561400e+05;
    q = q * eta + 7.84840440802219600e+04;
    q = q * eta + 6.34415954146555400e+03;
    q = q * eta + 1.70382561916735100e+02;
    q = q * eta + 1.00000000000000000e+00;

    p / q
}
