use crate::jaeckel2017::phi_tilde_times_x;

pub const SQRT_2PI: f64 = 2.5066282746310005024157652848110452530069867406099383; // Math.sqrt(2 * Math.PI)
pub const INV_SQRT_2PI: f64 = 0.3989422804014326779399460599343818684758586311649346; // 1 / SQRT_2PI
pub const SQRT_2: f64 = 1.4142135623730950488016887242096980785696718753769480; // Math.sqrt(2)
pub const BETA_E: f64 = 690.77552789821368219662058784810757731777271404094184; // 300.0 * ln(10)

pub fn eta_itm(z: f64) -> f64 {
    if z < 0.01 {
        let z2 = z * z;
        let z3 = z2 * z;
        let z4 = z2 * z2;
        let z5 = z4 * z;
        let z6 = z4 * z2;
        let z7 = z4 * z3;
        let z8 = z4 * z4;
        1.0 - z * 0.5 - z2 / 12.0 - z3 / 24.0 - 19.0 * z4 / 720.0
            - 3.0 * z5 / 160.0 - 863.0 * z6 / 60480.0
            - 275.0 * z7 / 24192.0 - 33953.0 * z8 / 3628800.0
    } else {
        -z / (-z).ln_1p()
    }
}

#[inline]
pub fn horner_fma(x: f64, c: &[f64]) -> f64 {
    if c.is_empty() {
        return 0.0;
    }
    let mut y = c[0];
    for &coeff in &c[1..] {
        y = y.mul_add(x, coeff);
    }
    y
}

#[inline]
pub fn compensated_horner(x: f64, c: &[f64]) -> f64 {
    if c.is_empty() {
        return 0.0;
    }
    let mut s = c[0];
    let mut e = 0.0f64;

    for &coeff in &c[1..] {
        // TwoProduct using FMA
        let p = s * x;
        let pe = s.mul_add(x, -p);

        // TwoSum (Knuth's formula)
        let t = p + coeff;
        let z = t - p;
        let te = (p - (t - z)) + (coeff - z);

        s = t;
        e = e.mul_add(x, pe + te);
    }

    s + e
}

pub fn bachelier_call(forward: f64, strike: f64, sigma: f64, time_to_expiry: f64) -> f64 {
    if sigma <= 0.0 || time_to_expiry <= 0.0 {
        return (forward - strike).max(0.0);
    }
    let x = forward - strike;
    let cotm = bachelier_otm_price(forward, strike, sigma, time_to_expiry);
    if x >= 0.0 {
        x + cotm
    } else {
        cotm
    }
}

pub fn bachelier_otm_price(forward: f64, strike: f64, sigma: f64, time_to_expiry: f64) -> f64 {
    let x = forward - strike;
    let v = sigma * time_to_expiry.sqrt();
    let abs_d = (x / v).abs();
    phi_tilde_times_x(-abs_d) * v
}
