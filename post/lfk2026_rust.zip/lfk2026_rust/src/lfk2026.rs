use crate::BachelierApproximation;
use crate::bachelier::{SQRT_2PI, BETA_E, horner_fma, compensated_horner};

// Coefficients shared by all LFK-2026 variants
const ITM_P: &[f64] = &[
    -3.39451638335349906e-10,
    8.06959950534549627e-07,
    1.17427118047196583e-04,
    4.67776338554095131e-03,
    7.81257091685455263e-02,
    6.51812439800918964e-01,
    2.96457253391146036e+00,
    7.62695942399991100e+00,
    1.10083895644891214e+01,
    8.26914966237441540e+00,
    2.50662827463100069e+00,
];

const ITM_Q: &[f64] = &[
    1.76070970713414280e-06,
    1.90358881940080979e-04,
    6.05262799121958784e-03,
    8.27294623127229206e-02,
    5.72905243689549204e-01,
    2.18581925252758946e+00,
    4.76157470081986212e+00,
    5.87074621959482457e+00,
    3.79891342328838499e+00,
    1.00000000000000000e+00,
];

const OTM1_P: &[f64] = &[
    -1.15188057059215700e+16,
    2.23602102096865640e+16,
    1.35683441709766740e+16,
    1.32385751716178975e+15,
    4.61473754119971406e+13,
    8.14953597568851318e+11,
    8.81948242946073532e+09,
    6.20616261157058701e+07,
    2.89118707775471907e+05,
    8.30013684602045146e+02,
    1.24910559446641112e+00,
];

const OTM1_Q: &[f64] = &[
    9.01018167981477888e+17,
    1.78457095251951296e+17,
    9.31612904921204000e+15,
    2.08194332615256938e+14,
    2.66113331187980811e+12,
    2.18139815883858109e+10,
    1.19319078802154481e+08,
    4.30671117130989209e+05,
    9.50178311644246946e+02,
    1.00000000000000000e+00,
];

const OTM2_P: &[f64] = &[
    4.53512764886659485e+11,
    -3.54669640321780615e+12,
    -1.07736581582367109e+13,
    -5.46607883881420703e+12,
    -8.98414557472468994e+11,
    -5.70761754440745773e+10,
    -1.43888265763526964e+09,
    -1.28046460022976995e+07,
    -1.74963499510044603e+04,
    2.09344504116440078e+02,
    1.25087969033276813e+00,
];

const OTM2_Q: &[f64] = &[
    -3.16204789033010312e+14,
    -3.32157260465782750e+14,
    -9.10822517732905625e+13,
    -8.93831987833861328e+12,
    -3.39232384615881042e+11,
    -4.63359666129231930e+09,
    -1.48653150107890852e+07,
    4.19868074702521844e+04,
    4.55619235679538008e+02,
    1.00000000000000000e+00,
];

const OTM3_P: &[f64] = &[
    4.62144628906322019e+00,
    -1.25257952774401772e+02,
    5.74901275345015438e+03,
    9.82243936325080576e+04,
    3.38490556724923430e+05,
    4.14000232322855853e+05,
    2.11536138072810922e+05,
    4.73452995425928821e+04,
    4.52092618390189637e+03,
    1.63839367097254751e+02,
    1.61713874667576762e+00,
];

const OTM3_Q: &[f64] = &[
    5.54442814599942540e+03,
    1.16810498733679834e+06,
    7.83292053799574263e+06,
    1.55296990844987314e+07,
    1.20766363495907933e+07,
    4.03973802769196732e+06,
    5.83977840443553636e+05,
    3.37041720211591382e+04,
    6.08432004257079598e+02,
    1.00000000000000000e+00,
];

#[inline]
fn horner_basic(x: f64, c: &[f64]) -> f64 {
    if c.is_empty() {
        return 0.0;
    }
    let mut y = c[0];
    for &coeff in &c[1..] {
        y = y * x + coeff;
    }
    y
}

// -------------------------------------------------------------
// Helper impl for volatility approximation logic
// -------------------------------------------------------------
fn implied_volatility_generic<FITM, FOTM1, FOTM2, FOTM3>(
    forward: f64,
    strike: f64,
    call_price: f64,
    time_to_expiry: f64,
    eval_itm: FITM,
    eval_otm1: FOTM1,
    eval_otm2: FOTM2,
    eval_otm3: FOTM3,
) -> f64
where
    FITM: Fn(f64) -> f64,
    FOTM1: Fn(f64) -> f64,
    FOTM2: Fn(f64) -> f64,
    FOTM3: Fn(f64) -> f64,
{
    let x = forward - strike;
    let sqrt_t = time_to_expiry.sqrt();
    let cotm;
    let mx;
    if x > 0.0 {
        cotm = call_price - x;
        mx = x;
    } else if x < 0.0 {
        cotm = call_price;
        mx = -x;
    } else {
        return call_price / sqrt_t * SQRT_2PI;
    }

    let neg_g = cotm / mx;
    let alpha = 0.15;
    if neg_g > alpha {
        let citm = cotm + mx;
        let u = mx / cotm;
        return citm / sqrt_t * eval_itm(u);
    }
    if neg_g < 1e-300 {
        return 0.0;
    }

    let beta_s = -alpha.ln();
    let inv_beta_range = 1.0 / (BETA_E - beta_s);
    let eta_tilde = -(neg_g.ln() + beta_s) * inv_beta_range;

    let otm_first_split = 0.011;
    let otm_second_split = 0.105;

    let inv_abs_d = if eta_tilde < otm_first_split {
        eval_otm1(eta_tilde)
    } else if eta_tilde < otm_second_split {
        eval_otm2(eta_tilde)
    } else {
        eval_otm3(eta_tilde)
    };

    mx * inv_abs_d / sqrt_t
}

// -------------------------------------------------------------
// Structs representing approximations
// -------------------------------------------------------------

pub struct Lfk2026;
pub struct Lfk2026Fma;
pub struct Lfk2026FmaPlusPlus;

impl BachelierApproximation for Lfk2026 {
    fn name(&self) -> &'static str {
        "LFK-2026"
    }

    fn implied_vol(&self, forward: f64, strike: f64, call_price: f64, time_to_expiry: f64) -> f64 {
        implied_volatility_generic(
            forward,
            strike,
            call_price,
            time_to_expiry,
            |x| horner_basic(x, ITM_P) / horner_basic(x, ITM_Q),
            |x| horner_basic(x, OTM1_P) / horner_basic(x, OTM1_Q),
            |x| horner_basic(x, OTM2_P) / horner_basic(x, OTM2_Q),
            |x| horner_basic(x, OTM3_P) / horner_basic(x, OTM3_Q),
        )
    }
}

impl BachelierApproximation for Lfk2026Fma {
    fn name(&self) -> &'static str {
        "LFK-2026+"
    }

    fn implied_vol(&self, forward: f64, strike: f64, call_price: f64, time_to_expiry: f64) -> f64 {
        implied_volatility_generic(
            forward,
            strike,
            call_price,
            time_to_expiry,
            |x| horner_fma(x, ITM_P) / horner_fma(x, ITM_Q),
            |x| horner_fma(x, OTM1_P) / horner_fma(x, OTM1_Q),
            |x| horner_fma(x, OTM2_P) / horner_fma(x, OTM2_Q),
            |x| horner_fma(x, OTM3_P) / horner_fma(x, OTM3_Q),
        )
    }
}

impl BachelierApproximation for Lfk2026FmaPlusPlus {
    fn name(&self) -> &'static str {
        "LFK-2026++"
    }

    fn implied_vol(&self, forward: f64, strike: f64, call_price: f64, time_to_expiry: f64) -> f64 {
        implied_volatility_generic(
            forward,
            strike,
            call_price,
            time_to_expiry,
            |x| compensated_horner(x, ITM_P) / compensated_horner(x, ITM_Q),
            |x| compensated_horner(x, OTM1_P) / compensated_horner(x, OTM1_Q),
            |x| compensated_horner(x, OTM2_P) / compensated_horner(x, OTM2_Q),
            |x| compensated_horner(x, OTM3_P) / compensated_horner(x, OTM3_Q),
        )
    }
}
