use crate::BachelierApproximation;
use crate::bachelier::INV_SQRT_2PI;

pub struct Jaeckel2017;

impl BachelierApproximation for Jaeckel2017 {
    fn name(&self) -> &'static str {
        "Jaeckel2017"
    }

    fn implied_vol(&self, forward: f64, strike: f64, call_price: f64, time_to_expiry: f64) -> f64 {
        implied_volatility(forward, strike, call_price, time_to_expiry)
    }
}

pub fn implied_volatility(forward: f64, strike: f64, call_price: f64, time_to_expiry: f64) -> f64 {
    let x = forward - strike;
    let sqrt_t = time_to_expiry.sqrt();
    if close_moneyness(strike, forward) {
        return call_price / (sqrt_t * INV_SQRT_2PI);
    }

    let time_value = call_price - x.max(0.0);
    if time_value == 0.0 {
        return 0.0;
    }
    if !(time_value > 0.0) {
        return f64::NAN;
    }

    let phi_tilde_star = -((time_value / (strike - forward)).abs());
    let xstar = inverse_phi_tilde(phi_tilde_star);
    ((strike - forward) / (xstar * sqrt_t)).abs()
}

fn inverse_phi_tilde(phi_tilde_star: f64) -> f64 {
    if phi_tilde_star > 1.0 {
        return -inverse_phi_tilde(1.0 - phi_tilde_star);
    }
    if phi_tilde_star >= 0.0 {
        return f64::NAN;
    }

    let xbar = if phi_tilde_star < -0.00188203927 {
        let g = 1.0 / (phi_tilde_star - 0.5);
        let g2 = g * g;
        let xibar = (0.032114372355
            - g2 * (0.016969777977
                - g2 * (0.002620733246 - 0.000096066952861 * g2)))
            / (1.0
                - g2 * (0.6635646938
                    - g2 * (0.14528712196 - 0.010472855461 * g2)));
        g * (INV_SQRT_2PI + xibar * g2)
    } else {
        let h = (-(-phi_tilde_star).ln()).sqrt();
        (9.4883409779
            - h * (9.6320903635
                - h * (0.58556997323 + 2.1464093351 * h)))
            / (1.0
                - h * (0.65174820867
                    + h * (1.5120247828 + 0.000066437847132 * h)))
    };

    let q = (phi_tilde(xbar) - phi_tilde_star) / phi(xbar);
    let xbar2 = xbar * xbar;
    xbar + 3.0 * q * xbar2 * (2.0 - q * xbar * (2.0 + xbar2))
        / (6.0 + q * xbar * (-12.0 + xbar * (6.0 * q
            + xbar * (-6.0 + q * xbar * (3.0 + xbar2)))))
}

fn phi_tilde(x: f64) -> f64 {
    phi_tilde_times_x(x) / x
}

pub fn phi_tilde_times_x(x: f64) -> f64 {
    let abs_x = x.abs();
    if abs_x <= 0.61200318096248076056 {
        let h = (x * x - 1.8727394675409748661e-1) * 5.3397710537550806412;
        let numerator = 1.9641549843774702457e-1
            + h * (2.9444812226268915305e-3 + 3.095828855856470717e-5 * h);
        let denominator = 1.0
            + h * (3.0261016846592326803e-2
                + h * (3.3735461911896198861e-4
                    + h * (1.290112376540573289e-6 - 1.6711975835244204502e-9 * h)));
        let g = numerator / denominator;
        INV_SQRT_2PI + x * (0.5 + x * g)
    } else if x > 0.0 {
        phi_tilde_times_x(-x) + x
    } else if x >= -3.5 {
        let numerator = 3.9894228040096173296e-1
            + x * (-2.8827250122716400843e-1
                + x * (1.1748934770055073669e-1
                    + x * (-2.9208930498324232842e-2
                        + x * (4.6704817087348921557e-3
                            + x * (-4.4448405482476358857e-4
                                + x * (1.9865267442385935787e-5
                                    + x * (7.6387393474143610035e-10
                                        + 1.3291525220137582449e-11 * x)))))));
        let denominator = 1.0
            + x * (-1.9759061396728604494
                + x * (1.7709332198933623888
                    + x * (-9.4350250026446231963e-1
                        + x * (3.2816118145388593816e-1
                            + x * (-7.6697408088214742324e-2
                                + x * (1.1843224303096222834e-2
                                    + x * (-1.1151416365524860908e-3
                                        + 4.9741005333758689307e-5 * x)))))));
        (-0.5 * x * x).exp() * numerator / denominator
    } else {
        let w = 1.0 / (x * x);
        let numerator = 2.999999999999991221
            + w * (2.3654556627823149931e2
                + w * (6.8126773449358787324e3
                    + w * (8.9697941598360784061e4
                        + w * (5.5163920591268613879e5
                            + w * (1.4345061123335662019e6
                                + w * (1.1504988246344881836e6
                                    + 1.1867600400997691371e4 * w))))));
        let denominator = 1.0
            + w * (8.3848522092737134602e1
                + w * (2.6551350587809577877e3
                    + w * (4.0555290884673789153e4
                        + w * (3.166737476299376429e5
                            + w * (1.2329795958024320559e6
                                + w * (2.1409810540619049948e6
                                    + 1.2145667804093160403e6 * w))))));
        let g = numerator / denominator;
        INV_SQRT_2PI * (-0.5 * x * x).exp() * w * (1.0 - g * w)
    }
}

fn phi(x: f64) -> f64 {
    (-0.5 * x * x).exp() * INV_SQRT_2PI
}

fn close_moneyness(x: f64, y: f64) -> bool {
    if x == y {
        return true;
    }
    (x - y).abs() <= f64::MIN_POSITIVE
}
