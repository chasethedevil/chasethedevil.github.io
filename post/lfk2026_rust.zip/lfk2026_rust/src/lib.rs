pub mod bachelier;
pub mod jaeckel2017;
pub mod lfk4;
pub mod lfk2026;
pub mod lfk2026c;
pub mod lfk2026d;

pub trait BachelierApproximation {
    fn name(&self) -> &'static str;
    fn implied_vol(&self, forward: f64, strike: f64, call_price: f64, time_to_expiry: f64) -> f64;
}
