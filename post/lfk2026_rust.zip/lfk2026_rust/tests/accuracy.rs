use lfk2026_rust::BachelierApproximation;
use lfk2026_rust::bachelier::{bachelier_call, bachelier_otm_price};
use lfk2026_rust::jaeckel2017::Jaeckel2017;
use lfk2026_rust::lfk4::Lfk4;
use lfk2026_rust::lfk2026::{Lfk2026, Lfk2026Fma, Lfk2026FmaPlusPlus};
use lfk2026_rust::lfk2026c::{Lfk2026C, Lfk2026CFma, Lfk2026CFmaPlusPlus};
use lfk2026_rust::lfk2026d::{Lfk2026D, Lfk2026DFma, Lfk2026DFmaPlusPlus};

#[test]
fn test_cody_bachelier_formula() {
    // Spot check OTM prices for forward = 1.0, strike = 1.1, sigma = 0.2, T = 1.0
    // d = (1.0 - 1.1) / 0.2 = -0.5. abs(d) = 0.5.
    let price = bachelier_otm_price(1.0, 1.1, 0.2, 1.0);
    assert!(price > 0.0);
    
    let call = bachelier_call(1.0, 1.1, 0.2, 1.0);
    assert_eq!(call, price); // strike > forward, so call price is equal to OTM price
}

#[test]
fn test_approximations_accuracy() {
    let approximations: &[Box<dyn BachelierApproximation>] = &[
        Box::new(Lfk4),
        Box::new(Lfk2026),
        Box::new(Lfk2026Fma),
        Box::new(Lfk2026FmaPlusPlus),
        Box::new(Lfk2026C),
        Box::new(Lfk2026CFma),
        Box::new(Lfk2026CFmaPlusPlus),
        Box::new(Lfk2026D),
        Box::new(Lfk2026DFma),
        Box::new(Lfk2026DFmaPlusPlus),
        Box::new(Jaeckel2017),
    ];

    let f = 1.0;
    let t = 1.0;
    let sigma_ref = 1.0;
    let strikes = &[0.5, 0.8, 1.0, 1.2, 1.5, 2.0, 5.0];

    for approx in approximations {
        for &strike in strikes {
            let price = bachelier_call(f, strike, sigma_ref, t);
            let implied = approx.implied_vol(f, strike, price, t);
            let error = (implied - sigma_ref).abs();
            
            // Check that errors are reasonably small (at least < 1e-3 for standard LFK and far smaller for FMA variants)
            println!("Method: {}, Strike: {}, Implied Vol: {}, Error: {:e}", approx.name(), strike, implied, error);
            assert!(error < 1e-3, "Method {} has too large error: {:e}", approx.name(), error);
        }
    }
}
