# LFK2026 Bachelier Implied Volatility Approximations (Rust)

A high-performance Rust library for the LFK2026 family of Bachelier implied volatility approximations, featuring FMA (Fused Multiply-Add) and FMA++ (compensated Horner scheme error correction).

This package contains Rust implementations of:
- **Jaeckel2017** 
- **LFK-4** 
- **LFK-2026**, **LFK-2026+** (FMA), and **LFK-2026++** (FMA++ with compensated Horner)
- **LFK-2026C**, **LFK-2026C+** (FMA), and **LFK-2026C++** (FMA++)
- **LFK-2026D**, **LFK-2026D+** (FMA), and **LFK-2026D++** (FMA++)

It includes the **Cody Bachelier formula** for pricing option values using Cody's rational approximations for the normal cumulative distribution function (CDF) times $x$.

## Features

- **Standard Arithmetic**: Basic rational evaluations mirroring original Java code.
- **FMA (Fused Multiply-Add)**: Leverages `f64::mul_add` for fused multiply-accumulate operations, improving performance and accuracy.
- **FMA++ (Compensated Horner)**: Implements Knuth's `TwoSum` and `TwoProduct` compensated algorithms via FMA to compute dynamic error correction on rational evaluations, pushing accuracy closer to full double-precision limits.

## Directory Structure

```text
lfk2026_rust/
├── Cargo.toml
├── README.md
├── src/
│   ├── lib.rs            # Traits and module declarations
│   ├── bachelier.rs      # Cody formula, FMA utilities, and constants
│   ├── jaeckel2017.rs    # Jaeckel 2017 implied vol solver
│   ├── lfk4.rs           # LFK-4 implied vol solver
│   ├── lfk2026.rs        # LFK-2026 baseline, +, and ++ versions
│   ├── lfk2026c.rs       # LFK-2026C baseline, +, and ++ versions
│   ├── lfk2026d.rs       # LFK-2026D baseline, +, and ++ versions
│   └── bin/
│       └── comparison.rs # Executable replicating JaeckelLFK2026Comparison.java
└── tests/
    └── accuracy.rs       # Crate integration/accuracy tests
```

## Compilation and Running

### Prerequisites
Make sure you have Rust and Cargo installed:
```bash
cargo --version
```

### Build the Project
To compile the library and the comparison binary in release mode:
```bash
cargo build --release
```

### Run Unit & Integration Tests
To run the automated tests validating approximation accuracy:
```bash
cargo test
```

### Run the Comparison Benchmark
To run the comparison binary (including LF Table 1, bucketed random sampling, Cui-Liu-Yao grid test, and timing runs):
```bash
# Run with the default of 1,000,000 samples per bucket (takes ~1-2 seconds)
RUSTFLAGS="-C target-cpu=native" cargo run --release

# Run with custom number of samples (e.g., 40,000,000)
RUSTFLAGS="-C target-cpu=native" cargo run --release --bin comparison 40000000
```
