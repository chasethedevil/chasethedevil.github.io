package thiopheneiv;

public final class Demo {
    private Demo() {}

    public static void main(String[] args) {
        boolean isCall = true;
        double forward = 100.0;
        double strike = 120.0;
        double tte = 1.0;
        double discountFactor = 1.0;
        double sigmaInput = 0.20;

        double price = ThiopheneIV.priceBlackScholes(
            isCall,
            strike,
            forward,
            sigmaInput * sigmaInput * tte,
            1.0,
            discountFactor
        );

        double sigma = ThiopheneIV.impliedVolatility(
            isCall, price, forward, strike, tte, discountFactor, false);
        double sigmaPlus = ThiopheneIV.impliedVolatility(
            isCall, price, forward, strike, tte, discountFactor, true);

        System.out.printf("Input sigma        : %.17g%n", sigmaInput);
        System.out.printf("Black price        : %.17g%n", price);
        System.out.printf("ThiopheneIV sigma  : %.17g%n", sigma);
        System.out.printf("ThiopheneIV+ sigma : %.17g%n", sigmaPlus);
    }
}
