package thiopheneiv;

import org.apache.commons.numbers.gamma.Erf;
import org.apache.commons.numbers.gamma.Erfc;
import org.apache.commons.numbers.gamma.Erfcx;

/**
 * Standalone ThiopheneIV / ThiopheneIV+ Black-Scholes implied-volatility solver.
 * This is an implementation of F. Le Floc'h "Faster Monotone Implied Volatility Solver",
 * @see <a href="https://arxiv.org/abs/2605.22427">https://arxiv.org/abs/2605.22427</a>.
 *
 * <p>The core uses the Choi-Huh-Su L3 seed, then three cubic steps on the
 * smaller tail-log objective: Euler-Chebyshev on {@code log(c)} for
 * {@code c <= 0.5} and Halley on {@code log(1 - c)} for {@code c > 0.5}.
 *
 * <p>The public implied-volatility API takes standard Black-Scholes option
 * inputs and returns annualised volatility {@code sigma}.
 */
public final class ThiopheneIV {
    private ThiopheneIV() {}

    private static final double SQRT_TWO = Math.sqrt(2.0);
    private static final double SQRT_TWO_PI = Math.sqrt(2.0 * Math.PI);
    private static final double SQRT_PI_OVER_TWO = Math.sqrt(Math.PI / 2.0);
    private static final double ONE_OVER_SQRT_TWO = 1.0 / SQRT_TWO;
    private static final double ONE_OVER_SQRT_TWO_PI = 1.0 / SQRT_TWO_PI;
    private static final double LOG2 = Math.log(2.0);
    private static final double LOG_2PI = Math.log(2.0 * Math.PI);
    private static final double SQRT_DBL_EPS = Math.sqrt(Math.ulp(1.0));
    private static final double FOURTH_ROOT_DBL_EPS = Math.sqrt(SQRT_DBL_EPS);
    private static final double EIGHTH_ROOT_DBL_EPS = Math.sqrt(FOURTH_ROOT_DBL_EPS);
    private static final double SIXTEENTH_ROOT_DBL_EPS = Math.sqrt(EIGHTH_ROOT_DBL_EPS);
    private static final int JAECKEL_ETA = -13;
    private static final double JAECKEL_TAU = 2.0 * SIXTEENTH_ROOT_DBL_EPS;

    private static final double MIN_TOTAL_VOL = 1e-10;
    private static final double DIRECT_POLISH_PRICE_CUTOFF = 0.5;
    private static final double NORM_INV_LOW = 0.02425;
    private static final double NORM_INV_HIGH = 1.0 - NORM_INV_LOW;

    private static final double TINY_PRICE_CUTOFF = 1e-6;
    private static final double TINY_X_CUTOFF = 1e-8;
    private static final double TINY_PRICE_CUTOFF_TOLERANCE = 1.0 + 1e-12;
    private static final double TINY_TAIL_LOG_GAP = 20.0;
    private static final double TINY_TAIL_RATIO_CUTOFF = 4.0;

    /** ThiopheneIV from an option price, forward, strike, expiry, and discount factor. */
    public static double impliedVolatility(boolean isCall, double price, double forward,
                                           double strike, double tte, double discountFactor) {
        return impliedVolatility(isCall, price, forward, strike, tte, discountFactor, false);
    }

    /** ThiopheneIV / ThiopheneIV+ from an option price, forward, strike, expiry, and discount factor. */
    public static double impliedVolatility(boolean isCall, double price, double forward,
                                           double strike, double tte, double discountFactor,
                                           boolean thiophenePlus) {
        double c = price / forward / discountFactor;
        double ex = forward / strike;
        if (!isCall) {
            if (ex <= 1.0) {
                c += 1.0 - 1.0 / ex;
            } else {
                c *= ex;
                ex = 1.0 / ex;
            }
        } else if (ex > 1.0) {
            c = (forward * (c - 1.0) + strike) / strike;
            ex = 1.0 / ex;
        }

        if (c <= 0.0) {
            return Math.ulp(1.0);
        }
        if (c >= 1.0) {
            throw new ArithmeticException("Price out of range");
        }
        double x = Math.log(ex);
        return solve(x, ex, c, Math.log(c), tte, thiophenePlus);
    }

    private static double solve(double x, double ex, double c, double logC,
                               double tte, boolean thiophenePlus) {
        double impliedVol = solveUnpolished(x, ex, c, logC, tte);
        return thiophenePlus && isDirectPolishRegion(c)
            ? betaNewtonPolish(x, ex, c, tte, impliedVol)
            : impliedVol;
    }

    private static boolean isDirectPolishRegion(double c) {
        return c <= DIRECT_POLISH_PRICE_CUTOFF;
    }

    private static double solveUnpolished(double x, double ex, double c, double logC, double tte) {
        double tinyNearAtm = tinyNearAtmBachelierVolatility(x, c, logC, tte);
        if (Double.isFinite(tinyNearAtm)) {
            return tinyNearAtm;
        }

        double v = choiL3Guess(x, ex, c);
        if (!(v > MIN_TOTAL_VOL) || !Double.isFinite(v)) {
            v = fallbackGuess(x, c, logC);
        }
        if (!(v > MIN_TOTAL_VOL) || !Double.isFinite(v)) {
            v = MIN_TOTAL_VOL;
        }

        if (c > 0.5) {
            double gapFromLogPrice = -Math.expm1(logC);
            double targetLogGap = gapFromLogPrice > 0.0 && Double.isFinite(gapFromLogPrice)
                ? Math.log(gapFromLogPrice)
                : Math.log1p(-c);
            for (int iter = 0; iter < 3; iter++) {
                v = halleyLogGapStep(x, v, targetLogGap);
            }
        } else {
            for (int iter = 0; iter < 3; iter++) {
                v = chebyshevLogPriceStep(x, v, logC);
            }
        }

        return v / Math.sqrt(tte);
    }

    private static double chebyshevLogPriceStep(double x, double v, double logC) {
        double h = x / v;
        double t = v / 2.0;
        double diff = Erfcx.value(-(h + t) / SQRT_TWO)
                    - Erfcx.value(-(h - t) / SQRT_TWO);
        if (!(diff > 0.0) || !Double.isFinite(diff)) {
            return v;
        }
        double logCEst = x == 0.0
            ? Math.log(Erf.value(t / SQRT_TWO))
            : -(h * h + t * t) / 2.0 - LOG2 - x / 2.0 + Math.log(diff);
        if (!Double.isFinite(logCEst)) {
            return v;
        }
        double logVega = (2.0 / SQRT_TWO_PI) / diff;
        double d2 = (h + t) * (h - t) / v - logVega;
        double step = -(logCEst - logC) / logVega;
        double next = v + step * (1.0 - 0.5 * d2 * step);
        return next > 0.0 && Double.isFinite(next) ? next : v;
    }

    private static double halleyLogGapStep(double x, double v, double targetLogGap) {
        double d1 = x / v + 0.5 * v;
        double b1 = d1 / SQRT_TWO;
        double d2 = d1 - v;
        double b2 = -d2 / SQRT_TWO;
        double erfcxSum = Erfcx.value(b1) + Erfcx.value(b2);
        if (!(erfcxSum > 0.0) || !Double.isFinite(erfcxSum)) {
            return v;
        }
        double logGap = -b1 * b1 - LOG2 + Math.log(erfcxSum);
        if (!Double.isFinite(logGap)) {
            return v;
        }
        double residual = logGap - targetLogGap;
        double newtonStep = 0.5 * SQRT_TWO_PI * erfcxSum * residual;
        double d1Prime = 0.5 - x / (v * v);
        double secondOverFirst = -d1 * d1Prime + 2.0 / (SQRT_TWO_PI * erfcxSum);
        double denominator = 1.0 + 0.5 * secondOverFirst * newtonStep;
        if (!(denominator > 0.0) || !Double.isFinite(denominator)) {
            return v;
        }
        double next = v + newtonStep / denominator;
        return next > 0.0 && Double.isFinite(next) ? next : v;
    }

    private static double choiL3Guess(double x, double ex, double c) {
        double k = Math.max(-x, 0.0);
        if (k == 0.0) {
            return atmTotalVol(c);
        }
        double ek = 1.0 / ex;
        if (!(ek > 0.0) || !Double.isFinite(ek)) {
            ek = Math.exp(k);
        }
        double denominator = 2.0 * c + ek - 1.0;
        if (!(denominator > 0.0) || !Double.isFinite(denominator)) {
            return Double.NaN;
        }
        double probability = clampProbability(c * (c + ek) / denominator);
        return inverseD1(normInv(probability), k);
    }

    private static double inverseD1(double z, double k) {
        if (k == 0.0) {
            return Math.max(2.0 * z, 0.0);
        }
        double root = Math.sqrt(z * z + 2.0 * k);
        return z >= 0.0 ? z + root : 2.0 * k / (root - z);
    }

    private static double atmTotalVol(double c) {
        if (c < 1e-4) {
            return SQRT_TWO_PI * c * (1.0 + Math.PI * c * c / 12.0);
        }
        return 2.0 * normInv(0.5 * (1.0 + c));
    }

    private static double normInv(double probability) {
        double p = clampProbability(probability);
        if (p < NORM_INV_LOW) {
            double q = Math.sqrt(-2.0 * Math.log(p));
            return tailNormInv(q);
        }
        if (p > NORM_INV_HIGH) {
            double q = Math.sqrt(-2.0 * Math.log1p(-p));
            return -tailNormInv(q);
        }

        double q = p - 0.5;
        double r = q * q;
        double num = (((((-39.69683028665376 * r + 220.9460984245205) * r
                     - 275.9285104469687) * r + 138.3577518672690) * r
                     - 30.66479806614716) * r + 2.506628277459239) * q;
        double den = (((((-54.47609879822406 * r + 161.5858368580409) * r
                     - 155.6989798598866) * r + 66.80131188771972) * r
                     - 13.28068155288572) * r + 1.0);
        return num / den;
    }

    private static double tailNormInv(double q) {
        return (((((-0.007784894002430293 * q - 0.3223964580411365) * q
                - 2.400758277161838) * q - 2.549732539343734) * q
                + 4.374664141464968) * q + 2.938163982698783)
             / ((((0.007784695709041462 * q + 0.3224671290700398) * q
                + 2.445134137142996) * q + 3.754408661907416) * q + 1.0);
    }

    private static double clampProbability(double probability) {
        return Math.min(Math.max(probability, Double.MIN_VALUE), Math.nextDown(1.0));
    }

    private static double fallbackGuess(double x, double c, double logC) {
        if (c < 1e-4 && Math.abs(x) < 0.01) {
            double atmVol = SQRT_TWO_PI * c;
            return Math.sqrt(x * x + atmVol * atmVol);
        }
        double d = Math.sqrt(Math.max(-2.0 * logC - LOG_2PI, 0.0));
        double disc = d * d - 2.0 * x;
        if (disc > 0.0 && d > 0.0) {
            return -2.0 * x / (d + Math.sqrt(disc));
        }
        return Math.sqrt(2.0 * Math.abs(x));
    }

    private static double betaNewtonPolish(double x, double ex, double c, double tte, double impliedVol) {
        if (!(impliedVol > 0.0) || !(tte > 0.0) || !(ex > 0.0) || !(c > 0.0)
                || !Double.isFinite(impliedVol) || !Double.isFinite(tte)) {
            return impliedVol;
        }
        double sqrtEx = Math.sqrt(ex);
        double targetBeta = c * sqrtEx;
        if (!(targetBeta > 0.0) || !(targetBeta < sqrtEx) || !Double.isFinite(targetBeta)) {
            return impliedVol;
        }
        double sqrtTte = Math.sqrt(tte);
        double s = impliedVol * sqrtTte;
        double beta = normalisedBlackBeta(x, s);
        double vega = normalisedVega(x, s);
        if (!(beta > 0.0) || !(vega > 0.0) || !Double.isFinite(beta) || !Double.isFinite(vega)) {
            return impliedVol;
        }
        double next = s - (beta - targetBeta) / vega;
        return next > 0.0 && Double.isFinite(next) ? next / sqrtTte : impliedVol;
    }

    private static double tinyNearAtmBachelierVolatility(double x, double c, double logC, double tte) {
        if (!(c > 0.0) || x > 0.0
                || c > TINY_PRICE_CUTOFF * TINY_PRICE_CUTOFF_TOLERANCE
                || Math.abs(x) > TINY_X_CUTOFF) {
            return Double.NaN;
        }
        double m = -x;
        double beta = c * Math.exp(0.5 * x);
        double logBeta = logC + 0.5 * x;
        double v = tinyBachelierDeepTailVolatility(m, logBeta);
        if (Double.isFinite(v)) {
            return v / Math.sqrt(tte);
        }
        v = lfk2026BachelierVolatility(m, beta);
        if (Double.isFinite(v) && v > 0.0) {
            v = tinyBlackExpansionPolish(m, beta, v);
            return v / Math.sqrt(tte);
        }
        return 0.0;
    }

    private static double tinyBlackExpansionPolish(double m, double beta, double v) {
        if (!(beta > 0.0) || !(v > 0.0) || !Double.isFinite(v)) {
            return v;
        }
        if (m > 0.0 && m / v > TINY_TAIL_RATIO_CUTOFF) {
            return v;
        }
        for (int iter = 0; iter < 2; iter++) {
            double a = m == 0.0 ? 0.0 : m / v;
            double phi = Math.exp(-0.5 * a * a) / SQRT_TWO_PI;
            double derivative = phi * Math.exp(-0.125 * v * v);
            if (!(derivative > 0.0) || !Double.isFinite(derivative)) {
                break;
            }
            double price = tinyBlackSqrtNormalisedExpansion(m, v);
            double step = (price - beta) / derivative;
            double v1 = v - step;
            if (!(v1 > 0.0) || !Double.isFinite(v1)) {
                break;
            }
            v = v1;
            if (Math.abs(step) <= 2.0 * Math.ulp(v)) {
                break;
            }
        }
        return v;
    }

    private static double tinyBlackSqrtNormalisedExpansion(double m, double v) {
        double a = m == 0.0 ? 0.0 : m / v;
        double phi = Math.exp(-0.5 * a * a) / SQRT_TWO_PI;
        double q = m == 0.0 ? 0.5 : 0.5 * Erfc.value(a / SQRT_TWO);
        double i0 = v * phi - m * q;
        double v2 = v * v;
        double m2 = m * m;
        double i2 = (v2 * v * phi - m2 * i0) / 3.0;
        double i4 = (v2 * v2 * v * phi - m2 * i2) / 5.0;
        return i0 - 0.125 * i2 + i4 / 128.0;
    }

    private static double tinyBachelierDeepTailVolatility(double k, double logC) {
        if (!(k > 0.0) || !Double.isFinite(logC)) {
            return Double.NaN;
        }
        double logGap = Math.log(k) - logC;
        if (logGap <= TINY_TAIL_LOG_GAP) {
            return Double.NaN;
        }
        double targetLogRatio = logC - Math.log(k);
        double tailRatio = Math.sqrt(Math.max(1.0, -2.0 * (targetLogRatio + 0.5 * LOG_2PI)));
        for (int iter = 0; iter < 4; iter++) {
            double millsRatio = SQRT_PI_OVER_TWO * Erfcx.value(tailRatio / SQRT_TWO);
            double scaledGap = 1.0 / tailRatio - millsRatio;
            if (!(scaledGap > 0.0) || !Double.isFinite(scaledGap)) {
                return Double.NaN;
            }
            double residual = -0.5 * tailRatio * tailRatio - 0.5 * LOG_2PI
                            + Math.log(scaledGap) - targetLogRatio;
            double slope = -tailRatio
                + (1.0 - 1.0 / (tailRatio * tailRatio) - tailRatio * millsRatio) / scaledGap;
            double step = residual / slope;
            double next = tailRatio - step;
            if (!(next > 0.0) || !Double.isFinite(next)) {
                return Double.NaN;
            }
            tailRatio = next;
            if (Math.abs(step) <= 1e-14 * Math.max(1.0, tailRatio)) {
                break;
            }
        }
        double v = k / tailRatio;
        return k / v > TINY_TAIL_RATIO_CUTOFF ? v : Double.NaN;
    }

    private static final double LFK2026_ALPHA = 0.15;
    private static final double LFK2026_BETA_S = -Math.log(LFK2026_ALPHA);
    private static final double LFK2026_BETA_E = 300.0 * Math.log(10.0);
    private static final double LFK2026_INV_BETA_RANGE = 1.0 / (LFK2026_BETA_E - LFK2026_BETA_S);

    private static double lfk2026BachelierVolatility(double k, double c) {
        if (!(c > 0.0) || !(k > 0.0)) {
            return k == 0.0 && c > 0.0 ? SQRT_TWO_PI * c : Double.NaN;
        }
        double zPos = c / k;
        if (zPos > LFK2026_ALPHA) {
            double u = k / c;
            return (c + k) * lfk2026EvalItm(u);
        }
        if (zPos < 1e-300) {
            return 0.0;
        }
        double etaTilde = -(Math.log(zPos) + LFK2026_BETA_S) * LFK2026_INV_BETA_RANGE;
        double invAbsD = etaTilde < 0.01
            ? lfk2026EvalOtm1(etaTilde)
            : (etaTilde < 0.09 ? lfk2026EvalOtm2(etaTilde) : lfk2026EvalOtm3(etaTilde));
        return k * invAbsD;
    }

    private static double lfk2026EvalItm(double u) {
        double p = -2.70797042551215202e-09;
        p = p * u + 5.03803837400379678e-06;
        p = p * u + 5.87928493313025560e-04;
        p = p * u + 1.83954491376296485e-02;
        p = p * u + 2.36012991833862845e-01;
        p = p * u + 1.47171929792136824e+00;
        p = p * u + 4.81532474104199881e+00;
        p = p * u + 8.38783649295939249e+00;
        p = p * u + 7.32071451154750097e+00;
        p = p * u + 2.50662827463100024e+00;
        double q = 1.06715338537575127e-05;
        q = q * u + 9.08750187647611803e-04;
        q = q * u + 2.23188636991579585e-02;
        q = q * u + 2.30574991341749191e-01;
        q = q * u + 1.17534367470784673e+00;
        q = q * u + 3.18165296194859026e+00;
        q = q * u + 4.63611136038634353e+00;
        q = q * u + 3.42054254140456848e+00;
        q = q * u + 1.00000000000000000e+00;
        return p / q;
    }

    private static double lfk2026EvalOtm1(double eta) {
        double p = -3.48308852288966554e+18;
        p = p * eta + 1.10299370004290995e+18;
        p = p * eta - 4.02413716168378048e+17;
        p = p * eta - 7.43714349945829120e+16;
        p = p * eta - 2.49477863322856750e+15;
        p = p * eta - 2.85331260987706523e+13;
        p = p * eta - 5.10817469063371429e+10;
        p = p * eta + 2.40533073130836535e+09;
        p = p * eta + 3.07861092585915886e+07;
        p = p * eta + 1.95717866058198881e+05;
        p = p * eta + 6.82178299087715914e+02;
        p = p * eta + 1.24910559446641112e+00;
        double q = -8.65868218927210598e+18;
        q = q * eta - 5.43691399201888000e+17;
        q = q * eta - 9.16374230029381000e+15;
        q = q * eta - 4.73283686242051484e+13;
        q = q * eta + 4.46201521087863831e+11;
        q = q * eta + 9.14684611768276405e+09;
        q = q * eta + 7.18091511301956624e+07;
        q = q * eta + 3.22084448691854079e+05;
        q = q * eta + 8.31825318775392361e+02;
        q = q * eta + 1.00000000000000000e+00;
        return p / q;
    }

    private static double lfk2026EvalOtm2(double eta) {
        double p = 2.99147136389716260e+12;
        p = p * eta - 8.76625536254249121e+12;
        p = p * eta + 3.09426714906955234e+13;
        p = p * eta + 5.73825498368429922e+13;
        p = p * eta + 2.03806992766065625e+13;
        p = p * eta + 2.58076177636243115e+12;
        p = p * eta + 1.39249460078530365e+11;
        p = p * eta + 3.45074450506824827e+09;
        p = p * eta + 4.12660599897888750e+07;
        p = p * eta + 2.57450335132154607e+05;
        p = p * eta + 8.82143141269435318e+02;
        p = p * eta + 1.24860495497317925e+00;
        double q = 2.10719786854519525e+15;
        q = q * eta + 1.45588799532258475e+15;
        q = q * eta + 2.92823593402229500e+14;
        q = q * eta + 2.31200993253629883e+13;
        q = q * eta + 7.95484765720863647e+11;
        q = q * eta + 1.24794454367125645e+10;
        q = q * eta + 9.56102882581782639e+07;
        q = q * eta + 4.17679926778023364e+05;
        q = q * eta + 9.91194200989211254e+02;
        q = q * eta + 1.00000000000000000e+00;
        return p / q;
    }

    private static double lfk2026EvalOtm3(double eta) {
        double p = -1.01865471163877160e+02;
        p = p * eta + 2.99524578014802091e+03;
        p = p * eta - 1.04999322668089051e+05;
        p = p * eta - 1.90438009836981818e+06;
        p = p * eta - 6.49374308713343088e+06;
        p = p * eta - 7.65563194503842667e+06;
        p = p * eta - 3.62091305895698769e+06;
        p = p * eta - 6.78815730118479463e+05;
        p = p * eta - 3.63727433825341577e+04;
        p = p * eta + 1.53669112770474931e+03;
        p = p * eta + 1.34977888075358550e+02;
        p = p * eta + 1.61947615412173973e+00;
        double q = -2.24196883894425444e+07;
        q = q * eta - 1.51588857602825403e+08;
        q = q * eta - 2.93510878971269727e+08;
        q = q * eta - 2.16291778562989831e+08;
        q = q * eta - 6.44309250732882321e+07;
        q = q * eta - 6.85415582536362950e+06;
        q = q * eta - 3.44836595974720476e+04;
        q = q * eta + 2.27524257249606417e+04;
        q = q * eta + 5.91576136257250369e+02;
        q = q * eta + 1.00000000000000000e+00;
        return p / q;
    }

    private static double normalisedBlackBeta(double x, double s) {
        if (x <= 0.0) {
            return stableNormalisedBlack(x, s);
        }
        return stableNormalisedBlack(-x, s) + Math.exp(0.5 * x) - Math.exp(-0.5 * x);
    }

    private static double stableNormalisedBlack(double thetaX, double s) {
        if (thetaX == 0.0) {
            return Erf.value(0.5 * ONE_OVER_SQRT_TWO * s);
        }
        if (s <= 0.0) {
            return 0.0;
        }
        if (isJaeckelRegionI(thetaX, s)) {
            return asymptoticExpansionOfScaledNormalisedBlack(thetaX / s, 0.5 * s)
                * normalisedVega(thetaX, s);
        }
        if (isJaeckelRegionII(thetaX, s)) {
            return smallTExpansionOfScaledNormalisedBlack(thetaX / s, 0.5 * s)
                * normalisedVega(thetaX, s);
        }
        return stableNormalisedBlackCodys(thetaX, s);
    }

    private static boolean isJaeckelRegionI(double thetaX, double s) {
        return thetaX < s * JAECKEL_ETA
            && s * (0.5 * s - (JAECKEL_TAU + 0.5 + JAECKEL_ETA)) + thetaX < 0.0;
    }

    private static boolean isJaeckelRegionII(double thetaX, double s) {
        return s * (s - 2.0 * JAECKEL_TAU) - thetaX / JAECKEL_ETA < 0.0;
    }

    private static double asymptoticExpansionOfScaledNormalisedBlack(double h, double t) {
        double e = (t / h) * (t / h);
        double r = (h + t) * (h - t);
        double q = (h / r) * (h / r);
        double a0 = 2.0;
        double a1 = -6.0 - 2.0 * e;
        double a2 = 30.0 + e * (60.0 + 6.0 * e);
        double a3 = -210.0 + e * (-1050.0 + e * (-630.0 - 30.0 * e));
        double a4 = 1890.0 + e * (17640.0 + e * (26460.0 + e * (7560.0 + 210.0 * e)));
        double a5 = -20790.0 + e * (-311850.0 + e * (-873180.0 + e * (-623700.0 + e * (-103950.0 - 1890.0 * e))));
        double a6 = 270270.0 + e * (5945940.0 + e * (26756730.0 + e * (35675640.0 + e * (14864850.0 + e * (1621620.0 + 20790.0 * e)))));
        double a7 = -4054050.0 + e * (-122972850.0 + e * (-811620810.0 + e * (-1739187450.0 + e * (-1352701350.0 + e * (-368918550.0 + e * (-28378350.0 - 270270.0 * e))))));
        double a8 = 68918850.0 + e * (2756754000.0 + e * (25086461400.0 + e * (78843164400.0 + e * (98553955500.0 + e * (50172922800.0 + e * (9648639000.0 + e * (551350800.0 + 4054050.0 * e)))))));
        double a9 = -1309458150.0 + e * (-66782365650.0 + e * (-801388387800.0 + e * (-3472683013800.0 + e * (-6366585525300.0 + e * (-5209024520700.0 + e * (-1869906238200.0 + e * (-267129462600.0 + e * (-11785123350.0 - 68918850.0 * e))))))));
        double a10 = 27498621150.0 + e * (1741579339500.0 + e * (26646163894350.0 + e * (152263793682000.0 + e * (384889034029500.0 + e * (461866840835400.0 + e * (266461638943500.0 + e * (71056437051600.0 + e * (7837107027750.0 + e * (274986211500.0 + 1309458150.0 * e)))))))));
        double a11 = -632468286450.0 + e * (-48700058056650.0 + e * (-925301103076350.0 + e * (-6741479465270550.0 + e * (-22471598217568500.0 + e * (-37180280687249700.0 + e * (-31460237504595900.0 + e * (-13482958930541100.0 + e * (-2775903309229050.0 + e * (-243500290283250.0 + e * (-6957151150950.0 - 27498621150.0 * e))))))))));
        double a12 = 15811707161250.0 + e * (1454677058835000.0 + e * (33603040059088500.0 + e * (304027505296515000.0 + e * (1.29211689751018875e18 + e * (2.81916414002223e18 + e * (3.289024830025935e18 + e * (2.067387036016302e18 + e * (6.8406188691715875e17 + e * (1.12010133530295e17 + e * (8.0007238235925e15 + e * (1.89740485935e14 + 6.3246828645e11 * e)))))))))));
        double a13 = -4.2691609335375e14 + e * (-4.624924344665625e16 + e * (-1.2764791191277125e18 + e * (-1.40412703104048375e19 + e * (-7.41067044160255312e19 + e * (-2.06151377739125569e20 + e * (-3.17155965752500875e20 + e * (-2.74868503652167425e20 + e * (-1.33392067948845956e20 + e * (-3.51031757760120938e19 + e * (-4.6804234368016125e18 + e * (-2.774954606799375e17 + e * (-5.54990921359875e15 - 1.581170716125e13 * e))))))))))));
        double a14 = 1.238056670725875e16 + e * (1.5599514051146025e18 + e * (5.06984206662245812e19 + e * (6.66322100184665925e20 + e * (4.27556680951827302e21 + e * (1.47701398874267613e22 + e * (2.89721974714909549e22 + e * (3.31110828245610914e22 + e * (2.2155209831140142e22 + e * (8.55113361903654604e21 + e * (1.83238577550783129e21 + e * (2.02793682664898325e20 + e * (1.01396841332449162e19 + e * (1.733279339016225e17 + 4.2691609335375e14 * e)))))))))))));
        double a15 = -3.8379756792502125e17 + e * (-5.56506473491280812e19 + e * (-2.10359446979704147e21 + e * (-3.25556286992399275e22 + e * (-2.49593153360839444e23 + e * (-1.04829124411552567e24 + e * (-2.55352995361474201e24 + e * (-3.72085793241005264e24 + e * (-3.28310994036181115e24 + e * (-1.74715207352587611e24 + e * (-5.49104937393846778e23 + e * (-9.76668860977197826e22 + e * (-9.11557603578717971e21 + e * (-3.89554531443896569e20 + e * (-5.75696351887531875e18 - 1.238056670725875e16 * e))))))))))))));
        double a16 = 1.26653197415257012e19 + e * (2.09399953059891594e21 + e * (9.10889795810528434e22 + e * (1.63960163245895118e24 + e * (1.48019591819210871e25 + e * (7.42789224401858187e25 + e * (2.19979885688242617e26 + e * (3.98058840769200926e26 + e * (4.47816195865351041e26 + e * (3.1425697955463231e26 + e * (1.36178024473674001e26 + e * (3.55247020366106089e25 + e * (5.32870530549159134e24 + e * (4.25081904711579936e23 + e * (1.57049964794918696e22 + e * (2.0264511586441122e20 + 3.8379756792502125e17 * e)))))))))))))));

        double[] thresholds = {12.347, 12.958, 13.729, 14.718, 16.016, 17.769, 20.221, 23.816, 29.419, 38.93, 57.171, 99.347};
        double val = -h - t + JAECKEL_TAU + 0.5;
        double[] coeffs = {a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16};
        int upperBound = 0;
        while (upperBound < thresholds.length && thresholds[upperBound] <= val) {
            upperBound++;
        }
        int nExtra = coeffs.length - upperBound;
        double omega = 0.0;
        for (int k = nExtra - 1; k >= 0; k--) {
            omega = q * (coeffs[k] + omega);
        }
        omega = a0 + q * (a1 + q * (a2 + q * (a3 + q * (a4 + omega))));
        return (t / r) * omega;
    }

    private static double yPrimeTailRational(double w) {
        return w * (-2.9999999999994663866 + w * (-1.7556263323542206288e2 + w * (-3.4735035445495633334e3
            + w * (-2.7805745693864308643e4 + w * (-8.3836021460741980839e4 - 6.6818249032616849037e4 * w)))))
            / (1.0 + w * (6.3520877744831739102e1 + w * (1.4404389037604337538e3 + w * (1.4562545638507033944e4
            + w * (6.6886794165651675684e4 + w * (1.2569970380923908488e5 + 6.9286518679803751694e4 * w))))));
    }

    private static double yPrime(double h) {
        if (h < -4.0) {
            double w = 1.0 / (h * h);
            return w * (1.0 + yPrimeTailRational(w));
        }
        if (h <= -0.46875) {
            return (1.0000000000594317229 - h * (6.1911449879694112749e-1 - h * (2.2180844736576013957e-1
                - h * (4.5650900351352987865e-2 - h * (5.545521007735379052e-3 - h * (3.0717392274913902347e-4
                - h * (4.2766597835908713583e-8 + 8.4592436406580605619e-10 * h)))))))
                / (1.0 - h * (1.8724286369589162071 - h * (1.5685497236077651429 - h * (7.6576489836589035112e-1
                - h * (2.3677701403094640361e-1 - h * (4.6762548903194957675e-2
                - h * (5.5290453576936595892e-3 - 3.0822020417927147113e-4 * h)))))));
        }
        return 1.0 + h * SQRT_PI_OVER_TWO * Erfcx.value(-ONE_OVER_SQRT_TWO * h);
    }

    private static double smallTExpansionOfScaledNormalisedBlack(double h, double t) {
        double a = yPrime(h);
        double h2 = h * h;
        double t2 = t * t;
        double b0 = 2.0 * a;
        double b1 = (-1.0 + a * (3.0 + h2)) / 3.0;
        double b2 = (-7.0 - h2 + a * (15.0 + h2 * (10.0 + h2))) / 60.0;
        double b3 = (-57.0 + (-18.0 - h2) * h2 + a * (105.0 + h2 * (105.0 + h2 * (21.0 + h2)))) / 2520.0;
        double b4 = (-561.0 + h2 * (-285.0 + (-33.0 - h2) * h2) + a * (945.0 + h2 * (1260.0 + h2 * (378.0 + h2 * (36.0 + h2))))) / 181440.0;
        double b5 = (-6555.0 + h2 * (-4680.0 + h2 * (-840.0 + (-52.0 - h2) * h2)) + a * (10395.0 + h2 * (17325.0 + h2 * (6930.0 + h2 * (990.0 + h2 * (55.0 + h2)))))) / 19958400.0;
        double b6 = (-89055.0 + h2 * (-82845.0 + h2 * (-20370.0 + h2 * (-1926.0 + (-75.0 - h2) * h2))) + a * (135135.0 + h2 * (270270.0 + h2 * (135135.0 + h2 * (25740.0 + h2 * (2145.0 + h2 * (78.0 + h2))))))) / 3113510400.0;
        return t * (b0 + t2 * (b1 + t2 * (b2 + t2 * (b3 + t2 * (b4 + t2 * (b5 + b6 * t2))))));
    }

    private static double stableNormalisedBlackCodys(double thetaX, double s) {
        double h = thetaX / s;
        double t = 0.5 * s;
        double q1 = -ONE_OVER_SQRT_TWO * (h + t);
        double q2 = -ONE_OVER_SQRT_TWO * (h - t);
        double codysThreshold = 0.46875;
        double twoB;
        if (q1 < codysThreshold) {
            if (q2 < codysThreshold) {
                twoB = Math.exp(0.5 * thetaX) * Erfc.value(q1)
                    - Math.exp(-0.5 * thetaX) * Erfc.value(q2);
            } else {
                twoB = Math.exp(0.5 * thetaX) * Erfc.value(q1)
                    - Math.exp(-0.5 * (h * h + t * t)) * Erfcx.value(q2);
            }
        } else {
            if (q2 < codysThreshold) {
                twoB = Math.exp(-0.5 * (h * h + t * t)) * Erfcx.value(q1)
                    - Math.exp(-0.5 * thetaX) * Erfc.value(q2);
            } else {
                twoB = Math.exp(-0.5 * (h * h + t * t)) * (Erfcx.value(q1) - Erfcx.value(q2));
            }
        }
        return Math.max(0.5 * twoB, 0.0);
    }

    private static double normalisedVega(double x, double s) {
        double ax = Math.abs(x);
        if (ax == 0.0) {
            return ONE_OVER_SQRT_TWO_PI * Math.exp(-0.125 * s * s);
        }
        if (s <= 0.0 || s <= ax * Math.sqrt(Double.MIN_NORMAL)) {
            return 0.0;
        }
        double h = x / s;
        double t = 0.5 * s;
        return ONE_OVER_SQRT_TWO_PI * Math.exp(-0.5 * (h * h + t * t));
    }

    /** Accurate Black-Scholes price through the sqrt-forward beta value. */
    public static double priceBlackScholes(boolean isCall, double strike, double spot,
                                           double totalVariance, double driftDiscountFactor,
                                           double discountFactor) {
        int sign = isCall ? 1 : -1;
        double forward = spot / driftDiscountFactor;
        if (totalVariance < Math.ulp(1.0)) {
            return discountFactor * Math.max(sign * (forward - strike), 0.0);
        }
        double s = Math.sqrt(totalVariance);
        double x = Math.log(forward / strike);
        double sqrtFK = Math.sqrt(forward * strike);
        if (isCall) {
            if (x <= 0.0) {
                return discountFactor * sqrtFK * normalisedBlackBeta(x, s);
            }
            return discountFactor * sqrtFK * normalisedBlackBeta(-x, s)
                 + discountFactor * (forward - strike);
        }
        if (x >= 0.0) {
            return discountFactor * sqrtFK * normalisedBlackBeta(-x, s);
        }
        return discountFactor * sqrtFK * normalisedBlackBeta(x, s)
             + discountFactor * (strike - forward);
    }

}
