# ThiopheneIV

Small standalone Java implementation of **ThiopheneIV** and **ThiopheneIV+**.

ThiopheneIV uses the Choi-Huh-Su L3 lower-bound seed followed by three
full-precision cubic corrections on the smaller tail-log objective:
Euler-Chebyshev on `log(c)` for `c <= 0.5` and Halley on `log(1-c)` for
`c > 0.5`.
ThiopheneIV+ adds one final Newton polish in sqrt-forward beta space only for
`c <= 0.5`; the upper half already uses the complementary `log(1-c)` objective.

## Requirements

- Java 17 or newer
- Gradle or Maven

The only runtime dependency is:

```text
org.apache.commons:commons-numbers-gamma:1.2
```

## Try it

With Gradle:

```bash
gradle run
```

With Maven:

```bash
mvn -q compile exec:java
```

The demo prices a Black-Scholes call option, then recovers the implied
volatility with ThiopheneIV and ThiopheneIV+.

## API

The public API is intentionally small: one implied-volatility entry point
(optionally enabling the ThiopheneIV+ polish) and one Black pricing helper for
examples/tests.

```java
double sigma = ThiopheneIV.impliedVolatility(
    true,   // isCall
    price,
    forward,
    strike,
    timeToExpiry,
    discountFactor,
    true    // true = ThiopheneIV+, false = ThiopheneIV
);
```

```java
double price = ThiopheneIV.priceBlackScholes(
    true,             // isCall
    strike,
    spot,
    sigma * sigma * timeToExpiry,
    driftDiscountFactor,
    discountFactor
);
```

`priceBlackScholes` takes `spot` plus two discount factors:

- `driftDiscountFactor` converts spot to the forward used in Black-Scholes:
    `forward = spot / driftDiscountFactor`.  For an equity with continuous risk-free
    rate `r` and dividend yield `q`, this is typically `exp(-(r - q) * T)`, so
    `forward = spot * exp((r - q) * T)`.  If you already have an equity forward
    curve, set `driftDiscountFactor = spot / forward`.
- `discountFactor` discounts the option payoff/payment date back to today.  In
    a collateralised equity setup this is often the OIS discount factor for the
    option payment date, for example from the relevant OIS curve.

For `impliedVolatility`, pass the already-computed `forward`, the present-value
option `price`, and the same payment `discountFactor` used to price it.

## Files

- `src/main/java/thiopheneiv/ThiopheneIV.java` - solver and helpers
- `src/main/java/thiopheneiv/Demo.java` - minimal runnable example

This folder is independent from the surrounding research repository and is
intended to be zipped or uploaded as its own small repo.
