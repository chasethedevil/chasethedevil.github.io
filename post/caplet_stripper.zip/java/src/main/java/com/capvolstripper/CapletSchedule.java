package com.capvolstripper;

import java.util.Arrays;

final class CapletSchedule {
    private final int frequencyMonths;
    private final double[] capletMonths;
    private final double[] expiries;
    private final double[] accruals;
    private final int[] capIndices;
    private final double[] nodeTimes;

    private CapletSchedule(int frequencyMonths, double[] capletMonths, double[] expiries,
                           double[] accruals, int[] capIndices, double[] nodeTimes) {
        this.frequencyMonths = frequencyMonths;
        this.capletMonths = capletMonths;
        this.expiries = expiries;
        this.accruals = accruals;
        this.capIndices = capIndices;
        this.nodeTimes = nodeTimes;
    }

    static CapletSchedule build(double[] capMaturitiesMonths, StripConfig config) {
        int frequency = config.capletFrequencyMonths();
        double maxMaturity = capMaturitiesMonths[capMaturitiesMonths.length - 1];
        double lastMonth = config.rateType() == RateType.FORWARD ? maxMaturity - frequency : maxMaturity;
        int nCaplets = (int) Math.round(lastMonth / frequency);
        if (nCaplets <= 0) {
            throw new IllegalArgumentException("cap schedule has no caplets");
        }

        double[] capletMonths = new double[nCaplets];
        double[] expiries = new double[nCaplets];
        double[] accruals = new double[nCaplets];
        double accrual = frequency / 12.0;
        for (int i = 0; i < nCaplets; i++) {
            capletMonths[i] = (i + 1.0) * frequency;
            expiries[i] = capletMonths[i] / 12.0;
            accruals[i] = accrual;
        }

        int offset = config.rateType() == RateType.FORWARD ? 1 : 0;
        int[] capIndices = new int[capMaturitiesMonths.length];
        for (int q = 0; q < capMaturitiesMonths.length; q++) {
            capIndices[q] = (int) Math.round(capMaturitiesMonths[q] / frequency) - offset;
            if (capIndices[q] < 1 || capIndices[q] > nCaplets) {
                throw new IllegalArgumentException("cap maturity " + capMaturitiesMonths[q]
                        + "M maps to invalid caplet index " + capIndices[q]);
            }
        }

        double[] nodeTimes = nodeTimes(capMaturitiesMonths, config);
        return new CapletSchedule(frequency, capletMonths, expiries, accruals, capIndices, nodeTimes);
    }

    int frequencyMonths() {
        return frequencyMonths;
    }

    int capletCount() {
        return capletMonths.length;
    }

    int quoteCount() {
        return capIndices.length;
    }

    double capletMonth(int index) {
        return capletMonths[index];
    }

    double expiry(int index) {
        return expiries[index];
    }

    double accrual(int index) {
        return accruals[index];
    }

    int capIndex(int quoteIndex) {
        return capIndices[quoteIndex];
    }

    double[] expiries() {
        return expiries.clone();
    }

    double[] nodeTimes() {
        return nodeTimes.clone();
    }

    double[] rawNodeTimes() {
        return nodeTimes;
    }

    double[] nodeTimesUntil(int quoteIndex) {
        return Arrays.copyOf(nodeTimes, quoteIndex + 1);
    }

    private static double[] nodeTimes(double[] capMaturitiesMonths, StripConfig config) {
        double nodeShift = config.rateType() == RateType.FORWARD ? config.capletFrequencyMonths() : 0.0;
        double[] shifted = Arrays.stream(capMaturitiesMonths).map(m -> m - nodeShift).toArray();
        if (config.knotPlacement() == KnotPlacement.AT_MATURITIES) {
            return shifted;
        }
        double[] nodeTimes = new double[shifted.length];
        nodeTimes[0] = shifted[0];
        for (int i = 1; i < shifted.length; i++) {
            nodeTimes[i] = 0.5 * (shifted[i - 1] + shifted[i]);
        }
        return nodeTimes;
    }
}
