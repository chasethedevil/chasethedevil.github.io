package com.capvolstripper;

public record StripResult(double[] capletExpiries,
                          double[] capletVols,
                          double[] nodeVols,
                          StripDiagnostics diagnostics) {
    public StripResult(double[] capletExpiries, double[] capletVols, double[] nodeVols) {
        this(capletExpiries, capletVols, nodeVols, StripDiagnostics.none());
    }

    public StripResult {
        capletExpiries = capletExpiries.clone();
        capletVols = capletVols.clone();
        nodeVols = nodeVols.clone();
        diagnostics = diagnostics == null ? StripDiagnostics.none() : diagnostics;
    }

    @Override
    public double[] capletExpiries() {
        return capletExpiries.clone();
    }

    @Override
    public double[] capletVols() {
        return capletVols.clone();
    }

    @Override
    public double[] nodeVols() {
        return nodeVols.clone();
    }
}
