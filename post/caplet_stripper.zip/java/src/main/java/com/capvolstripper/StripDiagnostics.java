package com.capvolstripper;

public record StripDiagnostics(String solverName,
                               boolean converged,
                               int iterations,
                               double maxRelativeResidual,
                               double objective,
                               double maxStep,
                               String convergenceReason) {
    public StripDiagnostics {
        if (solverName == null) {
            solverName = "unknown";
        }
        if (convergenceReason == null) {
            convergenceReason = "unknown";
        }
    }

    public static StripDiagnostics none() {
        return new StripDiagnostics("none", true, 0, 0.0, 0.0, 0.0, "not run");
    }
}
