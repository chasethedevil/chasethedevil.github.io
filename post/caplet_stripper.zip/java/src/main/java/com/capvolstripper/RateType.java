package com.capvolstripper;

public enum RateType {
    BACKWARD,
    FORWARD
}
