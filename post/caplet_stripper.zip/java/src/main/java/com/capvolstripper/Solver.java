package com.capvolstripper;

public enum Solver {
    AUTO {
        @Override
        StripSolver create(StripConfig config) {
            return config.knotPlacement() == KnotPlacement.AT_MATURITIES
                    ? new SequentialBootstrapSolver()
                    : new GlobalNewtonSolver();
        }
    },
    GLOBAL {
        @Override
        StripSolver create(StripConfig config) {
            return new GlobalNewtonSolver();
        }
    };

    abstract StripSolver create(StripConfig config);
}
