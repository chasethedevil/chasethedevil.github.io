package com.capvolstripper;

import java.util.Arrays;

public record StripMarketData(double[] capMaturitiesMonths,
                              double[] capVols,
                              double[] forwardRates,
                              double[] discountFactors) {
    public StripMarketData {
        Validation.sameLength(capMaturitiesMonths, capVols, "capMaturitiesMonths", "capVols");
        Validation.sorted(capMaturitiesMonths, "capMaturitiesMonths");
        capMaturitiesMonths = capMaturitiesMonths.clone();
        capVols = capVols.clone();
        forwardRates = forwardRates.clone();
        discountFactors = discountFactors == null ? null : discountFactors.clone();
    }

    public static StripMarketData of(double[] capMaturitiesMonths, double[] capVols, double[] forwardRates) {
        return new StripMarketData(capMaturitiesMonths, capVols, forwardRates, null);
    }

    public static StripMarketData withDiscountFactors(double[] capMaturitiesMonths, double[] capVols,
                                                      double[] forwardRates, double[] discountFactors) {
        return new StripMarketData(capMaturitiesMonths, capVols, forwardRates, discountFactors);
    }

    @Override
    public double[] capMaturitiesMonths() {
        return capMaturitiesMonths.clone();
    }

    @Override
    public double[] capVols() {
        return capVols.clone();
    }

    @Override
    public double[] forwardRates() {
        return forwardRates.clone();
    }

    @Override
    public double[] discountFactors() {
        return discountFactors == null ? null : discountFactors.clone();
    }

    double[] rawCapMaturitiesMonths() {
        return capMaturitiesMonths;
    }

    double[] rawCapVols() {
        return capVols;
    }

    double[] rawForwardRates() {
        return forwardRates;
    }

    double[] rawDiscountFactors() {
        return discountFactors;
    }

    @Override
    public String toString() {
        return "StripMarketData{"
                + "capMaturitiesMonths=" + Arrays.toString(capMaturitiesMonths)
                + ", capVols=" + Arrays.toString(capVols)
                + ", forwardRates=" + forwardRates.length
                + ", discountFactors=" + (discountFactors == null ? "none" : discountFactors.length)
                + '}';
    }
}
