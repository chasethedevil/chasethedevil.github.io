package com.capvolstripper;

@FunctionalInterface
public interface Interpolation {
    double interpolate(double[] nodesT, double[] nodesV, double t);
}
