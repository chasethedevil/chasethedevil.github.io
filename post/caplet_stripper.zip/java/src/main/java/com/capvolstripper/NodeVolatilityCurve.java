package com.capvolstripper;

final class NodeVolatilityCurve {
    private final StripConfig config;
    private final Interpolation interpolation;

    NodeVolatilityCurve(StripConfig config) {
        this.config = config;
        this.interpolation = config.interpolationMethod().create(config);
    }

    double valueAt(double[] nodeTimes, double[] nodeValues, double month) {
        return valueAtPrepared(nodeTimes, preparedNodeValues(nodeValues), month);
    }

    double[] preparedNodeValues(double[] nodeValues) {
        if (usesShiftedFloor()) {
            double[] shifted = new double[nodeValues.length];
            for (int i = 0; i < shifted.length; i++) {
                shifted[i] = nodeValues[i] - config.volFloor();
            }
            return shifted;
        }
        return nodeValues;
    }

    double valueAtPrepared(double[] nodeTimes, double[] preparedNodeValues, double month) {
        double raw;
        if (config.logSpace()) {
            raw = Math.exp(interpolation.interpolate(nodeTimes, preparedNodeValues, month));
        } else if (usesShiftedFloor()) {
            raw = interpolation.interpolate(nodeTimes, preparedNodeValues, month) + config.volFloor();
        } else {
            raw = interpolation.interpolate(nodeTimes, preparedNodeValues, month);
        }
        return Math.max(raw, config.volFloor());
    }

    private boolean usesShiftedFloor() {
        return config.volFloor() > 0.0 && config.interpolationMethod().usesShiftedFloor();
    }
}
