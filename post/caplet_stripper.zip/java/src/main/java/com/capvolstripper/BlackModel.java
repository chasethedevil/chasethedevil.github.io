package com.capvolstripper;

public final class BlackModel implements VolModel {
    @Override
    public double capletPrice(double sigma, double expiry, double accrual, double discountFactor,
                              double forward, double strike) {
        double srt = sigma * Math.sqrt(expiry);
        double intrinsic = Math.max(forward - strike, 0.0);
        if (Math.abs(srt) < 1.0e-30) {
            return discountFactor * accrual * intrinsic;
        }
        if (forward <= 0.0 || strike <= 0.0) {
            throw new IllegalArgumentException("Black model requires positive forward and strike");
        }

        double d1 = (Math.log(forward / strike) + 0.5 * srt * srt) / srt;
        double d2 = d1 - srt;
        return discountFactor * accrual
                * (forward * NormalDistribution.cdf(d1) - strike * NormalDistribution.cdf(d2));
    }

    @Override
    public double impliedVol(double price, double expiry, double accrual, double discountFactor,
                             double forward, double strike) {
        return ImpliedVolatility.black(price, expiry, accrual, discountFactor, forward, strike);
    }
}
