package com.capvolstripper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class CapletPriceStripper {
    private CapletPriceStripper() {
    }

    static PriceStripResult strip(StripMarketData marketData, PriceStripConfig config) {
        CapletSchedule schedule = CapletSchedule.build(marketData.rawCapMaturitiesMonths(), config.scheduleConfig());
        if (marketData.rawForwardRates().length != schedule.capletCount()) {
            throw new IllegalArgumentException("Expected " + schedule.capletCount()
                    + " forward rates, got " + marketData.rawForwardRates().length);
        }
        double[] discountFactors = resolveDiscountFactors(marketData, config, schedule.capletCount());
        double[] capPricesAll = marketCapPrices(marketData, config, schedule, discountFactors);

        FilteredQuotes filtered = config.arbitrageFree()
                ? filterArbitrageViolations(marketData, config, schedule, discountFactors, capPricesAll)
                : FilteredQuotes.keepAll(marketData.rawCapMaturitiesMonths(), capPricesAll);

        Interpolation interpolation = config.priceInterpolationMethod().create();
        double[] capletPrices = capletPrices(config, schedule, discountFactors, marketData.rawForwardRates(),
                filtered.maturitiesMonths, filtered.capPrices, interpolation);
        double[] capletVols = new double[schedule.capletCount()];
        for (int i = 0; i < capletVols.length; i++) {
            capletVols[i] = capletPrices[i] < 1.0e-30
                    ? 0.0
                    : config.model().impliedVol(capletPrices[i], schedule.expiry(i), schedule.accrual(i),
                            discountFactors[i], marketData.rawForwardRates()[i], config.strike());
        }
        return new PriceStripResult(schedule.expiries(), capletVols, filtered.capPrices, filtered.removedIndices());
    }

    private static double[] capletPrices(PriceStripConfig config, CapletSchedule schedule, double[] discountFactors,
                                         double[] forwards, double[] maturitiesMonths, double[] capPrices,
                                         Interpolation interpolation) {
        int nCaplets = schedule.capletCount();
        double[] capletPrices = new double[nCaplets];
        double[] capMaturitiesAtCaplets = new double[nCaplets];
        double[] intrinsic = new double[nCaplets];
        double frequency = config.capletFrequencyMonths();
        for (int i = 0; i < nCaplets; i++) {
            capMaturitiesAtCaplets[i] = config.rateType() == RateType.FORWARD
                    ? schedule.capletMonth(i) + frequency
                    : schedule.capletMonth(i);
            intrinsic[i] = discountFactors[i] * schedule.accrual(i) * Math.max(forwards[i] - config.strike(), 0.0);
        }

        if (config.target() == PriceStripTarget.PRICE) {
            double[] priceNodesT = prependZero(maturitiesMonths);
            double[] priceNodesV = prependZero(capPrices);
            double[] cumulativePrices = new double[nCaplets];
            for (int i = 0; i < nCaplets; i++) {
                cumulativePrices[i] = interpolation.interpolate(priceNodesT, priceNodesV, capMaturitiesAtCaplets[i]);
                if (i > 0) {
                    cumulativePrices[i] = Math.max(cumulativePrices[i], cumulativePrices[i - 1]);
                }
            }
            capletPrices[0] = Math.max(cumulativePrices[0], 0.0);
            for (int i = 1; i < nCaplets; i++) {
                capletPrices[i] = Math.max(cumulativePrices[i] - cumulativePrices[i - 1], 0.0);
            }
            return capletPrices;
        }

        double[] cumulativeIntrinsic = cumulativeIntrinsicAtNodes(config, schedule, discountFactors, forwards, maturitiesMonths);
        double[] timeValues = new double[capPrices.length];
        for (int i = 0; i < capPrices.length; i++) {
            timeValues[i] = Math.max(capPrices[i] - cumulativeIntrinsic[i], 0.0);
        }

        double[] tvNodesT;
        double[] tvNodesV;
        if (config.logTimeValue()) {
            int positives = 0;
            for (double timeValue : timeValues) {
                if (timeValue > 0.0) {
                    positives++;
                }
            }
            tvNodesT = new double[positives];
            tvNodesV = new double[positives];
            int index = 0;
            for (int i = 0; i < timeValues.length; i++) {
                if (timeValues[i] > 0.0) {
                    tvNodesT[index] = maturitiesMonths[i];
                    tvNodesV[index] = Math.log(timeValues[i]);
                    index++;
                }
            }
        } else {
            tvNodesT = prependZero(maturitiesMonths);
            tvNodesV = prependZero(timeValues);
        }

        double[] cumulativeTimeValues = new double[nCaplets];
        for (int i = 0; i < nCaplets; i++) {
            if (tvNodesT.length == 0) {
                cumulativeTimeValues[i] = 0.0;
            } else {
                double value = interpolation.interpolate(tvNodesT, tvNodesV, capMaturitiesAtCaplets[i]);
                cumulativeTimeValues[i] = config.logTimeValue() ? Math.exp(value) : value;
            }
            if (i > 0) {
                cumulativeTimeValues[i] = Math.max(cumulativeTimeValues[i], cumulativeTimeValues[i - 1]);
            }
        }

        capletPrices[0] = Math.max(cumulativeTimeValues[0], 0.0) + intrinsic[0];
        for (int i = 1; i < nCaplets; i++) {
            capletPrices[i] = Math.max(cumulativeTimeValues[i] - cumulativeTimeValues[i - 1], 0.0) + intrinsic[i];
        }
        return capletPrices;
    }

    private static FilteredQuotes filterArbitrageViolations(StripMarketData marketData, PriceStripConfig config,
                                                            CapletSchedule schedule, double[] discountFactors,
                                                            double[] capPricesAll) {
        double[] maturities = marketData.rawCapMaturitiesMonths();
        double[] cumulativeIntrinsic = cumulativeIntrinsicAtNodes(config, schedule, discountFactors,
                marketData.rawForwardRates(), maturities);
        double[] timeValues = new double[capPricesAll.length];
        for (int i = 0; i < timeValues.length; i++) {
            timeValues[i] = capPricesAll[i] - cumulativeIntrinsic[i];
        }

        List<Integer> keep = new ArrayList<>();
        for (int i = 0; i < maturities.length; i++) {
            keep.add(i);
        }
        List<Integer> removed = new ArrayList<>();
        boolean changed = true;
        while (changed) {
            changed = false;
            for (int j = 1; j < keep.size(); j++) {
                if (timeValues[keep.get(j)] <= timeValues[keep.get(j - 1)]) {
                    if (j == 1) {
                        if (keep.size() > 2 && timeValues[keep.get(j)] <= timeValues[keep.get(Math.min(j + 1, keep.size() - 1))]) {
                            removed.add(keep.remove(j - 1));
                        } else {
                            removed.add(keep.remove(j));
                        }
                    } else if (j == keep.size() - 1) {
                        removed.add(keep.remove(j));
                    } else {
                        int prev = keep.get(j - 2);
                        int left = keep.get(j - 1);
                        int right = keep.get(j);
                        int next = keep.get(j + 1);
                        double tvLinearLeft = timeValues[prev]
                                + (timeValues[next] - timeValues[prev]) * (maturities[left] - maturities[prev])
                                / (maturities[next] - maturities[prev]);
                        double tvLinearRight = timeValues[prev]
                                + (timeValues[next] - timeValues[prev]) * (maturities[right] - maturities[prev])
                                / (maturities[next] - maturities[prev]);
                        double devLeft = Math.abs(timeValues[left] - tvLinearLeft);
                        double devRight = Math.abs(timeValues[right] - tvLinearRight);
                        removed.add(keep.remove(devLeft >= devRight ? j - 1 : j));
                    }
                    changed = true;
                    break;
                }
            }
        }
        removed.sort(Integer::compareTo);
        double[] keptMaturities = new double[keep.size()];
        double[] keptPrices = new double[keep.size()];
        for (int i = 0; i < keep.size(); i++) {
            keptMaturities[i] = maturities[keep.get(i)];
            keptPrices[i] = capPricesAll[keep.get(i)];
        }
        int[] removedIndices = removed.stream().mapToInt(Integer::intValue).toArray();
        return new FilteredQuotes(keptMaturities, keptPrices, removedIndices);
    }

    private static double[] cumulativeIntrinsicAtNodes(PriceStripConfig config, CapletSchedule schedule,
                                                       double[] discountFactors, double[] forwards,
                                                       double[] maturitiesMonths) {
        double[] values = new double[maturitiesMonths.length];
        int offset = config.rateType() == RateType.FORWARD ? 1 : 0;
        for (int q = 0; q < maturitiesMonths.length; q++) {
            int capIndex = (int) Math.round(maturitiesMonths[q] / config.capletFrequencyMonths()) - offset;
            double value = 0.0;
            for (int i = 0; i < capIndex; i++) {
                value += discountFactors[i] * schedule.accrual(i) * Math.max(forwards[i] - config.strike(), 0.0);
            }
            values[q] = value;
        }
        return values;
    }

    private static double[] marketCapPrices(StripMarketData marketData, PriceStripConfig config,
                                            CapletSchedule schedule, double[] discountFactors) {
        double[] capPrices = new double[marketData.rawCapVols().length];
        for (int q = 0; q < capPrices.length; q++) {
            double price = 0.0;
            for (int i = 0; i < schedule.capIndex(q); i++) {
                price += config.model().capletPrice(marketData.rawCapVols()[q], schedule.expiry(i),
                        schedule.accrual(i), discountFactors[i], marketData.rawForwardRates()[i], config.strike());
            }
            capPrices[q] = price;
        }
        return capPrices;
    }

    private static double[] resolveDiscountFactors(StripMarketData marketData, PriceStripConfig config, int nCaplets) {
        double[] discountFactors = marketData.rawDiscountFactors();
        if (discountFactors == null) {
            discountFactors = config.discountFactors();
        }
        if (discountFactors == null) {
            double[] ones = new double[nCaplets];
            Arrays.fill(ones, 1.0);
            return ones;
        }
        if (discountFactors.length != nCaplets) {
            throw new IllegalArgumentException("Expected " + nCaplets
                    + " discount factors, got " + discountFactors.length);
        }
        return discountFactors.clone();
    }

    private static double[] prependZero(double[] values) {
        double[] result = new double[values.length + 1];
        System.arraycopy(values, 0, result, 1, values.length);
        return result;
    }

    private record FilteredQuotes(double[] maturitiesMonths, double[] capPrices, int[] removedIndices) {
        static FilteredQuotes keepAll(double[] maturitiesMonths, double[] capPrices) {
            return new FilteredQuotes(maturitiesMonths.clone(), capPrices.clone(), new int[0]);
        }
    }
}
