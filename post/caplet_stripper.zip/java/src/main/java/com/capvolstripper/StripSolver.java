package com.capvolstripper;

interface StripSolver {
    SolverResult solve(StripProblem problem);
}
