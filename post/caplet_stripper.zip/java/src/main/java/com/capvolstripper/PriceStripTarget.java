package com.capvolstripper;

public enum PriceStripTarget {
    TIME_VALUE,
    PRICE
}
