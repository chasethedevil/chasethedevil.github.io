package com.capvolstripper;

public enum PriceInterpolationMethod {
    HYMAN_MONOTONE {
        @Override
        Interpolation create() {
            return Interpolators::hymanMonotone;
        }
    },
    HUYNH_RATIONAL {
        @Override
        Interpolation create() {
            return Interpolators::huynhRational;
        }
    },
    HUYNH_HARMONIC {
        @Override
        Interpolation create() {
            return Interpolators::huynhHarmonic;
        }
    },
    MONOTONE_CUBIC {
        @Override
        Interpolation create() {
            return Interpolators::monotoneCubic;
        }
    },
    HYMAN_NON_NEGATIVE {
        @Override
        Interpolation create() {
            return Interpolators::hymanNonNegative;
        }
    },
    CUBIC_SPLINE {
        @Override
        Interpolation create() {
            return Interpolators::cubicSpline;
        }
    },
    CUBIC_HYMAN {
        @Override
        Interpolation create() {
            return Interpolators::cubicHyman;
        }
    },
    LINEAR {
        @Override
        Interpolation create() {
            return Interpolators::linear;
        }
    };

    abstract Interpolation create();
}
