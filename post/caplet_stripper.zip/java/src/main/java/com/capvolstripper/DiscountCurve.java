package com.capvolstripper;

import java.util.Arrays;

public final class DiscountCurve {
    public enum CurveInterpolation {
        LINEAR {
            @Override
            double interpolate(double[] pillarTimes, double[] logDiscountFactors, double time) {
                return Interpolators.linearExtrapolation(pillarTimes, logDiscountFactors, time);
            }
        },
        CUBIC_SPLINE_LINEAR_EXTRAPOLATION {
            @Override
            double interpolate(double[] pillarTimes, double[] logDiscountFactors, double time) {
                return Interpolators.cubicSplineLinearExtrapolation(pillarTimes, logDiscountFactors, time);
            }
        };

        abstract double interpolate(double[] pillarTimes, double[] logDiscountFactors, double time);
    }

    private final double[] pillarTimes;
    private final double[] logDiscountFactors;
    private final CurveInterpolation interpolation;

    public DiscountCurve(double[] pillarTimes, double[] discountFactors) {
        this(pillarTimes, discountFactors, CurveInterpolation.LINEAR);
    }

    public DiscountCurve(double[] pillarTimes, double[] discountFactors, CurveInterpolation interpolation) {
        Validation.sameLength(pillarTimes, discountFactors, "pillarTimes", "discountFactors");
        Validation.sorted(pillarTimes, "pillarTimes");
        Validation.positive(discountFactors, "discountFactors");
        this.pillarTimes = pillarTimes.clone();
        this.logDiscountFactors = Arrays.stream(discountFactors).map(Math::log).toArray();
        this.interpolation = interpolation;
    }

    public double discountFactor(double time) {
        return Math.exp(interpolation.interpolate(pillarTimes, logDiscountFactors, time));
    }

    public double[] discountFactors(double[] times) {
        double[] values = new double[times.length];
        for (int i = 0; i < times.length; i++) {
            values[i] = discountFactor(times[i]);
        }
        return values;
    }
}
