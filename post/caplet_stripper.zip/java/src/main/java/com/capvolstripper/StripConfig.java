package com.capvolstripper;

public final class StripConfig {
    private final double strike;
    private final VolModel model;
    private final int capletFrequencyMonths;
    private final InterpolationMethod interpolationMethod;
    private final KnotPlacement knotPlacement;
    private final boolean logSpace;
    private final double volFloor;
    private final double beta;
    private final double tension;
    private final Solver solver;
    private final RateType rateType;
    private final double[] discountFactors;

    private StripConfig(Builder builder) {
        this.strike = builder.strike;
        this.model = builder.model;
        this.capletFrequencyMonths = builder.capletFrequencyMonths;
        this.interpolationMethod = builder.interpolationMethod;
        this.knotPlacement = builder.knotPlacement;
        this.logSpace = builder.logSpace;
        this.volFloor = builder.volFloor;
        this.beta = builder.beta;
        this.tension = builder.tension;
        this.solver = builder.solver;
        this.rateType = builder.rateType;
        this.discountFactors = builder.discountFactors == null ? null : builder.discountFactors.clone();
    }

    public static Builder builder() {
        return new Builder();
    }

    public double strike() {
        return strike;
    }

    public VolModel model() {
        return model;
    }

    public int capletFrequencyMonths() {
        return capletFrequencyMonths;
    }

    public InterpolationMethod interpolationMethod() {
        return interpolationMethod;
    }

    public KnotPlacement knotPlacement() {
        return knotPlacement;
    }

    public boolean logSpace() {
        return logSpace;
    }

    public double volFloor() {
        return volFloor;
    }

    public double beta() {
        return beta;
    }

    public double tension() {
        return tension;
    }

    public Solver solver() {
        return solver;
    }

    public RateType rateType() {
        return rateType;
    }

    public double[] discountFactors() {
        return discountFactors == null ? null : discountFactors.clone();
    }

    public static final class Builder {
        private double strike = 0.0;
        private VolModel model = new BachelierModel();
        private int capletFrequencyMonths = 1;
        private InterpolationMethod interpolationMethod = InterpolationMethod.FLAT;
        private KnotPlacement knotPlacement = KnotPlacement.AT_MATURITIES;
        private boolean logSpace = false;
        private double volFloor = 0.0;
        private double beta = 0.5;
        private double tension = 1.0;
        private Solver solver = Solver.AUTO;
        private RateType rateType = RateType.BACKWARD;
        private double[] discountFactors = null;

        public Builder strike(double strike) {
            this.strike = strike;
            return this;
        }

        public Builder model(VolModel model) {
            this.model = model;
            return this;
        }

        public Builder capletFrequencyMonths(int capletFrequencyMonths) {
            this.capletFrequencyMonths = capletFrequencyMonths;
            return this;
        }

        public Builder interpolationMethod(InterpolationMethod interpolationMethod) {
            this.interpolationMethod = interpolationMethod;
            return this;
        }

        public Builder knotPlacement(KnotPlacement knotPlacement) {
            this.knotPlacement = knotPlacement;
            return this;
        }

        public Builder logSpace(boolean logSpace) {
            this.logSpace = logSpace;
            return this;
        }

        public Builder volFloor(double volFloor) {
            this.volFloor = volFloor;
            return this;
        }

        public Builder beta(double beta) {
            this.beta = beta;
            return this;
        }

        public Builder tension(double tension) {
            this.tension = tension;
            return this;
        }

        public Builder solver(Solver solver) {
            this.solver = solver;
            return this;
        }

        public Builder rateType(RateType rateType) {
            this.rateType = rateType;
            return this;
        }

        public Builder discountFactors(double[] discountFactors) {
            this.discountFactors = discountFactors == null ? null : discountFactors.clone();
            return this;
        }

        public StripConfig build() {
            if (model == null) {
                throw new IllegalArgumentException("model must not be null");
            }
            if (capletFrequencyMonths <= 0) {
                throw new IllegalArgumentException("capletFrequencyMonths must be positive");
            }
            if (interpolationMethod == null || knotPlacement == null || solver == null || rateType == null) {
                throw new IllegalArgumentException("configuration enums must not be null");
            }
            if (volFloor < 0.0) {
                throw new IllegalArgumentException("volFloor must be non-negative");
            }
            return new StripConfig(this);
        }
    }
}
