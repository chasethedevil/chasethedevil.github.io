package com.capvolstripper;

import java.util.Arrays;

final class StripProblem {
    private final StripConfig config;
    private final StripMarketData marketData;
    private final CapletSchedule schedule;
    private final NodeVolatilityCurve volatilityCurve;
    private final double[] discountFactors;
    private final double[] targetPrices;

    private StripProblem(StripConfig config, StripMarketData marketData, CapletSchedule schedule,
                         NodeVolatilityCurve volatilityCurve, double[] discountFactors, double[] targetPrices) {
        this.config = config;
        this.marketData = marketData;
        this.schedule = schedule;
        this.volatilityCurve = volatilityCurve;
        this.discountFactors = discountFactors;
        this.targetPrices = targetPrices;
    }

    static StripProblem of(StripMarketData marketData, StripConfig config) {
        CapletSchedule schedule = CapletSchedule.build(marketData.rawCapMaturitiesMonths(), config);
        if (marketData.rawForwardRates().length != schedule.capletCount()) {
            throw new IllegalArgumentException("Expected " + schedule.capletCount()
                    + " forward rates, got " + marketData.rawForwardRates().length);
        }

        double[] discountFactors = resolveDiscountFactors(marketData, config, schedule.capletCount());
        double[] targetPrices = new double[schedule.quoteCount()];
        for (int q = 0; q < targetPrices.length; q++) {
            targetPrices[q] = flatCapPrice(config.model(), marketData.rawCapVols()[q], schedule.capIndex(q),
                    schedule, discountFactors, marketData.rawForwardRates(), config.strike());
        }
        return new StripProblem(config, marketData, schedule, new NodeVolatilityCurve(config),
                discountFactors, targetPrices);
    }

    StripConfig config() {
        return config;
    }

    CapletSchedule schedule() {
        return schedule;
    }

    int quoteCount() {
        return marketData.rawCapVols().length;
    }

    double[] capVols() {
        return marketData.rawCapVols();
    }

    double targetPrice(int quoteIndex) {
        return targetPrices[quoteIndex];
    }

    double capPriceForNodes(double[] nodeTimes, double[] nodeValues, int quoteIndex) {
        double price = 0.0;
        double[] preparedNodeValues = volatilityCurve.preparedNodeValues(nodeValues);
        for (int i = 0; i < schedule.capIndex(quoteIndex); i++) {
            double sigma = volatilityCurve.valueAtPrepared(nodeTimes, preparedNodeValues, schedule.capletMonth(i));
            price += config.model().capletPrice(sigma, schedule.expiry(i), schedule.accrual(i),
                    discountFactors[i], marketData.rawForwardRates()[i], config.strike());
        }
        return price;
    }

    double[] initialNodeVols(boolean global) {
        double[] capVols = marketData.rawCapVols();
        double[] nodeVols = new double[capVols.length];
        double positiveFloor = Math.max(config.volFloor(), Math.ulp(1.0));
        for (int i = 0; i < capVols.length; i++) {
            if (config.logSpace()) {
                nodeVols[i] = Math.log(Math.max(capVols[i], positiveFloor));
            } else if (global) {
                nodeVols[i] = Math.max(capVols[i], config.volFloor());
            } else {
                nodeVols[i] = capVols[i];
            }
        }
        return nodeVols;
    }

    StripResult result(double[] nodeVols, StripDiagnostics diagnostics) {
        double[] nodeTimes = schedule.rawNodeTimes();
        double[] preparedNodeVols = volatilityCurve.preparedNodeValues(nodeVols);
        double[] capletVols = new double[schedule.capletCount()];
        for (int i = 0; i < capletVols.length; i++) {
            capletVols[i] = volatilityCurve.valueAtPrepared(nodeTimes, preparedNodeVols, schedule.capletMonth(i));
        }
        double[] outputNodeVols = config.logSpace() ? Arrays.stream(nodeVols).map(Math::exp).toArray() : nodeVols;
        return new StripResult(schedule.expiries(), capletVols, outputNodeVols, diagnostics);
    }

    private static double[] resolveDiscountFactors(StripMarketData marketData, StripConfig config, int nCaplets) {
        double[] discountFactors = marketData.rawDiscountFactors();
        if (discountFactors == null) {
            discountFactors = config.discountFactors();
        }
        if (discountFactors == null) {
            double[] ones = new double[nCaplets];
            Arrays.fill(ones, 1.0);
            return ones;
        }
        if (discountFactors.length != nCaplets) {
            throw new IllegalArgumentException("Expected " + nCaplets
                    + " discount factors, got " + discountFactors.length);
        }
        return discountFactors.clone();
    }

    private static double flatCapPrice(VolModel model, double sigma, int capIndex, CapletSchedule schedule,
                                       double[] discountFactors, double[] forwards, double strike) {
        double price = 0.0;
        for (int i = 0; i < capIndex; i++) {
            price += model.capletPrice(sigma, schedule.expiry(i), schedule.accrual(i),
                    discountFactors[i], forwards[i], strike);
        }
        return price;
    }
}
