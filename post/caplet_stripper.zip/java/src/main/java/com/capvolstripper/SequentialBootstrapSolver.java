package com.capvolstripper;

import java.util.Arrays;

final class SequentialBootstrapSolver implements StripSolver {
    @Override
    public SolverResult solve(StripProblem problem) {
        double[] nodeVols = problem.initialNodeVols(false);
        int totalIterations = 0;
        for (int q = 0; q < problem.quoteCount(); q++) {
            totalIterations += solveNode(problem, nodeVols, q);
        }
        double maxResidual = maxRelativeResidual(problem, nodeVols);
        StripDiagnostics diagnostics = new StripDiagnostics("sequential bootstrap",
                maxResidual < 1.0e-12, totalIterations, maxResidual, maxResidual * maxResidual,
                0.0, maxResidual < 1.0e-12 ? "residual tolerance" : "completed node solves");
        return new SolverResult(nodeVols, diagnostics);
    }

    private static int solveNode(StripProblem problem, double[] nodeVols, int quoteIndex) {
        double nodeValue = nodeVols[quoteIndex];
        int steps = 0;
        for (int iterations = 0; iterations < 50; iterations++) {
            double pv = capPriceGivenNode(problem, nodeVols, quoteIndex, nodeValue);
            double err = pv - problem.targetPrice(quoteIndex);
            if (Math.abs(err / (problem.targetPrice(quoteIndex) + 1.0e-30)) < 1.0e-14) {
                break;
            }
            double bump = Math.max(Math.abs(nodeValue) * 1.0e-4, 1.0e-6);
            double pvPlus = capPriceGivenNode(problem, nodeVols, quoteIndex, nodeValue + bump);
            double pvMinus = capPriceGivenNode(problem, nodeVols, quoteIndex, nodeValue - bump);
            double derivative = (pvPlus - pvMinus) / (2.0 * bump);
            if (Math.abs(derivative) < 1.0e-30 || !Double.isFinite(derivative)) {
                break;
            }
            nodeValue -= err / derivative;
            steps++;
        }

        if (!problem.config().logSpace()
                && problem.config().volFloor() > 0.0
                && nodeValue < problem.config().volFloor()) {
            nodeValue = problem.config().volFloor();
        }
        nodeVols[quoteIndex] = nodeValue;
        return steps;
    }

    private static double capPriceGivenNode(StripProblem problem, double[] nodeVols,
                                            int quoteIndex, double nodeValue) {
        nodeVols[quoteIndex] = nodeValue;
        double[] localTimes = problem.schedule().nodeTimesUntil(quoteIndex);
        double[] localVols = Arrays.copyOf(nodeVols, quoteIndex + 1);
        return problem.capPriceForNodes(localTimes, localVols, quoteIndex);
    }

    private static double maxRelativeResidual(StripProblem problem, double[] nodeVols) {
        double[] nodeTimes = problem.schedule().rawNodeTimes();
        double max = 0.0;
        for (int q = 0; q < problem.quoteCount(); q++) {
            double residual = (problem.capPriceForNodes(nodeTimes, nodeVols, q) - problem.targetPrice(q))
                    / (problem.targetPrice(q) + 1.0e-30);
            max = Math.max(max, Math.abs(residual));
        }
        return max;
    }
}
