package com.capvolstripper;

public enum InterpolationMethod {
    FLAT {
        @Override
        Interpolation create(StripConfig config) {
            return Interpolators::flat;
        }
    },
    LINEAR {
        @Override
        Interpolation create(StripConfig config) {
            return Interpolators::linear;
        }
    },
    CUBIC_SPLINE {
        @Override
        Interpolation create(StripConfig config) {
            return Interpolators::cubicSpline;
        }
    },
    MONOTONE_CUBIC {
        @Override
        Interpolation create(StripConfig config) {
            return Interpolators::monotoneCubic;
        }
    },
    TENSION {
        @Override
        Interpolation create(StripConfig config) {
            return (nodesT, nodesV, t) -> Interpolators.tension(nodesT, nodesV, t, config.tension());
        }
    },
    HYMAN_NON_NEGATIVE {
        @Override
        Interpolation create(StripConfig config) {
            return Interpolators::hymanNonNegative;
        }

        @Override
        boolean usesShiftedFloor() {
            return true;
        }
    },
    HYMAN_MONOTONE {
        @Override
        Interpolation create(StripConfig config) {
            return Interpolators::hymanMonotone;
        }
    },
    HUYNH_RATIONAL {
        @Override
        Interpolation create(StripConfig config) {
            return Interpolators::huynhRational;
        }
    },
    HUYNH_HARMONIC {
        @Override
        Interpolation create(StripConfig config) {
            return Interpolators::huynhHarmonic;
        }
    },
    CUBIC_HYMAN {
        @Override
        Interpolation create(StripConfig config) {
            return Interpolators::cubicHyman;
        }
    },
    FLAT_LINEAR {
        @Override
        Interpolation create(StripConfig config) {
            double beta = config.beta() * config.capletFrequencyMonths();
            double delta = config.capletFrequencyMonths();
            return (nodesT, nodesV, t) -> Interpolators.flatLinear(nodesT, nodesV, t, beta, delta);
        }
    },
    FLAT_SMOOTH {
        @Override
        Interpolation create(StripConfig config) {
            double beta = config.beta() * config.capletFrequencyMonths();
            double delta = config.capletFrequencyMonths();
            return (nodesT, nodesV, t) -> Interpolators.flatSmooth(nodesT, nodesV, t, beta, delta);
        }
    };

    abstract Interpolation create(StripConfig config);

    boolean usesShiftedFloor() {
        return false;
    }
}
