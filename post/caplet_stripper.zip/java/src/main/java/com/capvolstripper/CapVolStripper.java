package com.capvolstripper;

public final class CapVolStripper {
    private CapVolStripper() {
    }

    public static StripResult stripCapletVols(double[] capMaturitiesMonths,
                                              double[] capVols,
                                              double[] forwardRates,
                                              StripConfig config) {
        return stripCapletVols(StripMarketData.of(capMaturitiesMonths, capVols, forwardRates), config);
    }

    public static StripResult stripCapletVols(StripMarketData marketData, StripConfig config) {
        StripProblem problem = StripProblem.of(marketData, config);
        SolverResult solverResult = config.solver().create(config).solve(problem);
        return problem.result(solverResult.rawNodeVols(), solverResult.diagnostics());
    }

    public static PriceStripResult stripCapletVolsFromPrices(double[] capMaturitiesMonths,
                                                             double[] capVols,
                                                             double[] forwardRates,
                                                             PriceStripConfig config) {
        return stripCapletVolsFromPrices(StripMarketData.of(capMaturitiesMonths, capVols, forwardRates), config);
    }

    public static PriceStripResult stripCapletVolsFromPrices(StripMarketData marketData, PriceStripConfig config) {
        return CapletPriceStripper.strip(marketData, config);
    }

    public static double capletPrice(VolModel model, double sigma, double expiry, double accrual,
                                     double discountFactor, double forward, double strike) {
        return model.capletPrice(sigma, expiry, accrual, discountFactor, forward, strike);
    }

    public static double capPrice(VolModel model, double sigma, double[] expiries, double[] accruals,
                                  double[] discountFactors, double[] forwards, double strike) {
        return model.capPrice(sigma, expiries, accruals, discountFactors, forwards, strike);
    }

    public static double bachelierImpliedVol(double price, double expiry, double accrual,
                                             double discountFactor, double forward, double strike) {
        return ImpliedVolatility.bachelier(price, expiry, accrual, discountFactor, forward, strike);
    }

    public static double blackImpliedVol(double price, double expiry, double accrual,
                                         double discountFactor, double forward, double strike) {
        return ImpliedVolatility.black(price, expiry, accrual, discountFactor, forward, strike);
    }
}
