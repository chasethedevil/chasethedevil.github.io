package com.capvolstripper;

public enum KnotPlacement {
    AT_MATURITIES,
    MIDPOINTS
}
