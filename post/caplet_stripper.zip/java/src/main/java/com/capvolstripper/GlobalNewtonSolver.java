package com.capvolstripper;

final class GlobalNewtonSolver implements StripSolver {
    @Override
    public SolverResult solve(StripProblem problem) {
        int n = problem.quoteCount();
        double[] nodeVols = problem.initialNodeVols(true);
        double[] bumpedNodeVols = new double[n];
        double[] residual = new double[n];
        double[] bumpedResidual = new double[n];
        double[][] jacobian = new double[n][n];
        int iterations = 0;
        double maxRel = Double.POSITIVE_INFINITY;
        double objective = Double.POSITIVE_INFINITY;
        double maxStep = 0.0;
        int steps = 0;
        boolean converged = false;
        String reason = "maximum iterations";

        for (; iterations < 200; iterations++) {
            fillResidual(problem, nodeVols, residual);
            maxRel = maxAbs(residual);
            objective = dot(residual, residual);
            if (maxRel < 1.0e-14) {
                converged = true;
                reason = "residual tolerance";
                break;
            }

            for (int k = 0; k < n; k++) {
                double bump = Math.max(Math.abs(nodeVols[k]) * 1.0e-7, 1.0e-8);
                System.arraycopy(nodeVols, 0, bumpedNodeVols, 0, n);
                bumpedNodeVols[k] += bump;
                fillResidual(problem, bumpedNodeVols, bumpedResidual);
                for (int q = 0; q < n; q++) {
                    jacobian[q][k] = (bumpedResidual[q] - residual[q]) / bump;
                }
            }

            double[][] normalMatrix = new double[n][n];
            double[] normalRhs = new double[n];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    double sum = 0.0;
                    for (int q = 0; q < n; q++) {
                        sum += jacobian[q][i] * jacobian[q][j];
                    }
                    normalMatrix[i][j] = sum;
                }
                normalMatrix[i][i] += 1.0e-10;
                double sum = 0.0;
                for (int q = 0; q < n; q++) {
                    sum += jacobian[q][i] * residual[q];
                }
                normalRhs[i] = -sum;
            }

            double[] delta = LinearAlgebra.solve(normalMatrix, normalRhs);
            double objective0 = objective;
            double alpha = 1.0;
            double[] trial = new double[n];
            for (int ls = 0; ls < 40; ls++) {
                for (int i = 0; i < n; i++) {
                    trial[i] = nodeVols[i] + alpha * delta[i];
                }
                fillResidual(problem, trial, bumpedResidual);
                if (dot(bumpedResidual, bumpedResidual) < objective0) {
                    break;
                }
                alpha *= 0.5;
            }

            maxStep = 0.0;
            for (int i = 0; i < n; i++) {
                double step = alpha * delta[i];
                nodeVols[i] += step;
                maxStep = Math.max(maxStep, Math.abs(step));
            }
            steps++;
            if (!problem.config().logSpace()
                    && problem.config().volFloor() > 0.0
                    && problem.config().interpolationMethod().usesShiftedFloor()) {
                for (int i = 0; i < n; i++) {
                    nodeVols[i] = Math.max(nodeVols[i], problem.config().volFloor());
                }
            }
            if (maxStep < 1.0e-12) {
                reason = "step tolerance";
                break;
            }
        }
        fillResidual(problem, nodeVols, residual);
        maxRel = maxAbs(residual);
        objective = dot(residual, residual);
        if (maxRel < 1.0e-14) {
            converged = true;
            reason = "residual tolerance";
        }
        StripDiagnostics diagnostics = new StripDiagnostics("global Newton", converged,
                steps, maxRel, objective, maxStep, reason);
        return new SolverResult(nodeVols, diagnostics);
    }

    private static void fillResidual(StripProblem problem, double[] nodeVols, double[] residual) {
        double[] nodeTimes = problem.schedule().rawNodeTimes();
        for (int q = 0; q < residual.length; q++) {
            residual[q] = (problem.capPriceForNodes(nodeTimes, nodeVols, q) - problem.targetPrice(q))
                    / problem.targetPrice(q);
        }
    }

    private static double maxAbs(double[] values) {
        double max = 0.0;
        for (double value : values) {
            max = Math.max(max, Math.abs(value));
        }
        return max;
    }

    private static double dot(double[] left, double[] right) {
        double sum = 0.0;
        for (int i = 0; i < left.length; i++) {
            sum += left[i] * right[i];
        }
        return sum;
    }
}
