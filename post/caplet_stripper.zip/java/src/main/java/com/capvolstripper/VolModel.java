package com.capvolstripper;

public interface VolModel {
    double capletPrice(double sigma, double expiry, double accrual, double discountFactor,
                       double forward, double strike);

    double impliedVol(double price, double expiry, double accrual, double discountFactor,
                      double forward, double strike);

    default double capPrice(double sigma, double[] expiries, double[] accruals,
                            double[] discountFactors, double[] forwards, double strike) {
        Validation.sameLength(expiries, accruals, "expiries", "accruals");
        Validation.sameLength(expiries, discountFactors, "expiries", "discountFactors");
        Validation.sameLength(expiries, forwards, "expiries", "forwards");

        double price = 0.0;
        for (int i = 0; i < expiries.length; i++) {
            price += capletPrice(sigma, expiries[i], accruals[i], discountFactors[i], forwards[i], strike);
        }
        return price;
    }
}
