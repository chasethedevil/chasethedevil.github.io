package com.capvolstripper;

import java.util.Arrays;

final class Validation {
    private Validation() {
    }

    static void sameLength(double[] left, double[] right, String leftName, String rightName) {
        if (left.length != right.length) {
            throw new IllegalArgumentException(leftName + " length " + left.length
                    + " does not match " + rightName + " length " + right.length);
        }
    }

    static void sorted(double[] values, String name) {
        for (int i = 1; i < values.length; i++) {
            if (values[i] < values[i - 1]) {
                throw new IllegalArgumentException(name + " must be sorted ascending: " + Arrays.toString(values));
            }
        }
    }

    static void positive(double[] values, String name) {
        for (double value : values) {
            if (value <= 0.0) {
                throw new IllegalArgumentException(name + " must contain only positive values");
            }
        }
    }
}
