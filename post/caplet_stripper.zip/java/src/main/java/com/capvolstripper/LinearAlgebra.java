package com.capvolstripper;

final class LinearAlgebra {
    private LinearAlgebra() {
    }

    static double[] solve(double[][] matrix, double[] rhs) {
        int n = rhs.length;
        double[][] a = new double[n][n];
        double[] b = rhs.clone();
        for (int i = 0; i < n; i++) {
            System.arraycopy(matrix[i], 0, a[i], 0, n);
        }

        for (int k = 0; k < n; k++) {
            int pivot = k;
            double max = Math.abs(a[k][k]);
            for (int i = k + 1; i < n; i++) {
                double value = Math.abs(a[i][k]);
                if (value > max) {
                    max = value;
                    pivot = i;
                }
            }
            if (max < 1.0e-30) {
                throw new IllegalArgumentException("Singular matrix in linear solve");
            }
            if (pivot != k) {
                double[] tmpRow = a[k];
                a[k] = a[pivot];
                a[pivot] = tmpRow;
                double tmp = b[k];
                b[k] = b[pivot];
                b[pivot] = tmp;
            }

            for (int i = k + 1; i < n; i++) {
                double factor = a[i][k] / a[k][k];
                a[i][k] = 0.0;
                for (int j = k + 1; j < n; j++) {
                    a[i][j] -= factor * a[k][j];
                }
                b[i] -= factor * b[k];
            }
        }

        double[] x = new double[n];
        for (int i = n - 1; i >= 0; i--) {
            double sum = b[i];
            for (int j = i + 1; j < n; j++) {
                sum -= a[i][j] * x[j];
            }
            x[i] = sum / a[i][i];
        }
        return x;
    }
}
