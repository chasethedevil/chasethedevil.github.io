package com.capvolstripper;

record SolverResult(double[] nodeVols, StripDiagnostics diagnostics) {
    SolverResult {
        nodeVols = nodeVols.clone();
        diagnostics = diagnostics == null ? StripDiagnostics.none() : diagnostics;
    }

    @Override
    public double[] nodeVols() {
        return nodeVols.clone();
    }

    double[] rawNodeVols() {
        return nodeVols;
    }
}
