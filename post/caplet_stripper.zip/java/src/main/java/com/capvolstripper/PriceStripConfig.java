package com.capvolstripper;

public final class PriceStripConfig {
    private final double strike;
    private final VolModel model;
    private final int capletFrequencyMonths;
    private final RateType rateType;
    private final double[] discountFactors;
    private final PriceInterpolationMethod priceInterpolationMethod;
    private final PriceStripTarget target;
    private final boolean arbitrageFree;
    private final boolean logTimeValue;

    private PriceStripConfig(Builder builder) {
        this.strike = builder.strike;
        this.model = builder.model;
        this.capletFrequencyMonths = builder.capletFrequencyMonths;
        this.rateType = builder.rateType;
        this.discountFactors = builder.discountFactors == null ? null : builder.discountFactors.clone();
        this.priceInterpolationMethod = builder.priceInterpolationMethod;
        this.target = builder.target;
        this.arbitrageFree = builder.arbitrageFree;
        this.logTimeValue = builder.logTimeValue;
    }

    public static Builder builder() {
        return new Builder();
    }

    public double strike() {
        return strike;
    }

    public VolModel model() {
        return model;
    }

    public int capletFrequencyMonths() {
        return capletFrequencyMonths;
    }

    public RateType rateType() {
        return rateType;
    }

    public double[] discountFactors() {
        return discountFactors == null ? null : discountFactors.clone();
    }

    public PriceInterpolationMethod priceInterpolationMethod() {
        return priceInterpolationMethod;
    }

    public PriceStripTarget target() {
        return target;
    }

    public boolean arbitrageFree() {
        return arbitrageFree;
    }

    public boolean logTimeValue() {
        return logTimeValue;
    }

    StripConfig scheduleConfig() {
        return StripConfig.builder()
                .model(model)
                .strike(strike)
                .capletFrequencyMonths(capletFrequencyMonths)
                .rateType(rateType)
                .discountFactors(discountFactors)
                .build();
    }

    public static final class Builder {
        private double strike = 0.0;
        private VolModel model = new BachelierModel();
        private int capletFrequencyMonths = 1;
        private RateType rateType = RateType.FORWARD;
        private double[] discountFactors = null;
        private PriceInterpolationMethod priceInterpolationMethod = PriceInterpolationMethod.HYMAN_MONOTONE;
        private PriceStripTarget target = PriceStripTarget.TIME_VALUE;
        private boolean arbitrageFree = false;
        private boolean logTimeValue = false;

        public Builder strike(double strike) {
            this.strike = strike;
            return this;
        }

        public Builder model(VolModel model) {
            this.model = model;
            return this;
        }

        public Builder capletFrequencyMonths(int capletFrequencyMonths) {
            this.capletFrequencyMonths = capletFrequencyMonths;
            return this;
        }

        public Builder rateType(RateType rateType) {
            this.rateType = rateType;
            return this;
        }

        public Builder discountFactors(double[] discountFactors) {
            this.discountFactors = discountFactors == null ? null : discountFactors.clone();
            return this;
        }

        public Builder priceInterpolationMethod(PriceInterpolationMethod priceInterpolationMethod) {
            this.priceInterpolationMethod = priceInterpolationMethod;
            return this;
        }

        public Builder target(PriceStripTarget target) {
            this.target = target;
            return this;
        }

        public Builder arbitrageFree(boolean arbitrageFree) {
            this.arbitrageFree = arbitrageFree;
            return this;
        }

        public Builder logTimeValue(boolean logTimeValue) {
            this.logTimeValue = logTimeValue;
            return this;
        }

        public PriceStripConfig build() {
            if (model == null) {
                throw new IllegalArgumentException("model must not be null");
            }
            if (capletFrequencyMonths <= 0) {
                throw new IllegalArgumentException("capletFrequencyMonths must be positive");
            }
            if (rateType == null || priceInterpolationMethod == null || target == null) {
                throw new IllegalArgumentException("configuration enums must not be null");
            }
            return new PriceStripConfig(this);
        }
    }
}
