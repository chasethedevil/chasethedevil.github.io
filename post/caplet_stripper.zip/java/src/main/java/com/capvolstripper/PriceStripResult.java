package com.capvolstripper;

public record PriceStripResult(double[] capletExpiries,
                               double[] capletVols,
                               double[] capPricesMarket,
                               int[] removedQuoteIndices) {
    public PriceStripResult {
        capletExpiries = capletExpiries.clone();
        capletVols = capletVols.clone();
        capPricesMarket = capPricesMarket.clone();
        removedQuoteIndices = removedQuoteIndices.clone();
    }

    @Override
    public double[] capletExpiries() {
        return capletExpiries.clone();
    }

    @Override
    public double[] capletVols() {
        return capletVols.clone();
    }

    @Override
    public double[] capPricesMarket() {
        return capPricesMarket.clone();
    }

    @Override
    public int[] removedQuoteIndices() {
        return removedQuoteIndices.clone();
    }
}
