package com.capvolstripper;

public final class BachelierModel implements VolModel {
    @Override
    public double capletPrice(double sigma, double expiry, double accrual, double discountFactor,
                              double forward, double strike) {
        double srt = sigma * Math.sqrt(expiry);
        double intrinsic = Math.max(forward - strike, 0.0);
        if (Math.abs(srt) < 1.0e-30) {
            return discountFactor * accrual * intrinsic;
        }

        double d = (forward - strike) / srt;
        return discountFactor * accrual
                * (srt * NormalDistribution.pdf(d) + (forward - strike) * NormalDistribution.cdf(d));
    }

    @Override
    public double impliedVol(double price, double expiry, double accrual, double discountFactor,
                             double forward, double strike) {
        return ImpliedVolatility.bachelier(price, expiry, accrual, discountFactor, forward, strike);
    }
}
