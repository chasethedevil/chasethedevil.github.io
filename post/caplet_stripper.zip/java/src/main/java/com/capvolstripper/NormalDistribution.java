package com.capvolstripper;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;

final class NormalDistribution {
    private static final double INV_SQRT_2PI = 1.0 / Math.sqrt(2.0 * Math.PI);
    private static final double SQRT_2 = Math.sqrt(2.0);
    private static final MethodHandle COMMONS_ERFC = commonsErfc();
    private static final MethodHandle COMMONS_ERF = commonsSpecialFunction("org.apache.commons.numbers.gamma.Erf");
    private static final MethodHandle COMMONS_ERFCX = commonsSpecialFunction("org.apache.commons.numbers.gamma.Erfcx");

    private NormalDistribution() {
    }

    static double pdf(double x) {
        return INV_SQRT_2PI * Math.exp(-0.5 * x * x);
    }

    static double cdf(double x) {
        return 0.5 * erfc(-x / SQRT_2);
    }

    static double erf(double x) {
        if (COMMONS_ERF != null) {
            try {
                return (double) COMMONS_ERF.invokeExact(x);
            } catch (Throwable throwable) {
                throw new IllegalStateException("Commons Numbers Erf invocation failed", throwable);
            }
        }
        return 1.0 - erfc(x);
    }

    static double erfc(double x) {
        if (COMMONS_ERFC != null) {
            try {
                return (double) COMMONS_ERFC.invokeExact(x);
            } catch (Throwable throwable) {
                throw new IllegalStateException("Commons Numbers Erfc invocation failed", throwable);
            }
        }
        return fallbackErfc(x);
    }

    static double erfcx(double x) {
        if (COMMONS_ERFCX != null) {
            try {
                return (double) COMMONS_ERFCX.invokeExact(x);
            } catch (Throwable throwable) {
                throw new IllegalStateException("Commons Numbers Erfcx invocation failed", throwable);
            }
        }
        return fallbackErfcx(x);
    }

    private static MethodHandle commonsErfc() {
        return commonsSpecialFunction("org.apache.commons.numbers.gamma.Erfc");
    }

    private static MethodHandle commonsSpecialFunction(String className) {
        try {
            Class<?> erfcClass = Class.forName(className);
            return MethodHandles.publicLookup()
                    .findStatic(erfcClass, "value", MethodType.methodType(double.class, double.class));
        } catch (ClassNotFoundException | IllegalAccessException | NoSuchMethodException exception) {
            return null;
        }
    }

    private static double fallbackErfcx(double x) {
        if (x >= 2.5) {
            double iz2 = 1.0 / (2.0 * x * x);
            return 1.0 / Math.sqrt(Math.PI) / x
                    * (1.0 - iz2 * (1.0 - 3.0 * iz2 * (1.0 - 5.0 * iz2)));
        }
        if (x >= 0.0) {
            return Math.exp(x * x) * fallbackErfc(x);
        }
        if (x == x) {
            return 2.0 * Math.exp(x * x) - fallbackErfcx(-x);
        }
        return Double.NaN;
    }

    private static double fallbackErfc(double x) {
        double z = Math.abs(x);
        double t = 1.0 / (1.0 + 0.5 * z);
        double tau = t * Math.exp(-z * z - 1.26551223
                + t * (1.00002368
                + t * (0.37409196
                + t * (0.09678418
                + t * (-0.18628806
                + t * (0.27886807
                + t * (-1.13520398
                + t * (1.48851587
                + t * (-0.82215223
                + t * 0.17087277)))))))));
        return x >= 0.0 ? tau : 2.0 - tau;
    }
}
