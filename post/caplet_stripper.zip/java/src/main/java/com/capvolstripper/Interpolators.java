package com.capvolstripper;

import java.util.Arrays;

public final class Interpolators {
    private Interpolators() {
    }

    public static double flat(double[] nodesT, double[] nodesV, double t) {
        validateNodes(nodesT, nodesV);
        int idx = searchSortedFirst(nodesT, t);
        idx = clamp(idx, 0, nodesV.length - 1);
        return nodesV[idx];
    }

    public static double linear(double[] nodesT, double[] nodesV, double t) {
        validateNodes(nodesT, nodesV);
        int n = nodesT.length;
        if (n == 1 || t <= nodesT[0]) {
            return nodesV[0];
        }
        if (t >= nodesT[n - 1]) {
            return nodesV[n - 1];
        }
        int idx = clamp(searchSortedLast(nodesT, t), 0, n - 2);
        double fraction = (t - nodesT[idx]) / (nodesT[idx + 1] - nodesT[idx]);
        return nodesV[idx] + fraction * (nodesV[idx + 1] - nodesV[idx]);
    }

    public static double linearExtrapolation(double[] nodesT, double[] nodesV, double t) {
        validateNodes(nodesT, nodesV);
        int n = nodesT.length;
        if (n == 1) {
            return nodesV[0];
        }
        if (t <= nodesT[0]) {
            double slope = (nodesV[1] - nodesV[0]) / (nodesT[1] - nodesT[0]);
            return nodesV[0] + slope * (t - nodesT[0]);
        }
        if (t >= nodesT[n - 1]) {
            double slope = (nodesV[n - 1] - nodesV[n - 2]) / (nodesT[n - 1] - nodesT[n - 2]);
            return nodesV[n - 1] + slope * (t - nodesT[n - 1]);
        }
        int idx = clamp(searchSortedLast(nodesT, t), 0, n - 2);
        double fraction = (t - nodesT[idx]) / (nodesT[idx + 1] - nodesT[idx]);
        return nodesV[idx] + fraction * (nodesV[idx + 1] - nodesV[idx]);
    }

    public static double flatLinear(double[] nodesT, double[] nodesV, double t, double beta, double delta) {
        validateNodes(nodesT, nodesV);
        int n = nodesT.length;
        if (n == 1 || t <= nodesT[0]) {
            return nodesV[0];
        }
        if (t >= nodesT[n - 1]) {
            return nodesV[n - 1];
        }
        int idx = clamp(searchSortedFirst(nodesT, t), 0, n - 1);
        if (idx == 0) {
            return nodesV[0];
        }
        double prevT = nodesT[idx - 1];
        double nextT = nodesT[idx];
        double center = prevT + delta / 2.0;
        double rampStart = Math.max(prevT, center - beta / 2.0);
        double rampEnd = Math.min(nextT, center + beta / 2.0);
        if (t <= rampStart) {
            return nodesV[idx - 1];
        }
        if (t <= rampEnd) {
            double fraction = (t - rampStart) / (rampEnd - rampStart);
            return nodesV[idx - 1] + fraction * (nodesV[idx] - nodesV[idx - 1]);
        }
        return nodesV[idx];
    }

    public static double flatSmooth(double[] nodesT, double[] nodesV, double t, double beta, double delta) {
        validateNodes(nodesT, nodesV);
        int n = nodesT.length;
        if (n == 1 || t <= nodesT[0]) {
            return nodesV[0];
        }
        if (t >= nodesT[n - 1]) {
            return nodesV[n - 1];
        }
        int idx = clamp(searchSortedFirst(nodesT, t), 0, n - 1);
        if (idx == 0) {
            return nodesV[0];
        }
        double prevT = nodesT[idx - 1];
        double nextT = nodesT[idx];
        double center = prevT + delta / 2.0;
        double rampStart = Math.max(prevT, center - beta / 2.0);
        double rampEnd = Math.min(nextT, center + beta / 2.0);
        if (t <= rampStart) {
            return nodesV[idx - 1];
        }
        if (t <= rampEnd) {
            double s = (t - rampStart) / (rampEnd - rampStart);
            double psi = s * s * (3.0 - 2.0 * s);
            return nodesV[idx - 1] + psi * (nodesV[idx] - nodesV[idx - 1]);
        }
        return nodesV[idx];
    }

    public static double cubicSpline(double[] nodesT, double[] nodesV, double t) {
        validateNodes(nodesT, nodesV);
        int n = nodesT.length;
        if (n == 1 || t <= nodesT[0]) {
            return nodesV[0];
        }
        if (t >= nodesT[n - 1]) {
            return nodesV[n - 1];
        }
        double[] h = intervalWidths(nodesT);
        double[] moments = naturalSplineMoments(nodesT, nodesV, h);
        int idx = clamp(searchSortedLast(nodesT, t), 0, n - 2);
        return evaluateSpline(nodesT, nodesV, h, moments, idx, t);
    }

    public static double cubicSplineLinearExtrapolation(double[] nodesT, double[] nodesV, double t) {
        validateNodes(nodesT, nodesV);
        int n = nodesT.length;
        if (n == 1) {
            return nodesV[0];
        }
        double[] h = intervalWidths(nodesT);
        double[] moments = naturalSplineMoments(nodesT, nodesV, h);

        double slopeLeft = (nodesV[1] - nodesV[0]) / h[0] - h[0] * (2.0 * moments[0] + moments[1]) / 6.0;
        double slopeRight = (nodesV[n - 1] - nodesV[n - 2]) / h[n - 2]
                + h[n - 2] * (moments[n - 2] + 2.0 * moments[n - 1]) / 6.0;
        if (t <= nodesT[0]) {
            return nodesV[0] + slopeLeft * (t - nodesT[0]);
        }
        if (t >= nodesT[n - 1]) {
            return nodesV[n - 1] + slopeRight * (t - nodesT[n - 1]);
        }
        int idx = clamp(searchSortedLast(nodesT, t), 0, n - 2);
        return evaluateSpline(nodesT, nodesV, h, moments, idx, t);
    }

    public static double monotoneCubic(double[] nodesT, double[] nodesV, double t) {
        validateNodes(nodesT, nodesV);
        int n = nodesT.length;
        if (n == 1 || t <= nodesT[0]) {
            return nodesV[0];
        }
        if (t >= nodesT[n - 1]) {
            return nodesV[n - 1];
        }

        double[] h = intervalWidths(nodesT);
        double[] secants = secants(nodesV, h);
        double[] slopes = new double[n];
        slopes[0] = secants[0];
        slopes[n - 1] = secants[n - 2];
        for (int k = 1; k < n - 1; k++) {
            slopes[k] = Math.signum(secants[k - 1]) != Math.signum(secants[k])
                    ? 0.0
                    : 0.5 * (secants[k - 1] + secants[k]);
        }
        for (int i = 0; i < n - 1; i++) {
            if (Math.abs(secants[i]) < 1.0e-30) {
                slopes[i] = 0.0;
                slopes[i + 1] = 0.0;
            } else {
                double alpha = slopes[i] / secants[i];
                double beta = slopes[i + 1] / secants[i];
                double radius = alpha * alpha + beta * beta;
                if (radius > 9.0) {
                    double scale = 3.0 / Math.sqrt(radius);
                    slopes[i] = scale * alpha * secants[i];
                    slopes[i + 1] = scale * beta * secants[i];
                }
            }
        }
        return evaluateHermite(nodesT, nodesV, h, slopes, t);
    }

    public static double tension(double[] nodesT, double[] nodesV, double t, double p) {
        validateNodes(nodesT, nodesV);
        int n = nodesT.length;
        if (n == 1 || t <= nodesT[0]) {
            return nodesV[0];
        }
        if (t >= nodesT[n - 1]) {
            return nodesV[n - 1];
        }
        if (Math.abs(p) < 1.0e-8) {
            return cubicSpline(nodesT, nodesV, t);
        }

        double[] h = intervalWidths(nodesT);
        double[] z = new double[n];
        if (n > 2) {
            int m = n - 2;
            double[] a = new double[m];
            double[] b = new double[m];
            double[] c = new double[m];
            double[] rhs = new double[m];
            double p2 = p * p;
            for (int row = 0; row < m; row++) {
                int k = row + 1;
                double phLeft = p * h[k - 1];
                double phRight = p * h[k];
                if (row > 0) {
                    a[row] = 1.0 / (p2 * h[k - 1]) - 1.0 / (p * Math.sinh(phLeft));
                }
                b[row] = coth(phLeft) / p + coth(phRight) / p
                        - 1.0 / (p2 * h[k - 1]) - 1.0 / (p2 * h[k]);
                if (row < m - 1) {
                    c[row] = 1.0 / (p2 * h[k]) - 1.0 / (p * Math.sinh(phRight));
                }
                rhs[row] = (nodesV[k + 1] - nodesV[k]) / h[k]
                        - (nodesV[k] - nodesV[k - 1]) / h[k - 1];
            }
            double[] cStar = new double[m];
            double[] dStar = new double[m];
            cStar[0] = c[0] / b[0];
            dStar[0] = rhs[0] / b[0];
            for (int i = 1; i < m; i++) {
                double denom = b[i] - a[i] * cStar[i - 1];
                cStar[i] = i < m - 1 ? c[i] / denom : 0.0;
                dStar[i] = (rhs[i] - a[i] * dStar[i - 1]) / denom;
            }
            z[n - 2] = dStar[m - 1];
            for (int i = m - 2; i >= 0; i--) {
                z[i + 1] = dStar[i] - cStar[i] * z[i + 2];
            }
        }

        int idx = clamp(searchSortedLast(nodesT, t), 0, n - 2);
        double ph = p * h[idx];
        double sinh = Math.sinh(ph);
        double right = nodesT[idx + 1] - t;
        double left = t - nodesT[idx];
        double p2 = p * p;
        return z[idx] * Math.sinh(p * right) / (p2 * sinh)
                + z[idx + 1] * Math.sinh(p * left) / (p2 * sinh)
                + (nodesV[idx] - z[idx] / p2) * right / h[idx]
                + (nodesV[idx + 1] - z[idx + 1] / p2) * left / h[idx];
    }

    public static double hymanMonotone(double[] nodesT, double[] nodesV, double t) {
        validateNodes(nodesT, nodesV);
        int n = nodesT.length;
        if (n == 1 || t <= nodesT[0]) {
            return nodesV[0];
        }
        if (t >= nodesT[n - 1]) {
            return nodesV[n - 1];
        }
        double[] h = intervalWidths(nodesT);
        double[] secants = secants(nodesV, h);
        double[] slopes = besselSlopes(h, secants);
        hymanFilter(secants, slopes);
        return evaluateHermite(nodesT, nodesV, h, slopes, t);
    }

    public static double cubicHyman(double[] nodesT, double[] nodesV, double t) {
        validateNodes(nodesT, nodesV);
        int n = nodesT.length;
        if (n == 1 || t <= nodesT[0]) {
            return nodesV[0];
        }
        if (t >= nodesT[n - 1]) {
            return nodesV[n - 1];
        }
        double[] h = intervalWidths(nodesT);
        double[] secants = secants(nodesV, h);
        double[] moments = naturalSplineMoments(nodesT, nodesV, h);
        double[] slopes = new double[n];
        slopes[0] = secants[0] - h[0] * (2.0 * moments[0] + moments[1]) / 6.0;
        slopes[n - 1] = secants[n - 2] + h[n - 2] * (moments[n - 2] + 2.0 * moments[n - 1]) / 6.0;
        for (int k = 1; k < n - 1; k++) {
            slopes[k] = secants[k - 1] + h[k - 1] * (moments[k - 1] + 2.0 * moments[k]) / 6.0;
        }
        hymanFilter(secants, slopes);
        return evaluateHermite(nodesT, nodesV, h, slopes, t);
    }

    public static double huynhRational(double[] nodesT, double[] nodesV, double t) {
        validateNodes(nodesT, nodesV);
        int n = nodesT.length;
        if (n == 1 || t <= nodesT[0]) {
            return nodesV[0];
        }
        if (t >= nodesT[n - 1]) {
            return nodesV[n - 1];
        }
        double[] h = intervalWidths(nodesT);
        double[] secants = secants(nodesV, h);
        double[] slopes = huynhBoundarySlopes(h, secants);
        for (int k = 1; k < n - 1; k++) {
            double left = secants[k - 1];
            double right = secants[k];
            if (left * right <= 0.0) {
                slopes[k] = 0.0;
            } else {
                double alpha = (2.0 * h[k] + h[k - 1]) / (3.0 * (h[k - 1] + h[k]));
                double denom = alpha * right + (1.0 - alpha) * left;
                slopes[k] = Math.abs(denom) < 1.0e-30 ? 0.0 : left * right / denom;
            }
        }
        enforceBoundarySlopes(secants, slopes);
        return evaluateHermite(nodesT, nodesV, h, slopes, t);
    }

    public static double huynhHarmonic(double[] nodesT, double[] nodesV, double t) {
        validateNodes(nodesT, nodesV);
        int n = nodesT.length;
        if (n == 1 || t <= nodesT[0]) {
            return nodesV[0];
        }
        if (t >= nodesT[n - 1]) {
            return nodesV[n - 1];
        }
        double[] h = intervalWidths(nodesT);
        double[] secants = secants(nodesV, h);
        double[] slopes = huynhBoundarySlopes(h, secants);
        for (int k = 1; k < n - 1; k++) {
            double left = secants[k - 1];
            double right = secants[k];
            if (left * right <= 0.0) {
                slopes[k] = 0.0;
            } else {
                double denom = left + right;
                slopes[k] = Math.abs(denom) < 1.0e-30 ? 0.0 : 2.0 * left * right / denom;
            }
        }
        enforceBoundarySlopes(secants, slopes);
        return evaluateHermite(nodesT, nodesV, h, slopes, t);
    }

    public static double hymanNonNegative(double[] nodesT, double[] nodesV, double t) {
        validateNodes(nodesT, nodesV);
        int n = nodesT.length;
        if (n == 1 || t <= nodesT[0]) {
            return Math.max(0.0, nodesV[0]);
        }
        if (t >= nodesT[n - 1]) {
            return Math.max(0.0, nodesV[n - 1]);
        }

        double[] h = intervalWidths(nodesT);
        double[] secants = new double[n - 1];
        for (int i = 0; i < n - 1; i++) {
            secants[i] = (nodesV[i + 1] - nodesV[i]) / h[i];
        }

        double[] slopes = new double[n];
        slopes[0] = secants[0];
        slopes[n - 1] = secants[n - 2];
        for (int k = 1; k < n - 1; k++) {
            slopes[k] = (h[k] * secants[k - 1] + h[k - 1] * secants[k]) / (h[k - 1] + h[k]);
        }
        for (int k = 1; k < n - 1; k++) {
            if (secants[k - 1] * secants[k] <= 0.0) {
                slopes[k] = 0.0;
            }
        }
        for (int k = 0; k < n; k++) {
            double fk = nodesV[k];
            if (fk <= 0.0) {
                slopes[k] = 0.0;
                continue;
            }
            if (k > 0) {
                slopes[k] = Math.min(slopes[k], 3.0 * fk / h[k - 1]);
            }
            if (k < n - 1) {
                slopes[k] = Math.max(slopes[k], -3.0 * fk / h[k]);
            }
        }

        int idx = clamp(searchSortedLast(nodesT, t), 0, n - 2);
        double u = (t - nodesT[idx]) / h[idx];
        double y0 = nodesV[idx];
        double y1 = nodesV[idx + 1];
        double m0 = slopes[idx] * h[idx];
        double m1 = slopes[idx + 1] * h[idx];

        double value = (2.0 * u * u * u - 3.0 * u * u + 1.0) * y0
                + (u * u * u - 2.0 * u * u + u) * m0
                + (-2.0 * u * u * u + 3.0 * u * u) * y1
                + (u * u * u - u * u) * m1;
        return Math.max(0.0, value);
    }

    static int searchSortedFirst(double[] values, double target) {
        int idx = Arrays.binarySearch(values, target);
        if (idx >= 0) {
            return idx;
        }
        return -idx - 1;
    }

    static int searchSortedLast(double[] values, double target) {
        int idx = Arrays.binarySearch(values, target);
        if (idx >= 0) {
            while (idx + 1 < values.length && values[idx + 1] <= target) {
                idx++;
            }
            return idx;
        }
        return -idx - 2;
    }

    static int clamp(int value, int lower, int upper) {
        return Math.max(lower, Math.min(upper, value));
    }

    private static void validateNodes(double[] nodesT, double[] nodesV) {
        Validation.sameLength(nodesT, nodesV, "nodesT", "nodesV");
        if (nodesT.length == 0) {
            throw new IllegalArgumentException("nodes must not be empty");
        }
        Validation.sorted(nodesT, "nodesT");
    }

    private static double[] intervalWidths(double[] nodesT) {
        double[] h = new double[nodesT.length - 1];
        for (int i = 0; i < h.length; i++) {
            h[i] = nodesT[i + 1] - nodesT[i];
            if (h[i] <= 0.0) {
                throw new IllegalArgumentException("nodesT must be strictly increasing");
            }
        }
        return h;
    }

    private static double[] secants(double[] nodesV, double[] h) {
        double[] secants = new double[h.length];
        for (int i = 0; i < h.length; i++) {
            secants[i] = (nodesV[i + 1] - nodesV[i]) / h[i];
        }
        return secants;
    }

    private static double[] besselSlopes(double[] h, double[] secants) {
        int n = secants.length + 1;
        double[] slopes = new double[n];
        slopes[0] = secants[0];
        slopes[n - 1] = secants[n - 2];
        for (int k = 1; k < n - 1; k++) {
            slopes[k] = (h[k] * secants[k - 1] + h[k - 1] * secants[k]) / (h[k - 1] + h[k]);
        }
        return slopes;
    }

    private static double[] huynhBoundarySlopes(double[] h, double[] secants) {
        int n = secants.length + 1;
        double[] slopes = new double[n];
        if (n == 2) {
            slopes[0] = secants[0];
            slopes[1] = secants[0];
        } else {
            slopes[0] = ((2.0 * h[0] + h[1]) * secants[0] - h[0] * secants[1]) / (h[0] + h[1]);
            slopes[n - 1] = ((2.0 * h[n - 2] + h[n - 3]) * secants[n - 2]
                    - h[n - 2] * secants[n - 3]) / (h[n - 2] + h[n - 3]);
        }
        return slopes;
    }

    private static void hymanFilter(double[] secants, double[] slopes) {
        int n = slopes.length;
        enforceBoundarySlopes(secants, slopes);
        for (int k = 1; k < n - 1; k++) {
            if (secants[k - 1] * secants[k] <= 0.0) {
                slopes[k] = 0.0;
            } else {
                double limit = Math.min(Math.abs(secants[k - 1]), Math.abs(secants[k]));
                slopes[k] = Math.signum(secants[k - 1]) * Math.min(Math.abs(slopes[k]), 3.0 * limit);
            }
        }
    }

    private static void enforceBoundarySlopes(double[] secants, double[] slopes) {
        enforceBoundarySlope(secants[0], slopes, 0);
        enforceBoundarySlope(secants[secants.length - 1], slopes, slopes.length - 1);
    }

    private static void enforceBoundarySlope(double secant, double[] slopes, int index) {
        if (secant == 0.0 || Math.signum(slopes[index]) != Math.signum(secant)) {
            slopes[index] = 0.0;
        } else {
            slopes[index] = Math.signum(secant) * Math.min(Math.abs(slopes[index]), 3.0 * Math.abs(secant));
        }
    }

    private static double evaluateHermite(double[] nodesT, double[] nodesV, double[] h, double[] slopes, double t) {
        int idx = clamp(searchSortedLast(nodesT, t), 0, nodesT.length - 2);
        double u = (t - nodesT[idx]) / h[idx];
        double u2 = u * u;
        double u3 = u2 * u;
        double h00 = 2.0 * u3 - 3.0 * u2 + 1.0;
        double h10 = u3 - 2.0 * u2 + u;
        double h01 = -2.0 * u3 + 3.0 * u2;
        double h11 = u3 - u2;
        return h00 * nodesV[idx] + h10 * h[idx] * slopes[idx]
                + h01 * nodesV[idx + 1] + h11 * h[idx] * slopes[idx + 1];
    }

    private static double coth(double x) {
        return Math.cosh(x) / Math.sinh(x);
    }

    private static double[] naturalSplineMoments(double[] nodesT, double[] nodesV, double[] h) {
        int n = nodesT.length;
        double[] moments = new double[n];
        if (n <= 2) {
            return moments;
        }

        int m = n - 2;
        double[] a = new double[m];
        double[] b = new double[m];
        double[] c = new double[m];
        double[] rhs = new double[m];
        for (int j = 0; j < m; j++) {
            int k = j + 1;
            if (j > 0) {
                a[j] = h[k - 1];
            }
            b[j] = 2.0 * (h[k - 1] + h[k]);
            if (j < m - 1) {
                c[j] = h[k];
            }
            rhs[j] = 6.0 * ((nodesV[k + 1] - nodesV[k]) / h[k]
                    - (nodesV[k] - nodesV[k - 1]) / h[k - 1]);
        }

        double[] cStar = new double[m];
        double[] dStar = new double[m];
        cStar[0] = c[0] / b[0];
        dStar[0] = rhs[0] / b[0];
        for (int i = 1; i < m; i++) {
            double denom = b[i] - a[i] * cStar[i - 1];
            cStar[i] = i < m - 1 ? c[i] / denom : 0.0;
            dStar[i] = (rhs[i] - a[i] * dStar[i - 1]) / denom;
        }

        moments[n - 2] = dStar[m - 1];
        for (int i = m - 2; i >= 0; i--) {
            moments[i + 1] = dStar[i] - cStar[i] * moments[i + 2];
        }
        return moments;
    }

    private static double evaluateSpline(double[] nodesT, double[] nodesV, double[] h,
                                         double[] moments, int idx, double t) {
        double dtRight = nodesT[idx + 1] - t;
        double dtLeft = t - nodesT[idx];
        double hi = h[idx];
        return moments[idx] * dtRight * dtRight * dtRight / (6.0 * hi)
                + moments[idx + 1] * dtLeft * dtLeft * dtLeft / (6.0 * hi)
                + (nodesV[idx] - moments[idx] * hi * hi / 6.0) * dtRight / hi
                + (nodesV[idx + 1] - moments[idx + 1] * hi * hi / 6.0) * dtLeft / hi;
    }
}
