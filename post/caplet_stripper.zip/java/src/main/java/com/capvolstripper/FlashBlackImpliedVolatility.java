package com.capvolstripper;

final class FlashBlackImpliedVolatility {
    private static final double SQRT_TWO = Math.sqrt(2.0);
    private static final double SQRT_TWO_PI = Math.sqrt(2.0 * Math.PI);
    private static final double SQRT_PI_OVER_TWO = Math.sqrt(Math.PI / 2.0);
    private static final double ONE_OVER_SQRT_PI = 1.0 / Math.sqrt(Math.PI);
    private static final double LOG2 = Math.log(2.0);
    private static final double LOG_2PI = Math.log(2.0 * Math.PI);
    private static final double MIN_TOTAL_VOL = 1.0e-10;
    private static final double SMALL_PRICE_LI_CUTOFF = 0.0005;
    private static final double UPPER_PRICE_LI_CUTOFF = 0.9995;
    private static final double UPPER_PRICE_CUTOFF = 0.9990;
    private static final double NEAR_ATM_X_CUTOFF = 0.01;
    private static final double TINY_NEAR_ATM_PRICE_CUTOFF = 1.0e-8;
    private static final double TINY_NEAR_ATM_X_CUTOFF = 1.0e-8;
    private static final double TINY_BACHELIER_CENTRAL_RATIO_CUTOFF = 0.5;
    private static final double TINY_BACHELIER_TAIL_LOG_GAP = 20.0;
    private static final double TINY_BACHELIER_TAIL_RATIO_CUTOFF = 4.0;

    private static final double P = 0.3275911;
    private static final double A1 = 0.254829592;
    private static final double A2 = -0.284496736;
    private static final double A3 = 1.421413741;
    private static final double A4 = -1.453152027;
    private static final double A5 = 1.061405429;

    private static final double M00 = -0.00006103098165;
    private static final double M01 = 5.33967643357688;
    private static final double M10 = -0.40661990365427;
    private static final double M02 = 3.25023425332360;
    private static final double M11 = -36.19405221599028;
    private static final double M20 = 0.08975394404851;
    private static final double M03 = 83.84593224417796;
    private static final double M12 = 41.21772632732834;
    private static final double M21 = 3.83815885394565;
    private static final double M30 = -0.21619763215668;

    private static final double N00 = 1.0;
    private static final double N01 = 22.96302109010794;
    private static final double N10 = -0.48466536361620;
    private static final double N02 = -0.77268824532468;
    private static final double N11 = -1.34102279982050;
    private static final double N20 = 0.43027619553168;
    private static final double N03 = -5.70531500645109;
    private static final double N12 = 2.45782574294244;
    private static final double N21 = -0.04763802358853;
    private static final double N30 = -0.03326944290044;

    private FlashBlackImpliedVolatility() {
    }

    static double impliedVolatilityFromPrice(double price, double forward, double strike,
                                             double expiry, double discountFactor) {
        double[] normalised = normalizeCallPrice(price, forward, strike, discountFactor);
        return impliedVolatilityFromNormalisedPrice(normalised[0], normalised[1], expiry);
    }

    static double impliedVolatilityFromNormalisedPrice(double c, double ex, double expiry) {
        if (c <= 0.0) {
            return Math.ulp(1.0);
        }
        if (c >= 1.0 / ex) {
            throw new ArithmeticException("Black price out of range");
        }
        double x = Math.log(ex);
        return solve(x, ex, c, Math.log(c), expiry);
    }

    static double normalisedBlackCall(double x, double s) {
        if (s <= 0.0) {
            return Math.max(Math.exp(x / 2.0) - Math.exp(-x / 2.0), 0.0);
        }
        if (x == 0.0) {
            return NormalDistribution.erf(s / (2.0 * SQRT_TWO));
        }

        double h = x / s;
        double halfS = s / 2.0;
        double nPlus = NormalDistribution.erfcx(-(h + halfS) / SQRT_TWO);
        double nMinus = NormalDistribution.erfcx(-(h - halfS) / SQRT_TWO);
        double diff = nPlus - nMinus;
        double value = Math.exp(-(h * h + halfS * halfS) / 2.0) / 2.0 * diff;
        return Math.max(value, 0.0);
    }

    static double solve(double x, double ex, double c, double logC, double expiry) {
        double tinyNearAtm = tinyNearAtmBachelierVolatility(x, c, logC, expiry);
        if (Double.isFinite(tinyNearAtm)) {
            return tinyNearAtm;
        }
        double v = Math.max(liOrAsymGuess(x, c, logC, ex), MIN_TOTAL_VOL);
        if (c >= UPPER_PRICE_CUTOFF) {
            return polishUpperPrice(x, c, logC, v) / Math.sqrt(expiry);
        }
        v = fastH3Step(x, v, logC);

        for (int iter = 0; iter < 3; iter++) {
            double h = x / v;
            double halfS = v / 2.0;
            double h2 = h * h;
            double halfS2 = halfS * halfS;
            double diff = NormalDistribution.erfcx(-(h + halfS) / SQRT_TWO)
                    - NormalDistribution.erfcx(-(h - halfS) / SQRT_TWO);
            double logCEst = x == 0.0
                    ? Math.log(NormalDistribution.erf(halfS / SQRT_TWO))
                    : -(h2 + halfS2) / 2.0 - LOG2 - x / 2.0 + Math.log(diff);
            double logVega = (2.0 / SQRT_TWO_PI) / diff;
            double vov = (h + halfS) * (h - halfS) / v;
            double d2 = vov - logVega;
            double h2mt2 = h2 - halfS2;
            double d3 = (-3.0 * h2 - halfS2 + h2mt2 * h2mt2) / (v * v)
                    - 3.0 * logVega * vov + 2.0 * logVega * logVega;
            double fVal = logCEst - logC;
            double hn = -fVal / logVega;
            double numerator = 1.0 + d2 * hn / 2.0;
            double denominator = 1.0 + d2 * hn + d3 / 6.0 * hn * hn;
            double v1 = v + hn * numerator / denominator;
            if (Double.isFinite(v1) && v1 > 0.0) {
                v = v1;
            }
            if (iter >= 1 && Math.abs(fVal) < 1.0e-4) {
                break;
            }
        }

        return v / Math.sqrt(expiry);
    }

    private static double[] normalizeCallPrice(double price, double forward, double strike, double discountFactor) {
        double c = price / forward / discountFactor;
        double ex = forward / strike;
        if (ex > 1.0) {
            c = (forward * (c - 1.0) + strike) / strike;
            ex = 1.0 / ex;
        }
        return new double[]{c, ex};
    }

    private static double liOrAsymGuess(double x, double c, double logC, double ex) {
        double ax = Math.abs(x);
        if (ax < 3.0 && c > SMALL_PRICE_LI_CUTOFF && c < UPPER_PRICE_LI_CUTOFF) {
            return liRationalGuess(x, c);
        }
        if (c <= SMALL_PRICE_LI_CUTOFF && ax < NEAR_ATM_X_CUTOFF) {
            return nearAtmSmallPriceGuess(x, c);
        }
        if (c >= UPPER_PRICE_CUTOFF) {
            return upperPriceGuess(x, c);
        }
        if (c <= 0.5 && logC < -2.0) {
            return asymOtmGuess(x, logC);
        }

        double p = 1.0 / ex - c;
        if (p > 1.0e-300) {
            double logp = Math.log(p);
            double arg = -2.0 * logp - 2.0 * x - LOG_2PI;
            if (arg > 0.0) {
                double d = Math.sqrt(arg);
                return d + Math.sqrt(Math.max(d * d + 2.0 * x, 0.0));
            }
        }
        return Math.sqrt(2.0 * Math.abs(x));
    }

    private static double nearAtmSmallPriceGuess(double x, double c) {
        double atmVol = SQRT_TWO_PI * c;
        return Math.sqrt(x * x + atmVol * atmVol);
    }

    private static double upperPriceGuess(double x, double c) {
        double r = -2.0 * Math.log1p(-c) - LOG_2PI;
        double d = Math.sqrt(r);
        d -= 0.5 * Math.log(r) * d / (r + 1.0);
        return d + Math.sqrt(Math.max(d * d - 2.0 * x, 0.0));
    }

    private static double polishUpperPrice(double x, double c, double logC, double v) {
        double gapFromLogPrice = -Math.expm1(logC);
        double targetLogGap = gapFromLogPrice > 0.0 && Double.isFinite(gapFromLogPrice)
                ? Math.log(gapFromLogPrice)
                : Math.log1p(-c);
        for (int iter = 0; iter < 4; iter++) {
            double d1 = x / v + v / 2.0;
            double b1 = d1 / SQRT_TWO;
            double d2 = d1 - v;
            double b2 = -d2 / SQRT_TWO;
            double gap = 0.5 * Math.exp(-b1 * b1) * NormalDistribution.erfcx(b1)
                    + 0.5 * Math.exp(-x - b2 * b2) * NormalDistribution.erfcx(b2);
            if (!(gap > 0.0) || !Double.isFinite(gap)) {
                break;
            }
            double vega = Math.exp(-0.5 * d1 * d1) / SQRT_TWO_PI;
            double fVal = Math.log(gap) - targetLogGap;
            double step = fVal * gap / vega;
            double d1p = 0.5 - x / (v * v);
            double q = fVal * (d1 * d1p * gap / vega - 1.0);
            double denominator = 1.0 - 0.5 * q;
            if (denominator > 0.1) {
                step /= denominator;
            }
            if (!Double.isFinite(step)) {
                break;
            }
            double v1 = v + step;
            if (!(v1 > 0.0)) {
                v1 = 0.5 * v;
            }
            v = v1;
            if (Math.abs(step) <= 1.0e-14 * Math.max(1.0, v)) {
                break;
            }
        }
        return v;
    }

    private static double tinyNearAtmBachelierVolatility(double x, double c, double logC, double expiry) {
        double ax = Math.abs(x);
        if (!(c > 0.0) || x > 0.0 || c > TINY_NEAR_ATM_PRICE_CUTOFF || ax > TINY_NEAR_ATM_X_CUTOFF) {
            return Double.NaN;
        }

        double k = Math.expm1(-x);
        double v = tinyBachelierDeepTailVolatility(k, logC);
        if (Double.isFinite(v)) {
            return v / Math.sqrt(expiry);
        }

        v = tinyBachelierCentralVolatility(k, c);
        return Double.isFinite(v) ? v / Math.sqrt(expiry) : Double.NaN;
    }

    private static double tinyBachelierCentralVolatility(double k, double c) {
        double straddle = 2.0 * c + k;
        double nu = k / straddle;
        double eta = Math.abs(nu) < 1.0e-8 ? 1.0 : nu / (0.5 * Math.log1p(2.0 * nu / (1.0 - nu)));
        double v = SQRT_PI_OVER_TWO * straddle * choiH(eta);
        if (!(v > 0.0) || !Double.isFinite(v)) {
            return Double.NaN;
        }

        if (k / v >= TINY_BACHELIER_CENTRAL_RATIO_CUTOFF) {
            return Double.NaN;
        }
        return v;
    }

    private static double tinyBachelierDeepTailVolatility(double k, double logC) {
        if (!(k > 0.0) || !Double.isFinite(logC)) {
            return Double.NaN;
        }

        double logK = Math.log(k);
        double logGap = logK - logC;
        if (logGap <= TINY_BACHELIER_TAIL_LOG_GAP) {
            return Double.NaN;
        }

        double targetLogRatio = logC - logK;
        double tailRatio = Math.sqrt(Math.max(1.0, -2.0 * (targetLogRatio + 0.5 * LOG_2PI)));
        for (int iter = 0; iter < 4; iter++) {
            double millsRatio = SQRT_PI_OVER_TWO * NormalDistribution.erfcx(tailRatio / SQRT_TWO);
            double scaledGap = 1.0 / tailRatio - millsRatio;
            if (!(scaledGap > 0.0) || !Double.isFinite(scaledGap)) {
                return Double.NaN;
            }
            double residual = -0.5 * tailRatio * tailRatio - 0.5 * LOG_2PI
                    + Math.log(scaledGap) - targetLogRatio;
            double slope = -tailRatio + (1.0 - 1.0 / (tailRatio * tailRatio) - tailRatio * millsRatio)
                    / scaledGap;
            double step = residual / slope;
            double next = tailRatio - step;
            if (!(next > 0.0) || !Double.isFinite(next)) {
                return Double.NaN;
            }
            tailRatio = next;
            if (Math.abs(step) <= 1.0e-14 * Math.max(1.0, tailRatio)) {
                break;
            }
        }
        double v = k / tailRatio;
        return k / v > TINY_BACHELIER_TAIL_RATIO_CUTOFF ? v : Double.NaN;
    }

    private static double choiH(double eta) {
        double numerator = 0.3994961687345134
                + eta * (21.00960795068497
                + eta * (49.80340217855084
                + eta * (598.8761102690991
                + eta * (1848.489695437094
                + eta * (6106.322407867059
                + eta * (24934.15285349361
                + eta * 12664.58051348246))))));
        double denominator = 1.0
                + eta * (49.90534153589422
                + eta * (30.93573936743112
                + eta * (1495.105008310999
                + eta * (1323.614537899738
                + eta * (15989.19697679745
                + eta * (23920.08891720782
                + eta * (3608.817108375034
                + eta * (-206.7719486400926
                + eta * 11.74240599306013))))))));
        return Math.sqrt(eta) * numerator / denominator;
    }

    private static double liRationalGuess(double x, double c) {
        double x2 = x * x;
        double c2 = c * c;
        double c3 = c2 * c;
        double numerator = M00 + x * (M10 + x * (M20 + x * M30))
                + c * (M01 + M11 * x + M21 * x2) + c2 * (M02 + M12 * x) + c3 * M03;
        double denominator = N00 + x * (N10 + x * (N20 + x * N30))
                + c * (N01 + N11 * x + N21 * x2) + c2 * (N02 + N12 * x) + c3 * N03;
        return numerator / denominator;
    }

    private static double asymOtmGuess(double x, double logC) {
        double d = Math.sqrt(-2.0 * logC - LOG_2PI);
        double disc = d * d - 2.0 * x;
        return disc <= 0.0 ? d : -2.0 * x / (d + Math.sqrt(disc));
    }

    private static double fastH3Step(double x, double v, double logC) {
        double h = x / v;
        double halfS = v / 2.0;
        double h2 = h * h;
        double halfS2 = halfS * halfS;
        double diff = fastErfcx(-(h + halfS) / SQRT_TWO)
                - fastErfcx(-(h - halfS) / SQRT_TWO);
        if (diff <= 0.0) {
            return v;
        }

        double logCEst = -(h2 + halfS2) / 2.0 - LOG2 - x / 2.0 + Math.log(diff);
        double logVega = (2.0 / SQRT_TWO_PI) / diff;
        double vov = (h + halfS) * (h - halfS) / v;
        double d2 = vov - logVega;
        double h2mt2 = h2 - halfS2;
        double d3 = (-3.0 * h2 - halfS2 + h2mt2 * h2mt2) / (v * v)
                - 3.0 * logVega * vov + 2.0 * logVega * logVega;
        double hn = -(logCEst - logC) / logVega;
        double numerator = 1.0 + d2 * hn / 2.0;
        double denominator = 1.0 + d2 * hn + d3 / 6.0 * hn * hn;
        double v1 = v + hn * numerator / denominator;
        return Double.isFinite(v1) && v1 > 0.0 ? v1 : v;
    }

    private static double fastErfcx(double z) {
        if (z >= 2.5) {
            double iz2 = 1.0 / (2.0 * z * z);
            return ONE_OVER_SQRT_PI / z
                    * (1.0 - iz2 * (1.0 - 3.0 * iz2 * (1.0 - 5.0 * iz2)));
        }
        if (z >= 0.0) {
            double t = 1.0 / (1.0 + P * z);
            return ((((A5 * t + A4) * t + A3) * t + A2) * t + A1) * t;
        }
        if (z == z) {
            return 2.0 * Math.exp(z * z) - fastErfcx(-z);
        }
        return Double.NaN;
    }
}
