package com.capvolstripper;

import java.util.Arrays;

public final class CapVolStripperTests {
    private static final double[] BACH_CAP_MATS = {2, 3, 4, 5, 6, 9, 12, 24, 36, 60, 84, 120, 180};
    private static final double[] BACH_CAP_VOLS = {79.30, 111.83, 93.10, 91.83, 94.51, 102.25, 99.86, 60.42, 109.15, 96.34, 84.37, 76.90, 76.34};
    private static final double BACH_TAU = 1.0 / 12.0;

    private CapVolStripperTests() {
    }

    public static void main(String[] args) {
        pricingSmokeTest();
        quantLibFlatBlackTermVolRecovery();
        quantLibNonFlatBlackTermVolRepricing();
        discountCurveLinearExtrapolatesFlatForward();
        bachelierCleanMidpointTests();
        bachelierFullDataIsNotExactlyFit();
        openGammaBlackTests();
        openGammaNormalEquivalentTests();
        hymanInterpolationIsNonNegative();
        impliedVolRoundTrips();
        extraInterpolatorsStayFiniteAndMonotone();
        priceStripperRecoversFlatNormalVols();
        solverDiagnosticsAreExposed();
        System.out.println("All Java cap-vol stripper tests passed.");
    }

    private static void pricingSmokeTest() {
        BachelierModel bach = new BachelierModel();
        double sigma = 80.0;
        double expiry = 0.25;
        double expectedAtm = BACH_TAU * sigma * Math.sqrt(expiry) / Math.sqrt(2.0 * Math.PI);
        assertNear("ATM Bachelier", expectedAtm,
                bach.capletPrice(sigma, expiry, BACH_TAU, 1.0, 100.0, 100.0), 1.0e-8);

        BlackModel black = new BlackModel();
        double intrinsic = 0.25 * (0.03 - 0.02);
        assertNear("zero-vol Black intrinsic", intrinsic,
                black.capletPrice(0.0, 1.0, 0.25, 1.0, 0.03, 0.02), 1.0e-15);
    }

    private static void quantLibFlatBlackTermVolRecovery() {
        double[] capMaturities = {12, 24, 36, 48, 60, 72, 84, 96, 108, 120};
        double[] capVols = new double[capMaturities.length];
        Arrays.fill(capVols, 0.18);

        int frequency = 6;
        double flatRate = 0.04;
        double accrual = frequency / 12.0;
        int nCaplets = (int) Math.round(capMaturities[capMaturities.length - 1] / frequency) - 1;
        double[] forwards = new double[nCaplets];
        double[] discountFactors = new double[nCaplets];
        for (int i = 0; i < nCaplets; i++) {
            double fixTime = (i + 1.0) * accrual;
            double payTime = fixTime + accrual;
            forwards[i] = (Math.exp(flatRate * accrual) - 1.0) / accrual;
            discountFactors[i] = Math.exp(-flatRate * payTime);
        }

        StripConfig config = StripConfig.builder()
                .model(new BlackModel())
                .strike(0.03)
                .capletFrequencyMonths(frequency)
                .rateType(RateType.FORWARD)
                .discountFactors(discountFactors)
                .interpolationMethod(InterpolationMethod.FLAT)
                .knotPlacement(KnotPlacement.AT_MATURITIES)
                .solver(Solver.AUTO)
                .build();
        StripResult result = CapVolStripper.stripCapletVols(capMaturities, capVols, forwards, config);
        for (double vol : result.capletVols()) {
            assertNear("QuantLib-style flat Black caplet vol", 0.18, vol, 1.0e-10);
        }
        for (double vol : result.nodeVols()) {
            assertNear("QuantLib-style flat Black node vol", 0.18, vol, 1.0e-10);
        }
    }

    private static void quantLibNonFlatBlackTermVolRepricing() {
        double[] capMaturities = {12, 18, 24, 36, 48, 60, 72, 84, 96, 108, 120, 144, 180, 240, 300, 360};
        double[] capVols = {
            0.090304, 0.12180, 0.13077, 0.14832, 0.15570, 0.15816,
            0.15932, 0.16035, 0.15951, 0.15855, 0.15754, 0.15459,
            0.15163, 0.14575, 0.14175, 0.13889
        };

        int frequency = 6;
        double flatRate = 0.04;
        double accrual = frequency / 12.0;
        int nCaplets = (int) Math.round(capMaturities[capMaturities.length - 1] / frequency) - 1;
        double[] forwards = new double[nCaplets];
        double[] discountFactors = new double[nCaplets];
        for (int i = 0; i < nCaplets; i++) {
            double payTime = (i + 2.0) * accrual;
            forwards[i] = (Math.exp(flatRate * accrual) - 1.0) / accrual;
            discountFactors[i] = Math.exp(-flatRate * payTime);
        }

        StripConfig config = StripConfig.builder()
                .model(new BlackModel())
                .strike(0.04)
                .capletFrequencyMonths(frequency)
                .rateType(RateType.FORWARD)
                .discountFactors(discountFactors)
                .interpolationMethod(InterpolationMethod.FLAT)
                .knotPlacement(KnotPlacement.AT_MATURITIES)
                .solver(Solver.AUTO)
                .build();
        StripResult result = CapVolStripper.stripCapletVols(capMaturities, capVols, forwards, config);
        double err = repriceError(new BlackModel(), result,
                new MarketData(capMaturities, capVols, forwards, discountFactors), frequency, 0.04);
        assertTrue("QuantLib non-flat Black term-vol curve reprices", err < 1.0e-10);
        assertTrue("QuantLib non-flat Black stripped vols positive",
            Arrays.stream(result.capletVols()).min().orElseThrow() > 0.0);

        StripConfig hymanGlobal = StripConfig.builder()
                .model(new BlackModel())
                .strike(0.04)
                .capletFrequencyMonths(frequency)
                .rateType(RateType.FORWARD)
                .discountFactors(discountFactors)
                .interpolationMethod(InterpolationMethod.HYMAN_NON_NEGATIVE)
                .knotPlacement(KnotPlacement.MIDPOINTS)
                .volFloor(1.0e-12)
                .solver(Solver.GLOBAL)
                .build();
        StripResult hymanResult = CapVolStripper.stripCapletVols(capMaturities, capVols, forwards, hymanGlobal);
        double hymanErr = repriceError(new BlackModel(), hymanResult,
                new MarketData(capMaturities, capVols, forwards, discountFactors), frequency, 0.04);
        assertTrue("QuantLib non-flat Black Hyman global reprices", hymanErr < 1.0e-10);
        assertTrue("QuantLib non-flat Black Hyman global stays plausible",
            Arrays.stream(hymanResult.capletVols()).max().orElseThrow() < 0.25);

        StripConfig flatSmoothGlobal = StripConfig.builder()
                .model(new BlackModel())
                .strike(0.04)
                .capletFrequencyMonths(frequency)
                .rateType(RateType.FORWARD)
                .discountFactors(discountFactors)
                .interpolationMethod(InterpolationMethod.FLAT_SMOOTH)
                .knotPlacement(KnotPlacement.MIDPOINTS)
                .beta(1.0)
                .volFloor(1.0e-12)
                .solver(Solver.GLOBAL)
                .build();
        StripResult flatSmoothResult = CapVolStripper.stripCapletVols(capMaturities, capVols, forwards, flatSmoothGlobal);
        double flatSmoothErr = repriceError(new BlackModel(), flatSmoothResult,
                new MarketData(capMaturities, capVols, forwards, discountFactors), frequency, 0.04);
        assertTrue("QuantLib non-flat Black flat-smooth global reprices", flatSmoothErr < 1.0e-10);
        assertTrue("QuantLib non-flat Black flat-smooth global stays plausible",
            Arrays.stream(flatSmoothResult.capletVols()).max().orElseThrow() < 0.25);
    }

    private static void discountCurveLinearExtrapolatesFlatForward() {
        double[] times = {1.0, 2.0};
        double[] dfs = {Math.exp(-0.03), Math.exp(-0.06)};
        DiscountCurve curve = new DiscountCurve(times, dfs);
        assertNear("linear discount curve left flat-forward extrapolation",
                Math.exp(0.0), curve.discountFactor(0.0), 1.0e-15);
        assertNear("linear discount curve right flat-forward extrapolation",
                Math.exp(-0.09), curve.discountFactor(3.0), 1.0e-15);
    }

    private static void bachelierCleanMidpointTests() {
        MarketData data = bachMarketData(false);
        StripConfig linear = StripConfig.builder()
                .model(new BachelierModel())
                .capletFrequencyMonths(1)
                .rateType(RateType.FORWARD)
                .discountFactors(data.discountFactors)
                .interpolationMethod(InterpolationMethod.LINEAR)
                .knotPlacement(KnotPlacement.MIDPOINTS)
                .solver(Solver.GLOBAL)
                .build();
        StripResult linearResult = CapVolStripper.stripCapletVols(data.capMaturities, data.capVols, data.forwards, linear);
        double linearErr = repriceError(new BachelierModel(), linearResult, data, 1, 0.0);
        assertTrue("clean linear midpoint reprices", linearErr < 1.0e-10);

        StripConfig hyman = StripConfig.builder()
                .model(new BachelierModel())
                .capletFrequencyMonths(1)
                .rateType(RateType.FORWARD)
                .discountFactors(data.discountFactors)
                .interpolationMethod(InterpolationMethod.HYMAN_NON_NEGATIVE)
                .knotPlacement(KnotPlacement.MIDPOINTS)
                .solver(Solver.GLOBAL)
                .build();
        StripResult hymanResult = CapVolStripper.stripCapletVols(data.capMaturities, data.capVols, data.forwards, hyman);
        double hymanErr = repriceError(new BachelierModel(), hymanResult, data, 1, 0.0);
        assertTrue("clean hyman midpoint reprices", hymanErr < 1.0e-10);
        assertTrue("hyman caplet vols non-negative",
            Arrays.stream(hymanResult.capletVols()).min().orElseThrow() >= -1.0e-12);

        StripConfig cubicLog = StripConfig.builder()
                .model(new BachelierModel())
                .capletFrequencyMonths(1)
                .rateType(RateType.FORWARD)
                .discountFactors(data.discountFactors)
                .interpolationMethod(InterpolationMethod.CUBIC_SPLINE)
                .knotPlacement(KnotPlacement.MIDPOINTS)
                .logSpace(true)
                .solver(Solver.GLOBAL)
                .build();
        StripResult cubicLogResult = CapVolStripper.stripCapletVols(data.capMaturities, data.capVols, data.forwards, cubicLog);
        double cubicErr = repriceError(new BachelierModel(), cubicLogResult, data, 1, 0.0);
        assertTrue("clean cubic log midpoint reprices", cubicErr < 1.0e-10);
        assertTrue("log-space caplet vols positive",
            Arrays.stream(cubicLogResult.capletVols()).min().orElseThrow() > 0.0);
    }

    private static void bachelierFullDataIsNotExactlyFit() {
        MarketData data = bachMarketData(true);
        StripConfig config = StripConfig.builder()
                .model(new BachelierModel())
                .capletFrequencyMonths(1)
                .rateType(RateType.FORWARD)
                .discountFactors(data.discountFactors)
                .interpolationMethod(InterpolationMethod.LINEAR)
                .knotPlacement(KnotPlacement.MIDPOINTS)
                .solver(Solver.GLOBAL)
                .build();
        StripResult result = CapVolStripper.stripCapletVols(data.capMaturities, data.capVols, data.forwards, config);
        double err = repriceError(new BachelierModel(), result, data, 1, 0.0);
        assertTrue("full dirty data has residual", err > 1.0e-4 && err < 2.0e-2);
    }

    private static void openGammaBlackTests() {
        double[][] capMats = {
                {12, 24, 36, 60, 84, 120},
                {12, 24, 36, 48, 60, 84, 120},
                {12, 24, 36, 48, 60, 84, 120}
        };
        double[][] capVols = {
                {0.7175, 0.7781, 0.8366, 0.8101, 0.7633, 0.7140},
                {0.9893, 0.8376, 0.7274, 0.5983, 0.5169, 0.4083, 0.3375},
                {1.0476, 0.8411, 0.7072, 0.5885, 0.5006, 0.3856, 0.3135}
        };
        double[] strikes = {0.005, 0.04, 0.06};

        for (int row = 0; row < strikes.length; row++) {
            MarketData data = openGammaMarketData(capMats[row], capVols[row]);
            StripConfig config = StripConfig.builder()
                    .model(new BlackModel())
                    .strike(strikes[row])
                    .capletFrequencyMonths(3)
                    .rateType(RateType.FORWARD)
                    .discountFactors(data.discountFactors)
                    .interpolationMethod(InterpolationMethod.LINEAR)
                    .knotPlacement(KnotPlacement.MIDPOINTS)
                    .logSpace(true)
                    .solver(Solver.GLOBAL)
                    .build();
            StripResult result = CapVolStripper.stripCapletVols(data.capMaturities, data.capVols, data.forwards, config);
            double err = repriceError(new BlackModel(), result, data, 3, strikes[row]);
            assertTrue("OpenGamma Black row " + row + " reprices", err < 1.0e-8);
                assertTrue("OpenGamma Black row " + row + " has positive vols",
                    Arrays.stream(result.capletVols()).min().orElseThrow() > 0.0);
        }
    }

        private static void openGammaNormalEquivalentTests() {
        double[] capMaturities = {12, 24, 36, 48, 60, 84, 120};
        double[] capVols = {
            0.014345934996892178, 0.013026457768347524, 0.012872814762320993,
            0.012511992391841475, 0.012411501522441871, 0.011783024185340241,
            0.010987968181224094
        };
        double strike = 0.04;
        MarketData data = openGammaMarketData(capMaturities, capVols);
        StripConfig config = StripConfig.builder()
            .model(new BachelierModel())
            .strike(strike)
            .capletFrequencyMonths(3)
            .rateType(RateType.FORWARD)
            .discountFactors(data.discountFactors)
            .interpolationMethod(InterpolationMethod.LINEAR)
            .knotPlacement(KnotPlacement.MIDPOINTS)
            .solver(Solver.GLOBAL)
            .build();
        StripResult result = CapVolStripper.stripCapletVols(data.capMaturities, data.capVols, data.forwards, config);
        double err = repriceError(new BachelierModel(), result, data, 3, strike);
        assertTrue("OpenGamma normal-equivalent row reprices", err < 1.0e-8);
        assertTrue("OpenGamma normal-equivalent row has positive vols",
            Arrays.stream(result.capletVols()).min().orElseThrow() > 0.0);
        }

    private static void hymanInterpolationIsNonNegative() {
        double[] t = {1.0, 2.0, 5.0, 10.0};
        double[] v = {2.0, 0.0, 3.0, 1.0};
        for (int i = 10; i <= 100; i++) {
            double x = i / 10.0;
            assertTrue("hyman non-negative at " + x, Interpolators.hymanNonNegative(t, v, x) >= -1.0e-14);
        }
    }

    private static void impliedVolRoundTrips() {
        BachelierModel bachelier = new BachelierModel();
        double normalVol = 0.0065;
        double normalPrice = bachelier.capletPrice(normalVol, 2.0, 0.25, 0.97, 0.028, 0.031);
        assertNear("Bachelier implied vol round trip", normalVol,
            CapVolStripper.bachelierImpliedVol(normalPrice, 2.0, 0.25, 0.97, 0.028, 0.031), 1.0e-9);

        double tinyNormal = CapVolStripper.bachelierImpliedVol(
                Math.exp(-100.0) * 1.0e-14, 1.0, 1.0, 1.0, 0.0, 1.0e-14);
        assertTrue("tiny Bachelier tail returns finite positive vol",
                tinyNormal > 0.0 && tinyNormal < 1.0e-14 && Double.isFinite(tinyNormal));

        BlackModel black = new BlackModel();
        double[][] cases = {
                {0.22, 1.5, 0.25, 0.99, 0.035, 0.03},
                {0.45, 7.0, 0.5, 0.82, 0.015, 0.05},
                {0.08, 0.25, 0.25, 0.998, 0.04, 0.04}
        };
        for (double[] row : cases) {
            double sigma = row[0];
            double price = black.capletPrice(sigma, row[1], row[2], row[3], row[4], row[5]);
            double implied = CapVolStripper.blackImpliedVol(price, row[1], row[2], row[3], row[4], row[5]);
            assertNear("FlashIV Black implied vol round trip", sigma, implied, 2.0e-6);
        }
    }

    private static void extraInterpolatorsStayFiniteAndMonotone() {
        double[] t = {1.0, 2.0, 4.0, 7.0};
        double[] v = {0.10, 0.14, 0.20, 0.22};
        Interpolation[] monotoneInterpolations = {
                Interpolators::monotoneCubic,
                Interpolators::hymanMonotone,
                Interpolators::cubicHyman,
                Interpolators::huynhRational,
                Interpolators::huynhHarmonic
        };
        for (Interpolation interpolation : monotoneInterpolations) {
            double previous = interpolation.interpolate(t, v, t[0]);
            for (int i = 11; i <= 70; i++) {
                double x = i / 10.0;
                double y = interpolation.interpolate(t, v, x);
                assertTrue("extra monotone interpolation finite", Double.isFinite(y));
                assertTrue("extra monotone interpolation bounded", y >= v[0] - 1.0e-12 && y <= v[v.length - 1] + 1.0e-12);
                assertTrue("extra monotone interpolation nondecreasing", y + 1.0e-12 >= previous);
                previous = y;
            }
        }

        for (int i = 10; i <= 70; i++) {
            double y = Interpolators.tension(t, v, i / 10.0, 1.5);
            assertTrue("tension interpolation finite", Double.isFinite(y));
            assertTrue("tension interpolation locally bounded", y >= 0.08 && y <= 0.24);
        }
    }

    private static void priceStripperRecoversFlatNormalVols() {
        double[] capMaturities = {2, 3, 4, 5, 6};
        double[] capVols = new double[capMaturities.length];
        Arrays.fill(capVols, 0.0075);
        double[] forwards = {0.018, 0.019, 0.020, 0.021, 0.022};
        double[] discountFactors = {0.999, 0.998, 0.997, 0.996, 0.995};

        PriceStripConfig timeValueConfig = PriceStripConfig.builder()
                .model(new BachelierModel())
                .strike(0.020)
                .capletFrequencyMonths(1)
                .rateType(RateType.FORWARD)
                .discountFactors(discountFactors)
                .priceInterpolationMethod(PriceInterpolationMethod.HYMAN_MONOTONE)
                .target(PriceStripTarget.TIME_VALUE)
                .build();
        PriceStripResult timeValueResult = CapVolStripper.stripCapletVolsFromPrices(
                capMaturities, capVols, forwards, timeValueConfig);
        for (double vol : timeValueResult.capletVols()) {
            assertNear("time-value price stripper flat normal vol", 0.0075, vol, 1.0e-8);
        }
        assertTrue("time-value price stripper keeps all quotes", timeValueResult.removedQuoteIndices().length == 0);

        PriceStripConfig priceConfig = PriceStripConfig.builder()
                .model(new BachelierModel())
                .strike(0.020)
                .capletFrequencyMonths(1)
                .rateType(RateType.FORWARD)
                .discountFactors(discountFactors)
                .priceInterpolationMethod(PriceInterpolationMethod.LINEAR)
                .target(PriceStripTarget.PRICE)
                .build();
        PriceStripResult priceResult = CapVolStripper.stripCapletVolsFromPrices(
                capMaturities, capVols, forwards, priceConfig);
        for (double vol : priceResult.capletVols()) {
            assertNear("price stripper flat normal vol", 0.0075, vol, 1.0e-8);
        }
    }

    private static void solverDiagnosticsAreExposed() {
        double[] capMaturities = {12, 24, 36, 48};
        double[] capVols = {0.20, 0.20, 0.20, 0.20};
        double[] forwards = new double[7];
        double[] discountFactors = new double[7];
        Arrays.fill(forwards, 0.035);
        Arrays.fill(discountFactors, 0.98);
        StripConfig config = StripConfig.builder()
                .model(new BlackModel())
                .strike(0.03)
                .capletFrequencyMonths(6)
                .rateType(RateType.FORWARD)
                .discountFactors(discountFactors)
                .interpolationMethod(InterpolationMethod.FLAT)
                .knotPlacement(KnotPlacement.AT_MATURITIES)
                .solver(Solver.AUTO)
                .build();
        StripResult result = CapVolStripper.stripCapletVols(capMaturities, capVols, forwards, config);
        StripDiagnostics diagnostics = result.diagnostics();
        assertTrue("diagnostics expose solver name", diagnostics.solverName().equals("sequential bootstrap"));
        assertTrue("diagnostics converged", diagnostics.converged());
        assertTrue("diagnostics residual", diagnostics.maxRelativeResidual() < 1.0e-12);
        assertTrue("diagnostics iteration count", diagnostics.iterations() >= 0);
    }

    private static MarketData bachMarketData(boolean full) {
        double[] zrMonths = {0.0, 1.0, 2.0, 3.0, 6.0, 12.0, 24.0, 36.0, 60.0, 84.0, 120.0, 180.0, 240.0, 360.0};
        double[] zrRates = {0.05, 0.06, 0.20, 0.35, 0.69, 1.01, 1.44, 1.62, 1.71, 1.81, 1.83, 2.04, 2.25, 2.17};
        for (int i = 0; i < zrRates.length; i++) {
            zrRates[i] /= 100.0;
        }
        double[] pillarTimes = Arrays.stream(zrMonths).map(m -> m / 12.0).toArray();
        double[] pillarDfs = new double[zrRates.length];
        for (int i = 0; i < zrRates.length; i++) {
            pillarDfs[i] = Math.exp(-zrRates[i] * pillarTimes[i]);
        }
        DiscountCurve discountCurve = new DiscountCurve(pillarTimes, pillarDfs);

        int nCaplets = (int) Math.round(BACH_CAP_MATS[BACH_CAP_MATS.length - 1]) - 1;
        double[] fixTimes = new double[nCaplets];
        double[] payTimes = new double[nCaplets];
        for (int i = 0; i < nCaplets; i++) {
            fixTimes[i] = (i + 1.0) / 12.0;
            payTimes[i] = fixTimes[i] + BACH_TAU;
        }
        double[] discountFactors = discountCurve.discountFactors(payTimes);

        double[] liborBasisBp = {10.9, 10.5, 10.5, 10.5, 11.0, 11.4, 11.448, 11.448, 11.448, 11.448, 11.448, 11.448, 11.448, 11.448};
        double[] liborZrMonths = {0.0, 1.0, 2.0, 3.0, 6.0, 12.0, 18.0, 24.0, 36.0, 60.0, 84.0, 120.0, 180.0, 360.0};
        double[] oisZrAtLibor = {0.0005, 0.0006, 0.0020, 0.0035, 0.0069, 0.0101,
                0.5 * (0.0101 + 0.0144), 0.0144, 0.0162, 0.0171, 0.0181, 0.0183, 0.0204, 0.0217};
        double[] liborTimes = Arrays.stream(liborZrMonths).map(m -> m / 12.0).toArray();
        double[] liborDfs = new double[liborTimes.length];
        for (int i = 0; i < liborTimes.length; i++) {
            double rate = oisZrAtLibor[i] + liborBasisBp[i] / 10_000.0;
            liborDfs[i] = Math.exp(-rate * liborTimes[i]);
        }
        DiscountCurve liborCurve = new DiscountCurve(liborTimes, liborDfs);
        double[] fixDfs = liborCurve.discountFactors(fixTimes);
        double[] payDfs = liborCurve.discountFactors(payTimes);
        double[] forwards = new double[nCaplets];
        for (int i = 0; i < nCaplets; i++) {
            forwards[i] = (fixDfs[i] / payDfs[i] - 1.0) / BACH_TAU * 10_000.0;
        }

        if (full) {
            return new MarketData(BACH_CAP_MATS.clone(), BACH_CAP_VOLS.clone(), forwards, discountFactors);
        }
        int[] keep = {0, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12};
        double[] cleanMats = new double[keep.length];
        double[] cleanVols = new double[keep.length];
        for (int i = 0; i < keep.length; i++) {
            cleanMats[i] = BACH_CAP_MATS[keep[i]];
            cleanVols[i] = BACH_CAP_VOLS[keep[i]];
        }
        int nClean = (int) Math.round(cleanMats[cleanMats.length - 1]) - 1;
        return new MarketData(cleanMats, cleanVols,
                Arrays.copyOf(forwards, nClean), Arrays.copyOf(discountFactors, nClean));
    }

    private static MarketData openGammaMarketData(double[] capMaturities, double[] capVols) {
        double[] discTimes = {0.003, 0.088, 0.173, 0.255, 0.345, 0.425, 0.507, 0.759,
                1.005, 2.005, 3.010, 4.005, 5.005, 10.005};
        double[] discRates = {0.00213, 0.00144, 0.00145, 0.00135, 0.00134, 0.00133,
                0.00128, 0.00132, 0.00139, 0.00173, 0.00254, 0.00410, 0.00629, 0.01700};
        double[] idxTimes = {0.044, 0.088, 0.173, 0.255, 0.507, 0.759, 1.005,
                2.014, 3.010, 4.005, 5.005, 6.005, 7.018, 8.011,
                9.008, 10.008, 15.007, 20.008, 25.011, 30.014};
        double[] idxRates = {0.00184, 0.00201, 0.00241, 0.00281, 0.00295, 0.00310,
                0.00320, 0.00378, 0.00483, 0.00655, 0.00878, 0.01125,
                0.01363, 0.01576, 0.01768, 0.01942, 0.02540, 0.02825,
                0.02986, 0.03112};
        DiscountCurve discCurve = new DiscountCurve(discTimes, zeroToDfs(discTimes, discRates));
        DiscountCurve idxCurve = new DiscountCurve(idxTimes, zeroToDfs(idxTimes, idxRates));

        int nCaplets = (int) Math.round(capMaturities[capMaturities.length - 1] / 3.0) - 1;
        double[] dfs = new double[nCaplets];
        double[] forwards = new double[nCaplets];
        for (int i = 0; i < nCaplets; i++) {
            double fix = (i + 1.0) * 3.0 / 12.0;
            double pay = fix + 0.25;
            dfs[i] = discCurve.discountFactor(pay);
            forwards[i] = (idxCurve.discountFactor(fix) / idxCurve.discountFactor(pay) - 1.0) / 0.25;
        }
        return new MarketData(capMaturities.clone(), capVols.clone(), forwards, dfs);
    }

    private static double[] zeroToDfs(double[] times, double[] rates) {
        double[] dfs = new double[times.length];
        for (int i = 0; i < times.length; i++) {
            dfs[i] = Math.exp(-rates[i] * times[i]);
        }
        return dfs;
    }

    private static double repriceError(VolModel model, StripResult result, MarketData data, int frequency, double strike) {
        double[] expiries = result.capletExpiries();
        double[] vols = result.capletVols();
        double tau = frequency / 12.0;
        double maxErr = 0.0;
        for (int q = 0; q < data.capMaturities.length; q++) {
            int idx = (int) Math.round(data.capMaturities[q] / frequency) - 1;
            double market = 0.0;
            double modelPrice = 0.0;
            for (int i = 0; i < idx; i++) {
                market += model.capletPrice(data.capVols[q], expiries[i], tau, data.discountFactors[i], data.forwards[i], strike);
                modelPrice += model.capletPrice(vols[i], expiries[i], tau, data.discountFactors[i], data.forwards[i], strike);
            }
            maxErr = Math.max(maxErr, Math.abs(modelPrice - market) / (Math.abs(market) + 1.0e-30));
        }
        return maxErr;
    }

    private static void assertNear(String label, double expected, double actual, double tolerance) {
        if (Math.abs(expected - actual) > tolerance) {
            throw new AssertionError(label + ": expected " + expected + ", got " + actual);
        }
    }

    private static void assertTrue(String label, boolean condition) {
        if (!condition) {
            throw new AssertionError(label);
        }
    }

    private record MarketData(double[] capMaturities, double[] capVols, double[] forwards, double[] discountFactors) {
    }
}
