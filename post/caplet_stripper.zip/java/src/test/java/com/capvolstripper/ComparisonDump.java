package com.capvolstripper;

import java.util.Arrays;
import java.util.Locale;

public final class ComparisonDump {
    private static final double[] BACH_CAP_MATS = {2, 3, 4, 5, 6, 9, 12, 24, 36, 60, 84, 120, 180};
    private static final double[] BACH_CAP_VOLS = {79.30, 111.83, 93.10, 91.83, 94.51, 102.25, 99.86, 60.42, 109.15, 96.34, 84.37, 76.90, 76.34};
    private static final double BACH_TAU = 1.0 / 12.0;

    private ComparisonDump() {
    }

    public static void main(String[] args) {
        Locale.setDefault(Locale.ROOT);
        dumpBachelier("bach_clean_linear_mid", false, InterpolationMethod.LINEAR, false, 0.0);
        dumpBachelier("bach_clean_hyman_mid", false, InterpolationMethod.HYMAN_NON_NEGATIVE, false, 0.0);
        dumpBachelier("bach_clean_cubic_log_mid", false, InterpolationMethod.CUBIC_SPLINE, true, 0.0);
        dumpBachelier("bach_full_linear_mid", true, InterpolationMethod.LINEAR, false, 0.0);
        dumpBlackOpenGamma("black_4pct_linear_log_mid");
    }

    private static void dumpBachelier(String label, boolean full, InterpolationMethod method, boolean logSpace, double volFloor) {
        MarketData data = bachMarketData(full);
        StripConfig config = StripConfig.builder()
                .model(new BachelierModel())
                .capletFrequencyMonths(1)
                .rateType(RateType.FORWARD)
                .discountFactors(data.discountFactors)
                .interpolationMethod(method)
                .knotPlacement(KnotPlacement.MIDPOINTS)
                .logSpace(logSpace)
                .volFloor(volFloor)
                .solver(Solver.GLOBAL)
                .build();
        StripResult result = CapVolStripper.stripCapletVols(data.capMaturities, data.capVols, data.forwards, config);
        dump(label, result);
    }

    private static void dumpBlackOpenGamma(String label) {
        double[] capMats = {12, 24, 36, 48, 60, 84, 120};
        double[] capVols = {0.9893, 0.8376, 0.7274, 0.5983, 0.5169, 0.4083, 0.3375};
        MarketData data = openGammaMarketData(capMats, capVols);
        StripConfig config = StripConfig.builder()
                .model(new BlackModel())
                .strike(0.04)
                .capletFrequencyMonths(3)
                .rateType(RateType.FORWARD)
                .discountFactors(data.discountFactors)
                .interpolationMethod(InterpolationMethod.LINEAR)
                .knotPlacement(KnotPlacement.MIDPOINTS)
                .logSpace(true)
                .solver(Solver.GLOBAL)
                .build();
        StripResult result = CapVolStripper.stripCapletVols(data.capMaturities, data.capVols, data.forwards, config);
        dump(label, result);
    }

    private static void dump(String label, StripResult result) {
        System.out.println("CASE " + label);
        System.out.println("expiries " + Arrays.toString(result.capletExpiries()));
        System.out.println("capletVols " + Arrays.toString(result.capletVols()));
        System.out.println("nodeVols " + Arrays.toString(result.nodeVols()));
    }

    private static MarketData bachMarketData(boolean full) {
        double[] zrMonths = {0.0, 1.0, 2.0, 3.0, 6.0, 12.0, 24.0, 36.0, 60.0, 84.0, 120.0, 180.0, 240.0, 360.0};
        double[] zrRates = {0.05, 0.06, 0.20, 0.35, 0.69, 1.01, 1.44, 1.62, 1.71, 1.81, 1.83, 2.04, 2.25, 2.17};
        for (int i = 0; i < zrRates.length; i++) {
            zrRates[i] /= 100.0;
        }
        double[] pillarTimes = Arrays.stream(zrMonths).map(m -> m / 12.0).toArray();
        double[] pillarDfs = new double[zrRates.length];
        for (int i = 0; i < zrRates.length; i++) {
            pillarDfs[i] = Math.exp(-zrRates[i] * pillarTimes[i]);
        }
        DiscountCurve discountCurve = new DiscountCurve(pillarTimes, pillarDfs);

        int nCaplets = (int) Math.round(BACH_CAP_MATS[BACH_CAP_MATS.length - 1]) - 1;
        double[] fixTimes = new double[nCaplets];
        double[] payTimes = new double[nCaplets];
        for (int i = 0; i < nCaplets; i++) {
            fixTimes[i] = (i + 1.0) / 12.0;
            payTimes[i] = fixTimes[i] + BACH_TAU;
        }
        double[] discountFactors = discountCurve.discountFactors(payTimes);

        double[] liborBasisBp = {10.9, 10.5, 10.5, 10.5, 11.0, 11.4, 11.448, 11.448, 11.448, 11.448, 11.448, 11.448, 11.448, 11.448};
        double[] liborZrMonths = {0.0, 1.0, 2.0, 3.0, 6.0, 12.0, 18.0, 24.0, 36.0, 60.0, 84.0, 120.0, 180.0, 360.0};
        double[] oisZrAtLibor = {0.0005, 0.0006, 0.0020, 0.0035, 0.0069, 0.0101,
                0.5 * (0.0101 + 0.0144), 0.0144, 0.0162, 0.0171, 0.0181, 0.0183, 0.0204, 0.0217};
        double[] liborTimes = Arrays.stream(liborZrMonths).map(m -> m / 12.0).toArray();
        double[] liborDfs = new double[liborTimes.length];
        for (int i = 0; i < liborTimes.length; i++) {
            double rate = oisZrAtLibor[i] + liborBasisBp[i] / 10_000.0;
            liborDfs[i] = Math.exp(-rate * liborTimes[i]);
        }
        DiscountCurve liborCurve = new DiscountCurve(liborTimes, liborDfs);
        double[] fixDfs = liborCurve.discountFactors(fixTimes);
        double[] payDfs = liborCurve.discountFactors(payTimes);
        double[] forwards = new double[nCaplets];
        for (int i = 0; i < nCaplets; i++) {
            forwards[i] = (fixDfs[i] / payDfs[i] - 1.0) / BACH_TAU * 10_000.0;
        }

        if (full) {
            return new MarketData(BACH_CAP_MATS.clone(), BACH_CAP_VOLS.clone(), forwards, discountFactors);
        }
        int[] keep = {0, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12};
        double[] cleanMats = new double[keep.length];
        double[] cleanVols = new double[keep.length];
        for (int i = 0; i < keep.length; i++) {
            cleanMats[i] = BACH_CAP_MATS[keep[i]];
            cleanVols[i] = BACH_CAP_VOLS[keep[i]];
        }
        int nClean = (int) Math.round(cleanMats[cleanMats.length - 1]) - 1;
        return new MarketData(cleanMats, cleanVols,
                Arrays.copyOf(forwards, nClean), Arrays.copyOf(discountFactors, nClean));
    }

    private static MarketData openGammaMarketData(double[] capMaturities, double[] capVols) {
        double[] discTimes = {0.003, 0.088, 0.173, 0.255, 0.345, 0.425, 0.507, 0.759,
                1.005, 2.005, 3.010, 4.005, 5.005, 10.005};
        double[] discRates = {0.00213, 0.00144, 0.00145, 0.00135, 0.00134, 0.00133,
                0.00128, 0.00132, 0.00139, 0.00173, 0.00254, 0.00410, 0.00629, 0.01700};
        double[] idxTimes = {0.044, 0.088, 0.173, 0.255, 0.507, 0.759, 1.005,
                2.014, 3.010, 4.005, 5.005, 6.005, 7.018, 8.011,
                9.008, 10.008, 15.007, 20.008, 25.011, 30.014};
        double[] idxRates = {0.00184, 0.00201, 0.00241, 0.00281, 0.00295, 0.00310,
                0.00320, 0.00378, 0.00483, 0.00655, 0.00878, 0.01125,
                0.01363, 0.01576, 0.01768, 0.01942, 0.02540, 0.02825,
                0.02986, 0.03112};
        DiscountCurve discCurve = new DiscountCurve(discTimes, zeroToDfs(discTimes, discRates));
        DiscountCurve idxCurve = new DiscountCurve(idxTimes, zeroToDfs(idxTimes, idxRates));

        int nCaplets = (int) Math.round(capMaturities[capMaturities.length - 1] / 3.0) - 1;
        double[] dfs = new double[nCaplets];
        double[] forwards = new double[nCaplets];
        for (int i = 0; i < nCaplets; i++) {
            double fix = (i + 1.0) * 3.0 / 12.0;
            double pay = fix + 0.25;
            dfs[i] = discCurve.discountFactor(pay);
            forwards[i] = (idxCurve.discountFactor(fix) / idxCurve.discountFactor(pay) - 1.0) / 0.25;
        }
        return new MarketData(capMaturities.clone(), capVols.clone(), forwards, dfs);
    }

    private static double[] zeroToDfs(double[] times, double[] rates) {
        double[] dfs = new double[times.length];
        for (int i = 0; i < times.length; i++) {
            dfs[i] = Math.exp(-rates[i] * times[i]);
        }
        return dfs;
    }

    private record MarketData(double[] capMaturities, double[] capVols, double[] forwards, double[] discountFactors) {
    }
}
