#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
commons_numbers_version=1.3
classpath=""
for artifact in commons-numbers-core commons-numbers-fraction commons-numbers-gamma; do
	jar="build/lib/${artifact}-${commons_numbers_version}.jar"
	if [[ -f "$jar" ]]; then
		classpath="${classpath:+$classpath:}$jar"
	fi
done

rm -rf build/classes
mkdir -p build/classes
find src/main/java src/test/java -name '*.java' | sort > build/sources.txt
javac_args=(--release 21 -d build/classes)
java_classpath="build/classes"
if [[ -n "$classpath" ]]; then
	javac_args+=(-cp "$classpath")
	java_classpath="build/classes:$classpath"
fi
javac "${javac_args[@]}" @build/sources.txt
java -cp "$java_classpath" com.capvolstripper.CapVolStripperTests
