# Cap Vol Stripper Java Port

This directory contains a Java 21 port of the core cap/caplet volatility stripping code from the Julia implementation in the repository root. It focuses on pricing, stripping, interpolation, and regression tests; plotting and exploratory Julia scripts are intentionally not ported.

## Quick Start

From the repository root:

```bash
bash java/run-tests.sh
```

The script compiles all main and test sources with `javac --release 21` into `java/build/classes`, then runs `com.capvolstripper.CapVolStripperTests`.

A Maven descriptor is also provided:

```bash
cd java
mvn test
```

Maven is not required by `run-tests.sh`, but it is the preferred build path when Maven is available.

## Requirements

- Java 21 or newer.
- Bash for `run-tests.sh`.
- Maven is optional.

The Maven build declares Apache Commons Numbers `1.3` dependencies so `NormalDistribution` can use `org.apache.commons.numbers.gamma.Erfc` for the normal CDF. The lightweight `run-tests.sh` runner does not download dependencies; if the Commons jars are present under `java/build/lib`, it adds them to the classpath. Otherwise, `NormalDistribution` falls back to its local erfc approximation so the no-Maven workflow remains usable.

Expected optional jars:

```text
java/build/lib/commons-numbers-core-1.3.jar
java/build/lib/commons-numbers-fraction-1.3.jar
java/build/lib/commons-numbers-gamma-1.3.jar
```

## Public API

The main entry point is `CapVolStripper.stripCapletVols`:

```java
StripConfig config = StripConfig.builder()
        .model(new BachelierModel())
        .strike(0.0)
        .capletFrequencyMonths(1)
        .rateType(RateType.FORWARD)
        .discountFactors(discountFactors)
        .interpolationMethod(InterpolationMethod.LINEAR)
        .knotPlacement(KnotPlacement.MIDPOINTS)
        .solver(Solver.GLOBAL)
        .build();

StripResult result = CapVolStripper.stripCapletVols(
        capMaturitiesMonths,
        capVols,
        forwardRates,
        config);
```

`StripResult` contains:

- `capletExpiries()`: caplet expiry times in years.
- `capletVols()`: stripped caplet volatilities.
- `nodeVols()`: solved node volatilities.
- `diagnostics()`: solver name, convergence flag, iteration count, residual, objective, max step, and convergence reason.

Robust implied-volatility inversion is also exposed directly:

```java
double normalVol = CapVolStripper.bachelierImpliedVol(
        price, expiry, accrual, discountFactor, forward, strike);

double blackVol = CapVolStripper.blackImpliedVol(
        price, expiry, accrual, discountFactor, forward, strike);
```

The price/time-value stripping path uses `PriceStripConfig`:

```java
PriceStripConfig priceConfig = PriceStripConfig.builder()
        .model(new BachelierModel())
        .strike(strike)
        .capletFrequencyMonths(1)
        .rateType(RateType.FORWARD)
        .discountFactors(discountFactors)
        .priceInterpolationMethod(PriceInterpolationMethod.HYMAN_MONOTONE)
        .target(PriceStripTarget.TIME_VALUE)
        .build();

PriceStripResult priceResult = CapVolStripper.stripCapletVolsFromPrices(
        capMaturitiesMonths,
        capVols,
        forwardRates,
        priceConfig);
```

All public array-returning APIs make defensive copies.

## Main Components

- `CapVolStripper`: thin facade that builds a stripping problem, chooses a solver, and returns a result.
- `StripConfig`: immutable builder-based configuration.
- `StripMarketData`: cap maturities, cap vols, forwards, and optional discount factors.
- `CapletSchedule`: caplet months, expiries, accruals, cap quote indices, and node times.
- `StripProblem`: prepared numerical problem shared by solvers.
- `VolModel`, `BachelierModel`, `BlackModel`: pricing model strategy interface and implementations.
- `ImpliedVolatility`, `FlashBlackImpliedVolatility`: Bachelier/normal and Black/lognormal implied-volatility inversion.
- `InterpolationMethod`, `Interpolation`, `Interpolators`, `NodeVolatilityCurve`: interpolation selection and curve evaluation.
- `PriceStripConfig`, `PriceStripTarget`, `PriceInterpolationMethod`, `PriceStripResult`: price/time-value stripping API.
- `StripSolver`, `SequentialBootstrapSolver`, `GlobalNewtonSolver`: solver strategy interface and implementations.
- `DiscountCurve`: log-discount-factor interpolation helper for tests and examples.
- `LinearAlgebra`, `NormalDistribution`, `Validation`: small numerical and validation utilities.

The design keeps object orientation at setup and strategy boundaries while preserving primitive `double[]` loops inside numerical hot paths.

## Supported Features

Pricing models:

- Bachelier/normal caplet pricing.
- Black/lognormal caplet pricing.
- Bachelier implied volatility via the Le Floc'h Chebyshev approximation.
- Black implied volatility via a FlashIV-based total-volatility solver.

Stripping setup:

- Forward-looking and backward-looking caplet schedules.
- Optional discount factors, defaulting to `1.0` if omitted.
- Strike configuration.
- Vol floors.
- Log-space stripping/interpolation.

Knot placement:

- At quoted maturities.
- Midpoints between quoted maturities.

Interpolation methods:

- Flat.
- Linear.
- Cubic spline.
- Monotone cubic.
- Tension spline.
- Hyman non-negative.
- Hyman monotone.
- Huynh rational.
- Huynh harmonic.
- Cubic Hyman.
- Flat-linear.
- Flat-smooth.

Price/time-value stripping:

- Direct cap-price interpolation.
- Cumulative time-value interpolation.
- Optional log-time-value interpolation.
- Optional quote removal for non-monotone cumulative time-value inputs.

Solvers:

- Sequential bootstrap for triangular at-maturity setups.
- Global damped Newton least-squares solve for coupled midpoint/global setups.
- `Solver.AUTO`, which uses sequential bootstrap at maturities and global Newton for midpoint knots.
- Solver diagnostics on every `StripResult`.

## Tests

The plain Java test runner covers:

- Bachelier and Black pricing smoke tests.
- QuantLib-style flat Black term-vol recovery.
- QuantLib-style non-flat Black term-vol repricing.
- Clean Bachelier midpoint stripping with linear, Hyman, and cubic log-space interpolation.
- Dirty Bachelier data behavior where exact repricing is not expected.
- OpenGamma/Strata-style Black cap data for several strikes.
- OpenGamma/Strata-style normal-equivalent cap data.
- Hyman non-negative interpolation.
- Bachelier and FlashIV Black implied-volatility round trips.
- Additional interpolation kernels on monotone data.
- Price and time-value stripping recovery on aligned caplet quotes.
- Solver diagnostics exposure.

Run:

```bash
bash java/run-tests.sh
```

The repository root also contains a Julia comparison test:

```bash
julia --project=. test_java_port_compare.jl
```

It compiles/runs the Java code and compares selected Java stripping outputs against the Julia implementation.

## Java vs Julia Numeric Agreement

The Java port matches Julia closely on the comparison cases. Typical maximum differences observed are:

- Clean Bachelier stripped vols: about `3e-6` bp.
- OpenGamma Black stripped vols: about `4e-8`.
- Dirty overdetermined Bachelier caplet vols: about `5e-4` bp.
- Dirty overdetermined Bachelier node vols: about `0.05` bp.

The dirty case is less stable at the node level because it is a coupled least-squares fit to inconsistent market data. Small differences in finite differences, linear algebra, normal CDF evaluation, and line-search path can move node values more than final caplet vols or repriced cap prices.


## Reference Data

The test data is based on local Julia examples plus public caplet stripping references:

- OpenGamma/Strata-style USD 3M cap/floor stripping data, including Black cap vol rows, normal-equivalent cap vol rows, and curve data.
- QuantLib optionlet-stripper style flat term-vol recovery and non-flat ATM term-vol repricing behavior.

The Java tests use these references as regression-style checks without depending on external libraries at runtime.
