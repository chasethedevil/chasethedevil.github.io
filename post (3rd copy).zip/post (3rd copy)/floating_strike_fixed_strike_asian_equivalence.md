+++
categories = ["quant"]
date = "2017-01-18T09:55:32+01:00"
description = ""
keywords = ["quant"]
title = "Equivalence between floating-strike and fixed-strike Asian options"
+++
Many papers present formulae to price Asian options in the Black-Scholes world only for the fixed strike Asian case, that is
a contract that pays \\( \max(A-K,0)\\) at maturity \\(T\\) where \\(A = \sum\_{i=0}^{n-1} w\_i S(t\_i) \\) is the Asian average.

More generally, this can be seen as the payoff of a Basket option where the underlyings are just the same asset but at different times.
And any Basket option formula can actually be used to price fixed-strike Asian options by letting the correlation correspond to the correlation between the asset at the averaging times
and the variances correspond to the variance at each averaging time. The basket approach allows then naturally for a term-structure of rates, dividends and volatilities.

In order to price floating-strike Asian options paying  \\( \max(S-kA,0)\\) at maturity \\(T\\) where \\(k\\) is a percent strike,
we can use a change of measure to express it as the price of a fixed-strike Asian. This equivalence is presented in several paperS: it is somewhat hidden in 
Andreasen ["The pricing of discretely sampled Asian and lookback options: a change of numeraire approach"](https://www.researchgate.net/profile/Jesper_Andreasen2/publication/247953507_The_Pricing_of_Discretely_Sampled_Asian_and_Lookback_Options_A_Change_of_Numeraire_Approach/links/5445184a0cf2091108a4d9b5.pdf), more explicit in Eberlein and Papapantoleon
["Equivalence of floating and fixed strike Asian and lookback options"](http://www.sciencedirect.com/science/article/pii/S0304414904001061)
or Henderson et al. ["Bounds for in-progress floating-strike Asian options using symmetry"](https://pdfs.semanticscholar.org/7aca/df634e96744a5ff58a6a29f619b8438aabae.pdf). 
None of those really consider the simple case of Black-Scholes with a term-structure of rates, dividends and volatilities. 

 We have:
$$
	V\_{\textsf{floating}}(\eta,S\_0,k,\bar{\sigma}\_i^2 t\_i, C(0,t\_i), B(0,T)) =\\\\
	\quad k V\_{\textsf{fixed}}\left(-\eta,S\_0, \frac{S\_0}{k},\bar{\sigma}^2(T) T-\bar{\sigma}\_i^2 t\_i,\frac{C(0,t\_i)}{C(0,T)},B(0,T)C(0,T) \right)
$$
	where \\(\eta = \pm 1\\) for a call (respectively a put), \\(\bar{\sigma}\_i\\) are the Vanilla options implied volatilities at the averaging times \\(t\_i\\), \\(C(0,t\_i)\\) are the capitalization factors, and \\(B(0,T)\\) is the discount factor.

**Proof:**
	We assume that \\(S\\) follows \\(dS = \mu\_t S dt + \sigma\_t S dW\_t\\). The discount factor \\(B\\) is defined as \\(B(0,T)=e^{-\int\_{0}^T r\_s ds}\\). Let \\(C(0,t) = e^{\int\_{0}^t \mu\_s ds}\\). The process associated to the forward to time \\(t\\) is \\(F\_t=S\_0 C(0,t)M\_t\\) with \\(M\_t = e^{\int\_0^t \sigma\_s dW\_s - \frac{1}{2}\int\_0^t \sigma\_s^2 ds}\\) being a martingale. 
		We have:
$$
V\_{\textsf{floating}}(\eta,S\_0,k,\bar{\sigma}\_i^2 t\_i, C(0,t\_i), B(0,T))\\\\
= B(0,T)\mathbb{E}\left[\max\left(\eta F\_T-\eta k\sum\_{i=0}^{n-1}w\_i F\_{t\_i},0\right)\right]\\\\
= k B(0,T)\mathbb{E}\left[\max\left(\eta\frac{1}{k}F\_T-\eta\sum\_{i=0}^{n-1}w\_i F\_{t\_i},0\right)\right]\\\\
=k B(0,T)C(0,T)\mathbb{E}\left[ M\_T \max\left(\eta\frac{S\_0}{k}-\eta\sum\_{i=0}^{n-1}w\_i S\_0 \frac{C(0,t\_i)M\_{t\_i}}{C(0,T) M\_T },0\right)\right]
$$
We now proceed to a change of measure defined by \\(M\_T\\). Under the new measure \\(\mathbb{Q}^T\\), \\(\bar{W}\_t = W\_t - \int\_0^t \sigma\_s ds\\) is a Brownian motion. \\(\frac{M\_t}{M\_T}\\) under \\(\mathbb{Q}\\) has the same law as \\(\frac{M\_t}{M\_T} e^{-\int\_t^T \sigma\_s^2 ds}\\) under \\(\mathbb{Q}^T\\) or equivalently as 
\\(\bar{M}\_t = e^{\int\_t^T \sigma\_s d\bar{W}\_s - \frac{1}{2}\int\_t^T \sigma\_s^2 ds}\\)  under \\(\mathbb{Q}^T\\). 
Defining \\(\mathbb{E}^T\\) to be the expectation under \\(\mathbb{Q}^T\\), we thus have
$$
V\_{\textsf{floating}}(\eta,S,k,\bar{\sigma}\_i^2 t\_i, C(0,t\_i), B(0,T))\\\\
=k B(0,T)C(0,T)\mathbb{E}^{T}\left[\max\left(\eta\frac{S\_0}{k}-\eta\sum\_{i=0}^{n-1}w\_i S\_0 \frac{C(0,t\_i)}{C(0,T)}\bar{M}\_{t\_i},0\right)\right]\\\\
=k  V\_{\textsf{fixed}}\left(-\eta,S\_0, \frac{S\_0}{k},\bar{\sigma}^2(T) T-\bar{\sigma}\_i^2 t\_i,\frac{C(0,t\_i)}{C(0,T)},B(0,T)C(0,T) \right)
$$
		This concludes the proof.

