+++
title = "GPU computing in Finance"
date = 2012-10-15T16:14:00Z
updated = 2012-12-12T16:13:03Z
tags = ["finance", "quant", "math"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<span class="yj-message">Very interesting presentation from Murex about their GPU computing. Some points were:<br /> - GPU demand for mostly exotics pricing &amp; greeks<br /> - Local vol main model for EQD exotics. Local vol calibrated via PDE approach.<br /> - Markov functional model becoming main model for IRD.<br /> - Use of local regression instead of Longstaff Schwartz (or worse CVA like sim of sim).<br /> - philox RNG from DE Shaw. But the presenter does not seem to know RNGs  very well (recommended Brownian Bridge for Mersenne Twister!).<br /> - An important advantage of GPU is latency. Grid computing only improves throughput but not latency. GPU improves both.<br /> <br /> <a href="http://nvidia.fullviewmedia.com/gtc2010/0923-a7-2032.html" rel="nofollow" target="_blank">http://nvidia.fullviewmedia.com/gtc2010/0923-a7-2032.html</a></span>
