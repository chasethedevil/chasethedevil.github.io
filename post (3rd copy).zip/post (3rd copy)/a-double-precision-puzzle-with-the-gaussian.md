+++
title = "A Double Precision Puzzle with the Gaussian"
date = 2013-03-20T17:50:00Z
updated = 2013-12-27T17:43:08Z
tags = ["quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Some library computes $$e^{-\frac{x^2}{2}}$$ the following way:<br /><span style="font-size: x-small;"><span style="font-family: &quot;Courier New&quot;,Courier,monospace;"><br /></span></span><span style="font-size: x-small;"><span style="font-family: &quot;Courier New&quot;,Courier,monospace;">xsq = fint(x * 1.6) / 1.6;<br />del = (x - xsq) * (x + xsq);<br />result = exp(-xsq * xsq * 0.<span style="font-size: x-small;">5</span>) * exp(-del * <span style="font-size: x-small;">0.5</span>);</span></span><br /><br />where fint(z) computes the floor of z.<br /><br />Basically, x*x is rewritten as xsq*xsq+del. I have seen that trick once before, but I just can't figure out where and why (except that it is probably related to high accuracy issues).<br /><br />The answer is in the next post.
