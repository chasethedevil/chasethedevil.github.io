+++
title = "SVI on top of SABR"
date = 2014-02-20T18:36:00Z
updated = 2014-03-05T12:38:19Z
tags = ["quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Several papers show that the limit for large strikes of <a href="http://www.google.com/url?sa=t&amp;rct=j&amp;q=&amp;esrc=s&amp;source=web&amp;cd=2&amp;cad=rja&amp;ved=0CDUQFjAB&amp;url=http%3A%2F%2Farxiv.org%2Fabs%2F1002.3633&amp;ei=GjUGU5uVIeu00wXEwoCwBw&amp;usg=AFQjCNHvnJ9xYAv60R4GSUbMORRI9_-7Zg&amp;sig2=iqplpcXauJBLJ9DIw71vWA&amp;bvm=bv.61725948,d.d2k">Heston is SVI</a>.<br /><br />Interestingly, I stumbled onto a surface where the Hagan SABR fit was perfect as well as the SVI fit, while the Heston fit was not.<br /><br />Originally, I knew that, on this data, the SVI fit was perfect. Until today, I just never tried to fit a lognormal SABR on the same data. I did a small test with random values of the SABR parameters alpha, rho, nu, and found out that in deed, the SVI fit is always perfect on SABR.<br /><br />Is this just because the Taylor expansion of SVI will match the Taylor expansion of SABR up to the fourth order? It seems that the wings are also not too far off in general so there could be more to it.<br /><br />Gatheral actually devised an SVI formula that uses SABR like variables <a href="http://mfe.baruch.cuny.edu/wp-content/uploads/2013/01/OsakaSVI2012.pdf">in a talk here</a>.<br /><br /><div class="separator" style="clear: both; text-align: center;"><a href="http://3.bp.blogspot.com/-QNLwJnVGPUE/UwY9EwCkZ6I/AAAAAAAAHA4/DP6MstmUqg4/s1600/Screenshot+from+2014-02-20+18:36:06.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" src="http://3.bp.blogspot.com/-QNLwJnVGPUE/UwY9EwCkZ6I/AAAAAAAAHA4/DP6MstmUqg4/s1600/Screenshot+from+2014-02-20+18:36:06.png" height="79" width="320" /></a></div><br /><br />Of course, the reverse is not true. SVI has more parameters and provides in general a better fit than SABR.
