+++
title = "Martin Odersky teaches Scala to the Masses"
date = 2013-09-17T20:11:00Z
updated = 2013-10-07T14:35:27Z
tags = ["scala"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I tried today the <a href="https://www.coursera.org/course/progfun">Scala courses on coursera</a>&nbsp;by the Scala creator, Martin Odersky. I was quite impressed by the quality: I somehow believed Scala to be only a better Java, now I think otherwise. Throughout the course, even though it all sounds very basic, you understand the key concepts of Scala and why functional programming + OO concepts are a natural idea. What's nice about Scala is that it avoids the functional vs OO or even the functional vs procedural debate by allowing both, because both can be important, at different scales. Small details can be (and probably should be) procedural for efficiency, because a processor is a processor, but higher level should probably be more functional (immutable) to be clearer, easier to evolve and more easily parallelized.<br /><br />I recently saw a very good example at work recently of how mutability could be very problematic, with no gain in this case because it was high level (and likely just the result of being too used to OO concepts).<br /><br />I believe it will make my code more functional programming oriented in the future, especially at the high level.
