+++
title = "Java enum Is Evil"
date = 2010-08-12T17:32:00Z
updated = 2010-08-12T17:32:24Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Before Java 1.5, I never really complained about the lack of <b><span class="Apple-style-span" style="font-family: 'Courier New', Courier, monospace;"><span class="Apple-style-span" style="color: purple;">enum</span></span></b> keyword. Sure the <a href="http://java.sun.com/developer/Books/shiftintojava/page1.html">old enum via class pattern</a> was a bit verbose at first (N.B.: Java 1.5 enums can also be verbose once you start adding methods to them). But more importantly, you would often use the table lookup pattern in combination.<br /><br />The problem with Java 1.5 <b><span class="Apple-style-span" style="font-family: 'Courier New', Courier, monospace;"><span class="Apple-style-span" style="color: purple;">enum</span></span></b> is that it is not Object-Oriented. You <u>can't extend</u> an <b><span class="Apple-style-span" style="color: purple;"><span class="Apple-style-span" style="font-family: 'Courier New', Courier, monospace;">enum</span></span></b>, you can't add an element in an existing enum. Many will say "but that's what enum is for, a static list of things". In my experience, &nbsp;the list of things often changes with time, or needs to be extended at one point. Furthermore, most people (including me when I am very lazy) end up writing switch statements on enum values. Enum promotes bad programming practices.<br /><br />Think twice about using enum, this is often not what you want.
