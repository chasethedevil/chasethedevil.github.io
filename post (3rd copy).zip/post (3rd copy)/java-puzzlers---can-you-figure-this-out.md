+++
title = "Java Puzzlers - Can you figure this out?"
date = 2005-09-28T16:04:00Z
updated = 2008-06-16T16:53:04Z
tags = ["book", "java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<iframe src="http://rcm.amazon.com/e/cm?t=michelin-20&o=1&p=8&l=as1&asins=032133678X&fc1=000000&=1&lc1=0000ff&bc1=000000&lt1=_blank&IS2=1&bg1=ffffff&f=ifr" style="width:120px;height:240px;margin:5px" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" align="left"></iframe>The book Java Puzzlers is quite good. I don't think anyone can get every puzzle right. This shows again how you can very easily make someone fail interviews if you ask too silly questions. I suppose that if people were asking those questions they would not expect the right answers, but study the candidate reactions.<br /><br />Here is a sample:<br /><br /><tt>public class DosEquis {<br />&nbsp;&nbsp;public static void main(String[] args) {<br />&nbsp;&nbsp;&nbsp;&nbsp;char x = 'X';<br />&nbsp;&nbsp;&nbsp;&nbsp;int i = 0;<br />&nbsp;&nbsp;&nbsp;&nbsp;System.out.print(true ? x : 0);<br />&nbsp;&nbsp;&nbsp;&nbsp;System.out.print(false ? i : x);<br />&nbsp;&nbsp;}<br />} </tt><br /><br />This will output "X88". Obviously this is not good code, which is precisely one of the book objectives: to show how bad some practices can be. But at the same time you learn a bit more about the Java language and its possibilities. In the latter chapters they have more interesting puzzles.<br /><br /><span class="technoratitag">Tags: <a href="http://del.icio.us/tag/java" rel="tag">java</a>, <a href="http://del.icio.us/tag/book" rel="tag">book</a>, <a href="http://del.icio.us/tag/review" rel="tag">review</a></span>
