+++
categories = ["linux"]
date = "2017-01-19T09:55:32+01:00"
description = ""
keywords = ["linux"]
title = "Power management and XFCE under Fedora 25"
+++
The gnome shell has been crashing on me more regularly lately. 
XFCE is a good and fast more tradional desktop, but, from past experiences,
it does not play well with power management if you only install it via  
```
dnf install @xfce-desktop-environment
```

My typical experience is a black screen after resuming from suspend (sometimes, not always), or hibernate (always) and 
most of the time I end up just rebooting. It turns out this is all caused by the interaction between the gdm login daemon and xfce. Moving
to the lightdm login daemon instead fixes those issues for Fedora 25:
```
systemctl disable gdm
systemctl enable lightdm
systemctl stop gdm
systemctl start lightdm
```
