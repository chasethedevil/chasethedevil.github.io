+++
title = "A Proof That JavaScript Sucks."
date = 2006-12-15T16:51:00Z
updated = 2007-04-05T14:10:12Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Google developed <a href="http://code.google.com/webtoolkit">GWT</a>.<br><br>Why would GWT be so well acclaimed if JavaScript was a good language. When you talk about GWT to someone (a developer preferably), the first reaction is often  <br><blockquote style="border-left: 1px solid rgb(204, 204, 204); margin: 0pt 0pt 0pt 0.8ex; padding-left: 1ex;" class="gmail_quote">&quot;great I don't need to do any JavaScript&quot;.<br></blockquote><br>I recently discovered another similar open source project,  <a href="http://www.zkoss.org">ZK</a>. The first thing you can read on the website is <br><blockquote style="border-left: 1px solid rgb(204, 204, 204); margin: 0pt 0pt 0pt 0.8ex; padding-left: 1ex;" class="gmail_quote">&quot;ZK is an open source Ajax Web framework that enables rich user interface for web applications  <span style="font-weight: bold;">with no JavaScript</span> and little programming.&quot;<br></blockquote><br>If you compare that with how JRuby is (or Jython used to be) trendy, you will agree there must be a problem with JavaScript. <br><br>JavaScript is not bad at everything, for very simple scripting, it is quite decent, the recent inclusion of Rhino in the JDK 1.6 is useful anywhere you need simple dynamic behavior. But most developers obviously don't want to deal with it. <br><br><br> 
