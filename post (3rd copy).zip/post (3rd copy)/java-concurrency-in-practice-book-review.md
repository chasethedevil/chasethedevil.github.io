+++
title = "Java Concurrency In Practice Book Review"
date = 2007-02-14T16:33:00Z
updated = 2008-06-16T16:53:04Z
tags = ["book", "java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

My reference book on Java concurrency is Doug Lea&#39;s <span style="font-style: italic;"><span class="srTitle">Concurrent Programming in Java: Design Principles and Patterns</span></span>. He is one of the authors of this new book,  <span style="font-style: italic;">Java Concurrency In Practice</span>. There is also Joshua Bloch, author of <span style="font-style: italic;">Effective Java</span>, that many people love (but I am less a fan of it, even if I would recommend it to Java newbies), and author of  <span style="font-style: italic;">Java Puzzlers</span>, that I found more fun.<br><br>With such authors, I had relatively high expectations. I was surprised that there is not much material in common between Doug Lea&#39;s book and this one, which is a good thing. It&#39;s a different presentation, that focuses on different problems.  <br><br>There is some very interesting material, I especially enjoyed chapter 16 on the Java Memory Model. There are not many&nbsp; books with information on it. I did not know that initializing a final member in the constructor was providing thread safety for the accessor method of the corresponding field if there is no other modifying method, no synchronization needed. And not having the member declared as final was breaking the safety. <br><br>I also had not heard of <a href="http://en.wikipedia.org/wiki/Amdahl%27s_Law">Amdahl&#39;s law</a>  before. It seems quite intuitive, but then the example in the book about processing parallel tasks using a synchronized LinkedList (improvement up to 3 threads, no more later due to time spent on synchronization) shows that the reality is not that intuitive. <br><br>I enjoyed how the book is written, and how information is presented. There is for example their concept of publication and escape (in chapter 3) which tells you important things, like not starting a Thread in a constructor (and if you still want to do it they present a nice way to do it). <br><br>I think this book is a simpler read that Doug Lea original book, and probably a better introduction (that still goes very deep) to Java concurrency programming.<br><br> 
