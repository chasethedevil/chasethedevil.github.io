+++
title = "People Using Spring, EJBs Don't Know Basic JDBC"
date = 2007-05-30T12:03:00Z
updated = 2008-04-24T13:39:59Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I recently found a bug in software we are developing. I traced it and found the root was improper JDBC handling. The application is written using EJBs, Spring and plenty of other relatively complex technologies. I was surprised that developers who were able to use all those technologies had no understanding of basic JDBC.  <br><br>They fetched all the data (including double, decimal numbers) from the database as String using rs.getString() !<br><br>While this is most of the time <a href="http://java.sun.com/docs/books/tutorial/jdbc/basics/retrieving.html"> possible</a>, it is also most of the time not desirable (in the code they were actually converting it to numbers, etc.). More importantly, this can lead to nasty bugs due to different Locales (the . vs , game for example). And this is what&#39;s happening in our application. <br> 
