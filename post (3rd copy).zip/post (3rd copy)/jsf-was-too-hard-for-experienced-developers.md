+++
title = "JSF Was Too Hard for Experienced Developers"
date = 2006-06-23T14:59:00Z
updated = 2007-04-05T14:10:12Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

While starting to look into <a  href="http://www.jboss.com/products/seam">Seam</a>, I noticed that all examples use JSF for the view, and there is no alternative to it. If someone like Gavin (from Hibernate fame) thinks JSF is usable, then I probably overlooked something when I looked into it a few years ago, when JSF was the craze of the moment.<br> <br> At the beginning, JSF looks very similar to ASP.NET. But I have a small experience with ASP.NET, and ASP.NET is quite simple to understand and use. You can throw up inexperienced developers at it, they will manage to create something that works quite quickly. ASP.NET feels quite natural once you understand the postback thingy. JSF is another beast. Maybe part of it is due to the fact that the Java world has no excellent tools integration like Microsoft has (IBM RAD, one of the most advanced concerning integration, is quite far off). But there are also many technological reasons; when I read <a  href="http://www.onjava.com/pub/a/onjava/2004/06/09/jsf.html">that article about JSF shortcomings with JSP</a>, I was shocked that even to do very simple things, you would screw up, because simple things can be very complicated in JSF.<br> <br> What seems to make JSF much nicer is Facelets, as it solves all problems related to JSP and JSF. This might make my JSF experience a good one, after all. I am curious to see if it makes JSF programming really nicer, and if Seam makes the overall very quick to build and understand.<br>
