+++
title = "One Interview Question for Job Seekers in Finance"
date = 2014-06-19T21:51:00Z
updated = 2014-06-19T21:51:50Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I presented in an <a href="http://chasethedevil.github.io/post/good-software-books/" target="_blank">earlier post</a> that I was mostly disillusioned with interview questions, it's better to find out if you can learn something out of a candidate.<br /><br />Well there is maybe one very simple question that could be revealing, for people who pretend to be vaguely familiar with Black-Scholes:<br /><br /><blockquote class="tr_bq"><span style="font-size: large;"><i>What is the price of an at-the-money  binary option under very high volatility? </i></span></blockquote>Alternatively it can be asked with just an at-the-money european option under very high volatility.<br /><br />What makes think of it is that some "product manager" recently tested risk with volatilities at 300% and was wondering why they did not see any vega (based on a 1% additive shift), and opened bugs, generated noise... 
