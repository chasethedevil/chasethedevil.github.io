+++
categories = ["quant"]
date = "2017-04-02T7:56:42+01:00"
description = ""
keywords = ["quant"]
title = "Implied Volatility from Black-Scholes price"

+++
Dan Stefanica and Rados Radoicic propose a quite good initial guess in their very recent paper [An Explicit Implied Volatility Formula](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2908494). Their formula is simple, fast to compute and results in an implied volatility guess with a relative error of less than 10%.

It is more robust than the rational fraction from [Minquiang Li](https://mpra.ub.uni-muenchen.de/6867/1/MPRA_paper_6867.pdf): his rational fraction is only valid for a fixed range of strikes and maturities. The new approximation is mathematically proved accurate across all strikes and all maturities. There is only the need to be careful in the numerical implementation with the case where the price is very small (a Taylor expansion of the variable C will be useful in this case).

As mentioned in an [earlier post](/post/fast-and-accurate-implied-volatility-solver/), Peter Jäckel solved the real problem by providing the code for a fast, very accurate and robust solver along with his paper [Let's be rational](http://jaeckel.16mb.com/LetsBeRational.pdf). This new formula used as initial guess to Minquiang Li SOR-TS solver provides an interesting alternative: the resulting code is very simple and efficient. The accuracy, relative or absolute can be set to eventually speedup the calculation. 

Below is an example of the performance on a few different cases for strike 150, forward 100, time to maturity 1.0 year and a relative tolerance of 1E-8 using [Go 1.8](https://golang.org/).

| Original volatility | Method | Implied Volatility | Time |
|:-------------------:|:------:|:------------------ | ----:|
| 64% | Jäckel | 0.6400000000000002 | 1005 ns | 
| 64% | Rational|  0.6495154924570236 | 72 ns |
| 64% | SR | 0.6338265040549524 | 200 ns |
| 64% | Rational-Li  | 0.6400000010047917 |  436 ns | 
| 64% | SR-Li  | 0.6400000001905617 |  568 ns | 
| 16% | Rational|  0.1575005551326285 | 72 ns|
| 16% | SR | 0.15117970813645165 | 200 ns |
| 16% | Jäckel | 0.16000000000000025| 1323 ns | 
| 16% | Rational-Li  | 0.16000000000219483 | 714 ns | 
| 16% | SR-Li  | 0.16000000000018844 | 1030 ns | 
| 4% | Rational|  0.1528010258201771 | 72 ns |
| 4% | SR | 0.043006234681405076 | 190 ns |
| 4% | Jäckel |  0.03999999999999886| 1519 ns | 
| 4% | Rational-Li  |  0.040000000056277685 | 10235 ns | 
| 4% | SR-Li  | 0.040000000000453895 | 2405 ns | 

The case 4% was an example of a particularly challenging setting in a [Wilmott forum](https://forum.wilmott.com/viewtopic.php?f=34&t=97812&start=75). It results in a very small call option price (9E-25).

