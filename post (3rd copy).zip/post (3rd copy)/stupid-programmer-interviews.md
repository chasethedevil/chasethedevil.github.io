+++
title = "Stupid Programmer Interviews"
date = 2008-09-17T10:56:00Z
updated = 2008-09-17T10:56:04Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<div dir="ltr">I have read a blog post a few days ago about someone thinking a good programmer interview question was:<br><blockquote><blockquote style="border-left: 1px solid rgb(204, 204, 204); margin: 0pt 0pt 0pt 0.8ex; padding-left: 1ex;" class="gmail_quote"> How does a hash table work?<br></blockquote></blockquote><div>While it is a very interesting question, I doubt many programmers (even relatively good ones) can answer that question. If I look back and think of all the employees in all the companies I have known, I can count on one hand people that can answer that question. I can think of 3 or 4 I met in one company, and maybe another 1 or 2 in different companies.<br> <br>And I don&#39;t think anyone would have been able to go deeper in the details like mentioning <a href="http://www.dcs.gla.ac.uk/%7Epat/52219/l04.html">closed-addressed vs open-addressed</a> possible implementations.<br> <br>I am so negative, because a question about some important details of the inner working of the Java HashMap was raised at work a week ago. I was the only one (because I had read several times about hash tables) to be aware that the &quot;equals&quot; method of the key object was called every time you do a table.get(xxx) or a table.put(xxx, yyy). Others thought only the hashCode() method was used.<br> <br>This kind of interview question creates a high bias towards people coming straight out of school if they have Hashtable in their program. For people with more experience, it is highly likely if they ever read about it that they forgot the details (and maybe more than the details).<br> <br>This can seem shocking as hash tables are used almost everywhere these days, but it&#39;s a reality.<br></div></div> 
