+++
title = "Senior Developers Team Productivity X4 (from MS Research Paper)"
date = 2009-02-10T10:44:00Z
updated = 2009-02-10T11:26:46Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

There is a very interesting <a href="http://research.microsoft.com/en-us/projects/esm/nagappan_tdd.pdf">MS Research paper about test driven development</a> (TDD). It is one of the only real study about it that I know of. The paper conclusions from experiments over 4 TDD teams vs 4 traditional teams is:<br /><blockquote><span style="font-style: italic;">"TDD seems to be applicable in various domains and can significantly reduce the defect density of developed software without significant productivity reduction of the development team"</span></blockquote>Their data gives also other interesting results:<br /><ul><li>An experienced team (5 people over 10 years + 2 people under 5 years) : 155KLOC C# code (+60 test).<br /></li></ul><ul><li>A junior team (3 people under 10 years + 6 people under 5 years): 41 KLOC Java code (+28 test).<br /></li></ul>If you do the ratio of KLOC/man month, you have the following graph:<br /><a onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}" href="http://2.bp.blogspot.com/_9RyqGT46Fbk/SZFVEkXM8JI/AAAAAAAACts/_pwwDhnKTt0/s1600-h/MSPaperKLOCMonth.png"><img style="margin: 0px auto 10px; display: block; text-align: center; cursor: pointer; width: 400px; height: 252px;" src="http://2.bp.blogspot.com/_9RyqGT46Fbk/SZFVEkXM8JI/AAAAAAAACts/_pwwDhnKTt0/s400/MSPaperKLOCMonth.png" alt="" id="BLOGGER_PHOTO_ID_5301111773360615570" border="0" /></a><br />I know this is very far from scientific evidence and more like astrology, but still, the most conservative ratio for senior/junior is <span style="font-weight: bold;">4.23</span>!
