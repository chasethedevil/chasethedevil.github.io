+++
categories = ["hardware"]
date = "2017-10-02T23:56:42+01:00"
description = ""
keywords = ["hardware"]
title = "Google phones are overrated"

+++
It is a relatively common belief that the vanilla Android experience is better, as it runs smoother. The Samsung Touchwiz is often blamed for making things slow and not more practical.

I have had a Nexus 6 for a couple of years and I noticed the slowdowns after each update, up to a point where it sometimes took a few seconds to open the phone app, or to display the keyboard. I freed up storage, removed some apps but this did not make any difference. This is more or less the same experience that people have with the Samsung devices if [reddit comments](https://www.reddit.com/r/Android/comments/73necm/with_the_note_8_samsung_no_longer_delivers/) are to be believed. 

The other myth is that Google phones will be updated for a longer time. Prior to the Nexus 6, I had a Galaxy Nexus, which Google stopped supporting after less than 2 years. The Nexus 6 received security update until this October, that is nearly 2 years for me and 2.5 years for early buyers.

In comparison Apple updates its phones for much longer and a 4 years old iphone 5s still runs smoothly. Fortunately for Android phones, there are the alternative roms. Being desperate with the state of my Nexus phone, I installed [paranoid android](http://get.aospa.co/). I am surprised at how good it is. My phone feels like new again, and as good as any flagship I would purchase today. To my great surprise I did not find any clear step by step installation process for Paranoid Android. I just followed the [detailed steps for LineageOS](https://wiki.lineageos.org/devices/shamu/install) (CyanogenMod descendent), but with the paranoid android zip file instead of the LineageOS one. I have some trouble to understand how some open source ROM can be much nicer than the pure Google Android ROM, but it is. I have had no crash/reboot (which became more common as well with the years), plus it's still updated regularly. Google does not set a good standard by not supporting its own devices better.

There is however one thing that Google does well, it's the camera app. The HDR+ mode makes my Nexus 6 take great pictures, even compared to new android phones or iphones. I am often amazed at the pictures I manage to take, and others are also amazed at how good they look (especially since they look often better on the Nexus 6 screen than on a computer monitor). Initially I remember the camera to be not so great, but some update that came in 2016 transformed the phone into a fantastic shooter. It allowed me to take very nice pictures in difficult conditions, see for example [this google photo gallery](https://photos.app.goo.gl/s2IHVtKMzRkxDY1q1). Fortunately it's still possible to install the app in the Google Play store on Paranoid Android. They should really make it open-source and easier to adapt it to other android phones.

{{< figure src="https://lh3.googleusercontent.com/JjEGDeF4uiw1FPFVVDotOPNeN-GPr_5s8-n0ud7Ioio8GvegtJqJ_C6AinmV0plNBnEINZEVr6LZvHb7I68HbGaZcTRUlldsxHoXZVGSLJAYZHqEM94JnDINlVVEWSOvP39Qwj4dWw" title="A photo made with the Google camera app on the Nexus 6." link="https://photos.google.com/share/AF1QipOGPpDIYCAYJ_636MtjEGWQHj6da0EukBqwoAGMYvuMoWGGJ8EjCx4ADVNffqulPA?key=YjF4VnRGRGlqNlgtbS1Cb0U0WFo3djl5NEdUSk5R&source=ctrlq.org">}}
