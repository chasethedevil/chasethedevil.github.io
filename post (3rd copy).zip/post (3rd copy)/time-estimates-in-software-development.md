+++
title = "Time Estimates in Software Development"
date = 2013-05-07T21:01:00Z
updated = 2013-05-07T21:02:11Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Recently, that I completed a project that I had initially estimated to around 2 months,  in nearly 4 hours. This morning I fixed the few remaining bugs. I looked at the clock, surprised it was still so early and I still had so many hours left in the day.<br /><br />Now I have more time to polish the details and go beyond the initial goal (I think this scares my manager a bit), but I could (and I believe some people do this often) stop now and all the management would be satisfied.<br /><br />What's interesting is that everybody bought the 2 months estimate without questions (I almost even believed it myself). This reminded me of my <a href="http://chasethedevil.github.io/post/productivity-zero/">productivity zero post</a>.<br /><br /><br />
