+++
categories = ["quant", "programming"]
date = "2018-10-07T20:56:42+01:00"
description = ""
keywords = ["quant", "programming"]
title = "Fixing NaNs in Quadprog"

+++
Out of curiosity, I tried [quadprog](https://github.com/cran/quadprog) as [open-source quadratic programming convex optimizer](https://quantsrus.github.io/post/state_of_convex_quadratic_programming_solvers/), as it is looks fast, and the code stays relatively simple. I however stumbled on cases where the algorithm would return NaNs even though my inputs seemed straighforward. Other libraries such as CVXOPT did not have any issues with those inputs.

Searching on the web, I found that I was not the only one to stumble on this kind of issue with quadprog. In particular, in 2014, Benjamen Tyner [gave a simple example in R](http://r.789695.n4.nabble.com/quadprog-solve-QP-sometimes-returns-NaNs-td4697548.html), where solve.QP returns NaNs while the input is very simple: an identity matrix with small perturbations out of the diagonal. Here is a copy of his example:

{{< highlight R >}}
    library(quadprog)

    n <- 66L

    set.seed(6860)
    X <- matrix(1e-20, n, n)
    diag(X) <- 1
    Dmat <- crossprod(X)
    y <- seq_len(n)
    dvec <- crossprod(X, y)

    Amat <- diag(n)
    bvec <- y + runif(n)

    sol <- solve.QP(Dmat, dvec, Amat, bvec, meq = n)

    print(sol$solution) # this gives all NaNs
{{< /highlight >}}

Other people stumbled on [similar](https://stats.stackexchange.com/questions/259993/why-would-quadratic-program-in-svm-not-work-for-very-large-or-very-small-lambda) issues.

In my specific case, I was able to debug the quadprog algorithm and find the root cause: two variables \\(g\_c\\) and \\(g\_s\\) can become very small, and their square becomes essentially zero, creating a division by zero. If, instead of computing \\( \frac{g\_s^2}{g\_c^2} \\) we compute \\( \left(\frac{g\_s}{g\_c}\right)^2 \\), then the division by zero is avoided as the two variables are of the same order.

{{< figure src="/post/quadprog_nan_fix.png" title="Sample code change [on github](https://github.com/cran/quadprog/pull/1/commits/7f51915f7c662c7fac3d4e2ab067cfbc292767f8)." >}}

While it probably does not catter for all the possible NaN use cases, it did fix all the cases I stumbled upon.
