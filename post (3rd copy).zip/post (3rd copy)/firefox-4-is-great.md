+++
title = "Firefox 4 Is Great"
date = 2010-12-22T16:03:00Z
updated = 2010-12-22T16:03:30Z
tags = ["internet"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I temporarily <a href="http://chasethedevil.blogspot.com/2010/07/bye-bye-firefox.html">abandonned Firefox</a> for Chrome/Chromium. I am now back at using Firefox as Firefox 4 is as fast or faster than Chrome and seems more stable, especially under linux. Also it does not send anything to Google and there is bookmark sync independently of Google.<br /><br />I am impressed that Mozilla managed to improve Firefox that much.
