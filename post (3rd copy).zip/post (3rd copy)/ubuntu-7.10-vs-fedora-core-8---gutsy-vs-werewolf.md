+++
title = "Ubuntu 7.10 vs Fedora Core 8 - Gutsy vs Werewolf"
date = 2007-11-20T16:23:00Z
updated = 2007-11-20T16:23:39Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I was pretty happy with Ubuntu 7.10, but when Fedora 8 came out I decided to give it a try. Last time I tried it it was Core 2 or something like that, and it was NOT good.<br><br>At first Fedora 8 looks quite good, has a good Live CD install, reminiscent of Ubuntu.&nbsp; The positive side is that it is based on the latest Kernel. It manages my Thinkpad T42 very well (suspend, hibernate work). But after a few days, one notice Fedora is not as stable as Ubuntu, for example: <br><ul><li>I have had weird behavior with windows not being updated properly</li><li>I experienced big problems when playing with LVM, <br></li><li>It is also a general impression when interacting with the system.<br></li> </ul>One can wonder why Fedora 8 does not install OpenOffice by default.<br>Ubuntu is IMHO still the king of distros.<br> 
