+++
title = "How to Build Good Software? Lay Off Quickly."
date = 2007-04-10T11:12:00Z
updated = 2007-04-10T11:14:20Z
tags = ["howtobuildgoodsoftware"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

If you have to lay off in your job, do it quickly. I don't understand companies that want to keep someone as long as legally possible when this someone wants to leave. First the employee won't be as motivated, but more importantly, you will continue to train that person to your company's software and ways of work. This would be much better used on another person, that will stay in the company. Time for layoffs should exclusively be used for knowledge transfer.
