+++
title = "Orkut Statistics and Blog Evolution"
date = 2005-10-18T13:03:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I was just having a look at orkut again. As in my last look in the past year, there is not much new or interesting. The technical forums are mostly uninteresting and it almost looks like nothing is going on. Take a look at the orkut java forums, in 1 year, very few messages are good. <br> <br> Compare that to <a href="http://javablogs.com">javablogs.com</a> blogs aggregation, every week there are many interesting posts. The blog model is good because it is targeted at people who want to write. When you blog, you build a history. Forums don't let you do that. You could have a social model on top of blogs, and I am sure this will be one of their next evolution.<br> <br> I found one good page, the <a  href="http://www.orkut.com/MembersAll.aspx">orkut statistics:</a><br> <ol>   <li><b><big>Brasil </big></b>is number one country with almost <font  color="#ff0000">75%</font> of the people from there. I wonder why they find it that much better than alternatives. It's strange how something can be successful somewhere and not somewhere else.</li>   <li><b><big>US</big> </b>represent only <font color="#ff0000">7.8%</font>.   </li>   <li><b><big>Iran</big> </b>and <b><big>Pakistan</big> </b>represent     <font color="#ff0000">6%</font>, that is almost the equivalent of the US. I was very surprised by that.</li>   <li><b><big>Europe</big></b> does not exist there.</li> </ol> More than 50&uml;% of the orkutians are under 25, which probably explains why not much is going on there.<br> <br> <span class="technoratitag">Tags: <a  href="http://del.icio.us/tag/orkut" rel="tag">orkut</a>, <a  href="http://del.icio.us/tag/social" rel="tag">social</a>, <a  href="http://del.icio.us/tag/network" rel="tag">network</a></span><br> <br>
