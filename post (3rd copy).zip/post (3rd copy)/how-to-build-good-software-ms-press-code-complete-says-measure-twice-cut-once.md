+++
title = "How to Build Good Software? MS Press Code Complete says Measure twice, cut once"
date = 2007-04-05T14:14:00Z
updated = 2007-04-05T14:19:22Z
tags = ["howtobuildgoodsoftware"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I am starting a series of posts about software construction, based on good and bad experiences while working for my many employers.<br /><br />"Software construction (a.k.a. architecture), is the only activity that's guaranteed to happen on every project". It is not rare that projects or new features are abandoned either because they are too costly, or because they are not needed anymore, or because they are other more important priorities.<br /><br />In the same vein: "Measure twice, cut once". “Measure twice, cut once” is highly relevant to the construction part of software development, which can account for as much as 65 percent of the total project costs. The worst software projects end up doing construction two or three times or more. Doing the most expensive part of the project twice is as bad an idea in software as it is in any other line of work.<br /><br />When you see Software that change versions (major versions) while not really having been used much, this is a sign there is something wrong in the construction part.
