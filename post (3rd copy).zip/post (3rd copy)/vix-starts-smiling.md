+++
categories = ["quant"]
date = "2017-03-21T7:56:42+01:00"
description = ""
keywords = ["quant"]
title = "The VIX starts smiling"

+++
The VIX implied volatilities used to look like a logarithmic function of the strikes. I don't look at them often, but today, I noticed that the VIX had the start of a smile shape.

{{< figure src="/post/vix_smile.png" title="1m VIX implied volatilities on March 21, 2017 with strictly positive volume." >}}

Very few strikes trades below the VIX future level (12.9). All of this is likely because the VIX is unusually low: not many people are looking to trade it much lower. 

**Update March 22:** Actually the smile in VIX is not particularly new, it is visible in Jim Gatheral 2013 presentation [Joint modeling of SPX and VIX](https://www.google.fr/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwiF2LP9turSAhUJVBQKHUVFCIoQFggoMAA&url=http%3A%2F%2Fmfe.baruch.cuny.edu%2Fwp-content%2Fuploads%2F2012%2F09%2FBeijingSPXVIX2013.pdf&usg=AFQjCNHCx2b2AXNXPHixUAYQC2nWH9ULHQ) for the short maturities. Interestingly, [the issue with SVI](/post/when-svi-breaks-down/) is also visible in those slides in the shortest maturity.
