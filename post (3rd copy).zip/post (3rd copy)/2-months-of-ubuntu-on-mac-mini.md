+++
title = "2 Months of Ubuntu on Mac Mini"
date = 2007-08-27T23:48:00Z
updated = 2007-08-27T23:48:16Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++
{{< rawhtml >}}
I am finally happy with my OS. I had previously <A HREF="http://chasethedevil.blogspot.com/2007/01/1-year-of-mac-mini-deception-point.html">some complaints</A> about MacOs X and the Mac Mini. It is now over, with <A HREF="http://ubuntu.com">Ubuntu</A>, I am very happy of my quiet system. <BR> <BR> I use Quod Libet for Audio, it has similar interface as iTunes, with more features (ability to play most audio formats). I chose Quod Libet instead of the standard Rhythmbox because of its practical mp3 tags handling. This also means that unlike iTunes, when I reimport my full library with another player, or on another computer, I have it all organized the right way, because the right meta data is in the audio files and not in a xml file that sometimes gets corrupted.<BR> <BR> I can use Open Office (not yet available in non alpha version for Mac Os X).<BR> <BR> I can use Picasa or other more standard alternatives instead of iPhoto.<BR> <BR> I can use free guitar tuners, plenty of esoteric software.<BR> <BR> Remote control, fancy bluetooth apple keyboard, cd burning, dvd player, printer work flawlessly. And it's all free software (except Picasa which is only gratis).<BR> <BR> I am happy with my Ubuntu system :). {{< /rawhtml >}}
