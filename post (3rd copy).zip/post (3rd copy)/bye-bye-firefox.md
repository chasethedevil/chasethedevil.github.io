+++
title = "Bye Bye Firefox"
date = 2010-07-21T15:30:00Z
updated = 2010-07-21T15:30:06Z
tags = ["internet"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I have been a long user of Firefox, mostly thanks to the adblock extension. But recently, Firefox decided to change the way arrows work on the web pages, they don't make the page scroll anymore. Meanwhile Chrome has now a good adblock plugin (that filters ads on load, not after load like it use to be) and is really much much faster than Firefox. So there is no more reason not to use it.<br /><br />Hello Chrome, bye bye Firefox. Google has won the web browsers war.
