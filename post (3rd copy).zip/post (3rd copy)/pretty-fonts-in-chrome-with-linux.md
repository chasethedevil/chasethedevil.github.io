+++
title = "Pretty Fonts in Chrome with Linux"
date = 2012-09-12T18:06:00Z
updated = 2013-12-27T17:36:57Z
tags = ["linux"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

It's a bit incredible, but in 2012, some linux distros (like Fedora, or Kubuntu) still have trouble to have pretty fonts everywhere. I found a nice tip initially for Google Chrome but that seems to improve more than Chrome: create ~/.fonts.conf with the following:<br /><br /><span style="font-family: Courier New, Courier, monospace; font-size: x-small;">[match target="font"]</span><br /><span style="font-family: Courier New, Courier, monospace; font-size: x-small;">&nbsp; &nbsp; [edit name="autohint" mode="assign"]</span><br /><span style="font-family: Courier New, Courier, monospace; font-size: x-small;">&nbsp; &nbsp; &nbsp; [bool]true[/bool]</span><br /><span style="font-family: Courier New, Courier, monospace; font-size: x-small;">&nbsp; &nbsp; [/edit]</span><br /><span style="font-family: Courier New, Courier, monospace; font-size: x-small;">&nbsp; &nbsp; [edit name="hinting" mode="assign"]</span><br /><span style="font-family: Courier New, Courier, monospace; font-size: x-small;">&nbsp; &nbsp; &nbsp; [bool]true[/bool]</span><br /><span style="font-family: Courier New, Courier, monospace; font-size: x-small;">&nbsp; &nbsp; [/edit]</span><br /><span style="font-family: Courier New, Courier, monospace; font-size: x-small;">&nbsp; &nbsp; [edit mode="assign" name="hintstyle"]</span><br /><span style="font-family: Courier New, Courier, monospace; font-size: x-small;">&nbsp; &nbsp; &nbsp; [const]hintslight[/const]</span><br /><span style="font-family: Courier New, Courier, monospace; font-size: x-small;">&nbsp; &nbsp; [/edit]</span><br /><span style="font-family: Courier New, Courier, monospace; font-size: x-small;">[/match]</span><br /><div><br /></div><div>replace [ and ] with brackets &lt; and &gt;<br /><br />Update from 2013 - This can be done system wide, see <a href="http://chasethedevil.blogspot.com/2013/08/better-fonts-in-fedora-than-in-ubuntu.html">http://chasethedevil.blogspot.com/2013/08/better-fonts-in-fedora-than-in-ubuntu.html</a> </div><pre></pre>
