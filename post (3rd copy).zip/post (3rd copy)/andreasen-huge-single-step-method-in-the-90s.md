+++
title = "Andreasen-Huge Single-Step Method in the 90s"
date = 2015-04-29T17:47:00Z
updated = 2015-09-04T21:45:48Z
tags = ["quant"]
draft = true
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Recently, Daniel Duffy sent me some old papers from Shishkin around fitted schemes (<a href="http://oai.cwi.nl/oai/asset/10209/10209A.pdf">here is one</a>). When I read this, I thought that it would be interesting to try the simplest fitted scheme trick on the single step finite difference method as an alternative to Andreasen-Huge approximation.

Using the fitting coefficient $$\gamma(K,t)$$, the normal forward Dupire equation reads: 

$$
\frac{\partial C}{\partial t} = \frac{1}{2} \gamma(K,t) \sigma^2 \frac{\partial^2 C}{\partial K^2}
$$

As in Shishkin, we fit to the problem with step function initial condition: C is the cumulative normal distribution \\(\Phi(x)\\). Its second derivative is \\(-x \phi(x)\\) where \\(\phi\\) is the Gaussian. We have then:

$$
\Phi\left( \frac{S-K}{\sigma\sqrt{T}}\right) - 1_{S-K>0} = -T \frac{1}{2} \gamma(K,t) \frac{S-K}{T} \phi(\frac{S-K}{\sigma\sqrt{T}})
$$

let $$x= \frac{S-K}{\sigma\sqrt{T}}$$, we have then:

$$
\gamma = 2 \frac{1_{x>0}-\Phi(x)}{x\phi(x)}
$$
