+++
title = "Moved From Dropbox to Ubuntu One"
date = 2013-04-23T20:44:00Z
updated = 2013-04-23T20:44:38Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Dropbox worked well, but the company decided to blacklist it. I suppose some people abused it. While looking for an alternative, I found <a href="https://www.google.fr/url?sa=t&amp;rct=j&amp;q=&amp;esrc=s&amp;source=web&amp;cd=1&amp;cad=rja&amp;ved=0CDMQFjAA&amp;url=https%3A%2F%2Fone.ubuntu.com%2F&amp;ei=QtZ2UY3NO83GPePRgOgF&amp;usg=AFQjCNFS8gIGpHCkBTGRPbT7qLVFzb584g&amp;sig2=z3LX3TTwx8lLoS41AJCgaA&amp;bvm=bv.45580626,d.ZWU">Ubuntu One</a>. It's funny I never tried it before even though I use Ubuntu. I did not think it was a dropbox replacement, but it is. And you get 5GB instead of Dropbox 2GB limit, which is enough for me (I was a bit above the 2GB limit). It works well under Linux but as well on Android and there is an iOS app I have not yet tried. It also works on Windows and Mac.<br /><br /><br />
