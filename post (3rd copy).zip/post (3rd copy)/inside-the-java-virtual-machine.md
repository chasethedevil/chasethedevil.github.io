+++
title = "Inside the Java Virtual Machine"
date = 2005-08-18T11:03:00Z
updated = 2008-06-16T16:53:04Z
tags = ["book", "java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I am reading an old book, <a href="http://www.amazon.com/exec/obidos/redirect?link_code=ur2&amp;camp=1789&amp;tag=michelin-20&amp;creative=9325&amp;path=tg/detail/-/0079132480">Inside the Java Virtual Machine</a><img src="http://www.assoc-amazon.com/e/ir?t=michelin-20&amp;l=ur2&amp;o=1" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />. Some old books don't age, and this is one of them. The chapter on the Java Virtual Machine is just excellent and should be read by every Java developer. It explains each step a JVM does when you run a Java program, very clearly.<br /><br />You could get plenty of stupid interview questions from it like: How is the Java stack used? Between method area, heap, pc register, stack which one are shared among threads?<br /><br />Also they saw the full potential of Java quite early on (1997). They explain how the JVM specs allow for very different implementations, ones that can run in different environments, for example, simplifying a bit: low memory, embedded world, or lots of memory, mainframe world. It is not an accident if Microsoft chosed a very similar design for the CLI of .NET, they have been looking for getting into the embedded area for quite some time, and apparently, they are making good progress.<br /><br /><i>Tags: <a href="http://technorati.com/tag/java" rel="tag">java</a> <a href="http://technorati.com/tag/programming" rel="tag">programming</a><a href="http://technorati.com/tag/book" rel="tag">book</a><a href="http://technorati.com/tag/review" rel="tag">review</a><br /></i>
