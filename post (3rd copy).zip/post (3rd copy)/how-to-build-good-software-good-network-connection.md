+++
title = "How to Build Good Software? Good network connection"
date = 2007-04-27T12:40:00Z
updated = 2007-04-27T12:41:39Z
tags = ["howtobuildgoodsoftware"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Not having good internet connection can be problematic to download new libraries, read or search for documentation on development subjects. But not having a good internal network connection is  killer of productivity. It means sometimes not being able to access integration, preprod or even production environment, or ssh session not responding in the middle of an action. As software makes an increasing use of the network, it means not being able to test or to use correctly all kind of software.
