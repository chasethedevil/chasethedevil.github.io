+++
title = "Octave vs Scilab for PDEs in Finance"
date = 2013-07-30T12:10:00Z
updated = 2013-07-30T14:25:25Z
tags = ["scala", "quant", "java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I was used to <a href="http://www.scilab.org/">Scilab</a> for small experiments involving linear algebra. I also like some of Scilab choices in algorithms: for example it provides PCHIM monotonic spline algorithm, and uses Cody for the cumulative normal distribution.<br /><br />Matlab like software is particularly well suited to express PDE solvers in a relatively concise manner. To illustrate some of my experiments, I started to write a Scilab script for the <a href="http://chasethedevil.github.io/post/sabr-with-the-new-hagan-pde-approach/">Arbitrage Free SABR problem</a>. It worked nicely and is a bit nicer to read than my equivalent Scala program. But I was a bit surprised by the low performance.<br /><br />Then I heard about <a href="http://www.gnu.org/software/octave/">Octave</a>, which is even closer to Matlab syntax than Scilab and started wondering if it was better or faster. Here are my results for 1000 points and 10 time-steps: <br /><br />Scilab 4.3s<br />Octave 4.1s<br /><br />I then added the keyword sparse when I build the tridiagonal matrix and end up with:<br /><br />Scilab 0.04s<br />Octave 0.02s<br />Scala 0.034s (first run)<br />Scala 0.004s (once Hotpot has kicked in)<br /><br />So Octave looks a bit better than Scilab in terms of performance. However I could not figure out from the documentation what algorithm was used for the cumulative normal distribution and if there was a monotonic spline interpolation in Octave.<br /><br />In general I find it impressive that Octave is faster than the first run of Scala or Java, and impressive as well that the Hotspot makes gain of x10.
