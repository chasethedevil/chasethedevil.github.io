+++
title = "Bachelier vs. Black"
date = 2009-03-23T17:58:00Z
updated = 2009-03-23T18:09:44Z
tags = ["finance", "java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<a onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}" href="http://4.bp.blogspot.com/_9RyqGT46Fbk/ScfCRxmTocI/AAAAAAAACzk/5_lPpPc7LzU/s1600-h/bachelier_vs_black_normal.png"><img style="margin: 0pt 10px 10px 0pt; float: left; cursor: pointer; width: 400px; height: 300px;" src="http://4.bp.blogspot.com/_9RyqGT46Fbk/ScfCRxmTocI/AAAAAAAACzk/5_lPpPc7LzU/s400/bachelier_vs_black_normal.png" alt="" id="BLOGGER_PHOTO_ID_5316431495761732034" border="0" /></a><br />Black and Scholes gives a strange result for the price of a binary option under high volatility.  You will learn here how to simulate a stock price evolution using Java, and how to show it using JFreeChart library. It starts with more complex concepts (don't be afraid) and goes done towards simpler things.<br /><br />I could not write all that in a blog format, so I created a old HTML page about it <a href="http://31416.appspot.com/static/bachblack/Bachelier_vs_Black.html">here</a> and a <a href="http://31416.appspot.com/static/bachblack/Bachelier_vs_Black.pdf">PDF version</a>.<br /><span style="text-decoration: underline;"></span>
