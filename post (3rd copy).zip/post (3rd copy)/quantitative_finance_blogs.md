+++
categories = ["quant"]
date = "2017-06-21T23:56:42+01:00"
description = ""
keywords = ["quant"]
title = "Blogs on Quantitative Finance"

+++
There are not many blogs on quantitative finance that I read. Blogs are not so popular anymore with the advent of the various social networks (facebook, stackoverflow, google plus, reddit, ...). Here is a small list:

* [Clarus FT](https://www.clarusft.com/blog/): often interesting statistics on the swap market, clearing, plus the [more technical articles from Gary](https://www.clarusft.com/author/gary/).
* [Quants R Us](https://quantsrus.github.io/): A relatively new blog with a promising starting post analyzing [Andreasen-Huge one-step local-volatility algorithm with a Spline](https://quantsrus.github.io/post/andreasen_huge_spline/)
* [Fooling around with Quantlib](https://quantlib.wordpress.com/author/petercaspers/): the blog from Peter Caspers, also relevant  to non-Quantlib professionals has original insights such as [Smile dynamics by densities](https://quantlib.wordpress.com/2015/09/19/smile-dynamics-by-densities/) or the [Supernatural Libor Coupons](https://quantlib.wordpress.com/2015/08/23/supernatural-libor-coupons/). Unfortunately it is not so active anymore.
* [Implementing Quantlib](http://www.implementingquantlib.com): the blog from Luigi Ballabio, which explains many of the design decisions in Quantlib. Very interesting for developer of financial libraries, see for example [the fd solvers](http://www.implementingquantlib.com/2017/04/fd-solvers.html).
* [HPC Quantlib](https://hpcquantlib.wordpress.com/) from Klaus Spanderen. Yes lots of quantlib blogs, but this one is actually not much focused on quantlib. It goes into great details about some numerical techniques, see for example the [analysis of Heston pricing algorithm](https://hpcquantlib.wordpress.com/2017/05/07/newer-semi-analytic-heston-pricing-algorithms/)
* [Oxford Strat](http://oxfordstrat.com/rd-blog/). It is a different kind of subject: too many trading strategies but some interesting data, for example [global market correlations](http://oxfordstrat.com/data/global-market-correlations/) and [ideas](http://oxfordstrat.com/ideas/sharpe-ratio/). 
* [Wilmott forums](https://forum.wilmott.com/) not a blog, but it sometimes (not often) has interesting discussions and can be a good way to connect.

Another way to find out what's going on in the quantitative finance world is to scan regularly recent papers on [arxiv](https://arxiv.org/list/q-fin/recent), [SSRN](http://www.ssrn.com) or the suggestions of [Google scholar](http://scholar.google.com).
