+++
title = "Null vs. Errors"
date = 2006-04-26T16:16:00Z
updated = 2007-04-05T14:10:39Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<div>I am not particularly a fan of&nbsp; JCS (Jakarta Cache System) as I find ehcache code very clean and simple. But I have to say the author has some good comments on the <a href="http://jakarta.apache.org/jcs/JCSandJCACHE.html"> site</a>:</div> <div>&nbsp;</div> <div> <blockquote class="gmail_quote" style="PADDING-LEFT: 1ex; MARGIN: 0px 0px 0px 0.8ex; BORDER-LEFT: #ccc 1px solid"> <div>Nulls vs. Errors</div> <div>&nbsp;</div> <div>I started to support <code>ObjectNotFoundExceptions</code> for failed gets but the overhead and cumbersome coding needed to surround a simple get method is ridiculous. Instead the JCS return null. </div></blockquote> </div> <div>&nbsp;</div> <div>For having seen too many times the ObjectNotFoundException &quot;pattern&quot;, I can only agree!</div> <div>&nbsp;</div>
