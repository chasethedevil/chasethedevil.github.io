+++
categories = ["quant"]
date = "2016-05-12T19:32:42+02:00"
description = ""
keywords = ["quant"]
title = "SVI, SABR, or parabola on AAPL?"

+++
In a [previous post](/post/least_squares_spline), I took a look at least squares spline and parabola fits on AAPL 1m options market volatilities. I would have imagined SVI to fit even  better since it has 5 parameters, and SABR to do reasonably well.

It turns out that the simple parabola has the lowest RMSE, and SVI is not really better than SABR on that example.

{{< figure src="/post/svi_sabr_parabola.png" title="SVI, SABR, least squares parabola fitted to AAPL 1m options" >}}

Note that this is just one single example, unlikely to be representative of anything, but I thought this was interesting that in practice, a simple parabola can compare favorably to more complex models.

