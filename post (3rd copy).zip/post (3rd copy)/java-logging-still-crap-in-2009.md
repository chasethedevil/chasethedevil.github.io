+++
title = "Java Logging Still Crap in 2009"
date = 2009-04-24T15:01:00Z
updated = 2009-04-24T15:13:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

When java logging API was first introduced in JDK 1.4 in 2002, it caused quite a lot a fuss around, with everybody asking "Why did not they just include Log4j instead of creating their own bastard child?".<br /><br />I remember having looked at it very shortly before continuing using Log4j on all projects I have been involved with.<br /><br />Today, while doing a very small project, I tried once more to use <a href="http://java.sun.com/j2se/1.4.2/docs/guide/util/logging/overview.html">java logging</a>. The main reason is that I was lazy to add a dependency to one more jar for this small project. While trying I found out that:<br /><ol><li> you still need to use a damned JVM parameter to point to your configuration file</li><li>you can not change the formatting without writing a formatter class!<br /></li></ol>It's 2009! What has Sun done? I am amazed the most elementary things you expect from a Logger are still not included by default in the JDK.
