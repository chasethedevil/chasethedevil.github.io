+++
title = "What Is 'Modern' Java Compilation?"
date = 2006-02-07T11:12:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<span class="gmail_quote"></span>Occasionally in <a href="http://ant.apache.org" target="_blank" onclick="return top.js.OpenExtLink(window,event,this)">Ant</a> you can see messages like this:<br><span style="background-color: rgb(255, 204, 0);"> &quot;</span><font size="-1"><span style="background-color: rgb(255, 204, 0);">[javac] </span><b style="background-color: rgb(255, 204, 0);">Using modern compiler</b><span style="background-color: rgb(255, 204, 0);">&quot; </span><br><br>What does this mean? <br><br></font><div style="text-align: left;"><font size="-1">In Ant you have the property &quot; <span style="font-weight: bold;">build.compiler</span>&quot; to specify if you want to use a classic or modern compiler. Now what do they mean by modern or classic. Well, they call classic compiler the compilers of JDK 1.1   and 1.2 and they call modern compiler the ones of JDK 1.3+. They made that distinction because a classic compiler does not support the same options as modern compilers: the semantics of javac tool changed in JDK 1.3.</font> <br></div><font size="-1"> <br>This terminology can easily be confused with java class file compatibility. Java class file compatibility is changed using the &quot;<span style="font-weight: bold;">-target</span>&quot; option of javac tool. One can specify in ant to compile with modern compilers and a target  1.4, the result is likely to not run on JVM 1.3. One can specify modern and a target 1.1, the resulting classes will run on JVM 1.1, but ant build.xml file will not be usable with JDK 1.1 without changing modern to classic. <br><br>I find Ant choice of word a bit confusing as using a &quot;modern&quot; compiler has little to do with the resulting class files.<br></font>  
