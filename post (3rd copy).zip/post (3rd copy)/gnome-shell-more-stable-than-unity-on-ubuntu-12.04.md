+++
title = "Gnome Shell more stable than Unity on Ubuntu 12.04"
date = 2012-06-14T12:01:00Z
updated = 2012-12-12T16:17:10Z
tags = ["linux", "quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Regularly, the unity dock made some applications inaccessible: clicking on the app icon did not show or start the app anymore, a very annoying bug. This is quite incredible given that this version of Ubuntu is supposed to be long term support.  So I decided to give one more chance to Gnome Shell. Installing it on Ubuntu 12.04 is simple with <a href="http://www.filiwiese.com/installing-gnome-on-ubuntu-12-04-precise-pangolin/">this guide</a>. <br /><br />To my surprise it is very stable so far. Earlier Gnome Shell versions were not as stable. After installing various extensions (dock especially) it is as usable as Unity for my needs. It seems more responsive as well. I am not really into the Unity new features like HUD. It sounds to me like Ubuntu is making a mistake with Unity compared to Gnome Shell.<br /><br />To make an old extension support latest Gnome Shell version, it is sometimes necessary&nbsp; to update&nbsp; the extension metadata with what's given by <span style="font-family: &quot;Courier New&quot;,Courier,monospace;">gnome-shell --version</span>. For the weather extension you can just edit using gedit:<br /><br /><blockquote class="tr_bq">sudo gedit /usr/share/gnome-shell/extensions/weather@gnome-shell-extensions.gnome.org/metadata.json </blockquote>
