+++
title = "del.icio.us toolbar customized"
date = 2005-08-21T05:20:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

When I bookmark articles with <a href="http://del.icio.us">delicious</a>, I like to keep the content on my hard drive, because pages sometimes change, or are removed, or I want to do local searches. I believe this is one reason some people like furl (furl keeps a copy on their server that only yourself can read, but does not allow search).<br><br>A combination of slogger and delicious could solve partially the problem. But it is not integrated, I can't get my local version from delicious, so I loose the tagging, listing and all other plus from delicious.<br><br>I added my own feature to the delicious toolbar, which I like very much. This new toolbar saves automatically the file you bookmark (on the + button), and will add a link in your delicious home to the local version (if it exists).<br><br>I have it publicly accessible at <a href="http://perso.wanadoo.fr/logos01/deltoolbar.html">http://perso.wanadoo.fr/logos0</a><a href="http://perso.wanadoo.fr/logos01/deltoolbar.html">1/deltoolbar.html</a> <br><br>It is not meant to be used by everybody as it is not official. But the page will give you an idea of what it does. If you think it is useful, I will improve it, otherwise it will stay the way it is because it fits my use.<br><br /><span class="technoratitag">Categories: <a href="http://del.icio.us/tag/delicious" rel="tag">delicious</a>, <a href="http://del.icio.us/tag/firefox" rel="tag">firefox</a>, <a href="http://del.icio.us/tag/toolbar" rel="tag">toolbar</a></span>
