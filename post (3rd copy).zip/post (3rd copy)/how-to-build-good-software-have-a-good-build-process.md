+++
title = "How to Build Good Software? Have a good build process"
date = 2007-04-12T09:54:00Z
updated = 2007-04-12T10:05:14Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Important points are: standard code hierarchy, automatic download of dependencies, a distribution command with versioning support and source control interaction, a simple command to build each part of the project. In Java best candidates are a sophiticated ant build, or maven2. Maven2 is quite good since it forces you to do some of those steps, even though I think ant can't really be avoided for many more specific tasks.<br /><p>Once, I got wrong code before I left for a customer site, because code given to the customer was not checked into a source repository everytime before it was given to the customer. Furthermore the code I had could not be built because of missing jars, and the project structure forced some source directories containing source code common with other projects to be in a very specific directories at a particular level, because project isolation was poor. It took me 7 days to understand their very awkward build process.</p><p>A good build process is dependent on good CVS (or other source control system) management, which is itself dependent on good code split. CVS head should always compile. If CVS head does not compile, then people will start trying to work around it. Unfortunatly working around it means use it as rarely as possible (either by just not updating your code frequently, or by working in a branch that can not merge well because head is in a bad state). I have seen that on projects, the result is integration headaches, and extremely poor overall quality.<br /></p><p>An good check for a build process is to see how long and how many steps you have to do to build the latest deliverable on a new machine, and how difficult it is to put that in production.<br /></p><p><br /></p>
