+++
title = "Asymptotic Behavior of SVI vs SABR"
date = 2014-09-23T12:06:00Z
updated = 2015-01-21T14:21:18Z
tags = ["scala", "quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

The variance under SVI becomes linear when the log-moneyness is very large in absolute terms. The lognormal SABR formula with beta=0 or beta=1 has a very different behavior. Of course, the theoretical SABR model has actually a different asymptotic behavior.<br /><br />As an illustration, we calibrate SABR (with two different values of beta) and SVI against the same implied volatility slice and look at the wings behavior. <br /><div class="separator" style="clear: both; text-align: center;"><a href="http://4.bp.blogspot.com/-1w0jjvR9-Mk/VCFFhSiOcdI/AAAAAAAAHg4/E3yP_m3vhKA/s1600/Screenshot%2Bfrom%2B2014-09-23%2B11%3A52%3A07.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" src="http://4.bp.blogspot.com/-1w0jjvR9-Mk/VCFFhSiOcdI/AAAAAAAAHg4/E3yP_m3vhKA/s1600/Screenshot%2Bfrom%2B2014-09-23%2B11%3A52%3A07.png" height="497" width="640" /></a></div><br />While the Lee moments formula implies that the variance should be at most linear, something that the SABR formula does not respect. It is in practice not the problem with SABR as the actual Lee boundary: V(x) &lt; 2|x|/T (where V is the square of the implied volatility and x the log-moneyness) is attained for extremely low strikes only with SABR, except maybe for very long maturities.<br /><br />A related behavior is the fact that the lognormal SABR formula can actually match steeper curvatures at the money than SVI for given asymptotes.
