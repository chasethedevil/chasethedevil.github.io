+++
title = "Binary Voting"
date = 2012-09-07T17:21:00Z
updated = 2012-12-12T16:13:03Z
tags = ["finance", "quant", "math"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

How many reports have you had to fill up with a number of stars to choose? How much useless time is spent on figuring the this number just because it is always very ambiguous?<br /><br />Some blogger wrote an interesting entry on <a href="http://davidcelis.com/blog/2012/02/01/why-i-hate-five-star-ratings/">Why I Hate Five Stars Reviews</a>. Basically he advocates binary voting instead via like/dislike. Maybe a ternary system via like/dislike/don't care would be ok too.<br /><br />One coworker used to advocate the same for a similar reason: people reading those reports only pay attention to the extremes: the 5 stars or the 0 stars. So if you want to have a voice, you need to express it via 5 or 0, nothing in between.<br /><br /><br />
