+++
title = "Structured Equity Derivatives Book Review"
date = 2008-06-16T16:55:00Z
updated = 2008-06-16T17:08:56Z
tags = ["book"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

If one has to learn about equity derivatives, beside the classic <a href="http://chasethedevil.blogspot.com/2008/06/option-futures-and-other-derivatives.html"><span style="font-style: italic;">Option, Futures and Other Derivatives</span></a> from Hull, <span style="font-style: italic;">Structured Equity Derivatives</span> by Harry M Kat is a must read.<br /><br />His ideas are presented in a software developer friendly way, as his goal is to show how different equity derivatives products are behind the scenes, very similar.<br /><br />I enjoyed the variety of exotic products presented and the very detailed way in which they are explained.<br /><br />The book is filled up with graphs, which is a good thing. While browsing the book for the first time, I did not really grasp those graphs well. But after having read it, they do make sense and help visualize what's happening. With those graphs, volatility and other parameters don't look only like abstract variables in a formula.
