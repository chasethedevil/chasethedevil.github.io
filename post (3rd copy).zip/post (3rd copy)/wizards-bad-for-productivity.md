+++
title = "Wizards Bad For Productivity"
date = 2007-05-16T14:56:00Z
updated = 2007-05-16T14:58:04Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

IBM RAD comes with many wizards, to create EJBs, to create Web Services, do struts mapping... They are quite well done, making EJB < 3.0 usable, and Web Services look simple.<br /><br />But wizards sucks at:<br /><ul><li>typos correction</li><li>repetition</li></ul><br />But when you do a typo in your wizards, then all the files generated/changed are wrong, and you don't necessarily know if you can just do a search and replace. Plus you don't necessarily know all the files that were affected by the typo.<br /><br />In RAD, there is even a wizard to help you create a JSP. What does it do? Well, for example it generates those 2-3 lines of tag libraries include. The first time you write a JSP, it might help you, but the second time, it's much faster to copy/paste. Generally, when you have to do an wizard operation many times, it is much slower than doing it via copy/paste and few modifications here and there, or to use a more configurable alternative like XDoclets.<br /><br />The other complaint I have about wizards, is that they hide too much how things are working. As anybody can use them, it makes you think the operation it does and technologies behind are simple.<br /><br />More generally it feels to me like wizards are only there because of some over-complicated design somewhere. EJB 3.0 are much nicer to work with than EJB 2, a wizard will help you much less with EJB 3.0, and yet EJB 3.0 are more powerful.
