+++
title = "What Is Clustering About – An answer to Spring is not designed for scalability"
date = 2006-01-16T16:57:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

      <p class="MsoNormal" style=""><span style="" lang="EN-US">I wanted to reply to <a href="http://www.diegoparrilla.com/2006/01/spring-is-not-designed-for-scalability.html">Diego Parilla post about scalability</a>, but my reply ended up being too long not to post it over here. I don't know if I am the only one here but I don't fully understand his post and arguments.<br> <br> Clustering the web server and clustering the model are just two parts of clustering, not exclusive. </span></p>     <p class="MsoNormal" style=""><span style="" lang="EN-US">In a LAMP application, clustering the model is traditionally done by clustering the DB (MySQL) which is a no brainer. Clustering the web server does not always implies sharing the &quot;HTTP session&quot;. For example you can limit yourself to use cookies. For many web apps this works well. </span></p>         <p class="MsoNormal" style=""><span style="" lang="EN-US">For more stateful web apps, there are strategies to avoid clustering the session, you can make one client attack one server only for his whole session duration. Another strategy is to use DB where you would use a session. This is actually reported to work quite well. If my memory is right, this is how Friendster rewrote its app (used to be Java and session based, moved to PHP+DB).<br> <br> EJBs are not about clustering the model more than Spring, they are about clustering the business logic. And I don't see how EJB3 is more scalable than Hibernate.</span></p> 
