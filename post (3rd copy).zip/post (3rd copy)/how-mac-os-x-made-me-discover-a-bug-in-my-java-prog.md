+++
title = "How Mac Os X Made Me Discover a Bug in my Java Prog"
date = 2006-03-14T20:15:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<a onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}" href="http://photos1.blogger.com/blogger/6384/1303/1600/Image%201.jpg"><img style="display:block; margin:0px auto 10px; text-align:center;cursor:pointer; cursor:hand;" src="http://photos1.blogger.com/blogger/6384/1303/400/Image%201.jpg" border="0" alt="benham disc screenshot" /></a><br />Yesterday I had some free time to finally find out why MacOs X would not display my little applet properly. I checked various JDKs for MacOs, no difference. I checked if it was due to antialiasing use, no luck. I actually found out there was an error in the way I displayed images. I did not call repaint() between each image change. Strangely, it worked fine on Windows with many JDKs. Anyway now my  <a href="http://31416.org/info/benham.html" target="_blank" onclick="return top.js.OpenExtLink(window,event,this)">Benham Disc Applet</a> is working on Apple computers as well.<br><br>
