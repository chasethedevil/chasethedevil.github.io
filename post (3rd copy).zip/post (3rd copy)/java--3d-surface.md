+++
title = "Java & 3D Surface"
date = 2009-12-18T16:07:00Z
updated = 2009-12-18T16:11:55Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I have been looking all around the web for a Java library that can draw a simple 3D surface. And I did not find any. Most charting library, including the well known JFreeChart, can only draw 2D charts. <br /><br />I am quite shocked that something that has been in Excel for 15 years is still not available in Java. And it's not easy to make your own.
