+++
title = "Using MiG Layout For Better Swing Development"
date = 2008-04-29T18:27:00Z
updated = 2008-04-29T18:52:01Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I have forgotten a few libraries in my <a href="http://chasethedevil.blogspot.com/2008/04/better-java-swing-development.html">Better Swing Development</a> article, and notably <a href="http://www.miglayout.com">MiGLayout</a>.<br /><br />GridBagLayout is too verbose, and still feels too clumsy. This is why a while back I wrote <a href="http://easygridbag.sourceforge.net">a small tool</a> to help visualize various GridBagLayouts for people who are not used to it. But it would have been much simpler to use a better layout instead.<br /><br />MiGLayout is good, I managed to have good results without almost any practices on not so simple layouts. It also makes the code more concise.<br /><br />Related to my <a href="http://chasethedevil.blogspot.com/2008/04/swixml-review.html">previous post about SwiXml</a>, and as SwiXml does not yet support MiGLayout, I was thinking how easy it would be to achieve something relatively similar. With proper code conventions it is quite easy to describe the GUI outside a Java file, for example, for an easy start in a Beanshell file.<br /><br />The beanshell file would contain components construction, and MiGLayout of them afterwards, that's it. All listeners and component behaviours would be kept in java classes. With this kind of code split. The beanshell file is then extremely simple, as simple as the SwiXml.<br /><br />MiGLayout also has plenty of extra functionalities like "<span style="font-size:85%;"><span style="font-family: courier new;">hidemode 1</span></span>" that can help automatically redoing the layout if a component becomes visible/invisible.
