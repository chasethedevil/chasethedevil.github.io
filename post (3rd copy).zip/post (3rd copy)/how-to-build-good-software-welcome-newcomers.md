+++
title = "How to Build Good Software? Welcome newcomers"
date = 2007-04-18T20:17:00Z
updated = 2007-04-18T20:50:33Z
tags = ["howtobuildgoodsoftware"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Some companies do it naturally, some really don't. In small companies, it is almost natural, people will make a newcomer productive very quickly. In a big company it's not the same game.<p style="text-align: left;">Some important points are:<br /></p><ul><li>Computer ready the first day, well sized (right ram, right power, developers are not MS office users), right OS.  I had experience with having not the right amount of ram, not the right version of OS, not the right user rights to install and use critical software for my work, and all those were known from the team. I also hate when companies give the cheapest computer available for developers/architects. On top of that badly configured computers take often a month to be ready in big companies. It just does not makes sense.<br /></li><li>Network access. I have seen people coming for a short contract and not having network account or email account before 1 week.<br /></li><li>Give documents to read, show applications the person will work with. Involve newcomer in new decisions on his project.<br /></li></ul>Some big companies have it right. I remember my internship at IBM Germany, where on the first day I had a box waiting for me with computer inside, that I had to unpack and install (with OS/2) for my use. I think this is the best way for developers/tech people. And then they recommended excellent reading on the subject I would be working on. It's not that difficult.
