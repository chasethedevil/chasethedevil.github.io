+++
title = "Best Headphones Ever?"
date = 2011-04-06T13:08:00Z
updated = 2011-04-06T13:08:57Z
tags = ["audio"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I just miraculously received some AKG Q701 headphones. I never tried really high end headphones before those. I was used to my Sennheiser HD555, which I thought were quite good already.<br /><br />I always thought there was not much difference between let's say a $100 headphone and a $500 one, and that only real audiophiles would be able notice the difference: people like Jake who can distinguish artefacts in 320kbps mp3, but not people like me. I was wrong. Those headphones make a real difference, everything seems very clear, and it doesn't feel like listening music through headphones at all, it is much closer to a good hi-fi stereo sound on the ear.
