+++
categories = []
date = "2016-01-19T09:55:32+01:00"
description = ""
keywords = []
title = "Linear and Flat forward interpolation with cash dividends"

+++

When the dividend curve is built from discrete cash dividends, the dividend yield is discontinuous at the dividend time as the asset price jumps from the dividend amount. 
This can be particularly problematic for numerical schemes like finite difference methods. In deed, a finite difference grid
will make use of the forward yield (eventually adjusted to the discretisation scheme), which explodes then. 
Typically, if one is not careful about this, then increasing the number of time steps does not increase accuracy anymore, as 
the spike just becomes bigger on a smaller time interval. A simple work-around is to limit the resolution to one day.
This means that intraday, we interpolate the dividend yield.

If we simply interpolate the yields linearly intraday, then the yield becomes continuous again, and numerical schemes will work much better.
But if we take a look at the actual curve of "forward" yields, it becomes sawtooth shaped!
{{< figure src="/post/linear_flat_forward.png" title="effective forward drift used in the finite difference grid with 4 time-steps per day" >}}
On the above figure, we can see the Dirac like forward yield if we work with the direct formulas, while interpolating intraday allows to smooth out the initial Dirac overall the interval corresponding to 1-day.

In reality, one should use flat forward interpolation instead, where the forward yield is maintained constant during the day. The forward rate is defined as
<div>$$f(t_0,t_1)= \frac{r(t_1) t_1 -r(t_0) t_0}{t_1-t_0}$$</div>
where the continuously compounded rate \\(r\\) is defined so that \\(Z(0,t)= e^{-r(t)t}\\).
In the case of the Black-Scholes drift, the drift rate is defined so that the forward price (not to confuse with the forward rate) \\(F(0,t)= e^{-q(t)t}\\).

The flat forward interpolation is equivalent to a linear interpolation on the logarithm of discount factors.
In ACT/365, let \\(t_0=\max\left(0,\frac{365}{\left\lceil 365 t \right\rceil-1}\right), t_1 = \frac{365}{\left\lceil 365 t \right\rceil}\\), the interpolated yield is:
<div>$$\bar{q}(0,t)t = q(t_0)t_0\frac{t_1-t}{t_1-t_0} + q(t_1)t_1\frac{t-t_0}{t_1-t_0}\text{.}$$</div>
Another work-around would be to model this via proportional dividends instead of a "continuous" yield curve.
