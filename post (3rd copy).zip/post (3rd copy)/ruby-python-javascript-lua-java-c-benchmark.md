+++
title = "Ruby, Python, JavaScript, Lua, Java, C++ benchmark"
date = 2005-07-20T11:49:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Simple benchmark but with interesting comments <a  href="http://acker3.ath.cx/wordpress/archives/7">here</a>:<br> <br> Some of the conclusions are:<br> <ul>   <li>Java interpreter is very good</li>   <li>Java JIT is as fast as C++</li>   <li>Ruby, JavaScript, Python are of similar order of magnitude speed, Ruby the slowest.<br>   </li> </ul> It would have been interesting to benchmark interpreted languages for the JVM.<br> <br> Now for most projects, architecture, not language is key in achieving good performance.<br> <br> Tags: <a rel="tag" href="http://technorati.com/tag/java">java</a> <a  rel="tag" href="http://technorati.com/tag/benchmark">benchmark</a> <a  rel="tag" href="http://technorati.com/tag/programming">programming</a><br>
