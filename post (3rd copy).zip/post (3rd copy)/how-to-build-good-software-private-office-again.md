+++
title = "How to Build Good Software? Private office, again"
date = 2007-04-25T15:01:00Z
updated = 2007-04-25T15:02:29Z
tags = ["howtobuildgoodsoftware"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Apparently it's more a habit of French companies to have big open spaces with no separation at all between people. There is nothing more annoying than having people in conference call in front of you while you are trying to work on something completely different. French people forgot the cubicle part in the American open space idea. So sometimes the room is just a big mess, everybody being able to disturb you anytime. Even if I have no private office, please give me at least a cubicle.
