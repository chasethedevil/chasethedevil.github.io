+++
title = "Procedural Programming in an OO language"
date = 2006-08-08T12:35:00Z
updated = 2007-04-05T14:10:12Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<p class="mobile-post">OO is an old buzzword, that is not required anymore to get an employment. Recruiter seems to prefer SOA, Web Services, and in France, "mutualisation" and "urbanisation". Sometimes I really wonder if OO made it. </p><p class="mobile-post">I am sure many of you are confronted with programmers that love procedural programming in many of your projects. They might use an OO language but in the end will organize everything by "type", split invariably state and logic. Everything will be so much better stateless. And we will create lookup maps to glue everything back together. In a way I feel they remove the OO of the language.</p><p class="mobile-post">It's not necessarily bad programming. Sometimes it is encouraged by standards, after all, that's the way most Javabeans are used. It can be preferable in some places, for example you don't want to mix your XML creating code in the object that has to be transformed to XML, this way of transforming objects to XML has been gone a long time ago in Java.</p><p class="mobile-post">But the excess of it can be quite frustrating.</p>
