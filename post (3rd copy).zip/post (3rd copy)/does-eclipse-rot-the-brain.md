+++
title = "Does Eclipse Rot The Brain?"
date = 2005-10-27T17:42:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Slashdot presented a really insightful article on Visual Studio by Charles Petzold called <a  href="http://charlespetzold.com/etc/DoesVisualStudioRotTheMind.html">Does Visual Studio Rot the Mind.</a> Interestingly it seems that Eclipse does things better than the future Visual Studio. <br> <ul>   <li>Autocomplete in Eclipse is really good and does not suffer of the bottom-up problem M. Petzold mentioned, nor from the forced CTRL-Z.<br>   </li>   <li>There is no Form designer, and in Java it has been the practice to lay out forms programmatically. The Java Layouts have always been scalable, and Java programs very rarely rely on pixels.</li>   <li>There is no unnecessary import statements.<br>   </li> </ul> His positive feedback on XAML is interesting, especially since he thinks this allows for a better automatic UI.<br> <br> More importantly, he makes a good point on the exponential increase of method/classes/properties names to use for a regular programmer. This raises a serious question about how viable are the current tools.<br> <br>
