+++
title = "NetBeans 6.0M10 out without announcement yet!"
date = 2007-06-30T07:15:00Z
updated = 2008-04-24T13:39:59Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I just found it while browsing netbeans website, here is the <a href="http://dlc.sun.com.edgesuite.net/netbeans/download/6.0/milestones/m10/">link</a>. Netbeans is starting to be much more interesting that it used to be&nbsp; before  5.5, even though shortcuts are a pain, because so different from most other editors, and not always defined for important tasks. I like the all integrated feeling without plugin and slugishness by default.<br> 
