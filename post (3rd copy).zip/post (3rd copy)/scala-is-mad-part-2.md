+++
title = "Scala is Mad (part 2)"
date = 2013-02-13T16:20:00Z
updated = 2013-02-13T16:32:50Z
tags = ["scala", "java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I still did not abandon Scala despite my <a href="http://chasethedevil.github.io/post/scala-is-mad/">previous post</a>, mainly because I have already quite a bit of code, and am too lazy to port it. Furthermore the issues I detailed were not serious enough to motivate a switch. But these days I am more and more fed up with Scala, especially because of the Eclipse plugin. I tried the newer, the beta, and the older, the stable, the conclusion is the same. It's welcome but:<br /><ul><li>code completion is not great compared to Java. For example one does not seem to be able to see the constructor parameters, or the method parameters can not be automatically populated.</li><li>the plugin makes Eclipse *very* slow. Everything seems at least 3-5x slower. On the fly compilation is also much much slower than Java's.</li></ul><br />It's nice to type less, but if overall writing is slower because of the above issues, it does not help. Beside curiosity of a new language features, I don't see any point in Scala today, even if some of the ideas are interesting. I am sure it will be forgotten/abandoned in a couple of years. Today, if I would try a new language, I would give Google Go a try: I don't think another big language can make it/be useful on the JVM (beside a scripting kind of language, like JavaScript or Jython).<br /><br />Google Go focuses on the right problem: concurrency. It also is not constrained to JVM limitation (on the other side one can not use a Java library - but open source stuff is usually not too difficult to port from one language to another). It has one of the fastest compilers. It makes interesting practical choices: no inheritance.
