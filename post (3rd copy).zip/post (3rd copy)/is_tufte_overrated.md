+++
categories = []
date = "2016-02-03T16:11:30+01:00"
description = ""
keywords = []
title = "Is Tufte overrated?"

+++
[Tufte](http://www.edwardtufte.com/tufte/) proposes interesting guidelines to present data, or even to design written semi-scientific papers or books. Some advices 
are particularly relevant like the careful use of colors (don't use all the colors of the rainbow just because you can), and
in general don't add lines in a graph or designs that are not directly relevant to the message that needs to be conveyed. There is also a parallel
with Feynman message against (Nasa) [Powerpoint presentations](http://www.zdnet.com/article/death-by-powerpoint/). But other inspirations, are somewhat doubtful. 
He seems to have a fetish for [old texts](http://www.edwardtufte.com/bboard/q-and-a-fetch-msg?msg_id=0000hB). They might be considered pretty, or interesting in some ways, but 
I don't find them particularly easy to read. They look more like esoteric books rather than practical books. If you want to write 
the new Bible for your new cult, it's probably great, not so sure it's so great for a more simple subject.
Also somewhat surprisingly, his own website is not very well designed, it looks like a maze and very end of 90s.

I experimented a bit with the [Tufte latex template](https://tufte-latex.github.io/tufte-latex/). It produced [that document](http://papers.ssrn.com/sol3/Delivery.cfm/SSRN_ID2712316_code1514784.pdf?abstractid=2711720&mirid=1) for example. But someone rightfully pointed out to me
that the reference style was not really elegant, that it did not look like your typical nice science paper references. Furthermore,
 using superscript so much could be annoying for someone used to read math and consider superscript numbers as math symbols. 
In general, there seems to be a conflict between the use of Latex and many Tufte guidelines: 
Latex does not encourage you to lay out one by one each piece, 
something the good old desktop publishing software allow you to do quite well.

I was also wondering a bit on what design to use for a book. And I realised that the best layout to consider is simply the layout
of a book I enjoyed to read. For example, I like the recent SIAM book design, I find that it gives enough space to read the text
and the maths without having the impression of deciphering some codex, and without headache. It turns out there is even a [latex template](http://www.siam.org/books/authors/p_handbook8.php) available.

