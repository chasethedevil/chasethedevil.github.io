+++
title = "Current Popular Subjects In Java Blogs"
date = 2006-03-15T20:00:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Based on my blogs entries and success of other blog entries, I present the current trendy subjects and the not trendy ones:<br><br>In:<br><ul><li>Design Patterns</li><li>Ruby on Rails</li><li>EJB (bashing)<br></li><li>RSS</li> <li>Spring</li><li>Hibernate</li><li>Javascript and AJAX<br></li><li>Java Virtual Machine<br></li></ul>Out:<br><ul><li>RMI</li><li>Portal</li><li>Jini</li></ul>Neutral:<br><ul><li>JDK 5 features</li></ul>As you can see most of the popular stuff is fairly common, not that new. I will do a finer, less common, analysis later if I have time. <br> 
