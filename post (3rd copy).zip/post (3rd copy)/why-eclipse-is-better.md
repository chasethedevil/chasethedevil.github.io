+++
title = "Why Eclipse Is Better"
date = 2007-07-27T14:37:00Z
updated = 2008-04-24T13:39:59Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Initially I adopted Eclipse instead of Emacs because it was more powerful to search code, and it allowed refactoring. I regularly tried other IDEs but always end up back to Eclipse, even though there has been less big improvements in Eclipse in the past years (but lots of small ones). <br><br>I just saw today that Eclipse allowed <a href="http://www.eclipse.org/articles/article.php?file=Article-Unleashing-the-Power-of-Refactoring/index.html">programmatic refactoring</a>. Now that&#39;s something quite amazing, and I don&#39;t think other IDEs do that yet.  <a href="http://langexplr.blogspot.com/2007/07/creating-java-refactorings-with-scala.html">Someone</a> even had fun writing an Eclipse extension in Scala to add a particular kind of refactoring to Eclipse.<br> 
