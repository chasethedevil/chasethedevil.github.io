+++
title = "Java int Overflow Behavior"
date = 2009-06-15T16:15:00Z
updated = 2009-06-15T16:24:40Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

A coworker recently asked me if there was a guaranteed behavior in the case of int overflow. He gave the specific example on:<br />can we rely that int x = Integer.MAX_VALUE + 1 is the same for every JVM on any platform?<br /><br />I thought the answer would be easy to find in the Java specifications document. But I was wrong. It is not clearly defined.<br /><br />I found a trick that suggests this behavior is indeed standard and will stay the same, it is related to type casting. Java guarantees that the cast of a long just truncates the long to int precision. Therefore if<br />long l = Integer.MAX_VALUE;<br />l = l +1;<br />x = (int)l;<br />x has a guaranteed value.<br /><br /><a href="http://java.sun.com/docs/books/jls/third_edition/html/conversions.html">http://java.sun.com/docs/books/jls/third_edition/html/conversions.html</a><br />paragraph 5.1.3
