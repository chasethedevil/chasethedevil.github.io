+++
title = "Ogg better than MPC and MP3 - AAC crap"
date = 2006-01-04T11:47:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

The <a href="http://www.hydrogenaudio.org/forums/index.php?showtopic=36465">latest well done (e.g. blind) listening test</a> comparing Ogg, MPC, MP3, AAC at about 180kbps shows that Ogg is superior to all other compressing formats. It's not that easy to find relevant tests. Many people claim to be able to notice huge differences between CD and MP3 and yet, but confronted to a blind listening test, they are very surprised how difficult it actually is. Hydrogenaudio has a good community of audiophiles.<br> <br> Unfortunately Ogg is not supported officially in iTunes and not supported in the most popular hardware (iPod). It's been a while now Ogg is out, and even if it is a superior format, unless Apple embraces it, I don't see it succeeding. I wish Apple would make a tiny effort.<br> <br> In Java it is possible to play ogg files using <a href="http://www.jcraft.com/jorbis/">Jorbis</a> but I did not find any useable Java player compared to Windows foobar2000 or Linux XMMS or Apple iTunes. <br> <br> <br> 
