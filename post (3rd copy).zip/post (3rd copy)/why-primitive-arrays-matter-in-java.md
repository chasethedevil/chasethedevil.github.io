+++
title = "Why primitive arrays matter in Java"
date = 2012-02-29T10:01:00Z
updated = 2012-12-12T16:13:38Z
tags = ["finance", "quant", "math"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

In the past, I have seen that one could greatly improve performance of some Monte-Carlo simulation by using as much as possible <span style="font-size: x-small;"><span style="font-family: &quot;Courier New&quot;,Courier,monospace;">double[][]</span></span> instead of arrays of objects.<br /><br />It was interesting to read <a href="http://flavor8.com/index.php/2012/02/25/java-performance-autoboxing-and-data-structure-choice-obviously-matter-but-by-how-much/">this blog post explaining why that happens</a>: it is all about memory access.
