+++
title = "Giving Fedora Another Chance"
date = 2013-08-14T22:15:00Z
updated = 2013-12-27T17:42:27Z
tags = ["linux"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I have had some stability issues with the Ubuntu 13.04 on my home computer, not on my laptop. It might be related to hard disk encryption (out of curiosity I encrypted my main hard drive in the installer option, resulting in a usable but quite slow system - it's incredible how much the hard drive is still important for performance). I did not have any particular issue on my work laptop with it.<br /><br />Anyway I gave Fedora 19 a try, with Gnome Shell, even if I am no particular fan of it. So far so good, it seems more stable than my previous Fedora 17 trial, and I get used to Gnome Shell. It's quite different, so it takes a while to get used to, but it is as productive as any other env (maybe more so even).<br /><br />It made me notice that Ubuntu One cloud storage is much less open that it seems: it's extremely difficult to make it work under Fedora. Some people manage this, I did not. I moved to owncloud, which fits my needs. 
