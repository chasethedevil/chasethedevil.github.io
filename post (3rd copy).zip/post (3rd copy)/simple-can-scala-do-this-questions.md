+++
title = "Simple 'Can Scala Do This?' Questions"
date = 2013-06-11T00:28:00Z
updated = 2013-06-11T00:28:17Z
tags = ["scala", "java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Today, a friend asked me if Scala could pass primitives (such as Double) by reference. It can be useful sometimes instead of creating a full blown object. In Java there is commons lang MutableDouble. It could be interesting if there was some optimized way to do that.

One answer could be: it's not functional programming oriented and therefore not too surprising this is not encouraged in Scala.

Then he wondered if we could use it for C#.

I know this used to be possible in Scala 1.0, I believe it's not anymore since 2.x. This was a cool feature, especially if they had managed to develop strong libraries around it. I think it was abandoned to focus on other things, because of lack of resources, but it's sad.

Later today, I tried to use the nice syntax to return multiple values from a method:
var (a,b) = mymethod(1)

I noticed you then could not do:
(a,b) = mymethod(2)

So declaring a var seems pointless in this case.

One way to achieve this is to:

var tuple = mymethod(1)
var a = tuple._1
var b = tuple._2 

This does not look so nice.
