+++
title = "Broken Internet?"
date = 2015-11-09T13:40:00Z
updated = 2015-11-09T13:40:09Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

There is something funny going on with upcoming generic top level domains (gTLDs), they seem to be looked up in a strange manner (at least on latest Linux). For example:<br /><br /><span style="font-family: &quot;Courier New&quot;,Courier,monospace;">ping chrome&nbsp;</span><br /><br />or<br /><br /><span style="font-family: &quot;Courier New&quot;,Courier,monospace;">ping nexus&nbsp;</span><br /><br />returns 127.0.53.53.<br /><br />While existing <a href="https://www.name.com/new-gtld">official gTLD</a>s don't (<span style="font-family: &quot;Courier New&quot;,Courier,monospace;">ping dental</span> returns "unknown host" as expected). I first thought it was a network misconfiguration, but as <a href="https://groups.google.com/forum/#!msg/public-dns-discuss/bzhTQnFqE6I/E9F46xhka98J">I am not the only one to notice this</a>, it's likely a genuine internet issue.<br /><br />Strange times.
