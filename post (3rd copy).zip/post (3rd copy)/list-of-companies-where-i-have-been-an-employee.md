+++
title = "List of companies where I have been an employee"
date = 2012-01-11T02:14:00Z
updated = 2012-01-27T13:39:23Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Intern:<br />Siemens (Berlin)<br />IBM (Boeblingen)<br />Osram Sylvania (Beverly, MA)<br /><br />Employee:<br />Cap Gemini (Paris) working for Alcatel<br />Silicomp (Paris) working for Alcatel Nextenso<br />C2labs / one 0 development (San Francisco, CA) working for Whenmobile, Sony Pictures, GoPix, Technorati.<br />Credit Agricole alternative (Paris)<br />Prima solutions (Paris)<br />Esearchvision (Paris)<br />Ulink (Paris)<br />Edifixio (Paris)<br />Horizon (Paris)<br />Darty (Paris)<br />Calypso (Paris)
