+++
title = "Fedora 8 vs. Ubuntu 8"
date = 2008-02-28T14:23:00Z
updated = 2008-02-29T10:44:22Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I had the bad idea of trying (K)ubuntu 8.04 on my home computer. It worked for a few days, but as Ubuntu 8 is still in alpha, changes tend to break everything easily. At one point Wine stopped working, then the DVD, then the sound. I had crashes with USB plug/unplug. It was time to go back to a stable distro. I went back to Fedora 8.<br> <br>I found out that I had missed some positive sides of Fedora 8 before. It compares quite well with the future Ubuntu 8. Both include pulseaudio. Pulseaudio in Fedora 8 is very well integrated, works well by default. I had to manually tweak things with Ubuntu, probably because it is an alpha. <br> Both have a relatively new kernel (2.6.23 for Fedora 8, 2.6.24 for Ubuntu 8).<br>Packages I use everyday are as new in both Fedora 8 and Ubuntu 8.<br><br>Fedora 8 is also more stable than it used to be on my machine. Fedora people do their job very well at fixing various bugs after a release. <br> <br>2 drawbacks of Fedora:<br><ul><li>the package management. I know by experience that rpm+yum is more problematic with dependencies than apt.<br></li><li>Sun Java not installed by default (IcedTea instead). Being a Java developer, the reference is Sun JDK. Plus Sun JDK is open enough for me.<br> </li></ul>Other than that, Fedora 8 is excellent. I feel it has more features than Ubuntu: pulseaudio already well integrated, SELinux, Firewall by default.<br><br>Don&#39;t make the same mistake, don&#39;t install an alpha linux distro. It used to work without problems back in the days. I have used Gentoo, Slackware with custom kernel without troubles. Nowadays it seems quite risky to go without a distro that has not been well tested.<br>
