+++
title = "Vim setup"
date = 2007-07-27T16:13:00Z
updated = 2007-07-27T16:13:09Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Here is my Vim setup information for reference<br><br>in .vimrc or _vimrc, add at the beginning:<br><blockquote style="border-left: 1px solid rgb(204, 204, 204); margin: 0pt 0pt 0pt 0.8ex; padding-left: 1ex;" class="gmail_quote"> set langmenu=en_US.ISO_8859-1<br>set gfn=Bitstream_Vera_Sans_Mono:h9:cANSI<br>colorscheme oceandeep<br></blockquote><br>First line is to avoid menus in French.<br>The font (you can <a href="http://ftp.gnome.org/pub/GNOME/sources/ttf-bitstream-vera/1.10/"> find here</a>) is simply <a href="http://www.kuro5hin.org/story/2004/12/6/11739/5249">the best programmer&#39;s font</a>.<br>oceandeep mode can be found <a href="http://www.tomsdiner.org/vim/oceandeep/index.html">here</a> .<br> 
