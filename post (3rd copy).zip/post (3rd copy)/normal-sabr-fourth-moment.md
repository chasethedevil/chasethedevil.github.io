+++
categories = ["quant"]
date = "2018-06-11T20:56:42+01:00"
description = ""
keywords = ["quant"]
title = "The Fourth Moment of the Normal SABR Model"

+++
I was wondering if I could use the SABR moments to calibrate a model to SABR parameters directly. It turns out that the SABR moments have relatively
simple expressions when \\(\beta=0\\), that is, for the normal SABR model (with no absorption). This is for the pure SABR stochatic volatility model, not the Hagan approximation.
For the Hagan approximation, we would need to use the replication by vanilla options to compute the moments.

I first saw a simple derivation of the fourth moment in Xavier Charvet and Yann Ticot 2011 paper 
[Pricing with a smile: an approach using Normal Inverse Gaussian distributions with a SABR-like parameterisation](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=1968453). 
I discovered a more recent (2013) paper from Lorella Fatone et al. [The use of statistical tests to calibrate the normal SABR model](https://www.degruyter.com/view/j/jip.2013.21.issue-1/jip-2012-0093/jip-2012-0093.xml)
with simple formulae for the third and fourth moments (sci-hub.nu is your friend to read this). I had actually derived the third moment myself previously, based on the straighforward approach from Xavier Charvet, which
consists merely in applying the Ito-Doeblin formula several times. Funnily, Xavier Charvet and Yann Ticot make it Irish, by calling it the Ito-Dublin formula.

Now the two papers lead to a different formula for the fourth moment. I did not have the courage to find out where exactly was the mistake of Lorella Fatone et al., as their paper
is much more abstract, and follow a somewhat convoluted path to derive the formula. But I could not find a mistake in Xavier Charvet and Yann Ticot paper. They don't directly give
the fourth moment, but it is trivial to derive the centered fourth moment from their formulae. By centered, I mean the fourth moment of the process \\(F(t)-F(0)\\) where \\(F(0)\\) is the 
initial forward price.

$$ \frac{A}{\nu^2}\left(e^{6\nu^2 t}-1\right)+2\frac{B}{\nu^2}\left(e^{3\nu^2 t}-1\right)+6\frac{C}{\nu^2}\left(e^{\nu^2 t}-1\right) $$
with
$$ A = \frac{\alpha^4 (1+ 4\rho^2)}{5 \nu^2}\,,$$
$$ B = -\frac{2 \rho^2 \alpha^4}{\nu^2}\,,$$
$$ C = - A - B \,.$$

Fatone et al. includes a factor \\(\frac{1}{3}\\) in front of \\(\rho^2\\), which I believe is a mistake. There is however
no error in their third moment.

Unfortunately, my quick mapping idea does not appear to work so well for long maturities.
