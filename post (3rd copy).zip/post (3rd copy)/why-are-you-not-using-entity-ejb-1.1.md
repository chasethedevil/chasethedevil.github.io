+++
title = "Why are you not using Entity EJB 1.1?"
date = 2007-02-07T16:38:00Z
updated = 2007-04-05T14:10:12Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<div>I am currently quite busy learning about Websphere Commerce. I was surprised to notice that they still use Entity EJBs 1.1. My experience was that many companies turned away from Entity EJBs, sometimes from the beginning, preferring TopLink or Hibernate (later). </div> <div>&nbsp;</div> <div>I know that Entity EJBs are more heavy to use than Hibernate, but with the proper tooling support, it&#39;s not really a big issue. Are there more fundamental reasons? There are probably some mapping limitations, but IBM implementation is apparently quite good in term of features. </div> <div>&nbsp;</div> <div>I will write a complete post about my own analysis of EJB 1.1 vs IBM EJB 1.1 vs EJB 3.0 vs Hibernate, but I was wondering first what was your feedback on EJB 1.1.</div> 
