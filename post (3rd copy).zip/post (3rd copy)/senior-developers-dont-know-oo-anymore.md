+++
categories = ["programming", "java"]
date = "2018-03-08T20:56:42+01:00"
description = ""
keywords = ["programming", "java"]
title = "Senior Developers Don't Know OO Anymore"

+++
It has been a while since the good old object-oriented (OO) programming is not trendy anymore. Functional programming or more dynamic programming (Python-based) have been the trend, with an excursion in template based programming for C++ guys. Those are not strict categories: Python can be used in a very OO way, but it's not how it is marketed or considered by the community.

Recently, I have seen some of the ugliest refactoring in my life as a programmer, done by someone with at least 10 years of experience programming in Java. It is a good illustration because the piece of code is particularly simple (although I won't bother with implementation details). The original code was a simple boolean method on an object such as

{{< highlight java >}}
public class Dog
    public boolean isHappy() { ... }
    public void setHappy(boolean isHappy) { ... }
{{< / highlight >}}

The methods were marked deprecated, and instead, new "utility" methods replaced it:

{{< highlight java >}}
public class DogUtil
    public static boolean isHappy(Dog dog) { ... }
    public static void setHappy(Dog dog, boolean isHappy) { ... }
{{< / highlight >}}

This is really breaking OO and moving back to procedural programming.

In a big (but not that big in reality) company, it is quite a challenge to avoid such code transformations. The code might be written by a team with a different manager, managers try to play nice to each other. And is it really worth fighting over such a trivial thing? if some low level (in the company hierarchy) programmer reports this, he is more likely to be labeled as a black sheep. Most managers prefer white sheeps.

More generally software is like entropy: it can start from a simple and clean state, but eventually it will always grow complex and somewhat ugly. And you end up with the Cobol syndrome, where people don't really know anymore what the software is doing, can't replace it as it is used (but nobody can tell exactly which parts), and "developers" do only small fixes and evolutions (patches) in an obsolete language on a system they don't really understand.



