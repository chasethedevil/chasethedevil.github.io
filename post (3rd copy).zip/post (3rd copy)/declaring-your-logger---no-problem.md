+++
title = "Declaring Your Logger - No Problem"
date = 2006-12-29T11:45:00Z
updated = 2007-04-05T14:10:12Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I used to like the <a href="http://www.javaspecialists.co.za/archive/newsletter.do?issue=137&amp;locale=en_US">java specialists newsletter</a>, most news used to be a bit challenging. Nowadays however the quality is lower. In the  <a href="http://www.javaspecialists.co.za/archive/newsletter.do?issue=137&amp;locale=en_US">latest news</a>, the author proposes to use the StackTrace to get the class name, in order to declare a Logger independently of any explicit reference to the class name. <br><br>While this is a clever hack, it still requires some code to be duplicated in every class, compared to Aspect/IoC approach. But was there really a problem with declaring loggers the usual way in the first place?<br>  <br> With modern IDEs, most people just create a template for the logger declaration line. Also, renaming MyClass to MyClass2 will rename MyClass.class to MyClass2.class automatically. Here is my template for Eclipse to which I assigned the short name log4j:<br> <br><blockquote style="border-left: 1px solid rgb(204, 204, 204); margin: 0pt 0pt 0pt 0.8ex; padding-left: 1ex;" class="gmail_quote"> private static final Logger LOG = Logger.getLogger(${enclosing_type}.class);</blockquote><br><br> 
