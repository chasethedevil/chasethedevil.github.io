+++
title = "What's Your Favorite Design Pattern"
date = 2005-12-27T12:18:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Once in a job interview, someone asked me &quot;What's your favorite design pattern?&quot;. I was first surprised at the question. Usually a design pattern is about solving a problem not about a personal preference. I wondered if it was a trick question of some sorts. I was hesitating with my answer and asked more about the meaning of the question. I just had to really give the pattern I liked the most! I really should not have but I ended up pleasing my interviewer and said &quot;the decorator pattern&quot;. At least its name is somehow related to arts. <br> <br> Then he said his favorite one was &quot;the template pattern&quot;. He was really into it because he could use it anywhere. For him it was like the best thing since sliced bread. <br> <br> Sheesh! just an abstract class. What kind of pattern is that!?! Design Patterns discussions can be really dull.<br> 
