+++
categories = ["linux"]
date = "2017-01-26T09:55:32+01:00"
description = ""
keywords = ["linux"]
title = "Samsung Wireless Printer under Fedora 25"
+++
This is a note for those who want to setup a Samsung wireless printer under Linux. It is quite simple,
[this forum post](https://ubuntuforums.org/showthread.php?t=2263245) helped me, the actual useful steps on Fedora 25 are:

* download tar.gz linux driver from [Samsung website](http://www.samsungsetup.com/). As root, unpack & install:
```
tar xvzf SamsungPrinterInstaller.tar.gz 
cd uld
./install.sh
```

* in the printer menu, lookup for the wireless key (8 digits),
* connect to the printer Wifi network with a computer using the wireless key,
* enter the network gateway IP, this is typically [http://192.168.3.1](http://192.168.3.1),
* click on Login with user "admin" and password "sec00000",
* open the network wifi settings and select "Easy Wi-Fi Settings",
* connect back to your wireless network,
* add the network printer via the printer settings wizard, or alternatively through CUPS interface [http://localhost:631](http://localhost:631).

That's it. Printer and scanner will then work on your local Wi-Fi network.
