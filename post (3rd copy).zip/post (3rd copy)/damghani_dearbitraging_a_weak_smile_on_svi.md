+++
categories = ["quant"]
date = "2016-06-15T09:55:32+01:00"
description = ""
keywords = ["quant"]
title = "Dearbitraging a weak smile on SVI with Damghani's method"

+++
Yesterday, I wrote about some [calendar spread arbitrages with SVI](/post/svi_zeliade_arbitrage/). Today I am looking at the famous example of butterfly spread arbitrage from Axel Vogt.
<div>$$(a, b, m, \rho, \sigma) = (−0.0410, 0.1331, 0.3586, 0.3060, 0.4153)$$</div>
The parameters obey the weak no-arbitrage constraint of Gatheral, and yet produce a negative density, or equivalently, a negative denominator in the local variance Dupire formula. 
Those parameters are mentioned in Jim Gatheral and Antoine Jacquier paper on [arbitrage free SVI volatility surfaces](http://ssrn.com/abstract=2033323) and also in Damghani's paper [dearbitraging a weak smile](http://papers.ssrn.com/sol3/papers.cfm?abstract_id=2428532).

Gatheral proposes to adjust just two of the parameters (corresponding to call wing and minimum variance) and run an optimizer with a large penalty on arbitrage to find the best-fit SVI parameters.
The arbitrage can be easily detected by just computing the local variance denominator, which is not much more costly than computing the implied variance (the analytical derivatives come almost for free):
<div>$$g(y)=1 - \frac{y}{w}\frac{\partial w}{\partial y}	+ \frac{1}{4}\left(-\frac{1}{4}-\frac{1}{w}+\frac{y^2}{w^2}\right)\left(\frac{\partial w}{\partial y}\right)^2	+ \frac{1}{2}\frac{\partial^{2} w}{\partial y^2}$$</div>
where \\(w\\) is the total implied variance in log-moneyness \\(y\\) coming from the SVI formula.

It is also possible include this penalty directly in the Nelder-Mead minimization of Zeliade's quasi explicit calibration. In this case, all the parameters will be optimized. It is also not much slower than the more classic minimization without penalty.
While it results a much lower RMSE, the solution might not be as visually pleasing as Gatheral's one. 

I was curious to see what Damghani's technique would produce on this same example. Instead of doing the minimization with the full denominator evaluation, Damghani uses a simpler no-arbitrage necessary constraint
on the first derivative: 
<div>$$|\frac{\partial w}{\partial y}|<4 e $$</div>
and iteratively search for \\(e \in [0,1]\\) so that no arbitrage remains in \\(w\\). The standard weak no-arbitrage constraint stands for \\(e=1\\). Dhamgani thus proposes to enforce a stronger "weak" constraint during the minimization, in order to de-arbitrage.
Note, the equations in the paper have a typo (everywhere), the \\(b\\) parameter should be a factor in front of the parenthesis.

Now, it seems twisted to not enforce directly the real no arbitrage constraint in the minimization, which is actually not much more complex to evaluate, and to instead rely on some weak condition, that we make stronger by steps.
There would be no loop over the minimization needed. Does this produce any good result?
{{< figure src="/post/svi_dearbitraging_variance.png" title="implied variance with Axel Vogt SVI parameters" >}}

The graph is clear, the technique produces crap. This is the local variance denominator:
{{< figure src="/post/svi_dearbitraging_g.png" title="local variance denominator g with Axel Vogt SVI parameters" >}}


Maybe I misunderstood something big in this paper, but so far it was just a waste of time.
