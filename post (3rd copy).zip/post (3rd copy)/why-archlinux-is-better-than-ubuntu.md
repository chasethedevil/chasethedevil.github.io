+++
title = "Why ArchLinux Is Better Than Ubuntu"
date = 2008-11-14T10:41:00Z
updated = 2008-11-14T10:58:07Z
tags = ["linux"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

It has been now a week since I have installed <a href="http://www.archlinux.org">ArchLinux</a> on my home computer. I daily use Ubuntu 8.10 at work.<br /><br />Since the Ubuntu upgrade from 8.04 to 8.10 I have had problems with my Xorg settings. I just found out the nvidia-settings utility does not manage to save the configuration anymore. So I have to <a href="https://bugs.launchpad.net/ubuntu/+source/nvidia-settings/+bug/286424/">lookup on google</a> and try to fix it. And that annoys me. That annoys me because the promess of Ubuntu is that everything works out of the box. In reality, you have to mess with the configuration as much as with ArchLinux.<br /><br />There are 2 negative points of ArchLinux when compared to Ubuntu:<br />- The install on a new computer takes a lot of time (not the 30min of Ubuntu) to have a decent desktop running. It can only be done by people ready to fiddle with config files0. But it is well documented in the Arch wiki. So ArchLinux is definately not newbie oriented.<br />- Some proprietary software might not be installed easily. For a long time Oracle was not trivial to install. Now there is an AUR file for it, so it is quite simple.<br /><br />Now the positive side:<br />- good KDE 4.1.3 available<br />- more up-to-date packages<br />- "transparent" updates - no big breaking the system at each release.<br />- learn to use the useful configuration files. They are not many to use in ArchLinux. One feels much more in control on what's installed and what's happening. They are not many config files to know in the end. Configuration ends up being no more difficult (for someone not addicted to point and click) than in Ubuntu.<br />- fast boot<br />- no crap forced upon you, for example PulseAudio. I have less problems with pure ALSA.<br />- does not disappoint. You know you have to fiddle with the config from the start.
