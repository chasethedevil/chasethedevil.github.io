+++
title = "Akima for Yield Curve Interpolation ?"
date = 2013-06-03T00:07:00Z
updated = 2013-12-27T17:43:08Z
tags = ["quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

On my test of <a href="http://www.google.com/url?sa=t&amp;rct=j&amp;q=&amp;esrc=s&amp;source=web&amp;cd=2&amp;cad=rja&amp;ved=0CDgQFjAB&amp;url=http%3A%2F%2Fpapers.ssrn.com%2Fsol3%2Fpapers.cfm%3Fabstract_id%3D2175002&amp;ei=d8GrUb70CJCChQeA7IHoCg&amp;usg=AFQjCNHHizgzORef228lnYX3HygLb9okAg&amp;sig2=NYbhD30aD7sD8TS7CYodzw&amp;bvm=bv.47244034,d.ZG4">yield curve interpolations</a>, focusing on parallel delta versus sequential delta, <a href="http://200.17.213.49/lib/exe/fetch.php/wiki:internas:biblioteca:akima.pdf">Akima</a> is the worst of the lot. I am not sure why this interpolation is still popular when most alternatives seem much better. Hyman presented some of the issues with Akima in <a href="http://epubs.siam.org/doi/abs/10.1137/0904045">his paper</a> in 1983. <br /><br />In the following graph, a higher value is a higher parallel-vs-sequential difference. <br /><br /><div class="separator" style="clear: both; text-align: center;"><a href="http://4.bp.blogspot.com/-y1jkd6Pu4Y8/UavBtMgvLQI/AAAAAAAAGc4/CDRwTqv-suc/s1600/snapshot18.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="272" src="http://4.bp.blogspot.com/-y1jkd6Pu4Y8/UavBtMgvLQI/AAAAAAAAGc4/CDRwTqv-suc/s400/snapshot18.png" width="400" /></a></div><div class="separator" style="clear: both; text-align: center;"></div>That plus the Hagan-West example of a tricky curve looks a bit convoluted with it (although it does not have any negative forward).<br /><br /><div class="separator" style="clear: both; text-align: center;"><a href="http://4.bp.blogspot.com/-kKk7NEYtUaw/UavB245C8OI/AAAAAAAAGdA/elBq-es3jWY/s1600/snapshot19.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="225" src="http://4.bp.blogspot.com/-kKk7NEYtUaw/UavB245C8OI/AAAAAAAAGdA/elBq-es3jWY/s400/snapshot19.png" width="400" /></a></div>I have used Quantlib implementation, those results make me wonder if there is not something wrong with the boundaries.
