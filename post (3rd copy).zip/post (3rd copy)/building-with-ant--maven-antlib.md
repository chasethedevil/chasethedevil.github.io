+++
title = "Building With Ant + Maven Antlib?"
date = 2006-12-14T10:51:00Z
updated = 2007-04-05T14:10:12Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I discovered a new baby in the build world. Some open source projects use a combination of ant and maven. I thought you could vaguely use ant from maven. But I did not know of <a href="http://maven.apache.org/ant-tasks.html"> Maven Antlib</a> that allows you to use maven2 from Ant. Why would you use Maven2 from Ant?<br><br><ul><li>because Maven2 requires to adapt your project to its standard hierarchy, or to have excellent Maven2 skills to create your own archetype for each existing project. </li><li>because everybody knows Ant, but Ant does not manage dependencies well. Maven2 Antlib can be used just for that: managing dependencies.</li></ul>I have to try that on a real project to see if it is really an easy and flexible approach, better than plain Maven2. <br><br> 
