+++
title = "Moving The Needle"
date = 2012-08-21T21:23:00Z
updated = 2012-08-21T21:23:55Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<span class="yj-message">These days the expression "move the needle" is popular where I work. I did not know it was an expression of Steve Jobs.</span><br /><span class="yj-message"><br /> “The company starts valuing the great salesmen, because they’re the  ones who can move the needle on revenues, not the product engineers and  designers. So the salespeople end up running the company.… [Then] the  product guys don’t matter so much, and a lot of them just turn off. It  happened at Apple when [John] Sculley came in, which was my fault, and  it happened when Ballmer took over at Microsoft. Apple was lucky and it  rebounded, but I don’t think anything will change at Microsoft as long  as Ballmer is running it.”</span><br /><span class="yj-message"><br /> This is from the biography, just saw that in an interesting article about Microsoft problems:&nbsp;</span><br /><span class="yj-message"><a href="http://www.vanityfair.com/business/2012/08/microsoft-lost-mojo-steve-ballmer?mbid=social_retweet">http://www.vanityfair.com/business/2012/08/microsoft-lost-mojo-steve-ballmer?mbid=social_retweet </a></span><br /><span class="yj-message"><br /></span><span class="yj-message">I would not take those words literally: I have seen a company with the inverse problem: developping technical stuff for the sake of it, without a connection to what the market (or the users) are really after.&nbsp;</span><br /><br /><span class="yj-message">In the case of Apple, the engineers and designers actually know quite well what the market is after, maybe more so than the salespeople. But it is unfortunately not the case in every company. Still the case of people turning off because it is too hard to convince the hierarchy is probably quite common.</span>
