+++
title = "Web Services No Better Than CORBA?"
date = 2006-04-10T15:23:00Z
updated = 2007-04-05T14:10:39Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<div>Richard Monson-Haefel (RMH), author of the famous Enterprise Java Beans (O'Reilly) and of a Web Services book is making an alarming claim about JAX-WS, the new Java web services standard: </div> <div> <blockquote class="gmail_quote" style="PADDING-LEFT: 1ex; MARGIN: 0px 0px 0px 0.8ex; BORDER-LEFT: #ccc 1px solid"><strong>JAX-WS still sucks!</strong></blockquote></div> <div>&nbsp;</div> <div>In an effort to write a client to real world web services (for Google, Amazon, Ebay), <a href="http://rmh.blogs.com/weblog/2006/04/redeemed_jaxws_.html">he mostly&nbsp;failed</a>. Errors seem to be largely related to WSDL to Java conversion. Jason Green, a JBoss developer, managed to get quickly a web service working for Ebay, but analysis by RMH suggest that hundreds of classes were generated for this simple one method web service. </div> <div>&nbsp;</div> <div>Recently I had to try to do CORBA client classes by hand in Java since the rmic tool was not working that well to generate classes that could be run on a client JVM of different version than the server JVM. It proved to be a no-go in the end, because of the complexity involved not only in coding, but more on maintaining those modified generated classes. This would have required coding a tool dedicated for that purpose. We chose to pass simpler objects, differently,&nbsp;which looks just like a hack&nbsp;to avoid having CORBA issues. I am amazed that after that many years of CORBA, there are still simple cases where it does not work properly automatically.  </div> <div>&nbsp;</div> <div>Seeing that there is the same kind of problem with Web Services (IDL to Java translation) makes me wonder about Web Services &quot;improvement&quot; over CORBA. And WSDL is definitely less readable than CORBA IDL.</div>  <div>&nbsp;</div>
