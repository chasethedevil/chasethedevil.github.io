+++
categories = ["quant", "math"]
date = "2018-02-05T13:56:42+01:00"
description = ""
keywords = ["quant", "math"]
title = "Discrete Sine Transform via the FFT"
+++
Several months ago, I had a quick look at [a recent paper](https://papers.ssrn.com/sol3/Papers.cfm?abstract_id=2585529) describing how to use
Wavelets to price options under stochastic volatility models with a known characteristic function.
The more classic method is to use some numerical quadrature directly on the Fourier integral as described [in this paper](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2362968) for example.
When I read the paper, I was skeptical about the Wavelet approach, since it looked complicated, and with many additional parameters.

I recently took a closer look and it turns out my judgment was bad. The additional parameters can be easily automatically and reliably set
by very simple rules that work well ([a subsequent paper](https://ssrn.com/abstract=2705699) by the same author, which applies the method to Bermudan options, clarifies this). 
The method is also not as complex as I first imagined. And more importantly, the FFT makes it fast. It is quite amazing to see
the power of the FFT in action. It really is because of the FFT that the Shannon Wavelet method is practical. 

Anyway one of the things that need to be computed are the payoff coefficients, and one expression is just the sum of a [discrete Cosine transform](https://en.wikipedia.org/wiki/Discrete_cosine_transform) (DCT) and a discrete Sine transform (DST). 
I was wondering then
about a simple way to use the FFT for the Sine transform. There are many papers around how to use the FFT to compute the Cosine transform. A technique
that is efficient and simple is the one of [Makhoul](https://www.google.fr/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwirtpu5upHZAhUFOBQKHZnHBFoQFgg2MAA&url=http%3A%2F%2Feelinux.ee.usm.maine.edu%2Fcourses%2Fele486%2Fdocs%2Fmakhoul.fastDCT.pdf&usg=AOvVaw0b3sdSzaT-A9fRAGWZbUcP).

The coefficients that need to be computed for all k can be represented by the following equation 
$$	V\_{k} = \sum\_{j=0}^{N-1} a\_j \cos\left(\pi k\frac{j+\frac{1}{2}}{N}\right) + b\_j \sin\left(\pi k\frac{j+\frac{1}{2}}{N}\right) $$
with \\( N= 2^{\bar{J}-1} \\) for some positive integer \\( \bar{J} \\).
Makhoul algorithm to compute the DCT of size N with one FFT of size N consists in

* initialize the FFT coefficients \\(c\_j\\) with:
$$	c\_j = a\_{2j} \quad\,,\quad	c\_{N-1-j} = a\_{2j+1} \quad \text{ for } j = 0,..., \frac{N}{2}-1 $$
* and then from the result of the FFT \\( hat{c} \\), the DCT coefficients \\( \hat{a} \\) are
$$ \hat{a}\_k = \Re\left[ \hat{c}\_j e^{-i \pi\frac{k}{2N}} \right]\,. $$

Makhoul does not specify the equivalent formula for the DST, but we can do something similar. 

* We first initialize the FFT coefficients \\( c\_j \\) with:
$$ c\_j = b\_{2j} \quad\,,\quad	c\_{N-1-j} = -b\_{2j+1} \quad \text{ for } j = 0,..., \frac{N}{2}-1 $$
* and then from the result of the FFT \\(\hat{c}\\), the DST coefficients \\(\hat{b}\\) are
$$\hat{b}\_k = -\Im\left[ \hat{c}\_j e^{-i \pi\frac{k}{2N}} \right]\,. $$

For maximum performance, the two FFTs can reuse the same sine and cosine tables. And the last step of the DCT and DST can be combined together.

Another approach would be to compute a single FFT of size 2N as we can rewrite the coefficients as
$$	V\_{k} = \Re\left[e^{-i \pi \frac{k}{2N}} \sum\_{j=0}^{2N-1} (a\_j + i b_j) e^{-2i\pi k\frac{j}{2N}} \right] $$
with \\(a\_j = b\_j =0 \\) for \\( j \geq N \\)

In fact the two are almost equivalent, since a FFT of size 2N is [decomposed](https://en.wikipedia.org/wiki/Cooley%E2%80%93Tukey_FFT_algorithm) internally into two FFTs of size N.

With this in mind we can improve a bit the above to merge the two transforms together:

* We first initialize the FFT coefficients \\( c\_j \\) with:
$$ c\_j = a\_{2j} + i b\_{2j} \quad\,,\quad	c\_{N-1-j} = a\_{2j+1} -i b\_{2j+1} \quad \text{ for } j = 0,..., \frac{N}{2}-1 $$
* and then from the result of the FFT \\(\hat{c}\\), the coefficients are
$$V\_k = \Re\left[ \hat{c}\_j e^{-i \pi\frac{k}{2N}} \right]\,. $$

And we have computed the coefficients with a single FFT of size N.
