+++
title = "Hibernate Criteria API vs HQL Overhead"
date = 2005-08-10T14:16:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I was wondering what was the framework weight in the performance of my application, and I wanted to check at several frameworks performance. I used <a href="http://jakarta.apache.org/jmeter/">JMeter</a> to benchmark a stripped application (database access through tomcat) under various loads.<br> <br> My very modest test shows no significant difference between Hibernate Criteria API and HQL access for queries. Criteria might be a few milliseconds slower, but my query time will take 10x more time, even for a relatively simple query (my query is has 3 inner joins, is grouped, with a count and takes only 4ms when performed once in mysql under no load). <br> <br> It seems much more important for the Framework of choice to provide good scalability, easy development and maintenance, rather than saving a few cycles, unless the Framework becomes a bottleneck.<br><br /><i>Tags: <a href="http://technorati.com/tag/java" rel="tag">java</a> <a href="http://technorati.com/tag/hibernate" rel="tag">hibernate</a> <a href="http://technorati.com/tag/programming" rel="tag">programming</a></i>
