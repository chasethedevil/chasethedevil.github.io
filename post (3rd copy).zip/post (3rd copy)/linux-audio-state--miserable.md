+++
title = "Linux Audio State = Miserable"
date = 2009-03-19T12:39:00Z
updated = 2009-03-19T12:54:35Z
tags = ["linux"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

There are lots of programs for playing MP3 under linux, a few dealing decently with big libraries. But when you start looking for a program that does crossfade well and manage big libraries easily - there is nothing.<br />Rhythmbox does some crossfade, but crashes when you move manually in the song. Audacious does some crossfade but regularly crashes with crossfade plugin.<br /><br />The real alternative are AIMP2 or Foobar2000 in Wine. It is quite incredible that you can have good solid crossfade in wine and not natively in Linux.<br /><br />Maybe people spent too much time on useless Pulseaudio (I have much less issues using only ALSA).
