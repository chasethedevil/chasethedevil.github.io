+++
categories = ["quant", "programming"]
date = "2019-02-12T20:56:42+01:00"
description = ""
keywords = ["quant", "programming"]
title = "Numba, Pypy Overrated?"

+++
Many benchmarks show impressive performance gains with the use
of [Numba](https://numba.pydata.org/) or [Pypy](https://www.pypy.org/). Numba allows to compile just-in-time some specific methods, while Pypy takes 
the approach of compiling/optimizing the full python program: you use it just like the standard
python runtime. From those benchmarks, I imagined that those  tools would improve my 2D Heston PDE solver
performance easily. The initialization part of my program contains embedded for loops over several 10Ks elements.
To my surprise, numba did not improve anything (and I had to isolate the code, as it would
not work on 2D numpy arrays manipulations that are vectorized). I surmise it does not play well
with scipy sparse matrices.
Pypy did not behave better, the solver became actually slower than with the standard python
interpreter, up to twice as slow, for example, in the case of the main solver loop which only does matrix multiplications and LU solves sparse systems. I did not necessarily expect any performance improvement in this specific loop, since it only consists in a few calls to expensive scipy calculations. But I did not expect a 2x performance drop either.

While I am sure that there are good use cases, especially for numba, I was a bit disappointed
that it likely would require to significantly change my code to have any effect (possibly to not do the initialization with scipy sparse matrices, but then, it is not so clear how). Also, I
find [most](https://www.ibm.com/developerworks/community/blogs/jfp/entry/A_Comparison_Of_C_Julia_Python_Numba_Cython_Scipy_and_BLAS_on_LU_Factorization?lang=en) [benchmarks](https://modelingguru.nasa.gov/docs/DOC-2676) dumb. For example, the 2D ODE solver of the latter uses a simple dense 2D numpy array. On real code,
things are not as simple.

Next I should try Julia again out of curiosity. I tried it [several years ago](/post/modern-programming-language-for-monte-carlo/) in the context of a simple Monte-Carlo simulation and my experiment at the time
was not all that encouraging, but it may be much better at building PDE solvers and not too much work to port my python code. I am curious to see if it ends up being faster, and whether the accessible LU solvers are any good. If Julia delivers, it's a bit of a shame for python, since it has so many excellent high quality numerical libraries. Also when I look back at my old Monte-Carlo test, I bet it would benefit greatly from numba, somewhat paradoxically, compared to my current experiment.
