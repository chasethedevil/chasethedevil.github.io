+++
title = "Exact Forward in Monte-Carlo"
date = 2013-05-13T17:58:00Z
updated = 2013-06-03T01:26:33Z
tags = ["quant", "math"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Where I work, there used to be quite a bit of a confusion on which rates one should use as input to a Local Volatility Monte-Carlo simulation.<br /><br />In particular there is a paper in the Journal of Computation Finance by Andersen and Ratcliffe "The Equity Option Volatility Smile: a Finite Difference Approach" which explains one should use specially tailored rates for the finite difference scheme in order to reproduce exact Bond price and exact Forward contract prices.<br /><br />Code has been updated and roll-backed, people have complained around it. But nobody really made the effort to simply write clearly what's going on, or even write a unit test around it. So it was just FUD, until <a href="http://ssrn.com/abstract=2264327">this paper</a>.<br /><br />In short, for log-Euler, one can use the intuitive forward drift rate: r1*t1-r0*t0 (ratio of discount factors), but for Euler, one need to use a less intuitive forward drift rate to reproduce a nearly exact forward price.
