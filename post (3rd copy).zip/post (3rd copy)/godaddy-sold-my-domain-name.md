+++
title = "Godaddy sold my domain name"
date = 2013-06-24T19:11:00Z
updated = 2013-06-24T19:11:50Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I discovered that suddenly emails sent to me bounced back yesterday. I logged in my godaddy account and to my surprise saw that I did not own any domain name anymore. I looked at my emails to see if I had received a warning as is usually the case when your domain is about to expire. There was none recent, the most recent was from may 2011, the last time I had renewed my domain.<br /><br />I then tried to buy again the same domain name only to discover it was already taken! The whois record indicated a day old registration through godaddy itself.<br /><br />It's no coincidence that godaddy sells for 3 times the price the possibility to try to take over a domain as soon as it will expire. I find particularly dishonest that in this case they fail to warn their own customers that their domain is about to expire. As a result of this policy, someone else will take over the domain through them for a much higher price. A conflict of interest.<br /><br />From now on I will not register a domain through a registrar that offers the service to snatch up a domain.
