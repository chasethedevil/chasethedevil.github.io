+++
categories = ["quant"]
date = "2017-07-10T23:56:42+01:00"
description = ""
keywords = ["web"]
title = "Benham disc in web canvas"

+++
Around 15 years ago, I wrote a small Java applet to try and show the [Benham disk](https://en.wikipedia.org/wiki/Benham%27s_top) effect. Even back then applets were already passé and Flash would have been more appropriate. These days, no browser support Java applets anymore, and very few web users have Java installed. Flash also mostly disappeared. The [web canvas](https://www.w3schools.com/html/html5_canvas.asp) is today's standard allowing to embbed animations in a web page.

This effect shows color perception from a succession of black and white pictures. It is a computer reproduction from the Benham disc with ideas borrowed from "Pour La Science Avril/Juin 2003".
Using a delay between 40 and 60ms, the inner circle should appear <font color="#770000">red</font>, the one in the middle 
<font color="#000077">blue</font> and the outer one <font color="#007700">green</font>. When you reverse the rotation direction,
blue and red circles should be inverted.

<form>
  Delay: <input type="number" name="delay" value="60" id="delayInput"> Reverse <input type="checkbox" value="false" id="reverseInput" onclick="javascript:reverse()"> <input type="button" value="Start" onclick="javascript:startStop()" id="startButton">
</form>

<canvas id="myCanvas" width="480" height="480" style="border:1px solid #000000;">
</canvas> 

<script type="text/javascript">
var c = document.getElementById("myCanvas");
  c.style.width ='100%';
  c.style.height='100%';
  // ...then set the internal size to match
  c.width  = c.offsetWidth;
  c.height = c.offsetWidth;
var x=c.width/2;
var y=x;
linewidth = c.width / 100;
var g = c.getContext("2d");

function paintImage(g, x,y,startArcAngle) {
var radius = 0.9;
var r = radius*x; endAngle = 2*Math.PI/3+startArcAngle;
g.beginPath();
g.arc(x, y, r, Math.PI/3+startArcAngle, endAngle, false);
g.lineWidth = linewidth;
g.strokeStyle = "black";
g.stroke();

radius = 0.8; r = radius*x;
g.beginPath();
g.arc(x, y, r + 1, Math.PI/3+startArcAngle, endAngle, false);
g.stroke();

radius = 0.7; r = radius*x;
g.beginPath();
g.arc(x, y, r + 1, Math.PI/3+startArcAngle, endAngle, false);
g.stroke();

radius = 0.6; r = radius*x; endAngle = Math.PI/3+startArcAngle;
g.beginPath();
g.arc(x, y, r + 1, 0+startArcAngle, endAngle, false); 
g.stroke();

radius = 0.5; r = radius*x;
g.beginPath();
g.arc(x, y, r + 1, 0+startArcAngle, endAngle, false); 
g.stroke();

radius = 0.4; r = radius*x;
g.beginPath();
g.arc(x, y, r + 1, 0+startArcAngle, endAngle, false);
g.stroke();

//  paintImage(g, startArcAngle, 60, 0.3); //red -180 to -60
radius = 0.3; r = radius*x; endAngle = Math.PI+startArcAngle;// if (endAngle > Math.PI*2) endAngle = endAngle - 2*Math.PI 
g.beginPath();
g.arc(x, y, r + 1,  2*Math.PI/3+startArcAngle, endAngle, false); 
g.stroke();
        
radius = 0.2; r = radius*x;
g.beginPath();
g.arc(x, y, r + 1,  2*Math.PI/3+startArcAngle, endAngle, false); 
g.stroke();

radius = 0.1; r = radius*x;
g.beginPath();
g.arc(x, y, r + 1,  2*Math.PI/3+startArcAngle, endAngle, false); 
g.stroke();

g.beginPath();
g.arc(x, y, x,  Math.PI+startArcAngle, Math.PI*2+startArcAngle, false); 
g.fill();
}

var delay = 40;
var currentAnimate = 0;
var animationStartTime = window.performance.now();
var currentIndex = 3;
var angles = [0.0, 2*Math.PI/3, 4*Math.PI/3];

var offscreenCanvas = [document.createElement('canvas'),document.createElement('canvas'),document.createElement('canvas')];
for (var i in offscreenCanvas) {
  offscreenCanvas[i].width = c.offsetWidth;
  offscreenCanvas[i].height = c.offsetWidth;
  g = offscreenCanvas[i].getContext("2d");
  paintImage(g, x, y, angles[i]);
}
g = c.getContext("2d");

//function animate0() {
//  g.clearRect(0,0,c.width, c.height);
//  paintImage(g,x, y,  0.0);
//  currentAnimate = setTimeout(animate1, delay);
//}
//function animate1() {
//  g.clearRect(0,0,c.width, c.height);
//  paintImage(g,x, y,  2*Math.PI/3);
//  currentAnimate = setTimeout(animate2, delay);
//}
//function animate2() {
//  g.clearRect(0,0,c.width, c.height);
//  paintImage(g,x, y, 4*Math.PI/3);
//  currentAnimate= setTimeout(animate0, delay);
//}

window.requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame ||
                              window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;


function animateContinuous(time) {
  var index = Math.floor(((time - animationStartTime) % (3*delay))/delay);
  if (index < 0) index = 0
  if (index != currentIndex) {
    //g.clearRect(0,0,c.width, c.height);
    //paintImage(g, x, y, angles[index]);
    var offscreenContext = offscreenCanvas[index].getContext('2d');
    var image = offscreenContext.getImageData(0,0,c.width,c.height); 
    g.putImageData(image, 0, 0);       
    currentIndex = index;
  }
  currentAnimate = requestAnimationFrame(animateContinuous);
}

function reverse() {
  //tmp = angles[2]; angles[2] = angles[0]; angles[0] = tmp;
  tmp = offscreenCanvas[2]; offscreenCanvas[2] = offscreenCanvas[0]; offscreenCanvas[0] = tmp;
}

function startStop() {
  var elem = document.getElementById("startButton");
  var delayElem = document.getElementById("delayInput");
 if (elem.value=="Stop") {
    elem.value = "Start";
    //clearTimeout(currentAnimate);
    window.cancelAnimationFrame(currentAnimate);
    currentAnimate = 0;
  } else {
    elem.value = "Stop";
    delay = delayElem.value;
    animationStartTime = window.performance.now();
    //animate0();
    currentAnimate = requestAnimationFrame(animateContinuous);
  }
}
</script>
