+++
title = "Spring Web Services, Finally!"
date = 2007-08-23T11:22:00Z
updated = 2008-04-24T13:39:59Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<a href="http://static.springframework.org/spring-ws/site/">Spring Web Services</a> seems to be the technology I have been looking for recently. I am not a Spring bigot (too XML oriented), but here the Spring folks have something right. <br><br>I used to work with Web Services the simple way: create a java class (or EJB), expose it as Web Service through Axis or RAD, generating the WSDL in the process. And then a client would just be the reverse, take the WSDL, use a tool (Axis or RAD) that creates client Java classes from it automatically. Simple, easy. <br><br>But this process starts to fail if you have<br><ol><li>several very similar WSDL: you want reuse instead of copy.</li><li>other means of communicating XML represented by the XML schema embedded in the WSDL, for example via direct MQ use. </li></ol>In those cases, the contract first approach is particularly interesting. However most tools, if they allow contract first approach, they don&#39;t give you enough access on the message itself, and you can do 1), but not 2). I always found a bit silly that Axis or RAD had to have the logic to marshall/unmarshall java objects, but they did not give any explicit API access to do it, or to replace it with a standard way (JAXB 2 for example). <br><br>I found 2 techs that can help:<br><ul><li><a href="http://www.osoa.org/display/Main/SDO+Resources">SDOs (Service Data Objects)</a>: from my short experience, I find it a bit too verbose, and not yet fully mature, as you depend on libraries external to SDO ones for it to work in the case of web services. It can work, and if you use IBM products, it could be a good way to write Web Services Providers/Clients. <br></li><li>Spring Web Services: I have not tried it yet, but it seems to solve exactly the kind of problems I described earlier. And you can plug-in any marshalling/unmarshalling framework you want :).<br></li></ul>There are so many libraries to do web services, and different approaches, that an initiative like Spring Web Services is more than welcome! <br><br> 
