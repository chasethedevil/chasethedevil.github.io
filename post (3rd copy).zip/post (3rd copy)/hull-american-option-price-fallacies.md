+++
title = "Hull American Option Price Fallacies"
date = 2009-05-15T16:01:00Z
updated = 2009-05-15T16:09:58Z
tags = ["finance"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<a onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}" href="http://4.bp.blogspot.com/_9RyqGT46Fbk/Sg13q_LZDrI/AAAAAAAADNE/WHy0J8iNZoY/s1600-h/hull_american_r04_v20_q02_p49.png"><img style="margin: 0pt 10px 10px 0pt; float: left; cursor: pointer; width: 320px; height: 240px;" src="http://4.bp.blogspot.com/_9RyqGT46Fbk/Sg13q_LZDrI/AAAAAAAADNE/WHy0J8iNZoY/s320/hull_american_r04_v20_q02_p49.png" alt="" id="BLOGGER_PHOTO_ID_5336052713901330098" border="0" /></a><br />Hull says American put is best exercised immediately and american call is optimal at expiry like a european. Is this really true?<br /><br />At first it seems really clever and model show clearly this. But if we change the market assumptions only a tiny bit, everything falls down.<br /><br />I could not detail everything in a blog post so I created a <a href="http://31416.appspot.com/static/hullamerican/hull_american_price.html">static web page about it</a>. Everything was produced in Java using algorithm found in popular books and graphs through JFreeChart.
