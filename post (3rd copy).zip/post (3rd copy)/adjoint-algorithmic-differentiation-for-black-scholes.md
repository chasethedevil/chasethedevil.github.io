+++
title = "Adjoint Algorithmic Differentiation for Black-Scholes"
date = 2014-01-21T13:03:00Z
updated = 2014-02-18T09:34:00Z
tags = ["quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<a href="http://en.wikipedia.org/wiki/Automatic_differentiation">Adjoint algorithmic differentiation</a> is particularly interesting in finance as we often encounter the case of a function that takes many input (the market data) and returns one output (the price) and we would like to also compute sensitivities (greeks) to each input.<br /><br />As I am just starting around it, to get a better grasp, I first tried to apply the idea to the analytic knock out barrier option formula, by hand, only to find out I was making way too many errors by hand to verify anything. So I tried the simpler vanilla Black-Scholes formula. I also made various errors, but managed to fix all of them relatively easily.<br /><br />I decided to compare how much time it took to compute price, delta, vega, theta, rho, rho2 between single sided finite difference and the adjoint approach. Here are the results for 1 million options:<br /><br /><blockquote class="tr_bq">FD time=2.13s<br />Adjoint time=0.63s</blockquote><br /><b>It works well</b>, but doing it by hand is crazy and too error prone. It might be simpler for Monte-Carlo payoffs however.<br /><br />There are not many Java tools that can do reverse automatic differentiation, I found <a href="http://www.google.com/url?sa=t&amp;rct=j&amp;q=&amp;esrc=s&amp;source=web&amp;cd=5&amp;cad=rja&amp;ved=0CFAQFjAE&amp;url=http%3A%2F%2Fcluster.grid.pub.ro%2Fwiki%2Findex.php%2FADiJaC_-_Automatic_Differentiation_of_Java_Classfiles&amp;ei=SmDeUtDLCYrG0QWrlIHQDw&amp;usg=AFQjCNHLMwobO6u5jSoUifCdHvE2yPZ6oQ&amp;sig2=wFbGRYjgLenCNGRbrQ1gKQ&amp;bvm=bv.59568121,d.d2k">some thesis</a> on it, with an interesting byte code oriented approach (one difficulty is that you need to reverse loops, while statements).
