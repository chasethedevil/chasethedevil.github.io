+++
categories = ["quant"]
date = "2017-01-17T09:55:32+01:00"
description = ""
keywords = ["quant"]
title = "Bachelier Normal Volatility Asymptotics"

+++
It is relatively well known that the Black-Scholes volatility can not grow faster than \\(\sqrt{\ln(K)}\\). 
The rule is also sometimes simply stated as "the implied variance can not grow faster than linear" (in log-moneyness).
The proof comes from Roger Lee ["The moment formula for implied volatility at extreme strikes"](http://math.uchicago.edu/~rogerlee/moment.pdf) but the rule was suggested
earlier, for example in Hodge's paper from 1996 ["Arbitrage bounds of the implied volatility strike and term structures of European-style options"](http://www.iijournals.com/doi/pdfplus/10.3905/jod.1996.407950).

With the increasing use of the b.p. (a.k.a Normal, a.k.a Bachelier) vols, a natural question (that Gary asked) is:

#### Is there a similar rule for the Normal volatility?

It turns out that the answer is not as simple. It can easily be shown that the normal volatility can not grow faster than linear
in strike (not the variance this time). But it does not mean that linear is acceptable, in fact, it is not.
The upper bound can be refined to 
$$ \frac{K-F}{\sqrt{2T \ln \frac{K}{F}}} $$

It is still an asymptotic upper bound only. 
It can be shown that any number larger than the factor 2 in the denominator will not lead to asymptotic arbitrage. 
The boundary could even be made tighter with, I suspect, additional terms in \\( \ln \ln K \\), but there is no
simple exact formula for the limit as in the Black-Scholes world.

This is all summarized my note ["Asymptotic bounds of the normal volatility"](/lefloch_volatility_asymptotics.pdf).
