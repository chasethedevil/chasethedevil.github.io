+++
title = "Bessel and Harmonic Kinks in the Forward"
date = 2013-07-02T15:44:00Z
updated = 2013-07-02T16:26:41Z
tags = ["quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

As Bessel (sometimes called Hermite) spline interpolation is only <a href="http://en.wikipedia.org/wiki/Smooth_function#The_space_of_Ck_functions">C1</a>, like the Harmonic spline from Fritsch-Butland, the forward presents small kinks compared to a standard cubic spline. Hyman filtering also creates a kink where it fixes the monotonicity. Those are especially visible with a log scale in time. Here is how it looks on the Hagan-West difficult curve.<br /><br /><div class="separator" style="clear: both; text-align: center;"><a href="http://4.bp.blogspot.com/-xsT1uMr-S6c/UdLZE3SjlEI/AAAAAAAAGg0/lESF6PVyLkk/s942/snapshot30.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="369" src="http://4.bp.blogspot.com/-xsT1uMr-S6c/UdLZE3SjlEI/AAAAAAAAGg0/lESF6PVyLkk/s640/snapshot30.png" width="640" /></a></div><br />
