+++
title = "Linus vs OpenBSD"
date = 2008-07-17T11:38:00Z
updated = 2008-07-17T11:38:35Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<div dir="ltr">Today&#39;s popular story is <a href="http://article.gmane.org/gmane.linux.kernel/706950">Linus Torvalds message</a> to OpenBSD where he writes:<br><blockquote style="border-left: 1px solid rgb(204, 204, 204); margin: 0pt 0pt 0pt 0.8ex; padding-left: 1ex;" class="gmail_quote"> <pre>I think the OpenBSD crowd is a bunch of masturbating monkeys</pre></blockquote><div>&nbsp;Beside that provoking sentence he has a valid point. Security bugs should not be more important than other bugs. Too often, management and psychology encourage making security bugs a very important issue and security people VIPs. I have seen this over and over.<br> <br><br><br></div></div> 
