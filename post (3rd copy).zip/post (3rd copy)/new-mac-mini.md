+++
title = "New Mac Mini"
date = 2006-03-07T20:51:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<div style="text-align: left;"><div style="text-align: center;"><a href="http://photos1.blogger.com/blogger/6384/1303/1024/IMG_20060307_0004.jpg"><img style="display: block; text-align: center;" alt="" src="http://photos1.blogger.com/blogger/6384/1303/400/IMG_20060307_0004.jpg" border="0" /></a><br /></div>Here is my new Mac Mini Core Solo. I am quite happy with it since it is very quiet. It makes a good jukebox/movie/server machine. Apple was very quick in shipping it (2 days)<br /></div><br />However I was a bit disappointed by iPhoto 6, it is not as nice as Picasa to sort out pictures (no IPTC support). I did not try Java on it yet. I just found out my little Benham circle applet was not working properly on it. <a href="http://picasa.google.com/blogger/" target="ext"><img src="http://photos1.blogger.com/pbp.gif" alt="Posted by Picasa" style="border: 0px none ; padding: 0px; background: transparent none repeat scroll 0% 50%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial;" align="middle" border="0" /></a>
