+++
title = "Gnome 3 not so crap after all"
date = 2011-11-30T18:11:00Z
updated = 2012-12-12T16:17:10Z
tags = ["linux", "quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

In a previous post, I was complaining how <a href="http://chasethedevil.blogspot.com/2011/08/gnome-3-unity-crap.html">bad Gnome 3</a> was. Since I have installed a real dock: docky, it is now much more usable. I can easily switch / launch applications without an annoying full screen change.<br /><br />In addition I found out that it had a good desktop search (tracker). The ALT+F2 also does some sort of completion, too bad it can not use tracker here as well.<br /><br />So it looks like Gnome 3 + gnome-tweak-tool + docky makes a reasonably good desktop. XFCE does not really fit the bill for me: bad handling of sound, bad default applications, not so good integration with gnome application notifications.<br /><br /><div class="separator" style="clear: both; text-align: center;"><a href="http://4.bp.blogspot.com/-2DF1jycI5ZU/TtZmvdt2k-I/AAAAAAAAFic/ej8a7g1Gswg/s1600/Screenshot+at+2011-11-30+18%253A20%253A29.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="200" src="http://4.bp.blogspot.com/-2DF1jycI5ZU/TtZmvdt2k-I/AAAAAAAAFic/ej8a7g1Gswg/s320/Screenshot+at+2011-11-30+18%253A20%253A29.png" width="320" /></a></div><br /><br />Now if only I found a way to change this ugly big white scrollbar...
