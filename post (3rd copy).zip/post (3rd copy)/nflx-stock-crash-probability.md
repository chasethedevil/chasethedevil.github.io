+++
categories = ["quant"]
date = "2018-07-12T20:56:42+01:00"
description = ""
keywords = ["quant"]
title = "On the Probability of a Netflix Stock Crash"

+++
This is a follow up to my [previous post](/post/tsla-stock-crash-probability) where I explore the probability
of a TSLA stock crash, reproducing the [results of Timothy Klassen](https://www.linkedin.com/pulse/options-market-thinks-16-chance-tesla-exist-january-2020-klassen/?lipi=urn%3Ali%3Apage%3Ad_flagship3_feed%3BaOfn2Xf6RIum6%2F9ddKS9fA%3D%3D).

According to the implied cumulative probability density, TSLA has around 15% chance of crashing below $100. Is this really
high compared to other stocks? or is it the interpretation of the data erroneous?

Here I take a look at NFLX (Netflix). Below is the implied volatility according to three different models.

{{< figure src="/post/nflx2020_vol.png" title="Black volatility implied from Jan 2020 NFLX options." >}}

Again, the shape is not too difficult to fit, and all models give nearly the same fit, within the bid-ask spread as long as we
include an inverse relative bid-ask spread weighting in the calibration. 

The corresponding implied cumulative density is

{{< figure src="/post/nflx2020_cum.png" title="Cumulative density implied from Jan 2020 NFLX options." >}}

More explicitely, we obtain

|Model                     | probability of NFLX < 130 |
|--------------------------|---------------------------|
|Collocation               |                      3.3% |  
|Lognormal Mixture         |                      3.6% | 
|Andreasen-Huge regularized|                      3.7% | 

The probability of NFLX moving below $130 is significantly smaller than the probability of TSLA moving below $100 (which is also around the same 1/3 of the spot price).


For completeness, the implied probability density is

{{< figure src="/post/nflx2020_rnd.png" title="Probability density implied from Jan 2020 NFLX options." >}}

I did not particularly optimize the regularization constant here. The lognormal mixture can have a tendency to produce 
too large bumps in the density at specific strikes, suggesting that it could also benefit of some regularization.

What about risky stocks like SNAP (Snapchat)? It is more challenging to imply the density for SNAP as there are
much fewer traded options on the NASDAQ: less strikes, and a lower volume. Below is an attempt.

{{< figure src="/post/snap2020_vol.png" title="Black volatility implied from Jan 2020 SNAP options." >}}

{{< figure src="/post/snap2020_cum.png" title="Cumulative density implied from Jan 2020 SNAP options." >}}

We find a probability of moving below 1/3 of the current price lower than with TSLA: around 12% SNAP vs 15% for TSLA.
