+++
title = "Firefox 3"
date = 2008-06-18T11:26:00Z
updated = 2008-06-18T11:26:19Z
tags = ["linux"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I tried <a href="http://www.mozilla.com/en-US/firefox/">Firefox 3</a> twice before, while it was in alpha and beta. I was not impressed at all, it seemed buggy (normal for alpha) and I found the new location bar behavior unintuitive. It did not seem that much faster either. So I always quickly went back to Firefox 2.<br /><br />I tried again recently, funnily, because of a bad Kernel update. One day, after a kernel update, my laptop started to run only at a max of 800Mhz, I did not notice it immediately. I thought wow Firefox 2.0 is really slow with gmail, maybe I should try Firefox 3 again. I did and worked a few days without noticing the processor speed difference that much. Firefox 3 at 800Mhz is as fast as Firefox 2.0 at 2Ghz. It is only after struggling with very long compilation time related to my work that I thought something was wrong.<br /><br />As usual with Linux troubles, solution are strange but not too hard to find out. I just had to add a <span style="font-family: Courier; color: rgb(0, 153, 0);">processor.ignore_ppc=1</span> kernel parameter for the kernel to behave properly again.<br /><br />Yesterday I installed Firefox 3 on a MacBook, and I was really impressed by its speed. I felt faster than Safari. And now I got used to the new location bar behavior, I would not go back (I think the behavior improved after the betas as well).<br /><br />Another interesting browser these days, especially for bloggers, is Flock 2 (based on Firefox 3).
