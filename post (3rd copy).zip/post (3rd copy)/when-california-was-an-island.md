+++
title = "When California Was An Island"
date = 2005-09-21T19:01:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<a href='http://photos1.blogger.com/img/257/6856/1024/IMG_20050918_0012.jpg'><img border='0' style='border:1px solid #AAAAAA; margin:2px' src='http://photos1.blogger.com/img/257/6856/400/IMG_20050918_0012.jpg'></a><br />This is from an old (1680s) big (2 tons) Coronelli globe, currently displayed in Grand Palais, Paris. Can you spot San Francisco there?
