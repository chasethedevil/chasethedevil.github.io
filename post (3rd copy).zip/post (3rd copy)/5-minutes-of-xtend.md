+++
title = "5 Minutes of Xtend"
date = 2014-04-08T17:37:00Z
updated = 2014-05-14T14:22:27Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++
{{< rawhtml >}}
There is a relatively new JVM based language, <a href="https://www.eclipse.org/xtend" target="_blank">Xtend</a>. Their homepage says "<b>JAVA 10, TODAY!</b>", so I thought I would give it a try, I was especially interested in operator overloading support, and the fact that it compiles to Java code, not Java byte code.<br /><br />Unfortunately, after 5 minutes with it, and pasting some non Java code in an xtend file, Eclipse hangs forever, even on restart. After creating another workspace, just to trash the new workspace a similar way. This is quite incredible for a nearly 2 years old project, on eclipse.org.<br /><br />{{< /rawhtml >}}
