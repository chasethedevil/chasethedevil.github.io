+++
title = "Linux Desktops in 2015"
date = 2015-06-24T18:53:00Z
updated = 2015-09-04T21:46:04Z
tags = ["linux"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I seem to <a href="http://chasethedevil.github.io/post/kde-xfce-gnome-shell-in-2014/">never be entirely happy with any of the linux desktops</a> these days. I have used XFCE on Ubuntu quite a bit in the past year, it mostly works, but I still had minor annoyances:<br />- sometimes (rarely) my laptop would not wake up from sleep.<br />- notifications sometimes keep popping up too much.<br />- on my desktop, experienced strong tearing issues with the Radeon graphic card, except with some very specific combination of video player settings and desktop settings (and then I had annoying redraw issue when pushing volume up/down in movies).<br /><br />I am satisfied with two different approaches since:<br />- OpenSuse 13.2 with KDE 4. I use that on my desktop, all issues are gone, and the integration of KDE in OpenSuse is clearly the best I have experienced. In contrast, KDE 5 on Ubuntu was a disaster for me. I also managed to fuck up the apt dependencies so much that I thought it would be simpler to reinstall a new distribution.<br />- Mate on Ubuntu 15.04. Very impressed so far. It's probably what Gnome should have been instead of going to 3.0. Even if there are nice aspects of the Gnome shell, Mate is fast, pretty, user friendly, much better than Cinnamon. There are even a few layouts to choose (most of them are good), here is "Eleven with Mate menu" (it installed and setup the Plank dock automatically for that layout, more traditional layouts without dock are available):<br /><br /><div class="separator" style="clear: both; text-align: center;"><a href="http://1.bp.blogspot.com/-aCnzz5ujbA4/VYrfl3lhz1I/AAAAAAAAIDw/5qV5NrGn7a8/s1600/Mate-Eleven.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="358" src="http://1.bp.blogspot.com/-aCnzz5ujbA4/VYrfl3lhz1I/AAAAAAAAIDw/5qV5NrGn7a8/s640/Mate-Eleven.png" width="640" /></a></div><br />
