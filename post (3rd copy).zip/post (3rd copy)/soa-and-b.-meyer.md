+++
title = "SOA and B. Meyer"
date = 2006-03-31T15:08:00Z
updated = 2008-06-16T16:53:04Z
tags = ["book", "java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

While rereading parts of &quot;Object Oriented Software Construction&quot; from B. Meyer, I still find valuable information I overlooked. In the part about functional decomposition where he argues pro and cons of top-down / bottom-up approaches, he has the intuition of the current SOA hype. By showing that <br><br><blockquote style="border-left: 1px solid rgb(204, 204, 204); margin: 0pt 0pt 0pt 0.8ex; padding-left: 1ex;" class="gmail_quote"><font size="4"><span style="font-weight: bold;">Real systems have no top.</span></font> <br></blockquote><br>He suggests that the only way to build complex software is through a service oriented architecture. Of course SOA is a very old concept. Meyer example of Operating Systems is a fine one.<br><br>Another interesting remark is his object motto to design an object oriented system: <br><br><blockquote style="border-left: 1px solid rgb(204, 204, 204); margin: 0pt 0pt 0pt 0.8ex; padding-left: 1ex;" class="gmail_quote"><font size="4"><span style="font-weight: bold;">Ask not first what the system does:</span> <br style="font-weight: bold;"><span style="font-weight: bold;">Ask what it does it to!</span></font><br></blockquote><br><br>
