+++
title = "A Seasoned Volatility Swap"
date = 2013-03-14T19:55:00Z
updated = 2013-12-27T17:43:08Z
tags = ["quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

This is very much what's in the Carr-Lee paper "Robust Replication of Volatility Derivatives", but it wasn't so easy to obtain in practice:<br /><ul><li>The formulas as written in the paper are not usable as is: they can be simplified (not too difficult, but intimidating at first)</li><li>The numerical integration is not trivial: a simple Gauss-Laguerre is not precise enough (maybe if I had an implementation with more points), a Gauss-Kronrod is not either (maybe if we split it in different regions). Funnily a simple adaptive Simpson works ok (but my boundaries are very basic: 1e-5 to 1e5).</li></ul><div class="separator" style="clear: both; text-align: center;"><a href="http://4.bp.blogspot.com/-UbYc6dfh8Yw/UUIc6V2Mg8I/AAAAAAAAGSI/25Rdvjzk-xk/s1600/Screenshot+from+2013-03-14+19:33:04.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="254" src="http://4.bp.blogspot.com/-UbYc6dfh8Yw/UUIc6V2Mg8I/AAAAAAAAGSI/25Rdvjzk-xk/s320/Screenshot+from+2013-03-14+19:33:04.png" width="320" /></a></div>
