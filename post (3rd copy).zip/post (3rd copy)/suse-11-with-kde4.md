+++
title = "Suse 11 with KDE4"
date = 2008-07-17T11:38:00Z
updated = 2008-07-17T11:38:26Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<div dir="ltr">I was very <a href="http://chasethedevil.blogspot.com/2008/01/kde4-still-not-ready.html">disappointed by KDE 4.0</a> when I first tried it on an ubuntu machine. It was just unusable. I would not have even considered it as a beta.<br> <br>I changed the system on my home laptop because Ubuntu with KDE 4 was there. I decided to go for something more roots. I had good memories of Gentoo when I tried it some years ago. Maybe I just became too old to appreciate it anymore. But after spending several hours on a Grub error 2 problem, seeing the live CD does not even use grub so you can&#39;t use the CD to boot from hard drive and fix the problem easily, wondering if the problem was a problematic Grub version with my drive or not (I never had problems with Grub and other distros on that same machine before), I decided to install OpenSuse 11. <br> <br>I was surprised (and impressed by Suse) that KDE 4.xx shipped with OpenSuse was usable! Except the program menu, it&#39;s not worse than KDE 3.<br></div> 
