+++
title = "Java Programmers Are Idiots?"
date = 2008-12-17T20:16:00Z
updated = 2008-12-17T20:32:17Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

My brother just sent me a funny quote. I don't know if it is true or not:<br /><blockquote style="font-family: arial; font-style: italic;">entwickeln Sie lieber überzeugende Lösungen anstatt viele Stunden mit Coding zu verbringen? Ist Ihnen die Produktivität Ihres Teams wichtig?<br /><br />Mark Driver, *VP Research von Gartner*, kommentierte kürzlich:<br /><br />"Here’s a simple equation. In terms of mental fortitude...*<br />1 Smalltalk developer = 2.5 C++ developers<br />1 C++ developer = 1.5 Java developers*"</blockquote>You don't need german to understand. Of course it can not be true. How can anyone measure mental fortitude? And how does it related with productivity is another issue.<br /><br />There is a famous email exchange from <a href="http://lwn.net/Articles/249460/">Linux Torvald claiming the advantages of C versus C++</a>, here is a quote:<br /><blockquote style="font-family: arial; font-style: italic;">If you want a VCS that is written in C++, go play with Monotone. Really.They use a "real database". They use "nice object-oriented libraries". They use "nice C++ abstractions". And quite frankly, as a result of all these design decisions that sound so appealing to some CS people, the end result is a horrible and unmaintainable mess.</blockquote><br /><br />This however is quite interesting since I am probably not the only one to have seen the disastrous effects of too enthusiastic abstraction professionals in Java. This is why many Java projects are utter crap. But again, not everybody makes this mistake. Some people know how to build good things. As the result of Java being popular, we have many crap programmers with pseudo genius theories you don't find in C or Haskell.<br /><br />On another subject, I seriously wonder why we don't have more distributed compilation in Java as in C/C++. I am tired of seing those core doing nothing while compiling.
