+++
title = "JavaBlogs Daily Analysis"
date = 2005-09-09T17:10:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I was wondering what blog entries were the most interesting on <a  href="http://www.javablogs.com">Javablogs</a>. I decided to write a small application to do that. It was not much more complex to put it online for others to look at as well. It is currently running on <a  href="http://gopix.net:8081/javabuzz">http://gopix.net:8081/javabuzz</a> <br> <br> It also presents Javablogs a bit differently (I like it better that way).<br> <br> Please note that it is just the result of a 1 (full) day of work currently. I hopefully will have a bit of time to improve it. For example I'd like to add some graphs about popularity, some weekly stats, and comments in blog entries.<br> <br> <br>
