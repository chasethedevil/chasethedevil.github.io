+++
title = "A Discontinuity"
date = 2012-12-12T20:59:00Z
updated = 2012-12-21T18:17:21Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I am comparing various finite difference schemes on simple problems and am currently stumbling upon a strange discontinuity at the boundary for some of the schemes (Crank-Nicolson, Rannacher, and TR-BDF2) when I plot an American Put Option Gamma using a log grid. It actually is more pronounced with some values of the strike, not all. The amplitude oscillates with the strike. And it does not happen on a European Put, so it's not a boundary approximation error in the code. It might well be due to the nature of the scheme as schemes based on implicit Euler work (maybe monotonicity preservation is important). This appears on this graph around S=350.<br /><br /><div class="separator" style="clear: both; text-align: center;"><a href="http://1.bp.blogspot.com/-ugmThxi_c_g/UMjh4M8JKAI/AAAAAAAAGKg/Oj-p9_AaNzM/s1600/gamma_american_boundary.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="160" src="http://1.bp.blogspot.com/-ugmThxi_c_g/UMjh4M8JKAI/AAAAAAAAGKg/Oj-p9_AaNzM/s640/gamma_american_boundary.png" width="640" /></a></div><br /><b>Update December 13, 2012</b>: after a close look at what was happening. It was after all a boundary issue. It's more visible on the American because the Gamma is more spread out. But I reproduced it on a European as well.
