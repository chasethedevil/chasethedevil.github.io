+++
title = "Better Finite Difference Boundaries with a Tridiagonal Solver"
date = 2013-01-10T19:19:00Z
updated = 2013-01-10T19:19:17Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

In <i><a href="http://www.amazon.com/Pricing-Financial-Instruments-Finite-Difference/dp/0471197602/ref=sr_1_1?ie=UTF8&amp;qid=1357840985&amp;sr=8-1&amp;keywords=tavella+randall">Pricing Financial Instruments - The Finite Difference Method</a></i>, Tavella and Randall explain that boundary conditions using a higher order discretization (for example their "BC2" boundary condition) can not be solved in one pass with a simple tridiagonal solver, and suggest the use of SOR or some conjugate gradient based solver.<br /><br />It is actually very simple to reduce the system to a tridiagonal system. The more advanced boundary conditions only use 3 adjacent values, just 1 value makes it non tridiagonal, the one in <b>bold</b> is the following matrix representation<br />x x <b>x</b><br />x x x<br />&nbsp;&nbsp; x x x <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ......<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; x x x<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; x x x<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>x</b> x x<br />One just needs to replace the first line by a simple linear combination of the first 2 lines to remove the extra <b>x</b> and similarly for the last 2 lines. This amounts to ver little computational work. Then one can use a standard tridiagonal solver. This is how I implemented it in a past post about <a href="http://chasethedevil.github.io/post/finite-difference-approximation-of-derivatives/">boundary conditions of a bond in the CIR model</a>. It is very surprising that they did not propose that simple solution in an otherwise very good book.
