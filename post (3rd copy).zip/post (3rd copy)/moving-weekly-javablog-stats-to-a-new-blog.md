+++
title = "Moving weekly Javablog stats to a new blog"
date = 2006-06-26T17:25:00Z
updated = 2007-04-05T14:10:12Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Javablogs.com top 10 weekly/monthly/yearly entries were starting to pollute my blog too much for my taste. It is more appropriate to dedicate a blog to them. That is what I should have done in the first place as it is very easy to have many blogs with blogger.com.<br /><br />So you'll find at <a href="http://javabuzz.blogspot.com">javabuzz.blogspot.com</a> the weekly top 10 most read entries on Javablogs, and sometimes more.
