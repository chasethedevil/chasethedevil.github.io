+++
title = "_the_ Google 1998 paper"
date = 2008-04-25T14:22:00Z
updated = 2008-04-25T14:26:43Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I have just read "<a href="http://infolab.stanford.edu/%7Ebackrub/google.html">the anatomy of a search engine</a>" from S. Brin and L. Page. For those who don't know, it is _the_ Google paper. I have read other google labs papers in the past. What I like in this one is that you can follow how they came into having the Google ideas, how they assembled their ideas.<br /><br />I should have read that a long time ago.
