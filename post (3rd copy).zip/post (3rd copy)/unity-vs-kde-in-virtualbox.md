+++
title = "Unity vs KDE in Virtualbox"
date = 2013-07-10T23:17:00Z
updated = 2013-07-10T23:17:04Z
tags = ["linux"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

The other day I installed the latest Ubuntu 13.04 under a VirtualBox virtual machine using Windows as host. To my surprise, unity failed to launch properly on the virtual machine reboot, with compiz complaining, something I have sometimes seen on my work laptop. It's more surprising in a VM since it is in a way much more standard (no strange graphic card, no strange driver, the same stuff for every VirtualBox user (maybe I'm wrong there?)). I therefore installed KDE as a way to bypass this issue. Not only it worked, but the UI was much faster: there was some very noticeable lag in Unity, slow fade in fade out effects, when it worked before the reboot.<div><br /></div><div>I am no hater of Unity, it looks well polished, nice to the eye and I use it on a home computer. I find KDE looks a tiny bit less nice, although I prefer the standard scrollbars of KDE. I wonder if others have the same dreadful experience with Unity under VirtualBox.</div>
