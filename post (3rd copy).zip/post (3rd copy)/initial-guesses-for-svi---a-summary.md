+++
title = "Initial Guesses for SVI - A Summary"
date = 2014-09-26T10:46:00Z
updated = 2015-01-21T14:21:18Z
tags = ["scala", "quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I have been looking at various ways of finding initial guesses for SVI calibration (<a href="http://chasethedevil.blogspot.com/2014/07/another-svi-initial-guess.html">Another SVI Initial Guess</a>, <a class="GCUXF0KCPB" href="http://chasethedevil.blogspot.com/2014/07/more-svi-initial-guesses.html">More SVI Initial Guesses</a>, <a class="GCUXF0KCPB" href="http://chasethedevil.blogspot.com/2014/08/svi-and-long-maturities-issues.html">SVI and long maturities issues</a>). I decided to write <a href="http://papers.ssrn.com/abstract=2501898">a paper</a> summarizing this. I find that the process of writing a paper makes me think more carefully about a problem.<br /><br />In this case, it turns out that the Vogt initial guess method (guess via asymptotes and minimum variance) is actually very good as long as one has a good way to lookup the asymptotes (the data is not always convex, while SVI is) and as long as rho is not close to -1, that is for long maturity affine like smiles, where SVI is actually more difficult to calibrate properly due to the over-parameterisation in those cases.<br /><br />Still after looking at all of this, one has a sense that, even though it works on a wide variety of surfaces, it could break down because of the complexity (are asymptotes ok, is rho close to -1? how close? is ATM better or maximum curvature better? how do we impose boundaries on a and sigma with Levenberg-Marquardt? (truncation should not be too close to the transform, but how far?)<br /><br />This is where the Quasi-Explicit method from Zeliade is very interesting: it is simpler, not necessarily to code, but the method itself. There are things to take care of (solving at each boundary), but those are mathematically well defined. The only drawback is performance, as it can be around 40 times slower. But then it's still not that slow.<br /><br /><br />
