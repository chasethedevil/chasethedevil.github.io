+++
title = "Grails Spring Union Not Surprising"
date = 2008-11-27T17:18:00Z
updated = 2008-11-27T17:49:55Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Looking out at some<a href="http://chasethedevil.blogspot.com/2008/01/2008-java-web-framework.html"> old post</a>. I found out I was not far from the truth in January 2008 when I stated:<br /><blockquote>"In 2008 the Ruby On Rails mentality will continue to prevail. In the Java world, Grails is the most likely to benefit from it. (...) It could also be something based around Spring as their current MVC solution is not very good and very old fashioned."</blockquote>I don't think I will be right with the provocative <a href="http://chasethedevil.blogspot.com/2008/11/java-is-dead.html">Java is dead</a>. A post recently titled <a href="http://weblogs.java.net/blog/javakiddy/archive/2008/11/no_future_in_ja.html">No Future In Java</a> makes some good points about where the future of Java still is: the web applications. Grails is probably today the best contender in the Java world, far ahead from the others, and it leverages the Java developers. However I am not sure one can say that RIA is a fad, or that RIA will only be done in a super powerful browser in the future. Microsoft might be a game changer here. The real advantages of the browser application so far are: easy deployment (the killer argument IMHO), "simple" security. I would not be surprised if in the near future, Microsoft advertises a solution for RIA easily deployed, based on standard protocols (HTTP?), a bit like IBM does with <a href="http://www.ibm.com/developerworks/websphere/techjournal/0608_xu/0608_xu.html">Eclipse RIA</a>, but much more ambitious.
