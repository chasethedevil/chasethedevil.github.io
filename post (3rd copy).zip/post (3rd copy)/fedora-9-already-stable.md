+++
title = "Fedora 9 Already Stable"
date = 2008-04-25T11:33:00Z
updated = 2008-04-25T11:36:26Z
tags = ["linux"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<a onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}" href="http://1.bp.blogspot.com/_9RyqGT46Fbk/SBGmDm9HaaI/AAAAAAAABL0/bgukGZZLRwA/s1600-h/Fedora9.png"><img style="margin: 0px auto 10px; display: block; text-align: center; cursor: pointer;" src="http://1.bp.blogspot.com/_9RyqGT46Fbk/SBGmDm9HaaI/AAAAAAAABL0/bgukGZZLRwA/s400/Fedora9.png" alt="" id="BLOGGER_PHOTO_ID_5193114426261596578" border="0" /></a><br />I "upgraded" my home computer to Fedora 9. "upgraded" because I reinstalled the OS instead of using the upgrade procedure. I have had so many issues with "partial" upgrades in the past (with any distro).<br /><br />Although it is the preview/RC1 version, Fedora 9 is already as stable as a release IMHO. No issues so far, it feels more polished than Fedora 8. OpenJDK 1.6 is there. Firefox 3 is there. Not a single problem with kernel 2.6.25 (while I had plenty with the 2.6.24 ones).<br /><br />Even <a href="https://bugzilla.redhat.com/show_bug.cgi?id=439858">Linus's wife</a> uses it!
