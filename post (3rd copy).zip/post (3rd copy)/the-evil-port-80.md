+++
title = "The Evil Port 80"
date = 2005-09-01T13:46:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I was writing an Atom feed generator for my current project. I chosed to support <a href="http://www.atomenabled.org/developers/syndication/">Atom 1.0</a> since it looks like it has the capabilities to establish as the next standard. Unfortunately I quickly saw that it was quite hard to test it in the real world (out of the good feedvalidator), as almost nobody seems to accept Atom 1.0 feeds yet, even if it is rapidely changing (there is support for it in Firefox CVS version).<br /><br />So I decided to support RSS as well, the big question was: which RSS version? After grabbing lots of info on the subject, I opted for 1.0 again (more flexible, more different than Atom). It was actually quick to support RSS, but then when in real world, neither <a href="http://desktop.google.com/en/">Google Desktop</a> nor <a href="http://my.yahoo.com/">My Yahoo</a> was willing to accept my feed. I looked at every bit of my xml, fiddled with Tomcat configuration in any possible way when I saw that no request was coming to my server from Yahoo or Google. And finally I thought, hmm maybe it's the port. I restarted my server on port 80, and yup, it worked!<br /><br /><a onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}" href="http://photos1.blogger.com/blogger/6384/1303/1600/mubot_local.jpg"><img style="margin: 0pt 10px 10px 0pt; float: left; cursor: pointer;" src="http://photos1.blogger.com/blogger/6384/1303/320/mubot_local.jpg" alt="" border="0" /></a><br /><br />I wonder why Google Desktop and My Yahoo don't support another port than port 80 for RSS feeds.<br /><br />tags: <span class="technoratitag">Categories: <a href="http://del.icio.us/tag/atom" rel="tag">atom</a>, <a href="http://del.icio.us/tag/rss" rel="tag">rss</a>, <a href="http://del.icio.us/tag/gdesktop" rel="tag">gdesktop</a>, <a href="http://del.icio.us/tag/syndication" rel="tag">syndication</a></span>
