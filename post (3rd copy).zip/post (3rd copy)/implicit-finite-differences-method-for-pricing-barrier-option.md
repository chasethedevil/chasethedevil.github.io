+++
title = "Implicit Finite Differences Method For Pricing Barrier Option"
date = 2009-08-17T12:04:00Z
updated = 2009-08-17T12:09:42Z
tags = ["java finance"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<a onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}" href="http://3.bp.blogspot.com/_9RyqGT46Fbk/Sokrd-84xhI/AAAAAAAAERE/-gs3_MMw0oo/s1600-h/implicit_method_barrier_option_html_m531cf9ea.jpg"><img style="float:left; margin:0 10px 10px 0;cursor:pointer; cursor:hand;width: 320px; height: 74px;" src="http://3.bp.blogspot.com/_9RyqGT46Fbk/Sokrd-84xhI/AAAAAAAAERE/-gs3_MMw0oo/s320/implicit_method_barrier_option_html_m531cf9ea.jpg" border="0" alt=""id="BLOGGER_PHOTO_ID_5370871824730605074" /></a><br />While trying to price a simple knock down and out barrier option, I encountered several difficulties I did not expect with the implicit finite differences method. The explicit method has less issues with barrier options pricing. I will show here what the tricky parts are and why explicit seems simpler in this case.<br /><br />The full article is <a href="http://www.31416.org/static/implicitbarrier/implicit_method_barrier_option.pdf">here (pdf)</a> or <a href="http://www.31416.org/static/implicitbarrier/implicit_method_barrier_option.html">here (html)</a> (the later is not very well formatted).<br /><br />Algorithms used in this article can be found at <a href="http://code.google.com/p/javamc/">http://code.google.com/p/javamc/</a>
