+++
title = "Two SABR for the same smile"
date = 2014-05-20T12:08:00Z
updated = 2014-07-17T09:56:50Z
tags = ["quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

While playing around with <a href="http://chasethedevil.github.io/post/good--popular-algorithms-are-simple/" target="_blank">differential evolution</a> &amp; SABR calibration, I noticed that sometimes, several set of parameters can lead to a very similar smile, usually the good one is for relatively low vol of vol and the bad one is for relatively high vol of vol. I first looked for errors in my implementation, but it's a real phenomenon.<br /><div class="separator" style="clear: both; text-align: center;"><a href="http://1.bp.blogspot.com/-W8y6ZCg2RC8/U3snVBI5I8I/AAAAAAAAHNI/JTCgBE4ZR3I/s1600/Screenshot+from+2014-05-19+17:55:50.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" src="http://1.bp.blogspot.com/-W8y6ZCg2RC8/U3snVBI5I8I/AAAAAAAAHNI/JTCgBE4ZR3I/s1600/Screenshot+from+2014-05-19+17:55:50.png" height="332" width="400" /></a></div><br />I used the normal implied volatility formula with beta=1, then converted it to lognormal (Black) volatility. While it might not be a great idea to rely on the normal formula with beta=1, I noticed the same phenomenon with the <a href="http://chasethedevil.blogspot.fr/2013/05/sabr-with-new-hagan-pde-approach.html" target="_blank">arbitrage free PDE density approach</a>, especially for long maturities. Interestingly, I did not notice such behavior before with other stochastic volatility models like Heston or Schobel-Zhu: I suspect it has to do with the approximations rather than with the true behavior of SABR.<br /><br />Differential evolution is surprisingly good at finding the global minimum without much initial knowledge, however when there are close fits like this it can be more problematic, usually this requires pushing the population size up. I find that differential evolution is a neat way to test the robustness (as well as performance) of different SABR algorithms as it will try many crazy sets.<br /><br />In practice, for real world calibration, there is not much use of differential evolution to calibrate SABR as it is relatively simple to find a good initial guess.<br /><br /><br /><br />
