+++
title = "Jumps impact: Variance swap vs volatility swap"
date = 2015-02-20T13:24:00Z
updated = 2015-02-24T13:51:11Z
tags = ["quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<div class="separator" style="clear: both; text-align: center;"><a href="http://4.bp.blogspot.com/-9BEKyX_gWc0/VOclAJRe19I/AAAAAAAAH0g/AxbdgL48GaA/s1600/Screenshot%2B-%2B200215%2B-%2B13%3A13%3A38.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" src="http://4.bp.blogspot.com/-9BEKyX_gWc0/VOclAJRe19I/AAAAAAAAH0g/AxbdgL48GaA/s1600/Screenshot%2B-%2B200215%2B-%2B13%3A13%3A38.png" height="388" width="640" /></a></div>Beside <a href="http://chasethedevil.github.io/post/variance-swap-replication--discrete-or-continuous/">the problem with the discreteness</a> of the replication, variance swaps are sensitive to jumps. This is an often mentioned reason for the collapse of the single name variance swap market in 2008 as jumps are more likely on single name equities.<br /><br />Those graphs are the result of Monte-Carlo simulations with various jump sizes using the Bates model, and using Local Volatility implied from the Bates vanilla prices. The local volatility price will be the same price as per static replication for the variance swap, and we can see it they converge when there is no jump.<br /><br />The presence of jumps lead to a theoretically higher variance swap price, again, which we miss completely with the static replication. As jumps go higher, the difference is more pronounced.<br /><br />Volatility swaps are a bit better behaved in this regard. Interestingly, local volatility overestimate the value in this case (which for variance swaps it underestimates the value). I also noticed that the relatively <a href="http://chasethedevil.blogspot.fr/2013/03/a-volatility-swap-and-straddle.html">recent formula from Carr-Lee</a> will underestimate jumps even more so than local volatility: it is more precise in the absence of jumps, very close to Heston, but less precise than local volatility when jumps increase in size.<br /><br />I have added a small section around this in <a href="http://papers.ssrn.com/sol3/papers.cfm?abstract_id=2567398">my paper on SSRN</a>.<br /><br />
