+++
title = "You Know IOException? Think Again!"
date = 2006-09-14T10:59:00Z
updated = 2007-04-05T14:10:12Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I was amazed today to find out that there was no constructor <tt>IOException(String, Throwable)</tt> or<tt> IOException(Throwable)</tt> in JDK1.4 and JDK1.5. It is finally in JDK1.6, I can't believe it took Sun that much time to change that.<br> <br> So the workaround is:<br> <blockquote><tt>IOException ioe = new IOException("message");</tt><br>   <tt>ioe.initCause(e);</tt><br>   <tt>throw ioe;</tt><br> </blockquote> It can also be written as:<br> <blockquote><tt>throw (IOException) new IOException("message").initCause(e);</tt><br> </blockquote> It is not a major problem, but still. We can all thank the guy who <a  href="http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=5070673">reported that as a bug</a> to Sun in 2004.<br>
