+++
title = "Commons-Beanutils Is Slow"
date = 2005-09-07T17:28:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

The <a href="http://jakarta.apache.org/commons/beanutils/commons-beanutils-1.7.0/docs/api/">BeanUtil.popupate(bean,map)</a> can be very handy, but if you care about performance, it is quite slow. I ran a micro benchmark on my machine (centrino 1.8ghz, JDK1.5) and found out that BeanUtils is up to 40x slower than a hand coded solution (where I assign each bean field manually). I was a bit surprised to find such a difference. I suppose there is a big penalty for using reflection and another big one for the BeanUtils abstraction (automatic casting, etc.). I did another test without BeanUtils, using if/else statements vs HashMap.get and found out that the if/else string.equals(...) statements can degrade performance by about 10x. The HashMap appears to be very performant, even with just a few elements in.<br /><br />In conclusion, if you need more performance, consider hand coding or code generation (using aspectj, or annotations for example) rather than BeanUtils. Actually nowadays, using annotations where you used beanutils probably makes much more sense .
