+++
title = "Maven: Game Over, Try Again"
date = 2006-11-24T17:51:00Z
updated = 2007-04-05T14:10:12Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I am writing only as a newbie on Maven2. I tried to use it several times on small projects, but each time I found out that the time involved to make it work with an existing project was too much a pain in the a**. When confronted to very simple hierarchies that are not the standard of the documentation, I was a bit lost on how to arrange things, except changing the whole hierarchy to adapt to Maven.  <br><br>Also on small scale code, Maven requires you again to adapt your project to it and it will make your small code look like an important enterprise project. For example if you want to build a small test that can be executed as a server (with one particular class), as a client (with another class), or as a servlet, using one or two other common classes, Maven requires at least 3 source hierarchies (with src directory). <br><br>I think it is not only because I know ant (much) better that ant proved many times to be quite flexible, and I have never been on a project where switching from Makefile to ant was a problem. I am not an ant fan. I have a preference of code over XML that ends up here and there being like code, in a much less flexible way. However Ant, as I said, is flexible. One can always use the good old scripting languages (javascript, beanshell, etc.) to define new tasks, and therefore bypass any inflexibility of the original design. <br><br>Still Maven2 has plenty of very good stuff, especially for more normal projects. It provides versioning, central repository and dependency checking for you. It is probably a good idea to use it rather than bad ant scripts, or, even worse, old Makefiles. Also Maven2 hierarchy conventions are not stupid, it is just not fitted for quick and dirty stuff. <br><br><br> 
