+++
title = "Java is more productive than Ruby/Rails"
date = 2005-07-26T13:26:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I have been doing some Ruby On Rails, for 2 small projects. While I think it is good, I think it is overhyped as well. It is well designed, has good ideas (easy configuration), and focus on the right problem, architecture. But my conclusion is that I am not more productive with it than with Java.<br> <br> I think most of the development time is not spent coding, but thinking. It is a very obvious statement, and yet too often ignored.<br> <br> The <a href="http://www.joelonsoftware.com/articles/HighNotes.html">current Joel On Software article</a> is just making my point: if you look at how much time it took the students to complete their program, you can see it is not the writing that took that much time. And I am sure you noticed the same on your own projects.<br> <br> So all the nice features of the Ruby language don't save you a lot of time. And actually when your code size is growing, it becomes increasingly difficult for an outsider to understand your program. Everything can be so dynamic, and your only help is a syntax coloring editor. Compare that to Eclipse, or IDEA, or Netbeans, where you have very convenient search, not text search, but search for declarations, for calls, of methods, variables, classes, all that just a mouse click away. Strong typing goes a little bit in the way while writing, but helps understanding better in many cases (personally I wish Java had type inference, as all the verbosity is not always needed). And when if you really want less verbosity, then you have access to a handful of JVM languages.<br> <br> A drawback of Java is maybe that you have access to too many libraries. Sometimes, making a choice among the bazaar is not easy and the hype gets scattered.<br> <br> <i>Tags: <a rel="tag" href="http://technorati.com/tag/java">java</a> <a  rel="tag" href="http://technorati.com/tag/programming">programming</a> <a rel="tag" href="http://technorati.com/tag/ruby">ruby</a></i><br>
