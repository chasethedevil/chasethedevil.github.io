+++
title = "Generating random numbers following a given discrete probability distribution"
date = 2012-01-09T00:14:00Z
updated = 2012-12-12T16:13:03Z
tags = ["finance", "quant", "math"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I have never really thought very much about generating random numbers according to a precise discrete distribution, for example to simulate an unfair dice. In finance, we are generally interested in continuous distributions, where there is typically 2 ways: the <a href="http://en.wikipedia.org/wiki/Inverse_transform_sampling">inverse transform</a> (usually computed in a numerical way), and the <a href="http://en.wikipedia.org/wiki/Rejection_sampling">acceptance-rejection</a> method (typically the <a href="http://en.wikipedia.org/wiki/Ziggurat_algorithm">ziggurat</a>). The inverse transform is often preferred, because it's usable method for Quasi Monte-Carlo simulations while the acceptance rejection is not.<br /><br />I would have thought about the simple way to generate random numbers according to a discrete distribution as first described <a href="http://www.delicious.com/redirect?url=http%3A//blog.sigfpe.com/2012/01/lossless-decompression-and-generation.html">here</a>. But establishing a link with <a href="http://en.wikipedia.org/wiki/Huffman_coding">Huffman encoding</a> is brilliant. Some better performing alternative (unrelated to Huffman) is offered <a href="http://www.keithschwarz.com/darts-dice-coins/">there</a>.
