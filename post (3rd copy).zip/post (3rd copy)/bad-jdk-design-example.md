+++
title = "Bad JDK Design Example"
date = 2006-03-16T15:02:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Have you ever used the Authenticator class? It is standard since JDK 1.2. This allows you to establish authenticated HTTP requests. OnJava has an in-depth <a href="http://www.onjava.com/pub/a/onjava/excerpt/jvntwkprg_3e/?page=4"> article presenting it</a>. Now here is my story about it.<br><br>The other day I just wanted to do that a simple authenticated HTTP request. You would expect it to be very simple to do in the modern internet world. <br><br> It is actually not very difficult to do, by hand, a <a href="http://www.javaworld.com/javaworld/javatips/jw-javatip47.html">JavaWorld article</a>  presents this way. Unfortunately it uses internal JDK sun classes for Digest and I am uncomfortable to use that since it is not guaranteed to work on any JVM. So I have to download jakarta commons-codec to just do a simple authenticated HTTP request. I really wonder why some of those codecs are not in the JDK (not as sun.* classes but as java.* classes). <br><br>When I read that it was possible to do it a standard way in JDK 1.2, I was excited. I was wrong. Not only you have to extend a class (ok, implementation is faily simple) that adds in my mind unnecessary clutter, but you are forced to have only 1  <a href="http://java.sun.com/j2se/1.4.2/docs/api/java/net/Authenticator.html">Authenticator</a> at a given time (and this Authenticator scope seems much wider than just securing HTTP connection). What about server programs dealing with different credentials?  <br><br>So I am left downloading jarkata httpclient library that is more powerful and easier to use than hand coded digest authentication (that anyway needs common codecs) just to have HTTP authentication the way it should be done. <br> 
