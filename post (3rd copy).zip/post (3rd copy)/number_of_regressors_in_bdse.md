+++
categories = ["quant"]
date = "2016-07-26T09:55:32+01:00"
description = ""
keywords = ["quant"]
title = "Number of regressors in a BSDE"

+++
Last year, I was kindly invited at the workshop on Models and Numerics in Financial Mathematics at the Lorentz center. 
It was surprinsgly interesting on many different levels. Beside the relatively large gap between academia and the industry, which this
workshop was trying to address, one thing that struck me is how difficult it was for people of slightly different specialties to communicate.

It seemed that mathematicians of different countries working on different subjects related to backward stochastic differential equations (BSDEs) would not truly understand each other. I know this is
very subjective, and maybe those mathematicians did not feel this at all. One concrete example is related to the number of regressors needed to solve a BSDE on 10 different variables. 
Solving a BSDE on 10 variables for EDF was given as an illustration at the end of an otherwise excellent presentation. 
Someone in the audience asked how possibly they could do that in practice since it would involve \\(10^{10}\\) regression factors. The answer of the speaker was more or less that it was what they do, with no particular trick but with a large computing power, as if \\(10^{10}\\) was not so big.
 
At this point I was really wondering why \\(10^{10}\\). Usually, when we do regressions in some BSDE like algorithm, for example Longstaff-Schwartz for American Monte-Carlo, we don't consider all the powers of each variables  from 0 to 10 as well as their cross products.
We only consider polynomials of degree 10, that is all the cross-combinations that lead to a total degree of 10 or less. On two variables \\(X\\) and \\(Y\\), we care about \\(1, X, Y, XY, X^2, Y^2\\) but we dont care about \\(X^2 Y, X Y^2, X^2 Y^2\\).

We can count then how many factors would be needed for 10 variables. 
We can proceed degree by degree and compute how many ordered ways we can add \\(N\\) non negative integers to produce the given degree \\(D\\) for each degree and \\(N=10\\).
This number is simply \\( C^{N+D-1}_{N-1} = C^{N+D-1}_D \\) where \\(C_k^n \\) denotes the [binomial coefficient](https://en.wikipedia.org/wiki/Binomial_coefficient).

If this number is not so obvious, we can proceed step by step as well: for degree 1, there is just \\( N \\) factors (we assign 1 to one of the variables).
For degree 2, there is \\(N\\) factors to place the number 2 on each variable, plus \\( C^N\_2 \\) to place (1,1) on the variables. From Pascal triangle, we have \\( C^{N+1}\_{2} = C^N\_2 + C^N\_1\\).
For degree 3, there is \\(N\\) factors to place the number 3 on each variable, plus \\( C^N\_3 \\) to place the numbers (1,1,1) on the variables plus \\(2C^N\_2\\) to place (1,2) and (2,1). Applying the Pascal identity twice, we have \\( C^{N+2}\_{3} = (C^N\_1+ C^N\_2) + (C^N\_2 + C^N\_3)\\). etc.

Thus the total number of factors for \\(N\\) variables is
<div>$$ 1+\sum\_{i=1}^N C^{N+i-1}\_{N-1} $$</div>
where 1 stands for the constant coefficient (power of zero).

For \\(N=10\\), the total number of factors is 184756.
Although, the total number of factors is large, it is much less than \\(10^{10}\\). The surprising fact of the workshop is that there were many very advanced mathematicians in the audience, specialists of BSDEs, and none made a comment to help the presenter.
