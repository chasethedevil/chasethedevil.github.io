+++
title = "Street Fighting Mathematics Book"
date = 2010-07-28T14:25:00Z
updated = 2012-12-12T16:17:10Z
tags = ["maths math", "quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

The&nbsp;MIT has a downloadable book on basic mathematics: <a href="http://mitpress.mit.edu/catalog/item/default.asp?ttype=2&amp;tid=12156">Street Fighting Mathematics</a>. I liked the part focused on the geometrical approach. It reminded me of the early greek mathematics.<div><br /></div><div>Overall it does look like a very American approach to Maths: answering a multiple choices questions test by elimination. But it is still an interesting book.</div>
