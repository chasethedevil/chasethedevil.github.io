+++
title = "The Wonderful UN"
date = 2013-04-24T21:35:00Z
updated = 2013-04-24T21:36:30Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Already the name United Nations should be suspicious, but now <a href="http://boingboing.net/2013/04/24/more-evidence-that-haitis-ch.html">they are shown to have spread Cholera</a> to Haiti, as if the country did not have enough suffering. They have a nice building in New-York, and used to have a popular representative, but unfortunately, for poor countries, they never really achieved much. In Haiti, there were many stories of rapes and corruption by U.N. members more than 10 years ago. The movie<i> <a href="http://www.imdb.com/title/tt0896872/">The Whistleblower</a> </i>suggests it was the same in the Balkans. I am sure it did not change much since.
