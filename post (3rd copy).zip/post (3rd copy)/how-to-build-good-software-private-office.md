+++
title = "How to Build Good Software? Private Office"
date = 2007-04-11T10:52:00Z
updated = 2007-04-11T10:54:38Z
tags = ["howtobuildgoodsoftware"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

In an open space, people keep on coming to discuss various issues with various people, issues that have nothing to do with your work. You end up either being distracted, or annoyed by the increased noise level. <p>Apparently at Microsoft, they have private offices for each programmer. It might be extreme, paradoxally not in the XP (extreme programming) sense, but it is much better than open space for productivity. In XP, it's almost the opposite with 2 developers working often together. </p>
