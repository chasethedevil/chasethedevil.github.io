+++
title = "Is Java Flawed - a big advantage of Python/Ruby/(your favorite interpreted language)"
date = 2006-06-02T17:33:00Z
updated = 2007-04-05T14:10:39Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<p class="mobile-post">Java is supposed to be much better to build big projects, because of static type checking, and all the rigour around the language. But how many of you have seen  medium sized projects taking more than 30 minutes to build.</p><p class="mobile-post">At work, they have a standard J2EE project, with only about 50 EJBs, hundreds of JDO classes, and   standard classes. Between the JDO generation, EJB generation, EJB dependencies calculations, and packaging, it takes 20 minutes. And the project is not doing that much. One can optimize to avoid dependencies calculations and it would then take about 12 minutes. But still.</p><p class="mobile-post">With Python, Ruby or your favorite interpreted language, this would be at most a few seconds to test a new version. Now I am a fan of Java and don't enjoy that much programming in interpreted languages, especially since modern IDE like Eclipse do so much for you.</p><p class="mobile-post">To sum up, Java is supposed to be the right language for large scale projects, and yet it is on large scale projects that compilation is an issue. Ok, this will enforces a better separation of concerns, and will probably be beneficial in the end. But I am not sure that most people do a good separation of concerns in projects they manage. <br/><br/>I think it is no accident if the next step in Java development involves much more runtime compilation. It somehow started with JSPs, and then with the various XML config files combined to java reflection. It is now made even more popular with annotations, see EJB 3.0.</p><p class="mobile-post">I am wondering a bit if one day compiled languages will be only a curiosity for most enterprise projects.</p>
