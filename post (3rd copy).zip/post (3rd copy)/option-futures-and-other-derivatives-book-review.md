+++
title = "Option, Futures and Other Derivatives Book Review"
date = 2008-06-16T17:06:00Z
updated = 2008-06-16T17:08:15Z
tags = ["book"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<span style="font-style: italic;">Option, Futures and Other Derivatives</span> is by far the most popular book in finance. You will find it in every finance company, on many desks.<br /><br />It is a very good introduction for people not familiar with standard financial products. This kind of book is unavoidable to understand the basis. It goes also beyond with the chapters on pricing and hedging. These 2 chapters make one understand many other book. If one understands the Black and Scholze formula, one can easily approach many other pricing formula, as in a way, there are all similar in their approach.
