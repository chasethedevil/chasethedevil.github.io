+++
title = "Decoding Hagan's arbitrage free SABR PDE derivation"
date = 2015-05-08T16:50:00Z
updated = 2015-09-04T21:45:48Z
tags = ["quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++


Here are the main steps of Hagan derivation. Let's recall his notation for the SABR model where typically, \\(C(F) = F^\beta\\)

<div class="separator" style="clear: both; text-align: center;"><a href="http://1.bp.blogspot.com/-uq2IhJPDd7M/VUzC4Hh3xoI/AAAAAAAAH9k/sY034iAD38Y/s1600/Screenshot_2015-05-08_16-04-27.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" src="http://1.bp.blogspot.com/-uq2IhJPDd7M/VUzC4Hh3xoI/AAAAAAAAH9k/sY034iAD38Y/s1600/Screenshot_2015-05-08_16-04-27.png" /></a></div>First, he defines the moments of stochastic volatility:
<div class="separator" style="clear: both; text-align: center;"></div><div class="separator" style="clear: both; text-align: center;"></div><div class="separator" style="clear: both; text-align: center;"><a href="http://2.bp.blogspot.com/-RxzKVIrxbl8/VUzC4HGhMNI/AAAAAAAAH9c/7FmxbMuB4kw/s1600/Screenshot_2015-05-08_16-04-53.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="60" src="http://2.bp.blogspot.com/-RxzKVIrxbl8/VUzC4HGhMNI/AAAAAAAAH9c/7FmxbMuB4kw/s320/Screenshot_2015-05-08_16-04-53.png" width="320" /></a></div>Then he integrates the Fokker-Planck equation over all A, to obtain
<div class="separator" style="clear: both; text-align: center;"><a href="http://4.bp.blogspot.com/-mDsC-Zd6FMA/VUzC4L9dF_I/AAAAAAAAH9g/cAvRNw1VTkg/s1600/Screenshot_2015-05-08_16-05-36.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" src="http://4.bp.blogspot.com/-mDsC-Zd6FMA/VUzC4L9dF_I/AAAAAAAAH9g/cAvRNw1VTkg/s1600/Screenshot_2015-05-08_16-05-36.png" /></a></div>On the backward Komolgorov equation, he applies a Lamperti transform like change of variable:
<div class="separator" style="clear: both; text-align: center;"><a href="http://2.bp.blogspot.com/-QiYromr1SDU/VUzE5q_OfjI/AAAAAAAAH94/nfbr14tEnj0/s1600/Screenshot_2015-05-08_16-10-33.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" src="http://2.bp.blogspot.com/-QiYromr1SDU/VUzE5q_OfjI/AAAAAAAAH94/nfbr14tEnj0/s1600/Screenshot_2015-05-08_16-10-33.png" /></a></div>And then makes another change of variable so that the PDE has the same initial conditions for all moments: 
<div class="separator" style="clear: both; text-align: center;"><a href="http://2.bp.blogspot.com/-1C8j58UD1lA/VUzE5hZJ95I/AAAAAAAAH-I/541DaJBFbAU/s1600/Screenshot_2015-05-08_16-12-34.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" src="http://2.bp.blogspot.com/-1C8j58UD1lA/VUzE5hZJ95I/AAAAAAAAH-I/541DaJBFbAU/s1600/Screenshot_2015-05-08_16-12-34.png" /></a></div>&nbsp;This leads to
<div class="separator" style="clear: both; text-align: center;"><a href="http://3.bp.blogspot.com/--wj3nYsi9g8/VUzE5glQ0VI/AAAAAAAAH98/NlVSXIc2NDI/s1600/Screenshot_2015-05-08_16-13-32.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="107" src="http://3.bp.blogspot.com/--wj3nYsi9g8/VUzE5glQ0VI/AAAAAAAAH98/NlVSXIc2NDI/s320/Screenshot_2015-05-08_16-13-32.png" width="320" /></a></div>It turns out that there is a magical symmetry for k=0 and k=2.
<div class="separator" style="clear: both; text-align: center;"><a href="http://1.bp.blogspot.com/-OStv8D0OSw0/VUzGJ6HKqDI/AAAAAAAAH-Y/jk85U57eHnY/s1600/Screenshot_2015-05-08_16-19-45.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="32" src="http://1.bp.blogspot.com/-OStv8D0OSw0/VUzGJ6HKqDI/AAAAAAAAH-Y/jk85U57eHnY/s320/Screenshot_2015-05-08_16-19-45.png" width="320" /></a></div><div class="separator" style="clear: both; text-align: center;"><a href="http://3.bp.blogspot.com/-67k-xTphi7Q/VUzGJwbwSWI/AAAAAAAAH-U/Faz235QNpKs/s1600/Screenshot_2015-05-08_16-20-09.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="32" src="http://3.bp.blogspot.com/-67k-xTphi7Q/VUzGJwbwSWI/AAAAAAAAH-U/Faz235QNpKs/s320/Screenshot_2015-05-08_16-20-09.png" width="320" /></a></div>Note that in the second equation, the second derivative applies to the whole.
Because of this, he can express \\(Q^{(2)}\\) in terms of \\(Q^{(0)}\\):
<div class="separator" style="clear: both; text-align: center;"><a href="http://1.bp.blogspot.com/-k-3DQd9MuIQ/VUzHl5TSuAI/AAAAAAAAH-s/CjTFtlX4upw/s1600/Screenshot_2015-05-08_16-25-36.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="29" src="http://1.bp.blogspot.com/-k-3DQd9MuIQ/VUzHl5TSuAI/AAAAAAAAH-s/CjTFtlX4upw/s320/Screenshot_2015-05-08_16-25-36.png" width="320" /></a></div>And he plugs that back to the integrated Fokker-Planck equation to obtain the arbitrage free SABR PDE:
<div class="separator" style="clear: both; text-align: center;"><a href="http://1.bp.blogspot.com/-aEwTOxulsWI/VUzHl3qfZAI/AAAAAAAAH-o/qQZPb8Vvz7o/s1600/Screenshot_2015-05-08_16-25-48.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="29" src="http://1.bp.blogspot.com/-aEwTOxulsWI/VUzHl3qfZAI/AAAAAAAAH-o/qQZPb8Vvz7o/s320/Screenshot_2015-05-08_16-25-48.png" width="320" /></a></div>
There is a simple more common explanation in the world of local stochastic volatility for what's going on. For example, in the particle method paper from Guyon-Labordère, we have the following expression for the true local volatility.
<div class="separator" style="clear: both; text-align: center;"><a href="http://3.bp.blogspot.com/-uV792mNz4Xo/Ul6baEs2ktI/AAAAAAAAG1U/8Iv1i23oXok/s1600/Screenshot%2Bfrom%2B2013-10-16%2B15%3A51%3A46.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="127" src="http://3.bp.blogspot.com/-uV792mNz4Xo/Ul6baEs2ktI/AAAAAAAAG1U/8Iv1i23oXok/s320/Screenshot%2Bfrom%2B2013-10-16%2B15%3A51%3A46.png" width="320" /></a></div>
In the first equation, the numerator is simply \\(Q^{(2)}\\) and the denominator \\(Q^{(0)}\\). Of course, the integrated Fokker-Planck equation can be rewritten as:

$$ Q^{(0)}\_T = \frac{1}{2}\epsilon^2 \left[C^2(F) \frac{Q^{(2)}}{Q^{(0)}} Q^{(0)}\right]\_{FF} $$

Karlsmark uses that approach directly in his thesis, using the expansions of Doust for \\(Q^{(k)}\\). Looking a Doust expansions, the fraction reduces straightforwardly to the same expression as Hagan, and the symmetry in the equations appears a bit less coincidental. 



