+++
title = "Is Prolog Better Suited Than SQL?"
date = 2005-09-26T15:36:00Z
updated = 2008-06-16T16:53:04Z
tags = ["book", "java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I am currently reading a Prolog book "<i>Artificial Intelligence Through Prolog</i>", I have been doing a bit of Prolog when I was very young and wanted to refresh my memory a bit. It is a very interesting read, especially when I take the viewpoint of our current application where no ACID compliance is required.<br /><br />It seems to me that all the logic we coded to parametrize SQL queries and construct them dynamically could have been avoided if we had chosen Prolog as Prolog expressions would have been very natural to use in our project. With Prolog, there is no need to think about joins, type of joins, SQL syntax. It is at the level just higher. I wonder very much why Prolog did not become more mainstream as it seems to solve some problems in a much nicer, natural way.<br />Here is a short example to get reviews of things by user or by user and tags or ...:<br /><ol>   <li>let's define some facts:<br />  </li>   <ul>     <li>is_tag(tag1, user1, thing_id)</li>     <li>is_tag(tag2, user1, thing_id)</li>     <li>...<br />    </li>     <li>review(user1, thing_id, description, extended, date)</li>     <li>...<br />    </li>   </ul>   <li>review for user "user_x"</li>   <ul>     <li>?review(user_x, THING_ID, DESC, EXT, DATE)<br />    </li>   </ul>   <li>review for user "user_x" with tag "tag_y"</li>   <ul>     <li>?review(user_x, THING_ID, DESC, EXT, DATE), is_tag(tag_y, user_x, THING_ID)</li>   </ul> </ol> We could imagine some better ways to lay out information. This is just a first draft.<br /><br />Now of course, Prolog does not necessary makes sense for us because:<br />  a) We already have it working in SQL<br />  b) SQL is much more used and should therefore be more tunable, stable, etc.<br /><br />Still the Prolog way of things is interesting and powerful. We could have written a code with a logic near Prolog instead of our custom code.<br /><span class="technoratitag">Tags: <a target=_top href="http://del.icio.us/tag/book" rel="tag">book</a> <a target=_top href="http://del.icio.us/tag/review" rel="tag">review</a></span>
