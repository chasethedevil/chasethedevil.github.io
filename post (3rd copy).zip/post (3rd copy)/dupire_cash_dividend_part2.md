+++
categories = ["quant"]
date = "2016-05-29T17:01:00+02:00"
description = ""
keywords = ["quant"]
title = "Dupire Local Volatility with Cash Dividends Part 2"

+++
I had a look at how to price under Local Volatility with Cash dividends in [my previous post](/post/dupire_cash_dividend/). I still had a somewhat large error in my FDM price. After too much time, I managed to find the culprit, it was the extrapolation of the prices when applying the jump continuity condition \\(V(S,t\_\alpha^-) = V(S-\alpha, t\_\alpha^+) \\) for an asset \\(S\\) with a cash dividend of amount \\(\alpha\\) at \\( t\_\alpha \\). 

I stumbled in the meantime on another alternative to compute the Dupire local volatility with cash dividends [in the book of Lorenzo Bergomi](http://www.lorenzobergomi.com/#!blank/cnec), one can rely on the
classic Gatheral formulation in terms of total implied variance \\(w(y,T)\\) function of log-moneyness:
<div>$$\sigma^{\star 2}\left(y, T\right) = \frac{ \frac{\partial w}{\partial T}}{1 - \frac{y}{w}\frac{\partial w}{\partial y}	+ \frac{1}{4}\left(-\frac{1}{4}-\frac{1}{w}+\frac{y^2}{w^2}\right)\left(\frac{\partial w}{\partial y}\right)^2	+ \frac{1}{2}\frac{\partial^{2} w}{\partial y^2}} \text{.}$$</div>

In this case the total implied variance corresponds to the Black volatility of the pure process (the process without dividend jumps), that is, the Black volatility corresponding to (shifted) market option prices. If the reference data consists of model volatilities for the spot model (with known jumps at dividend dates), the market prices can be obtained by using a good approximation of the spot model, for example [the improved Etore-Gobet expansion of this paper](http://papers.ssrn.com/sol3/papers.cfm?abstract_id=2698283), not with the Black formula directly.

In theory, it should be more robust to work directly with implied variances as there is not the problem of dealing with a very small numerator and denominator of the option prices equivalent formula. In practice, if we rely on one of the Etore-Gobet expansions, it can be much faster to work directly with option prices if we are careful when computing the ratio, as this ratio can be obtained in closed form. In theory as well, we need to use a fine discretisation in time to represent the pure Black equivalent smile accurately. In practice, if we are not too bothered by a mismatch with the true theoretical model, introducing volatility slices just before/at the dividends is enough to reproduce the market prices exactly, as long as we make sure that those obey the option price continuity at the dividend \\(C(S\_0,K,t\_{\alpha}^-) = C(S\_0, K-\alpha,t\_{\alpha}^+)\\). The difference is that the interpolation in time (linear in total variance) is going to describe a slightly different dynamic from the true spot process. The advantage, is that then, it is much faster.

I thought it would be interesting to have a look at the various volatilities. My initial spot volatility is a simple smile constant in time:
{{< figure src="/post/dupire_labordere_ll3_modelvolraw.png" title="Model volatility. Before,At = before the dividend, at the dividend. Log scale for strikes." >}}

Actually it's not all that constant since there is the need to introduce a shift at the dividend date to obey the option price continuity relationship. The pure process model volatility is however constant.
{{< figure src="/post/dupire_labordere_ll3_modelvol.png" title="Pure process model volatility." >}}

The equivalent pure process Black vols looks like this:
{{< figure src="/post/dupire_labordere_ll3_blackvol.png" title="Pure process Black volatility" >}}

Notice how it does not jump at the dividend date, and how the cash dividend results in a lower Black volatility at maturity. The local volatility is:
{{< figure src="/post/dupire_labordere_ll3_localvol.png" title="Dupire Local Volatility under the spot model with jump at dividend date = 3.5" >}}

While the one of the pure process is:
{{< figure src="/post/dupire_labordere_ll3_purelv.png" title="Pure Process Local Volatility under the spot model with jump at dividend date = 3.5" >}}

It falls towards zero for low pure strikes or equivalently near the market strike corresponding to the dividend amount. 

So far, this is not too far from the textbook theory. Now it happens that there is another subtlety related to the dividend policy. The dividend policy defines what happens when the spot price is lower than the cash dividend. Haug, Haug and Lewis defined two policies, liquidator and survivor as

\\(V(S,K,t\_\alpha^-) = V(0,K, t\_\alpha^+) \\) for the liquidator - the stock drops to zero.
\\(V(S,K,t\_\alpha^-) = V(S,K, t\_\alpha^+) \\) for the survivor - the dividend is not paid.

Not applying any particular policy would mean that the stock price can become negative:
\\(V(S,K,t\_\alpha^-) = V(S-\alpha,K, t\_\alpha^+) \\) also when \\( S < \alpha \\).

Which one should we use? The approximation formulae (when not adjusted by the call price at strike 0) actually correspond to the "no dividend policy" rule. It can be verified numerically on extreme scenarios. It appears then natural that the finite difference scheme should also follow the same policy. And the volatility slice after the dividend date is really a constant size shift of the volatility slice just before.

It becomes however more surprising if the model of reference is the liquidator (or the survivor) policy, that is, the market option prices are computed with a nearly exact numerical method according to the liquidator policy. In this case the volatility slice after the dividend date is not merely a constant size shift anymore, as the dividend policy will impact the option price continuity relationship. {{< figure src="/post/dupire_labordere_liquidator_modelvol.png" title="Liquidator model volatility. Before,At = before the dividend, at the dividend. Notice the difference in the BeforeShifted curve compared to the graph with no dividend policy." >}}
It turns out, that then, using the same policy in the FDM scheme at the dividend dates will actually create a bias, while discarding the dividend policy will make the method converge to the correct price. How can this be? My interpretation is that the Dupire local volatility already includes the dividend policy effect, and therefore it should not be taken into account once more in the finite difference scheme dividend jump condition. It is only a partial explanation, since imposing a liquidator policy via the jump condition seems to actually never work with Dupire (on non flat vols), even if the Dupire local volatility does not include the dividend policy effect.
{{< figure src="/post/dupire_labordere_liquidator_localvol.png" title="Dupire Local Volatility under the spot model with liquidator policy and jump at dividend date = 3.5" >}}


Of course, this is not true when the volatility is constant until the option maturity (no smile, no Dupire). In this case, the policy must be enforced via the jump condition in the finite difference scheme. 

Note that this effect is not always simple to see, in my example, it is visible, especially on Put options of low strikes, because the volatility surface wings imply a high volatility when the strike is low and the option maturity is relatively long (5 years). For short maturities or lower volatilities, the dividend policy impact on the price is too small to be noticed.
