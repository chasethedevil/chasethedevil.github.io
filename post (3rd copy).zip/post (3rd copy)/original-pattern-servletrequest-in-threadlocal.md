+++
title = "Original Pattern: ServletRequest in ThreadLocal"
date = 2007-08-02T12:07:00Z
updated = 2008-04-24T13:39:59Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

After seeing <a href="http://www.scala-lang.org/">Scala</a> had elements of Erlang through Actors, I decided to take a closer look at the language. There is an interesting new web framework in Scala, called <a href="http://liftweb.net/"> Lift</a>. One drawback of Lift is that it seems to be very cutting edge and not that easy to grasp. While reading its source code, I stumbled upon a strange pattern: <span style="font-weight: bold;">Storing the ServletRequest in a ThreadLocal </span>.<br><br>I had not seen that before, and was wondering why one would do such a thing. It seems to be unintuitive. I found my answer through... GWT widgets. In <a href="http://gwt-widget.sourceforge.net/?q=node/39"> this page</a>, the author explain motivations behind doing such a thing:<br><blockquote style="border-left: 1px solid rgb(204, 204, 204); margin: 0pt 0pt 0pt 0.8ex; padding-left: 1ex;" class="gmail_quote"><p> While not 100% in tune with the MVC pattern, it is often convenient to access the servlet<br> container, the HTTP session or the current HTTP request from the business layer. The GWT-SL<br> provides several strategies to achieve this which pose a compromise in the amount of configuration<br> required to set up and the class dependencies introduced to the business code. </p> <p> The easiest way to obtain the current HTTP request is by using the <code>ServletUtils</code> class<br> which provides convenience methods for accessing the <code>HttpServletRequest</code> and<br> <code>HttpServletResponse</code> instances. Please note that it makes use of thread local variables<br> and will obviously not return correct values if used in any other than the invoking thread. </p></blockquote><div>Still one can doubt if this is good design. In my long experience of web apps in Java I never had the need to do such a thing. Have you seen that pattern before? <br></div><br> 
