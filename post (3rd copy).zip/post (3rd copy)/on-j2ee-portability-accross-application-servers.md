+++
title = "On J2EE Portability Accross Application Servers"
date = 2005-09-13T16:50:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Brian Alexander Lee <a  href="http://www.prepend.com/2005/09/porting-j2ee-apps-to-websphere.html">wrote</a>:<br> "dismal interview where I asked about the candidate's experience with porting a J2EE application from WebLogic to WebSphere (which was listed on his resume). The candidate said that it was very easy and he just deployed his application with no problems or changes necessary, he had no changes made for the application to run properly. This was one of many bad signs for the candidate."<br> <br> I disagree. I would even use his example to show that the portability game is more about configuration and packaging rather than about anything else so that many developers would in-deed not see a big deal into porting an application to a new application server.<br> <br> You can make a port to Websphere or Weblogic quite transparent if you externalize the JNDI strings (for example in properties file), which is anyway what you should do. Repeating a same string everywhere in your code is bad practice in Java.<br> The most problematic is usually the packaging, weblogic and websphere, for example used to manage the jar dependencies a different way (websphere being very strict, weblogic a bit more practicle). And actually JNDI settings, DataSources and Security should boil down to packaging problems, which is why, I think, your candidate did not know of any problem unless he worked on the packaging of the app.<br> <br> Recruitment is no easy task. I did not find yet a magic formula for it, except maybe, try the person for a month. Personality is more important than knowing technical details. I am not sure if one can see if a person is serious, rigorous, and reasonably fast in an interview.<br>
