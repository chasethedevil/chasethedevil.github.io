+++
categories = []
date = "2016-02-03T16:45:58+01:00"
description = ""
keywords = []
title = "Yahoo Finance Implied Volatility"
+++

The [option chain](https://finance.yahoo.com/q/op?s=GOOG&date=1457049600) on Yahoo finance shows an implied volatility number for each call or put option in the last column.
I was wondering a bit how they computed that number. I did not exactly find out their methodology, especially since we don't even know the daycount convention used, but
I did find that it was likely just garbage.


A red-herring is for example the large discrepancy between put vols and call vols. For example strike 670, call vol=50%, put vol=32%. 
This suggests that the two are completely decoupled, and they use some wrong forward (spot price?) to obtain those numbers. If I compute
the implied volatilities using put-call parity close to the money to find out the implied forward price, I end up with ask vols of 37% and 34% or call and put mid vols of 33%.
By considering the put-call parity, I assume European option prices, which is not correct in this case. It turns out however, that with the low interest rates we live in, there is nearly zero additional value due to the American early exercise.


I am not sure what use people can have of Yahoo implied volatilities.
