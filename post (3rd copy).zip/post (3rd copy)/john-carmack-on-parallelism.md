+++
title = "John Carmack on Parallelism"
date = 2012-04-27T06:40:00Z
updated = 2012-04-27T06:40:36Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

This is the interesting bit "Modify some of your utility object code to return new copies instead of  self-mutating, and try throwing const in front of practically every  non-iterator variable you use".<br />&nbsp; <br />http://www.altdevblogaday.com/2012/04/26/functional-programming-in-c/
