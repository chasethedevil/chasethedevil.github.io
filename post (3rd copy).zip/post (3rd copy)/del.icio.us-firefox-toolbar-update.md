+++
title = "Del.icio.us Firefox Toolbar Update"
date = 2006-03-13T19:45:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I updated my little <a href="http://31416.org/deltoolbar.html">delicious toolbar</a> that provides autosave feature for me. I did not bother reworking the new <a href="http://del.icio.us">delicious</a> extension as I don't use its new functionalities. However people are free to do so if they want with the code from this toolbar.<br /><br /><img alt="deltoolbar screenshot" src="http://photos1.blogger.com/blogger/6384/1303/320/deltoolbar_.jpg" height="403" width="486" /><br /><br />With Firefox 1.5, display of saved documents was not working properly anymore due to a change in Firefox handling of security permissions to view local files. It is fixed now.<br /><span class="technoratitag">Tags: <a href="http://del.icio.us/tag/delicious" rel="tag">delicious</a>, <a href="http://del.icio.us/tag/toolbar" rel="tag">toolbar</a>, <a href="http://del.icio.us/tag/extension" rel="tag">extension</a>, <a href="http://del.icio.us/tag/firefox" rel="tag">firefox</a></span>
