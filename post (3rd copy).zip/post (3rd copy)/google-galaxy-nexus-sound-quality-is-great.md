+++
title = "Google Galaxy Nexus Sound Quality Is Great"
date = 2012-03-27T00:38:00Z
updated = 2012-03-27T00:38:18Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Many people are not enthusiastic of this phone sound if you read silly forums. They are wrong! the sound coming out of this thin phone is amazing, at least with high quality headphones. I find the akg q601 incredible with it: much much better than with the old ipod nano or the cowon i7.<br /><br />In general most complaints i have read about the phone were wrong. The battery is ok, the size is great.
