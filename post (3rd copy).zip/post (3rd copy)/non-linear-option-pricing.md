+++
title = "Non-linear Option Pricing"
date = 2014-04-18T22:18:00Z
updated = 2014-05-14T14:22:17Z
tags = ["quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I am currently reading the book "<a href="http://www.amazon.co.uk/Nonlinear-Pricing-Chapman-Financial-Mathematics/dp/1466570334/ref=sr_1_1?ie=UTF8&amp;qid=1397852099&amp;sr=8-1&amp;keywords=nonlinear+option+pricing" target="_blank">Nonlinear Option Pricing</a>" by J. Guyon and P. Henry-Labordère. It's quite interesting even if the first third is quite theoretical. For example they describe how to solve some not well defined non-linear parabolic PDE by relying on the parabolic envelope. They also explain why most problems lead to parabolic PDEs in finance. <br /><br />The rest is a bit more practical. I stumbled upon an good remark regarding Longstaff-Schwartz: the algorithm as Longstaff and Schwarz describe it does not necessary lead to a low-biased estimate as they use future information (the paths they regress on) in the Monte-Carlo estimate. It was actually <a href="http://chasethedevil.github.io/post/quasi-monte-carlo--longstaff-schwartz-american-option-price/" target="_blank">a subject of discussion</a> with colleagues, and I analyzed the numerical impact in a simple use case in <a href="http://papers.ssrn.com/abstract=2262259">http://papers.ssrn.com/abstract=2262259</a> In short: it's actually more precise to include the path, even if the estimate is not purely low biased anymore, but the bias is really small in practice. <br /><br />On the same subject I was a bit surprised that <a href="http://www.google.com/url?sa=t&amp;rct=j&amp;q=&amp;esrc=s&amp;source=web&amp;cd=1&amp;cad=rja&amp;uact=8&amp;ved=0CCgQFjAA&amp;url=http%3A%2F%2Farxiv.org%2Fabs%2F1404.1180&amp;ei=LYhRU_iZGqWO7Qb9x4HYDQ&amp;usg=AFQjCNGfwQQ-TumcT5nv8gk1BiUCoRn8Qw&amp;sig2=uqPbG7aLjmZ1crAxUYP_FA&amp;bvm=bv.65058239,d.ZGU" target="_blank">a recent paper</a> on American Monte-Carlo regressed systematically on all paths instead of just a subset. One interesting part of the paper is a way to do successive regressions on different blocks of paths.<br /><br />Those details are rarely discussed in papers and books. It was comforting to see that I am not alone to wonder about all this.
