+++
title = "How to Build Good Software? Use a bug management software, really."
date = 2007-04-13T10:56:00Z
updated = 2007-04-13T10:58:51Z
tags = ["howtobuildgoodsoftware"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

This will seem obvious, unfortunately, when people are involved, nothing is that obvious. It's not because you setup a bug/feature management software that people will use it. You have to force people to go through the bug management software each time they want something fixed. If you don't do that some people will keep sending incomplete mails, or worse call you to get something fixed, that will be forgotten in a week. It is also very useful to avoid receiving 10x the same request from the same person.
