+++
title = "Adjoint Delta for Monte-Carlo"
date = 2014-02-25T18:37:00Z
updated = 2014-03-05T12:38:19Z
tags = ["quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

In an earlier post, I have been quickly exploring <a href="http://chasethedevil.github.io/post/adjoint-algorithmic-differentiation-for-black-scholes/">adjoint differentiation</a> in the context of analytical Black-Scholes. Today, I tried to mix it in a simple Black-Scholes Monte-Carlo as described in <a href="http://www.google.com/url?sa=t&amp;rct=j&amp;q=&amp;esrc=s&amp;source=web&amp;cd=1&amp;cad=rja&amp;ved=0CCsQFjAA&amp;url=http%3A%2F%2Fwww.luca-capriotti.net%2Fpdfs%2FFinance%2Fjcf_capriotti_press_web.pdf&amp;ei=rNMMU4_wGKjt0gWQpYGIAQ&amp;usg=AFQjCNFovkw47-Y1WrIKkt-m5FQ1lhmqYA&amp;sig2=vmiqHzd6SJuq5Fp2TlPjdA&amp;bvm=bv.61725948,d.d2k">L. Capriotti paper</a>, and measured the performance to compute delta compared to a numerical single sided finite difference delta.<br /><br />I was a bit surprised that even on a single underlying, without any real optimization, adjoint delta was faster by a factor of nearly 40%. I suspect this is mostly due to exp evaluations being /2.<br /><br />On a basket of 4 assets, the adjoint method was 3.25x faster.<br /><br />It's quick to have such results on basic payoffs: it took me a few hours and worked on the first run, even though my Monte-Carlo is slightly different from the Capriotti paper. It is much more challenging to have it working across a wide variety of payoffs, and to automatize some of it.
