+++
title = "Why did Netscape choose Javascript?!?"
date = 2006-03-09T17:10:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Last year, I have helped building an AJAX web application, where the web client was composed of only one web page and tons of javascript. The 1 web page for a site approach is similar to Gmail and many full AJAX sites. This approach looks quite elegant. Using JSON (and JSON templates) we were able to separated fully presentation logic and business logic and componentization seemed to occur naturally.  <br><br>But I remember how often I complained on how bad Javascript was to code. I find it does not encourage good practices at all. The object orientation of Javascript is really a pain to use. If I had not a small experience with  <a href="http://python.org">Python</a> before, I would have thought scripting languages were really bad at building applications, even not so big ones. I find that even for good programmers, Javascript is a challenge, as it seems to always be a struggle to organize properly your code with it. <br><br>I was recently relieved to see that around me, almost nobody likes Javascript either. It is very sad that Netscape chosed such a bad language in 1995. Firefox appears like a miraculous program to me as a lot of the UI is done in Javascript. <br><br>Ah! If ever it had been Python all the way.<br> 
