+++
title = "Fowler On Your Future: editing the abstract representation of a program"
date = 2005-07-19T12:40:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

This <a href="http://martinfowler.com/articles/languageWorkbench.html">Fowler article</a> on "language workbench" reminds me of <a  href="http://www.artima.com/intv/jackpot.html">Gosling Jackpot</a> ideas: it is about a different interaction with your program where the source code does not matter so much, but its structure. It must be fascinating to work on this kind of project.<br> <br> Maybe MDA sounds similar to you, after all, actual language workbench systems are generating source code. But the fundamental difference is that a workbench generated program is much richer and can capture everything you want to do (MDA is too based on UML to be that powerful), also, the source could disappear and be replaced by byte codes only.<br> <br> Now this all seems very nice, but unfortunately, there are always problems, and Fowler does not miss them: vendor lock-in (not that big of a deal if source is generated), integration with dev tools (especially version control), maturity. It looks like an open source language workbench would help here.<br> <br> It is interesting to see that Intellij (yes, the company behind IDEA) is already well on its way. You can check it out in <a  href="http://martinfowler.com/articles/mpsAgree.html">Fowler examples</a>. His examples are a bit too simple and not very far off rules in rules engines, but the language definition tool does look very neat.<br> <br> As <a href="http://lispm.dyndns.org/news?ID=NEWS-2005-07-08-1">Rainer Joswig</a> shows in his video, LISP seems like a particularly good language to do this. This is hardly surprising since LISP is very near the abstract tree structure and therefore already very used in the AI circles.<br> <br> Tags: <a href="http://technorati.com/tag/java" rel="tag">java</a> <a href="http://technorati.com/tag/programming" rel="tag">programming</a>
