+++
title = "KDE4 Still Not Ready"
date = 2008-01-18T19:08:00Z
updated = 2008-01-18T19:08:20Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I tried KDE4.0 last week, when it was everywhere in the news. I was very disappointed.<br><br>I have a long experience of trying beta software, not well known software. I have used Linux since 1998 (partly). I have even used windows beta at one point. And I have seen nothing as crappy as  KDE4.0 release. <br><br>It is not usable at all. <br><br>Now I can understand what are KDE motivations to do such a bad release. It is to gain momentum in their project. KDE4.0 is in development at least <a href="http://www.advogato.org/person/tjansen/diary.html?start=13"> since 2002</a> - 6 years! By creating a .0 release now even if it is an alpha, they have at least something officially out and hope to have developers starting to improve it. It is especially important for them because Gnome has, in the mean time, made regularly lots of improvements. <br><br>I admire the initiative, KDE 3.5 needed lots of improvements, and KDE4 goals are the right ones. But it just feel like the release was more political than everything else. Hell, <a href="https://lists.linux-foundation.org/pipermail/desktop_architects/2007-February/001129.html"> even Linus seems to use Gnome</a> nowadays. 
