+++
title = "I Need Another DB Framework!"
date = 2005-08-23T19:37:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I am currently facing a problem that neither <a  href="http://www.hibernate.org">Hibernate</a> nor <a  href="http://ibatis.apache.org/">iBatis</a> solves nicely. I also looked at other ORM or just DB framework, without success. <br> <br> What I would need is a framework that generates PreparedStatements with a query by Criteria like API. I have many queries that are similar but varying according to different input parameters. iBatis can handle this, but for complex queries and scenarios, the XML becomes completely unreadable, and you therefore loose any advantage that iBatis was bringing with the externalization of SQL statements in XML. The other issue I have with using iBatis is that for another part of my project, the automatic generation of SQL statements a-la Hibernate is useful.<br> <br> Hibernate has a very nice <a  href="http://www.hibernate.org/hib_docs/v3/reference/en/html/querycriteria.html">Query by Criteria</a> API, but it lacks just a tiny bit of flexibility in customizing queries. For example, I could not find a way to specify a "USE INDEX(index_name)" in the generated SQL, after the SELECT FROM xxx and before the rest of the query. I did not find either a way to specify the use of a "STRAIGHT_JOIN" instead of an INNER JOIN. These are all MySQL specific issues, but those little things are extremely useful at improving some of my queries performances. Writing N sql queries hard coded is not a good option, since this N can be quite big, which is why I am using Query by Criteria in the first place.<br> <br> So is there a need for yet another DB framework?<br>
