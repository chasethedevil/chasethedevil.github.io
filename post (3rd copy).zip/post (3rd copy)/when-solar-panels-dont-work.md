+++
title = "When solar panels don't work"
date = 2012-08-21T21:14:00Z
updated = 2012-08-21T21:14:53Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I thought I would add another word about <a href="http://chasethedevil.github.io/post/keyboard-porn/">keyboard trends</a>. A coworker has bought the <a href="http://search.yahoo.com/r/_ylt=A0oG7hB23TNQAF0AE8FXNyoA;_ylu=X3oDMTE1N201OTNsBHNlYwNzcgRwb3MDMQRjb2xvA2FjMgR2dGlkA1ZJUDEzNF8xOTc-/SIG=12jtgdin3/EXP=1345605110/**http%3a//www.logitech.com/en-us/keyboards/keyboards/k750-keyboard">Logitech K750</a>, the one with solar panels to recharge the battery. This keyboard has excellent reviews on many websites, or even on Amazon. I somehow always found the idea a bit strange, it looked like the old solar panel calculators that used to be trendy when I was in primary school.<br /><br /><div class="separator" style="clear: both; text-align: center;"><a href="http://www.logitech.com/assets/33482/4/logitech-wireless-solar-keyboard-k750-feature-image.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="320" src="http://www.logitech.com/assets/33482/4/logitech-wireless-solar-keyboard-k750-feature-image.png" width="291" /></a></div><br />Well after maybe 6 months of use, he needs to change the battery! It sounds like the solar panels were just a marketing plot after all.<br /><br />
