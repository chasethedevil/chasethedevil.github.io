+++
title = "Tired Of 'My 10 Best XXX' Blog Posts"
date = 2006-03-30T10:32:00Z
updated = 2007-04-05T14:10:39Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++
{{< rawhtml >}}
It's incredible how many posts on popular aggregators are just about a list of stuff, and how except one word they sound the same.<br>Only today on Javaworld, I can read:<br>&quot;<span class="blogentrytitle"><a href="http://javablogs.com/Jump.action?id=262700" title="Read full entry on author's blog"> Ten Things Every Java Developer Should Know About Unix</a>&quot;<br></span><span class="blogentrytitle"><a href="http://javablogs.com/Jump.action?id=262710" title="Read full entry on author's blog">&quot;My 10 Favorite Scripting Languages </a>&quot; <br>&quot;</span><span class="blogentrytitle"><a href="http://javablogs.com/Jump.action?id=262519" title="Read full entry on author's blog">7 Must-Have Programs for Windows&quot;</a><br><br>They all seem to have read the <br>&quot;10 best ways to have your post popular on delicious&quot;<br><br>It's a bit boring.<br> </span>{{< /rawhtml >}}
