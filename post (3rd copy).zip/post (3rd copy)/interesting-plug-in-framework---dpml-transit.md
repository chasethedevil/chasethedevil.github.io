+++
title = "Interesting Plug-In Framework - DPML Transit"
date = 2005-09-29T15:20:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Today, I just found out about <a  href="http://dpml.net/transit/latest/overview.html">DPML Transit</a>, it is a small framework that helps you build plug-ins based software. It seems to work a bit with <a  href="http://dpml.net/magic/latest/index.html">DPML Magic</a>, their build system based upon Ant. Both are quite interesting, since in big projects, you often end up with a packaging per component (which DPML Magic seems to make very simple) and a versioning of those components. DPML Transit allows then for an efficient way to look up a particular version of one component.<br> <br> I have not heard of DPML before, they seem to write useful software. Has anybody used those frameworks already?<br> <br> <span class="technoratitag">Tags: <a href="http://del.icio.us/tag/java"  rel="tag">java</a>, <a href="http://del.icio.us/tag/framework"  rel="tag">framework</a>, <a href="http://del.icio.us/tag/programming"  rel="tag">programming</a></span><br>
