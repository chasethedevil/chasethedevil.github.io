+++
title = "I Get Spring"
date = 2006-08-23T18:04:00Z
updated = 2007-04-05T14:10:12Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

When you google up Java Spring, one of the best results is a post from crazybob called "<a  href="http://crazybob.org/2006/01/i-dont-get-spring.html">I Don't Get Spring</a>". For a long time, I shared a similar opinion. But now that I have used it, I get it. I only use it for defining replaceable services, so when I talk about Spring, I mean spring-core and spring-beans. <br> <br> These two packages are not big, and have only very few dependencies. So it is quite easy to use Spring in any project, be it small or not. It is actually easier than using NanoContainer because Spring has less external dependencies.<br> <br> I did not talk about <a  href="http://www.martinfowler.com/articles/injection.html">Dependency Injection</a> yet, because that was not my primary goal. Many times I had to write by hand configurable factories. By using Spring, I avoid writing all that boilerplate code. I was surprised that with 1 line of code I actually had my factory done. Granted, the config file is xml, an I am not necessarily an xml fan. But 1) it's very simple, and 2) if you don't want your custom factory to depend on all implementations, you will either use strings in your code or a config file, which in the end is no better than Spring config file.<br> <br> Dependency Injection is the big plus that Springs gives on top of it. It's very useful to define your dependencies explicitly in the config file, since all beans instantiated from the config file are instantiated dynamically. And by defining the dependencies, you also get for free the injection.<br> <br> Spring is not big and strange and unknown. It solves a fairly simple problem. But again I don't use it for everything, every class. I don't think it brings much versus straight Java code when you don't want replaceable services. And putting it in places where it is not needed would be dangerous, because of the unneeded xml configuration.
