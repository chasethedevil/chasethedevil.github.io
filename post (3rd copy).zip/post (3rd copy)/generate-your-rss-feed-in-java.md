+++
title = "Generate your RSS feed in Java"
date = 2005-09-05T14:03:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

There are some open source projects that can help you in generating or reading RSS feeds in Java. I found only two libraries a bit mature, other code is often embedded in other open source products (jroller for example):<br /><ul>    <li><a href="http://informa.sourceforge.net/">Informa</a>: Does various RSS formats and Atom 0.3. Documentation is better than its alternative, but less focused (has some hibernate helper thingy, some lucene helper, etc.).<br /></li>   <li><a href="http://sourceforge.net/projects/sandler/">Sandler</a>: There is no working homepage while I am writing this. But the code is of decent quality, supports Atom 0.3 and RSS 1.0. It is easy to use it. However in reality it is not much more than a wrapper around some XML parser specialized in generating an RSS structure or an Atom structure.</li><li>Ooops, I forgot another important one, <a href="https://rome.dev.java.net/">Rome</a>. This RSS/Atom framework with a catchy name is very similar to Informa, has good documentation and good looking code. Under the hood it makes use of jdom.</li> </ul> I personally use <a href="http://dom4j.org/">dom4j</a> since I only need to generate RSS, and RSS, or Atom are just XML. I don't find it particularly verbose to use dom4j for that, and it is very flexible.<br /><br />If you need to parse feeds, then those libraries might make sense and save you a bit of time. For generating, I think their main interest is to abstract you from the differences in formats. So if you need to handle different formats, a framework will allow you to do it through only one API, which can be a big time-saver.<br /><br /><span class="technoratitag">Categories: <a href="http://del.icio.us/tag/java" rel="tag">java</a>, <a href="http://del.icio.us/tag/rss" rel="tag">rss</a>, <a href="http://del.icio.us/tag/atom" rel="tag">atom</a></span>
