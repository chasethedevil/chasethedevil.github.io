+++
title = "Java Compilation Performance / Processor Speed"
date = 2008-07-01T19:50:00Z
updated = 2008-07-01T19:50:13Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I just found out my laptop was faster in default settings than my home desktop to compile a resonably sized project (5 min vs 6 min). I was surprised as I thought the disk in the desktop would make a big difference. The processor in my desktop is not that great (simple pentium e2180). My laptop has a 2ghz core2duo processor. In Ghz processor are of the same speed.<br /><br />I tried to overclock my home pc to see what difference it could make, I made it run at 2.6Ghz instead of the standard 2Ghz. The compilation time dropped to 4.5 min.<br /><br />The ration of processor speed (2.6/2) is almost the same as the ratio of compilation time (6/4.5). I am surprised by such a linearity of behavior.
