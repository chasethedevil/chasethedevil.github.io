+++
categories = ["quant"]
date = "2018-05-27T20:56:42+01:00"
description = ""
keywords = ["quant"]
title = "Implying the Probability Density from Market Option Prices (Part 2)"

+++
This is a follow-up to my posts on the implied risk-neutral density (RND) of the SPW options before and after the big volatility change that happened in early February with two different techniques: 
[a smoothing spline on the implied volatilities](/post/spx500_bets_after_rates_hike/) and a [Gaussian kernel approach](/post/implying-the-probability-density-from-market-option-prices/).

The Gaussian kernel (as well as to some extent the smoothing spline) let us believe that there are multiple modes in the distribution (multiple peaks in the density). In reality,
Gaussian kernel approaches will, by construction, tend to exhibit such modes. It is not so obvious to know if those are real or artificial. There are other ways to apply the Gaussian kernel,
for example by optimizing the nodes locations and the standard deviation of each Gaussian. The resulting density with those is very similar looking.

Following is the risk neutral density implied by nonic polynomial collocation out of the same quotes (Kees and I were looking at robust ways to apply the stochastic collocation):

{{< figure src="/post/rnd_nonic_collocation.png" title="probability density of the SPX implied from 1-month SPW options with stochastic collocation on a nonic polynomial." >}}

There is now just one mode, and the fit in implied volatilities is much better.

{{< figure src="/post/nonic_collocation_vol.png" title="implied volatility of the SPX implied from 1-month SPW options with stochastic collocation on a nonic polynomial." >}}

In a related experiment, [Jherek Healy showed](https://quantsrus.github.io/post/staying-arbitrage-free-with-andreasen-huge-volatility-interpolation/)
 that the Andreasen-Huge arbitrage-free single-step interpolation will lead to a noisy RND. 
[Sebastian Schlenkrich uses](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3150689) a simple regularization to calibrate his own piecewise-linear local volatility approximation
(a Lamperti-transform based approximation instead of the single step PDE approach of Andreasen-Huge).
His Tikhonov regularization consists here in applying a roughness penalty consisting
in the sum of squares of the consecutive local volatility slope differences. This is nearly the same as using the matrix of discrete second derivatives as Tikhonov matrix. The same idea can be found in cubic spline smoothing.
This roughness penalty can be added in the calibration of the Andreasen-Huge piecewise-linear discrete local volatilities and we obtain then a smooth RND:

{{< figure src="/post/rnd_ah_tikhonov.png" title="density of the SPX implied from 1-month SPW options with Andreasen-Huge and Tikhonov regularization." >}}

One difficulty however is to find the appropriate penalty factor \\( \lambda \\). On this example, the optimal penalty factor can be guessed from the L-curve which consists in plotting
the L2 norm of the objective against the L2 norm of the penalty term (without the factor lambda) in log-log scale, see for example [this document](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwjQ28KQ5qjbAhUFWRQKHXIQA2cQFggoMAA&url=https%3A%2F%2Fwww.sintef.no%2Fglobalassets%2Fproject%2Fevitameeting%2F2005%2Flcurve.pdf&usg=AOvVaw18VTDweUhAT0nzDdL2KZtR). Below I plot a closely related function: the log of the penalty (with the lambda factor) divided by the log of the objective, against lambda. The point of highest curvature corresponds to the optimal penalty factor.

{{< figure src="/post/rnd_ah_tikhonov_lcurve.png" title="density of the SPX implied from 1-month SPW options with nodes located at every 2 market strike." >}}

Note that in practice, this requires multiple calibrations the model with different values of the penalty factor, which can be slow.
 Furthermore, from a risk perspective, it will also be challenging to deal with changes in the penalty factor.
 
The error of model versus market implied volatilies is similar to the nonic collocation (not better) even though the shape is less smooth and, a priori, less constrained as,
on this example, the Andreasen-Huge method has 75 free-parameters while the nonic collocation has 9.
