+++
title = "Object Oriented Analysis And Design with Applications Book Review"
date = 2009-01-08T17:24:00Z
updated = 2009-01-08T17:24:35Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

A while ago, I had a comment from someone implying I knew nothing about OO programming because I had not mentioned (and therefore read) <i>Object Oriented Analysis And Design with Applications</i> from G. Booch. I was intrigued by such a silly comment and decided to look at this book that was considered as the bible of OOP. <br> <br>Well, I don&#39;t find it that good! But I don&#39;t find the bible particularly good either. I like <a href="http://archive.eiffel.com/doc/oosc/">B Meyer Object Oriented Software Construction</a> book much more, because it is more practical, more in touch with realities while pointing at the real important problems like: &quot;<b>Real systems have no top</b>&quot;<br> <br>In contrast G Booch book has too much evident concepts that don&#39;t really make you learn anything or think things a different way. It is a good book for someone who is learning OO for the first time. It covers the subject in details, but I did not find anything in it that made me say &quot;wow!&quot;. It is like most other book you can find on OO. Furthermore only the first parts are on OO, the rest is more a UML tutorial.<br> <br> 
