+++
title = "A Very Interesting Feature of Scala"
date = 2010-08-07T12:35:00Z
updated = 2010-08-11T18:27:11Z
tags = ["scala", "java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I tried Scala <a href="http://chasethedevil.blogspot.com/2007/09/fast-web-development-with-scala.html">a few years ago</a>. There are several good ideas in it, but I found the language to be a bit too complicated to master. But I recently stubbled upon <a href="http://lamp.epfl.ch/~dragos/files/scala-spec.pdf">a paper on Scala generics</a>&nbsp;that might change my mind about using Scala.<br /><br />Scala Generics used to work in a similar way as Java Generics: via type erasure. One main reason is compatibility with Java, another is that C++ like templates make the code base blow up. Scala Generics offered some additional behavior (the variance/covariance notion).&nbsp;C++ templates, however, have some very interesting aspects: one is that everything is done at compile time, the other is &nbsp;performance. If the generics are involved in any kind of computation intensive task, all the Java type conversion will create a significant overhead.<br /><br />Now Scala has <b><a href="http://www.scala-lang.org/api/current/scala/specialized.html">@specialized</a></b>&nbsp;(since Scala 2.8). Annotating a generic type with @specialized will generate code. One has the choice to accept the performance penalty or to get all the performance but accept the code blow up. I think this is very useful.<br /><br />If you read the paper you will see that the performance implications of this are not always small.<br /><br />UPDATE: I thank the readers for pointing that this work only with primitive types to avoid autoboxing. It is still valuable but less than I first thought.
