+++
title = "Tired Of Bad Singletons"
date = 2007-01-04T11:50:00Z
updated = 2007-04-05T14:10:12Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

While looking through some code for a project, I saw that:<br><br><blockquote style="border-left: 1px solid rgb(204, 204, 204); margin: 0pt 0pt 0pt 0.8ex; padding-left: 1ex;" class="gmail_quote">&nbsp; public static final ProductYP instance = new ProductYP(); <br>&nbsp; <br>&nbsp; public ProductYP()<br>&nbsp; {<br>&nbsp;&nbsp;&nbsp; if (instance != null)<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; throw new RuntimeException(&quot;Only one instance allowed&quot;);<br><br>&nbsp;&nbsp;&nbsp; prods = new HashMap();<br>&nbsp; }<br><br>&nbsp; public static ProductYP getInstance() <br>&nbsp; {<br>&nbsp;&nbsp;&nbsp; return instance;<br>&nbsp; }<br></blockquote><br>And I don&#39;t think it was done by a newbie... It&#39;s actually not far from being correct, it&#39;s just that the guy obviously does not know about private constructors. I have seen several broken singleton implementations in previous projects and had several debates on the  <a href="http://www.cs.umd.edu/%7Epugh/java/memoryModel/DoubleCheckedLocking.html">double-checked locking pattern</a> (<a href="http://en.wikipedia.org/wiki/Double-checked_locking">it works since JDK1.5</a> with volatiles but is useless). I am upset to see another half broken implementation. Everybody should have read at least  <a href="http://java.sun.com/developer/technicalArticles/Programming/singletons/">this</a>.<br><br>What have you seen as broken singletons?<br><br> 
