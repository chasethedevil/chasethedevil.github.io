+++
title = "Using Linux to Recover Fucked Up Windows Data"
date = 2006-06-01T01:52:00Z
updated = 2007-04-05T14:10:39Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Recently, one of my relatives computer under Windows XP, refused to boot. There was no way of fixing it with Windows Install CD as partition table seemed corrupt to Windows. I tried everything in an 2003 <a href="http://www.ultimatebootcd.com/">Ultimate Boot CD</a>, but nothing worked out. <br/><br/>Someone gave me an install cd of Ubuntu Linux, and it managed to read the data. Well sometimes only. The erratic behaviour was due to a bad ATA cable. This probably was the cause of the corruption in the first place. Anyway with a new cable, Windows was still not able to read its data. But Ubuntu Linux, now working well, was able to, without having anything to configure (except mounting the drive).<br/><br/>So I copied the data, and reformated the NTFS partition, reinstalled Windows, recopied the data. <br/><br/>After this experience, I'd recommend to any Windows user to have a spare Ubuntu Linux Live CD, just in case your Windows corrupts itself.  <br/>
