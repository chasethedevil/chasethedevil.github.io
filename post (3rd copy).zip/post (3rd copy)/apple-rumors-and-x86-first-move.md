+++
title = "Apple Rumors and X86 first move"
date = 2005-11-16T17:59:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I find the mac mini a particularly compelling computer. It is small, noise friendly, relatively cheap. If you want to have a cheap home server (based on Linux or MacOS X), this is quite a good choice as you probably don't want to hear all the fans of bigger computers the whole day. It's also a very good candidate for a media box: you can connect a huge hard drive for mp3s, and watch your DVDs, photos on a nice LCD (and MacOS helps here).<br> <br> Unfortunately it might not be the best moment to buy it now. There are rumors everywhere that the first Mac Intel will be presented in January. And I am quite confident that this Mac Intel will be the Mac Mini. Here are the reasons:<br> <ul>   <li>PowerMacs and iMacs use the quite modern G5 processor. It makes sense to update the very old G4 to Intel first.</li>   <li>if iBook was updated, it would be much more attractive than the Powerbook.</li> </ul> This leaves us with either powerbook upgrade or mac mini upgrade, but:<br> <ul>   <li>XBox 360 has almost arrived. While not a direct competitor, it can be used as media center, it is cheap and powerful. Unfortunately it's not customizable enough.</li>   <li>Powerbooks got a recent update. They are advertised heavily on apple websites, while the mac mini had just a silent and minor upgrade and is not advertised anymore.</li> </ul> <br> <span class="technoratitag">Tags: <a  href="http://del.icio.us/tag/apple" rel="tag">apple</a>, <a  href="http://del.icio.us/tag/mac" rel="tag">mac</a>, <a  href="http://del.icio.us/tag/intel" rel="tag">intel</a>, <a  href="http://del.icio.us/tag/rumors" rel="tag">rumors</a></span><br> <br> <br>
