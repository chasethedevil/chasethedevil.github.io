+++
title = "KDE 4.8 finally has a dock"
date = 2012-01-27T13:38:00Z
updated = 2013-03-21T12:50:27Z
tags = ["linux", "quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

KDE 4.8 finally has a dock: you just have to add the plasma icon tasks. Also the flexibility around ALT+TAB is welcome. With Krusader as file manager, Thunderbird and Firefox for email and web, it is becoming a real nice desktop, but it took a while since the very bad KDE 4.0 release.<br /><br />It is easy to install under ubuntu 11.10 through the backports and seems very stable so far.<br /><br />Something quite important is to tweak the fonts: use Déjà Vu Sans instead of Ubuntu fonts, use RGB subpixel rendering, use Crisp desktop effects. With those settings, KDE looks very nice. It's sad that they are not default in Kubuntu.<br /><br /><b>Update March 2013</b>:<i> It's been a while now that it is in the standard Ubuntu repositories and I believe installed by default, one has just to remove the task manager widget add the icon task widget:</i><br /><div class="separator" style="clear: both; text-align: center;"><a href="http://1.bp.blogspot.com/-_LWYVO4CCKQ/UUry_yhXmQI/AAAAAAAAGSw/JPGByZuWsdw/s1600/snapshot3.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="60" src="http://1.bp.blogspot.com/-_LWYVO4CCKQ/UUry_yhXmQI/AAAAAAAAGSw/JPGByZuWsdw/s400/snapshot3.png" width="400" /></a></div><i>One can also change the settings using a right click (I find useful not to highlight the windows) and it can look like:</i><br /><div class="separator" style="clear: both; text-align: center;"></div><br /><div class="separator" style="clear: both; text-align: center;"><a href="http://3.bp.blogspot.com/-VqpLb8rULAQ/UUrz8cPYleI/AAAAAAAAGTA/fs3b8ytQID8/s1600/snapshot4.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" height="60" src="http://3.bp.blogspot.com/-VqpLb8rULAQ/UUrz8cPYleI/AAAAAAAAGTA/fs3b8ytQID8/s400/snapshot4.png" width="400" /></a></div><br />
