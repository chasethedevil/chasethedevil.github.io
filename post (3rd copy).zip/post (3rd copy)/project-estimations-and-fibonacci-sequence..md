+++
title = "Project Estimations And Fibonacci Sequence."
date = 2007-04-13T13:01:00Z
updated = 2007-04-13T13:01:32Z
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I was recently in a meeting where use case complexity was estimated using numbers in the <a href="http://en.wikipedia.org/wiki/Fibonacci_number">Fibonacci sequence</a>. I was surprised by the choice of the Fibonacci sequence. Why not any sequence? Why a particular one? I googled and found the culprit,  <a href="http://www.mountaingoatsoftware.com/system/hidden_asset/file/15/aep_sample.pdf">Mr Mike Cohn</a>  in his book Agile Estimating and Planning. It&#39;s actually not a bad sequence to choose, since the scale is increasing constantly, so by picking up numbers in this sequence, you can quite accurately describe estimation. If you have defined complexities of 1,2,3,16,17 corresponding to 5 different use cases then obviously 16 or 17 denotes the same complexity, and it would be surprising that you can really distinguish both. You need an ever increasing scale. But a power of 2 scale might not be precise enough (steps are growing too fast). <br><br>Still I think the main reason for him to chose Fibonacci sequence is due to Da Vinci Code, that was just popular at that time in 2004 when he wrote his book. And then this particular series seduces people easily, be it because of the da vinci code book, or because of a mathematical tool that gives the impression our estimations are better, even if there is no real mathematical reason to use it. <br> 
