+++
title = "Social (Web) Revelation: Tags Are Lame"
date = 2007-01-16T10:26:00Z
updated = 2007-04-05T14:10:12Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I had a revelation yesterday while thinking about <a href="http://del.icio.us">del.icio.us</a>, the most well known social bookmarks site. I find out that I almost never use my tags, and I am often not satisfied by results when I search using tags. What use can you make of 100s of tags? in the end only less than 10 are usable to classify very different stuff. And even then compared to a search it&#39;s not a much useful classification. <br><br>If <a href="http://del.icio.us">del.icio.us</a> search engine was decent then I am sure I would never use tags. But their search engine is slow, and does not search much (it sometimes fails to find results on words in titles). <br><br>What is needed is really a social search engine, where you could look things up by user as criteria, and possibly by dates. I googled for it and immediately saw that my &quot;revelation&quot; was quite common. There are several social search engines. There is  <a href="http://cranky.com">cranky</a>, where you can see eventual reviews by some users, added to search results. There is <a href="http://www.eurekster.com/">eurekster</a>, where you can search in any user bookmarks, but you can&#39;t search everybody (how silly). There is  <a href="http://myweb.yahoo.com">Yahoo MyWeb</a>, quite decent if you ignore the presentation and if they added descriptions on results.<br><br>A friend of mine told me that <a href="http://www.furl.net">furl</a>, another social bookmarks site, is more search oriented, but unfortunately a bit slower to use since it keeps a copy of the page you bookmark. <br><br>But still I feel like none of the sites do the right thing, some have too many features, others bad presentation, focusing on useless crap. I actually think that google should have that feature integrated with the common search. I am sure it will in the future, but they seem to be late on the social side of the web. <br><br> 
