+++
title = "My Dream Job"
date = 2006-01-12T11:42:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<img src="file:///C:/Documents%20and%20Settings/flh/Mes%20documents/MSwanson%20-%20Leaf%2002.png" alt=""><br> In my dream job, I would have <span style="font-weight: bold;">freedom </span>to play with and build software based on new ideas I have.<br>  In my dream job, I would work with <span style="font-weight: bold;">creative </span>people, luminaries.<br>  In my dream job, I would have a good enough salary.<br>  In my dream job, I would not have to worry about the company <span style="font-weight: bold;">stability</span>.<br>  In my dream job, I would have freedom in my work schedule.<br>  <br>  Get <span style="font-weight: bold;">paid </span>for doing what you really want (i.e. your ideas) is possible. But without worrying about the next 6 months, I have not seen that. 
