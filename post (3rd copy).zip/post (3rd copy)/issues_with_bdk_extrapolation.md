+++
categories = ["quant"]
date = "2016-10-04T09:55:32+01:00"
description = ""
keywords = ["quant"]
title = "Benaim et al. extrapolation does not work on equities"

+++
We have seen [earlier](/mystic_parabola.md) that a simple parabola allows to capture the smile of AAPL 1m options surprisingly well. For very high and very low strikes,
the parabola does not obey Lee's moments formula (the behavior in the wings needs to be at most linear in variance/log-moneyness).

Extrapolating the volatility smile in the low or high strikes in a smooth \\(C^2\\) fashion is however not easy. 
A surprisingly popular so called "arbitrage-free"
method is the [extrapolation of Benaim, Dodgson and Kainth](http://www.quarchome.org/RiskTailsPaper_v5.pdf) developed to remedy the negative density of SABR in interest rates as 
well as to give more control over the wings.

The call options prices (right wing) are extrapolated as:
$$
C(K) = \frac{1}{K^\nu} e^{a\_R + \frac{b\_R}{K} +  \frac{c\_R}{K^2}} \text{.}
$$
\\(C^2\\) continuity conditions for the right wing at strike \\(K_R\\) lead to:
$$
c\_R =\frac{{C'}\_R}{C\_R}K\_{R}^3+ \frac{1}{2}K\_{R}^2 \left(K\_{R}^2 \left(- \frac{{C'}\_{R}^{2}}{C\_{R}^2}+ \frac{{C''}\_R}{C\_R}\right) + \nu \right)\text{,} \\
$$
$$
b\_R =  - \frac{{C'}\_R}{C\_R} K\_R^2 - \nu K\_R-2 \frac{c\_R}{K\_R}\text{,}\\
$$
$$
a\_R = \log(C\_R)+ \nu \log(K\_R) - \frac{b\_R}{K\_R} - \frac{c\_R}{K\_{R}^2}\text{.}
$$
The \\( \ nu \\) parameters allow to adjust the shape of the extrapolation.

Unfortunately it does not really work for equities. 
Very often, the extrapolation will explode, which is what we wanted to avoid in the first place. We illustrate it here on
our best fit parabola of the AAPL 1m options:
{{< figure src="/post/bdk-explodes.png" title="BDK explodes on AAPL 1m options." >}}

The \\( \nu\\) parameter does not help either.

**Update Dec 5 2016**
Here are details about call option price, slope, curvature:
The strike cutoff is \\(K\_R=115.00001307390328\\). For the parabola, 

$$\begin{align}
C(K\_R)&=0.014516747104643029,\\\\
C'(K\_R)&=-0.002899391065224203,\\\\
C''(K\_R)&=0.000750774042345718.
\end{align}$$

And the BDK parameters for the right wing:

$$a\_R=34.279812, b\_R=-10292.881677, c\_R=737108.461636.$$

For the least squares spline, 
$$\begin{align}
C(K\_R)&=0.03892674300426042,\\\\
C'(K\_R)&=-0.00171386452499034,\\\\
C''(K\_R)&=0.0007835686926501496.
\end{align}$$
which results in
$$a\_R=131.894286, b\_R=-26839.217814, c\_R=1550285.706087.$$

