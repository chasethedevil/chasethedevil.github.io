+++
categories = ["quant"]
date = "2017-12-09T13:56:42+01:00"
description = ""
keywords = ["quant"]
title = "Quantitative Finance Books Citing My Papers"
+++
I would have never really expected that when I started writing papers, but little by little there is a growing list of books citing [my papers](https://papers.ssrn.com/sol3/cf_dev/AbsByAuth.cfm?per_id=1514784):

* [Applied Quantitative Finance for Equity Derivatives](https://www.amazon.com/Applied-Quantitative-Finance-Equity-Derivatives/dp/1977557872/ref=sr_1_1?ie=UTF8&qid=1512751819&sr=8-1&keywords=jherek+healy) by [Jherek Healy](https://jherekhealy.github.io): the most recent book on equity derivatives refers to several of my papers. In contrast with many other books, the author goes beyond and provides additional insights on the papers.
* [Interest Rate Derivatives Explained: Volume 2: Term Structure and Volatility Modelling](https://www.amazon.com/Interest-Rate-Derivatives-Explained-Engineering/dp/1137360186/ref=sr_1_1?ie=UTF8&qid=1512825081&sr=8-1&keywords=Interest+Rate+Derivatives+Explained%3A+Volume+2%3A+Term+Structure+and+Volatility+Modelling) by Jörg Kienitz and Peter Casper. It refers to the paper "finite difference techniques for arbitrage-free SABR", written in collaboration with Gary Kennedy. 
* [Interest Rate Derivatives Explained: Volume 1: Products and Markets](https://www.amazon.com/Interest-Rate-Derivatives-Explained-Engineering/dp/1137360062/ref=sr_1_1?s=books&ie=UTF8&qid=1512824387&sr=1-1) by Jörg Kienitz. It refers to my paper on curve interpolation (there is a mistake in the actual reference given inside the book,about arbitrage-free SABR, which unrelated to the text). I like how this book gives real world market data related to the products considered.
* [Interest Rate Modelling in the Multi-Curve Framework: Foundations, Evolution and Implementation](https://www.amazon.com/Interest-Rate-Modelling-Multi-Curve-Framework/dp/1137374659/ref=sr_1_1?s=books&ie=UTF8&qid=1512825258&sr=1-1&keywords=henrard+interest) by [Marc Henrard](http://multi-curve-framework.blogspot.fr/). It refers to the paper about yield curve interpolation. This is one of the rare books to present curve construction in depth.


There are also some Springer books which are typically a collection of papers on a specific subject (which I find less interesting).

* [Novel Methods in Computational Finance](https://www.amazon.com/Methods-Computational-Finance-Mathematics-Industry/dp/3319612816/ref=sr_1_1?s=books&ie=UTF8&qid=1512825785&sr=1-1&keywords=Novel+Methods+in+Computational+Finance). Jörg Kienitz refers to my paper on arbitrage free SABR in chapter 4.
* [Innovations in Derivatives Markets: Fixed Income Modeling, Valuation Adjustments, Risk Management, and Regulation](https://www.amazon.com/Innovations-Derivatives-Markets-Adjustments-Proceedings/dp/331933445X/ref=sr_1_1?s=books&ie=UTF8&qid=1512825510&sr=1-1&keywords=Innovations+in+Derivatives+Markets). Christian Fries refers to my paper on curve interpolation in chapter 10.
