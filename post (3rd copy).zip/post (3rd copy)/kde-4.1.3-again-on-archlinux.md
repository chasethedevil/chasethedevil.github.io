+++
title = "KDE 4.1.3 (again) on ArchLinux"
date = 2008-11-08T15:54:00Z
updated = 2008-11-08T16:03:02Z
tags = ["linux"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I tried another silly thing with Linux, <a href="http://www.archlinux.org">ArchLinux</a>. The setup is quite rough as you have to edit many config files manually. But if you know a bit your way around it takes only a few hours to have everything running well. The installation manual on the wiki is detailed enough to correct all eventual mistakes humans do.<br /><br />I decided to try once more KDE 4 on it, as at first it was just a silly experiment: I was really not sure ArchLinux would be workable. In the end I am pleasantly surprised, KDE 4.1.3 is way way better than any other versions of KDE I have tried before. It is stable and quite pretty. It took the team a lot of time to get there but now I think KDE 4 is a very good window manager, pleasant to use.<br /><br />It's a big change from older versions which were too unstable/had too few features to be of any use.<br /><br />I am not convinced with ArchLinux compared to Ubuntu. The setup is much more complex, less packages are available. True you learn a bit more with ArchLinux. We will see if it can keep working well for a few years.
