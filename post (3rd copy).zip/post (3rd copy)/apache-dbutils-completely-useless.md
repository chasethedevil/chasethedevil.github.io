+++
title = "Apache DbUtils Completely Useless"
date = 2007-11-02T17:17:00Z
updated = 2008-04-24T13:39:59Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I am disappointed about the Jarkarta Commons DbUtils project. I give a link to it, because it&#39;s a bad project (even if written in clean code). It is very simple, but it really does not do much for you. <br><br>I was looking for a very simple abstraction of JDBC. I thought bringing Spring in my project would be overkill. After trying DbUtils, I think again. It does not help. It does not handle frequent cases well, and it does not save many lines of code. <br><br>I am a bit angry about it as I noticed that by using it, my test program that was taking 2s with straight JDBC before is now using 1 minute!<br><br>The reason behind this huge performance penalty is that there is no way to just reuse a PreparedStatement with the existing classes. For each query with a same sql, it will create a new PreparedStatement object, even if you reuse the connection. I am surprised since this is probably why PreparedStatement is used in the first place. How can such a project be part of Jakarta repository? <br><br>Now I just wish Spring was more Guice like, maybe I should write a Spring JDBC like layer for Guice.<br> 
