+++
title = "Volatility Swap vs Variance Swap Replication - Truncation"
date = 2015-03-16T14:39:00Z
updated = 2015-09-04T21:45:48Z
tags = ["quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

I have looked at <a href="http://chasethedevil.github.io/post/jumps-impact-variance-swap-vs-volatility-swap/">jump effects on volatility vs. variance swaps</a>. There is a similar behavior on tail events, that is, on truncating the replication.<br /><br />One main <a href="http://chasethedevil.blogspot.fr/2015/02/variance-swap-replication-discrete-or.html">problem with discrete replication of variance swaps</a> is the implicit domain truncation, mainly because the variance swap equivalent log payoff is far from being linear in the wings.<br /><br />The equivalent payoff with Carr-Lee for a volatility swap is much more linear in the wings (<a href="http://chasethedevil.blogspot.fr/2013/03/a-volatility-swap-and-straddle.html">not so far of a straddle</a>). So we could expect the replication to be less sensitive to the wings truncation.<br /><br />I have done a simple test on flat 40% volatility:<br /><div class="separator" style="clear: both; text-align: center;"><a href="http://4.bp.blogspot.com/-hxdKaTQrj4w/VQbYgb7IB9I/AAAAAAAAH6o/z2NDk9wtC3w/s1600/Screenshot%2Bfrom%2B2015-03-16%2B14%3A19%3A33.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" src="http://4.bp.blogspot.com/-hxdKaTQrj4w/VQbYgb7IB9I/AAAAAAAAH6o/z2NDk9wtC3w/s1600/Screenshot%2Bfrom%2B2015-03-16%2B14%3A19%3A33.png" height="113" width="320" /></a></div><br /><div class="separator" style="clear: both; text-align: center;"><a href="http://1.bp.blogspot.com/-kv6b3fbejKI/VQbYjGOv3dI/AAAAAAAAH6w/M0YfIZ1WlPc/s1600/Screenshot%2B-%2B03162015%2B-%2B02%3A19%3A47%2BPM.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" src="http://1.bp.blogspot.com/-kv6b3fbejKI/VQbYjGOv3dI/AAAAAAAAH6w/M0YfIZ1WlPc/s1600/Screenshot%2B-%2B03162015%2B-%2B02%3A19%3A47%2BPM.png" height="72" width="320" /></a></div>As expected, the vol swap is much less sensitive, and interestingly, very much like for the jumps, it moves in the opposite direction: the truncated price is higher than the non truncated price.<br /><br />
