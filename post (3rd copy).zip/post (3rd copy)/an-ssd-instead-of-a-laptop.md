+++
title = "An SSD instead of a laptop"
date = 2014-02-04T15:45:00Z
updated = 2014-02-18T09:34:21Z
tags = ["linux"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Last week, my work laptop died after spilling out some water on its keyboard inadvertently. Fortunately, its SSD was intact.<br /><br />As the laptop SSD connector (SATA) and power follow the desktop computers standards, and as I use Linux, I just plugged the SSD to my home desktop and booted off the SSD. I had to change slightly the X configuration but otherwise everything worked. Linux is great for that.<br /><br />The same way, I just plugged the SSD to the desktop at work and it worked. Instead of carrying a laptop, I carry now my small &amp; ultra-light SSD.<br /><br />The experience is so good, that it seems to me it should be an option to everybody. Before, hard drives were very sensitive to travel, but now with SSDs, I don't really see why we should carry a screen and a keyboard unless we use them (for example in a travel). Also I find that I actually notice the speed difference between my desktops and former laptop, which I never really paid too much attention to before.<br /><br />
