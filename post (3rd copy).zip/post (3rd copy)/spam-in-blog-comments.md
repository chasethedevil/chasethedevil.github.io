+++
title = "Spam In Blog Comments"
date = 2005-09-10T01:34:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<p class="mobile-post">I was a victim like many other of spams in comments. It's stupid for people to do that on Blogger.com since the links on comments can not be referenced by search engines (they have some special 'relative'attribute for that) and improve pagerank. </p><p class="mobile-post">Fortunately Blogger.com provides a word verification step if you want to avoid random spam. However I am a bit disappointed that they force Blogger.com users to do that word verification as well. This time I find it stupid from Blogger.com. They have control on their users, so they could ban spamming users, and for everybody else on Blogger.com, this would be just one less step. I am always a bit annoyed at measures that solve a problem caused by a hand of people by making it more annoying for the majority.</p>
