+++
title = "Bilinear Gaussian Lanczos? Downsampling!"
date = 2006-03-17T17:32:00Z
updated = 2007-04-05T14:10:39Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Not easy to choose a downsampling algorithm. Some links:<br><ul><li><a href="http://www.mplayerhq.hu/DOCS/tech/swscaler_methods.txt" target="_blank" onclick="return top.js.OpenExtLink(window,event,this)">mplayer</a>: advises bilinear for quality and describes artifacts for each algo </li><li><a href="http://www.lassekolb.info/gim35_downsampling.htm" target="_blank" onclick="return top.js.OpenExtLink(window,event,this)"> a blogger</a>: advises lanczos. This links shows pictures produced by each algo.<br></li><li><a href="http://www.cambridgeincolour.com/tutorials/image-interpolation.htm">digital image interpolation</a>: seems to have a preference for bicubic, what photoshop uses. </li><li><a href="http://forum.videohelp.com/viewtopic.php?t=295115">videohelp</a>: tested various algorithms and think <span class="postbody">Bicubic spline is the best.</span></li></ul>People don't seem to agree. If you want to check the theory: <br><ul><li><a href="http://en.wikipedia.org/wiki/Bilinear_interpolation">wikipedia lanczos<br>   </a></li><li><a href="http://en.wikipedia.org/wiki/Bilinear_interpolation">wikipedia bilinear</a></li></ul><br><br>  
