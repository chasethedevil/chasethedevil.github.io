+++
title = "Variance Swap Replication : Discrete or Continuous?"
date = 2015-02-19T18:45:00Z
updated = 2015-02-24T13:51:11Z
tags = ["quant"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

People regularly believe that Variance swaps need to be priced by discrete replication, because the market trades only a discrete set of options.<br /><div class="separator" style="clear: both; text-align: center;"><a href="http://1.bp.blogspot.com/-9dEW7QRFa7k/VOYguM8BHOI/AAAAAAAAH0Q/RPFxCeyq6nU/s1600/Screenshot%2B-%2B190215%2B-%2B18%3A36%3A26.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" src="http://1.bp.blogspot.com/-9dEW7QRFa7k/VOYguM8BHOI/AAAAAAAAH0Q/RPFxCeyq6nU/s1600/Screenshot%2B-%2B190215%2B-%2B18%3A36%3A26.png" height="340" width="640" /></a></div><br />In reality, a discrete replication will misrepresent the tail, and can be quite arbitrary. It looks like the discrete replication as described in <a href="http://bfi.cl/papers/Derman%201999%20-%20More%20about%20Variance%20Swaps.pdf">Derman Goldman Sachs paper</a> is in everybody's mind, probably because it's easy to grasp. Strangely, it looks like most forget the section "Practical problems with replication" on p27 of his paper, where you can understand that discrete replication is not all that practical.<br /><br />Reflecting on all of this, I noticed it was possible to create more accurate discrete replications easily, and that those can have vastly different hedging weights. It is a much better idea to just replicate the log payoff continuously with a decent model for interpolation and extrapolation and imply the hedge from the greeks.<br /><br />I wrote <a href="http://papers.ssrn.com/sol3/papers.cfm?abstract_id=2567398">a small paper around this here</a>.
