+++
title = "Portlets in an AJAX World"
date = 2005-11-29T16:29:00Z
updated = 2007-04-05T14:11:06Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Recently, I have had my first encounter with <a href="http://developers.sun.com/prodtech/portalserver/reference/techart/jsr168/">Portlets</a> although Portlets are not very new. IBM had their own Portlet API before the JSR 168 was final in 2003. Unfortunately both approaches are quite different and IBM does not recommend the use of their own API.<br> <br> Portlets were a needed concept for a long time. I worked in 2000 on a java portal system and it would have been handy at that time. Portals are everywhere since the internet bubble. <br> <br> But Portlets do not do that much either. Sites designed with strict and intelligent rules can bypass the portlets need for example by using a combination of custom tags and java beans.<br> <br> What shocks me a bit more is that while not doing much, it looks a bit old fashioned already. With AJAX you could build very flexible and user-friendly Portlets replacement. This AJAX-let is actually probably what Microsoft has already done on their <a href="http://www.start.com/">start.com</a> web site. Now with AJAX, I just wish Javascript would evolve (a lot) or die to be more OO friendly.<br> <br> <br> <br> <br> 
