+++
title = "Diffusion Limited Aggregation Applet"
date = 2010-06-09T14:05:00Z
updated = 2010-06-09T14:05:36Z
tags = ["java", "math"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Yes, I wrote an applet. I know it is very 1990s but, amazingly, it still does the job quite well. Ok, next time I should really use Flash to do this.<br /><br /><div class="separator" style="clear: both; text-align: center;"><a href="http://1.bp.blogspot.com/_9RyqGT46Fbk/TA-C4-xEq8I/AAAAAAAAFH8/OwEFEpO4eA8/s1600/dla.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" src="http://1.bp.blogspot.com/_9RyqGT46Fbk/TA-C4-xEq8I/AAAAAAAAFH8/OwEFEpO4eA8/s320/dla.png" /></a></div><br />The Applet simulates <a href="http://en.wikipedia.org/wiki/Diffusion-limited_aggregation">Diffusion Limited Aggregation</a> as described in Chaos And Fractals from Peitgen, Juergens, and Saupe. It represents ions randomly wandering around (in a Brownian motion) until they are caught by an attractive force in electrochemical deposition experiment. This kind of phenomenon occurs at all scales, for example it happens in the distribution of galaxies. You can play around with the applet at <a href="http://31416.appspot.com/dla.vm">http://31416.appspot.com/dla.vm</a>
