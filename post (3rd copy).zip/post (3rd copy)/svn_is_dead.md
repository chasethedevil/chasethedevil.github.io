+++
categories = ["programming"]
date = "2017-09-26T23:56:42+01:00"
description = ""
keywords = ["programming"]
title = "SVN is dead"

+++
A few years ago, when [Git](https://git-scm.com/) was rising fast and [SVN](https://subversion.apache.org/) was already not hype anymore, a friend thought that SVN was for many organizations better suited than Git, with the following classical arguments, which were sound at the time:

1. Who needs decentralization for a small team or a small company working together?
2. ‎SVN is proven, works well and is simple to use and put in place.

Each argument is in reality not so strong. It becomes clear now that Git is much more established.

Regarding the first argument, a long time ago some people had trouble with CVS as it introduced the idea of merging instead of locking files. Git represents a similar paradigm shift between the centralized and the decentralized. It can scare people in not so rational ways. You could lock files with CVS as you did with visual sourcesafe or any other crappy old source control system. It's just that people favored merges as it was effectively more convenient and more productive. You can also use Git with a centralized workflow. Another more scary paradigm shift with Git is to move away from the idea that branches are separate folders. With Git you just switch branches as it is instantaneous even though, again, you could use it in the old fashioned SVN way.

Now onto the second argument, SVN is proven to work well. But so is Cobol. Today it should be clear that SVN is essentially dead. Most big projects move or have moved to git. Tools work better with Git, even [Eclipse](https://www.eclipse.org/) works natively with Git but requires buggy plugins for SVN. New developers don't know SVN.

I heard other much worse arguments against Git since. For example, some people believed that, with Git, they could lose some of their code changes. This was partially due to sensational news article such as the [Gitlab.com data loss](https://www.theregister.co.uk/2017/02/01/gitlab_data_loss/), where in reality some administrator deleted some directory and had non-working backups. As a result, some Git repositories were deleted, but in reality it's a common data loss situation, unrelated to the use of Git as version control system. This Stackoverflow question gives a nice overview of [data loss risks with Git](https://stackoverflow.com/questions/21048765/what-can-cause-data-loss-in-git).

What I feel is true however is that Git is more complex than SVN, because it is more powerful and more flexible. But if you adopt a simple workflow, it's not necessarily more complicated.
