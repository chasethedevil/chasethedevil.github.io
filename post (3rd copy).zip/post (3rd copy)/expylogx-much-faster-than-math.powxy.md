+++
title = "exp(y*log(x)) Much Faster than Math.pow(x,y)"
date = 2011-04-08T23:03:00Z
updated = 2012-12-12T16:17:10Z
tags = ["quant", "java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

Today I found out that replacing <b>Math.pow(x,y) </b>by <b>Math.exp(y*Math.log(x)) </b>made me gain 50% performance in my program. Of course, both x and y are double in my case. I find this quite surprising, I expected better from Math.pow.
