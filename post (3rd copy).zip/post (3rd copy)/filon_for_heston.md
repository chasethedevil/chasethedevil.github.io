+++
categories = ["quant"]
date = "2016-05-12T19:08:18+02:00"
description = ""
keywords = ["quant"]
title = "Adaptive Filon quadrature for stochastic volatility models"

+++
A while ago, I have applied a relatively simple adaptive Filon quadrature to the problem of [volatility swap pricing](http://papers.ssrn.com/abstract=2620166). The [Filon quadrature](https://www.google.fr/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwi18brlh9XMAhWIVhoKHdnGA2UQFggdMAA&url=http%3A%2F%2Fwww.ams.org%2Fmcom%2F1968-22-101%2FS0025-5718-1968-0225485-5%2FS0025-5718-1968-0225485-5.pdf&usg=AFQjCNEQvSMm6vOaXIX2MqAJ-GQt79QRiA&sig2=HLHd-rc74qnCuo5yp1Q13A) is an old quadrature from 1928 that allows to integrate oscillatory integrand like \\(f(x)\cos(k x) \\) or \\(f(x)\sin(k x) \\). It turns out that combined with an adaptive Simpson like method, it has many advantages over more generic adaptive quadrature methods like Gauss-Lobatto, which is often used on similar problems.

[Flinn](http://dl.acm.org/citation.cfm?id=321029) derived a similar quadrature, but taking into account the derivative values, which are likely to be easily available on those problems. This produces a even more robust quadrature and of higher convergence order.

I was curious how practical this would be on Heston or other stochastic volatility models with a known characteristic function. It turns out it produces a very competitive performance-wise and very stable option pricing method: it can be up to **five times faster** than an adaptive Gauss-Lobatto within a calibration. I found it faster and more robust than the Cos method (especially as it is quite tricky to guess properly the truncation of the Cos method).

If you are interested, you will find much more details in [this document](/lefloch_heston_filon.pdf).


