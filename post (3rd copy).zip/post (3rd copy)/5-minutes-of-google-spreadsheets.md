+++
title = "5 Minutes of Google Spreadsheets"
date = 2006-08-17T12:10:00Z
updated = 2007-04-05T14:10:12Z
tags = ["java"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

{{< rawhtml >}}
<p class="mobile-post">Today I noticed a Google Spreadsheets link in my gmail screen. I had read about it but never bothered to try before. In the finance industry, a lot of traders use excel, so I was wondering if Google spreadsheets could be another fit. </p><p class="mobile-post">Unfortunately for Google, under Linux at least, I don't find Google Spreadsheets usable for anything else than storing and sharing some information, not often updated. Although I admire the engineers that managed to write the Javascript behind Google Spreasheet, it is way too slow for using it in interesting ways. Editing is slow, copy/paste is slow, sorting is slow. </p><p class="mobile-post">I then wondered if it could read my contacts CSV from GMail (you can export contacts to a CSV file in Gmail). It could be a better interface to edit contacts. But strangely, importing Gmail CSV in Google Spreadsheets does not work.</p><p class="mobile-post">I don't think I'll use it another 5 more minutes.</p>{{< /rawhtml >}}
