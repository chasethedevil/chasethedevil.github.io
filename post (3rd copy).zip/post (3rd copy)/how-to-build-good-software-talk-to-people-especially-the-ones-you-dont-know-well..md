+++
title = "How to Build Good Software? Talk to people, especially the ones you don't know well."
date = 2007-04-06T17:02:00Z
updated = 2007-04-06T17:04:29Z
tags = ["howtobuildgoodsoftware"]
blogimport = true 
[author]
	name = "Fabien"
	uri = "https://www.blogger.com/profile/07288327695801480778"
+++

<p>Someone modified a simple launch script on a integration machine. This pissed off the author of the script. Why?</p> <p>Just because the guy who modified the script never worked before with the author of the script. If only the author had been notified verbally or by mail of the modification, he would have been happy. Furthermore this would increase the quality of the change since the new guy might have made a change that has other impacts, that the author will best evaluate quickly.</p>
